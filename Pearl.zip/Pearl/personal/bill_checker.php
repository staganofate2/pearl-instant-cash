<?php
include'connect.php';

$query="select* from bill where status='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
  while($x=mysqli_fetch_array($se)){
 
$id=$x['bill_id'];
$account=$x['account_no'];
$phone=$x['phone'];
	$amount=$x['amount'];
	$name=$x['name'];
	$name=urlencode($name);
	$type=$x['types'];
	$cnumber=$x['cnumber'];
	$invoice=$x['invoice'];
	$id=$x['billtwo_id'];
	$number=$x['numbers'];
$amount=$amount.".00";

if($type=="startimes"){

$http="https://mobileairtimeng.com/httpapi/startimes?userid=08107302391&pass=912363232d306466ae2a1&phone=$phone&amt=$amount&smartno=$number&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){
	$query="update bill set status='1',sent_date=now() where account_no='$account' and bill_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
							
									
										
										
	}
}
			}else{


$http="https://mobileairtimeng.com/httpapi/multichoice?userid=08107302391&pass=912363232d306466ae2a1&phone=$phone&amt=$amount&smartno=$number&customer=$name&invoice=$invoice&billtype=$type&customernumber=$cnumber&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){				
							
		$query="update bill set status='1',sent_date=now() where account_no='$account' and bill_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));								
	}
}

  
  }
  }
}

$query="select* from billtwo where status='0' and rejected='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
      
  while($x=mysqli_fetch_array($se)){
 
$query="select* from paystacktwo where  types_id='".$x['billtwo_id']."' and confirmed='1' and types='Bill'";
 $see=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($see)<1){
      continue;
  }


$account=$x['account_no'];

$phone=$x['phone'];
	$amount=$x['amount'];
	$amount=$amount.".00";
	$name=$x['name'];
	$name=urlencode($name);
	$type=$x['types'];
	$cnumber=$x['cnumber'];
	$invoice=$x['invoice'];
	$id=$x['bill_id'];
	$number=$x['numbers'];


if($type=="startimes"){

$http="https://mobileairtimeng.com/httpapi/startimes?userid=08107302391&pass=912363232d306466ae2a1&phone=$phone&amt=$amount&smartno=$number&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){
	$query="update billtwo set status='1',sent_date=now() where  billtwo_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
							
							
									
										
										
	}
}
			}else{


$http="https://mobileairtimeng.com/httpapi/multichoice?userid=08107302391&pass=912363232d306466ae2a1&phone=$phone&amt=$amount&smartno=$number&customer=$name&invoice=$invoice&billtype=$type&customernumber=$cnumber&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){				
							
									$query="update billtwo set status='1',sent_date=now() where  billtwo_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
										
	}else{
											
										}
}

  
  }
  }
}
?>