<?php
include'connect.php';

$query="select r.account_number as account,r.email_address as email,r.firstname,r.lastname,c.deposit as deposit,r.phone as phone,a.amount,c.loan_id,c.total as total,a.loan_repay_id as ids,date(a.pay_date) as pay_date from  loan_repay a, registeruser r ,loan c where datediff(a.pay_date,'".date("Y-m-d")."')='2' and r.account_number=a.account_no and c.loan_id=a.loan_id and c.collected='1' and a.paid='0' and c.paid='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	  echo mysqli_num_rows($se);
	 while($row=mysqli_fetch_array($se)){
	$id=$row['loan_id'];	 
  $phone=$row['phone'];
   $firstname=$row['firstname'];
 $lastname=$row['lastname'];
  $email=$row['email'];
  $date=$row['pay_date'];
  $total=$row['total'];
 $ids=$row['ids'];
  $deposit=$row['deposit'];
 $amount=$row['amount'];
  $account=$row['account'];
 
   
  $message=" A reminder of your weekly Loan repayment of N $amount on $date. For early fund of wallet  click on this link . https://pearlinstantcash.com/account_deposit.php?acx=$account";
 
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 //echo "done";
	 
 }
  }
?>