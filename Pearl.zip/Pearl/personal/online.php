<?php
 session_start();
 include"connect.php";
$query="select* from onlineusers  where ip!='0' limit 20";

$re=mysqli_query($con,$query)or die(mysqli_error($con));

?>

            <div class="related_post">
			
			<?php
if(mysqli_num_rows($re)<1){
echo "<h4>Non of the staff are online</h4>";
}
else{
	echo "<p>  click  below to begin instant chat with staff</p>";
echo '<ul class="latest_postnav">';
while($row=mysqli_fetch_array($re)){
?>


<li>
	<div class="media"><a href="chat.php?receiver=<?php echo $row['users']?>" class="media-left"><?php echo $row['users']?></a>
 
 </div>
              </li>
			  <?php
}
echo "</ul>";
}
 
?>
 </div>
 