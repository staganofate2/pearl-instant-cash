<?php
include"header.php";
include"modal_box.php"; 
$bar="index";
?>


<style>
  /* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add an active class to highlight the current page */
.active {
    background-color: #4CAF50;
    color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
    display: none;
} 
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}
@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive a.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
.gallery ul li{
	max-width:30%;
	
	border:solid;
	list-style:none;
	
}
.clears{
	clear:both
}
.gallery a img{
	
	width:22%;
	margin:10px 5px;
	
}
#clear{clear:both;
}
#x{
	border-bottom: solid 1px white;
}
#x .div{
	float:left;
	border:solid 2px #FF8C00;
	border-radius:4px;
	margin-bottom:10px;
	background:gray;
	padding:2px;
}
#wallet{
	color:lime;font-size:110%;
	margin-right:20%;
	
}
#wallet2{
	color:lime;font-size:110%;
	margin-right:20%;
	border:solid;
}
#wallet strong{
	color:white;
}
 </style>
 <script>

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
} 


 
</script>

<?php

include"sidebar.php";
?>
		
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main"  id='main'>
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header" style='color:pink'><?php echo $row['firstname']." ".$row['middlename']." ".$row['lastname']; ?></h2>
				
			</div>
		</div><!--/.row-->
		<div id='x'>
		<div id='wallet' class='div'>Wallet ID : <strong><?php echo $row['account_number'] ?></strong></div><div class='div' style='color:lime;width:200px;' id='wallet2'>Wallet Balance:   <b style='color:white'>₦  <?php $query="select total from wallet where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				$ve=mysqli_fetch_array($res);  echo $ve['total'] ?></b></div>
		
		<div id='clear'></div>
		
		</div>
		
		<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-8">
		<div class='gallery'>
		<a href='../wallet/recharge.php'><img src='../images/p1.jpg' alt='mtn recharge'></a>
			<a href='../wallet/bill.php'><img src='../images/p2.jpg' alt=''></a>
			<a href='../wallet/sms.php'><img src='../images/p3.jpg' alt=''></a>
			<a href='../wallet/tranfer.php'><img src='../images/p4.jpg' alt='9mobile'></a>
			<a href='../wallet/data.php'><img src='../images/p5.jpg' alt='glo data'></a>
			<a href='../wallet/wallettransfer.php'><img src='../images/p6.jpg' alt='mtn data'></a>
			<a href='../wallet/deposit.php'><img src='../images/p7.jpg' alt='9mobile data'></a>
			<a href='#' id="myAnchor"><img src='../images/p8.jpg' alt='Electricity Bill'></a>
			<a href='../wallet/withdraw.php'><img src='../images/p9.jpg' alt='dstv'></a>
			<a href='../loan/loan.php'><img src='../images/p10.jpg' alt='Loan Application'></a>
			
			
			<div class='clear'></div>
			</div>
		</div>
		
		</div>
		<?php include "footer.php"; ?>
		<script>
		var y=document.getElementById("myAnchor");
		
		y.addEventListener("click", function(event){
  event.preventDefault();
  alert("The Feature is Coming soon");
});

		
		</script>
	