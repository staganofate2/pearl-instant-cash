<?php
include'connect.php';

$query="select* from datas where status='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
  while($e=mysqli_fetch_array($se)){
 
$id=$e['datas_id'];
$account=$e['account_no'];

$phone=$e['phone'];
echo	$amount=$e['amount'];
	$phone=$e['phone'];
	$code=$e['code'];
	
	
	
	
$http="https://mobileairtimeng.com/httpapi/datatopup.php?userid=08107302391&pass=912363232d306466ae2a1&network=$code&phone=$phone&amt=$amount&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['code']=="100"){
							
									
echo$query="update datas set status='1',sent_date=now(),total='$amount' where account_no='$account' and datas_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

							
}
}
	}
	
	
	
  }
      
  
$query="select* from datas where status='0' and rejected='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
  while($e=mysqli_fetch_array($se)){
 $query="select* from paystacktwo where  types_id='".$x['datas_id']."' and confirmed='1' and types='Data'";
 $see=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($see)<1){
      continue;
  }
$id=$e['rechargetwo_id'];


$phone=$e['phone'];
	$amount=$e['amount'];
	$phone=$e['phone'];
	$code=$e['code'];
	$id=$e['datastwo_id'];
	
	$amount=$amount."00";
	
	$http="https://mobileairtimeng.com/httpapi/datatopup.php?userid=08107302391&pass=912363232d306466ae2a1&network=$code&phone=$phone&amt=$amount&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 // print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
							
									
$query="update rechargetwo set status='1',sent_date=now() where datastwo_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

							
}
}
	}
	
	
	
  }
      
?>