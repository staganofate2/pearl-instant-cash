<?php
session_start();
include"connect.php";
$mont=$_POST['month'];
    $query="select link from refer where account_no='{$_SESSION['account']}'";
	$result=mysqli_query($con,$query) or die(mysqli_error($con));
    if(mysqli_num_rows($result)>0){
		echo "exist";
	}else{
		$query="insert into refer (link,account_no,regdate) values('$mont','{$_SESSION['account']}',now())";
		mysqli_query($con,$query) or die(mysqli_error($con));
		echo "done";
	}

	?>