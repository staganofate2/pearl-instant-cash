<?php
session_start();

if (isset($_POST["label"])) {
    $label = $_POST["label"];


 $fileName = $_FILES["file"]["name"];
 $fileTmpLoc = $_FILES["file"]["tmp_name"];
list($width, $height) = getimagesize($fileTmpLoc);
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		
		
	$db_file_name="userphoto/$db_file_name";
	$db_file_name2="../$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_name2 );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}

			 echo $db_file_name;
        }
    }
 else {
    echo "Invalid file";
}

}

?>