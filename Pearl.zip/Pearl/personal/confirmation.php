<?php
include"header.php";
$bar="";
?>
		
		
		<?php
		include "sidebar.php";
		
		$method=htmlspecialchars($_GET['method']);
		$confirm_id=htmlspecialchars($_GET['confirm_id']);
		?>
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">confirmation</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			<?php if(isset($_POST['submit'])){
				$bank=$_POST['bank'];
				$payment_date=$_POST['payment_date'];
				$depositor_name=$_POST['depositor_name'];
				$phone=$_POST['phone'];
				$amount=$_POST['amount'];
				$amount=str_replace(",","",$amount);
				$query="update deposit set bank='$bank',confirmed='1',payment_date='$payment_date',phone='$phone',amount='$amount',depositor_name='$depositor_name' where deposit_id='$confirm_id'";
				mysqli_query($con,$query)or die(mysqli_error($con));
				
				if(isset($_POST['transfer'])){
				$transfer=$_POST['transfer'];
				$query="update deposit set transfer='$transfer' where deposit_id='$confirm_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
				}
				if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["files"])) {
 $fileTmpLoc = $_FILES["files"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["files"]["name"]);
$extension = end($temp);
if ((($_FILES["files"]["type"] == "image/gif")
|| ($_FILES["files"]["type"] == "image/jpeg")
|| ($_FILES["files"]["type"] == "image/jpg")
|| ($_FILES["files"]["type"] == "image/pjpeg")
|| ($_FILES["files"]["type"] == "image/x-png")
|| ($_FILES["files"]["type"] == "image/png"))
&& ($_FILES["files"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["files"]["error"] > 0) {
        echo "Return Code: " . $_FILES["files"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		$db_file_namee="userphoto/$db_file_name";
	$db_file_names="../userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_names;
	$resized_file = $db_file_names;
	$wmax = 400;
	$hmax = 400 ;                                                                                                                                                                                                                                          00;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		$query="update deposit set upload='$db_file_namee' where deposit_id='$confirm_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	$query="insert into uploads(account_no,purpose,image,regdate) values('{$_SESSION['account']}','Deposit Confirmation','$db_file_namee',now())";
	mysqli_query($con,$query) or die(mysqli_error($con));
	
		
			
        }
    }
 else {
    echo "Invalid file";
}
}



				echo "<br><br><br><h3>Thank You for Patronage</h3><p>We Credit Your Account as soon as we Verify Your Payment</p>";
				$query="update deposit set confirmed='1' where deposit_id='$confirm_id' and account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
			}
			else{
				?>
			   
				<h4 class="page-header"> Deposit Confirmation</h4>
				
				<p>Hi, <?php echo $row['firstname']." .. Please Fill in  Your  Payment details and Submit";  ?>
				</p>
				
								<div class="col-md-8">
				<form action="" method="POST" enctype="multipart/form-data"> 
				<table class="table">
				<tr>
				<td>Bank Name</td>
				<td><input class="form-control"  name="bank"  type="text" ></td>
				</tr>
				
				<?php if($method=="Transfer"){
					?>
				
				<td>Account Name for the Transfer</td>
				<td><input class="form-control"  name="transfer"  type="text" ></td>
				</tr>
					<?php
				}
					?>
					<tr>
				
				
					<td>Date of Payment</td>
				<td><input class="form-control"  name="payment_date"  type="text" placeholder="20/12/2018"></td>
				</tr>
				<td>Depositor Name</td>
				<td><input class="form-control"  name="depositor_name"  type="text" ></td>
				</tr>
				
				<tr>
				<td>Depositor Phone</td>
				<td><input class="form-control"  name="phone"  type="text" ></td>
				
				</tr>
				<tr>
				<td>Amount</td>
				<td><input class="form-control"  name="amount"  type="text" onkeyup="this.value = numFormat(this.value)" ></td>
				
				</tr>
				
				<tr>
				<td>Upload Evidence of Payment</td>
				<td><img src="../images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="files" id="ufile5" accept="image/*" onchange="loadFile(event)" required="" /><br></td>
				
				</tr>
				
				
				
				
				</table>

				<input type="submit" class="btn btn-info " value="SUBMIT" name="submit"> <br>
				</div>
				<?php
			}
			?>
				
				
		<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
  </script>
  
  
  <style>
                                                     *{
	                                                              margin:0;
	                                                                 padding:0;
                                                                                  }
																				  
#outputpix,#outputpix2{
	width:50%;
	height:130px;
	border-radius:20px;
	margin:10px;
}																				  
  </style>  
  <?php include "footer.php"; ?>