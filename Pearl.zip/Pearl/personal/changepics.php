<?php
include"header.php";
include"modal_box.php"; 
$bar="changepics";



?>

		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Change Profile Picture</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h3 class="page-header">Change Profile Picture</h3>
				
				
								<div class="col-md-4">
								<?php
			 
				 if (isset($_POST['change'])){

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["files"])) {
 $fileTmpLoc = $_FILES["files"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["files"]["name"]);
$extension = end($temp);
if ((($_FILES["files"]["type"] == "image/gif")
|| ($_FILES["files"]["type"] == "image/jpeg")
|| ($_FILES["files"]["type"] == "image/jpg")
|| ($_FILES["files"]["type"] == "image/pjpeg")
|| ($_FILES["files"]["type"] == "image/x-png")
|| ($_FILES["files"]["type"] == "image/png"))
&& ($_FILES["files"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["files"]["error"] > 0) {
        echo "Return Code: " . $_FILES["files"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	
	$db_file_names="../userphoto/$db_file_name";
	$db_file_name="userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_names;
	$resized_file = $db_file_names;
	$wmax = 400;
	$hmax = 400 ;                                                                                                                                                                                                                                          00;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		$query="update registeruser set picture='$db_file_name' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo"<h3>Profile picture changed succesfullly</h3>";

				 }
}
}
				 }else{
?>
				<form action="" method="POST" enctype="multipart/form-data">

				
							
							<div class="form-group">
							<p>Select Your Profile Picture *</p>
			<img src="../images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="files" id="ufile5" accept="image/*" onchange="loadFile(event)" required="" /><br>
			
							</div>
							<div class="form-group">
							
							<button class="btn btn-info" name="change" type="submit">Save</button>
				
				
				
				</form>
				
				<?php
				 }
				 ?>
				
				</div>
				
				
				
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };

	function submitForm1() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo1"));
            fd.append("label", "WEBUPLOAD");
			document.getElementById("button1").value="Uploading ...";
            $.ajax({
              url: "upload.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                
                alert(data);
				$('#outputpix1').attr('src',data);
				document.getElementById("button1").value="Upload";
				
				
            });
            return false;
        }
		
		function closediv(id){
			
			document.getElementById(id).innerHTML="";
		}
		function sendval(action,value,but,rs,change){
			
		var val=document.getElementById(value).value;
var but=document.getElementById(but);

var v=but.textContent;

but.textContent="Please Wait...";
but.style.disabled=true;
if(val==""){
	document.getElementById(value).placeholder="Please type something !";
	return false;
}
ajax.open("POST", "updater.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
document.getElementById(rs).innerHTML = ajax.responseText;

}
if(ajax.responseText){
	document.getElementById(change).innerHTML=val;
but.style.disabled=false;
but.textContent=ajax.responseText;

}
}

ajax.send("action="+action+"&value="+val);	
			
		}
		
		function spass() {

var pass =document.getElementById('pass2').value;
var reg=document.getElementById("savepass").style.color;
if(reg=="red"){
	return false;
}
if(pass==""){
	document.getElementById("pass2").placeholder="password can not be empty";
	return false;
}
var RequestObj = document.getElementById("passresult");
ajax.open("POST","check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;
document.getElementById('passres').innerHTML="";
}

}
ajax.send("action=save&pass="+pass);
}
function sendpass() {

var pass =document.getElementById('pass1').value;
var reg=document.getElementById('savepass');
var RequestObj = document.getElementById("rs");
ajax.open("POST", "check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;

}
if(ajax.responseText=="password not correct"){
reg.style.disabled=true;
reg.style.color="red";
}else{
reg.style.color="white";	
}
}

ajax.send("action=check&pass="+pass);
}
function checkpass (){
var pass1=document.getElementById('pass2').value;
var pass2=document.getElementById('pass3').value;
var reg=document.getElementById('savepass');

if(pass1 !== pass2){
document.getElementById('res').innerHTML = "Password do not match";

reg.style.disabled=true;
reg.style.color="red";

}
else{
	reg.style.disabled=false;
	document.getElementById('res').innerHTML = "matched";
	reg.style.color="white";
}
}

		</script>
		
		<?php include "footer.php"; ?>