<?php 
session_start() ;
include"connect.php";
$receiver=$_POST['receiver'];

 
  
  $query2="select m.message_id,con.conversation_id,con.contype,con.userone,con.usertwo,m.message,m.image,m.mdate,m.sender from message m inner join conversation con using(conversation_id)where con.userone='$receiver' and con.usertwo='{$_SESSION['account']}' or con.userone='{$_SESSION['account']}' and con.usertwo='$receiver'" ;
 $result5=mysqli_query($con,$query2)or die(mysqli_error($con));
 if(mysqli_num_rows($result5)==0){
 echo "There is no conversation yet Between you and ".$receiver;
 }
 else{
 echo "<table class='table' >";
while($row= mysqli_fetch_array($result5)){
	$query="select picture from registeruser where account_number='".$row['sender']."'";
	$x=mysqli_query($con,$query)or die(mysqli_error($con));
	$y=mysqli_fetch_array($x);
if($row['sender']==$receiver){
echo "<tr><td id='lt'><b style='color:brown;margin-left:10px' >".$row['sender']."</b><br><div style='background:#DCDCDC;border:solid white;padding:3px 10px;border-radius:15px;color:green;margin-left:30px;max-width:200px;'><p>"; if($row['image']!=""){?><img src='../".$row['image']."' alt='' width='120px' height='100px'><?php 
} echo "</p>".$row['message']."</div></td></tr>";
}else {
echo "<tr><td id='rt' align='right'><b style='margin:10px;color:blue'>".$row['sender']."</b><br><div style='background:#F0FFFF;border:solid white;padding:3px 10px;border-radius:15px;color:gold;margin-right:30px;max-width:200px;text-align:left'><p>"; if($row['image']!=""){?><img src='../".$row['image']."' alt='' width='120px' height='100px'><?php 
} echo "</p>".$row['message']."</div></td></tr>";
}
 $query="update message set red='1' where message_id='".$row['message_id']."' and sender !='{$_SESSION['account']}'";
 mysqli_query($con,$query)or die(mysqli_error($con));
}
echo "</table>";
 }

?>
