<?php
session_start();
include'connect.php';
$banks=array("044"=>"Access Bank","023"=>"Citibank Nigeria","063"=> "Access Bank (Diamond) Bank","050"=>"Ecobank Nigeria","084"=>"Enterprise Bank","070"=>"Fidelity Bank","011"=>"First Bank of Nigeria","214"=>"First City Monument Bank","058"=>"Guaranty Trust Bank","030"=>"Heritage Bank","082"=>"Keystone Bank","014"=>"MainStreet Bank","076"=>"Polaris(Skye) Bank","221"=>"Stanbic IBTC Bank","068"=>"Standard Chartered Bank","232"=>"Sterling Bank","032"=>"Union Bank of Nigeria","033"=>"United Bank For Africa","215"=>"Unity Bank","035"=>"Wema Bank","057"=>"Zenith Bank","other"=>"Others");	

$bank_name=$_POST['bank_name'];
$account_number=$_POST['account_number'];
$account_name=$_POST['account_name'];
$bank=$banks[$bank_name];
$query="insert into account_confirm (bank,account_name,account_number,postdate) values('$bank','$account_name','$account_number',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
	
	$query = "select* from bank_info where  account_no='{$_SESSION['account']}'";
								$result = mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($result)>0){
									$rows=mysqli_fetch_array($result);
									if($rows['account_number']==$account_number){
								echo $email_err="Account number already exists";
								
								}
								elseif($rows['account_name']==$account_name){
								
							
									
								$query="update bank_info set account_name='$account_name',account_number='$account_number',bank_name='$bank',code='$bank_name' where account_no='{$_SESSION['account']}'";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
								
										exit();
										echo "<h3>Bank Account Info added Successfully</h3>";
									}else{
										echo "<h3>different account name is not allowed</h3>";
									}
									}else{
									$query="insert into bank_info (account_name,account_number,bank_name,account_no,code) values('$account_name','$account_number','$bank','{$_SESSION['account']}','$bank_name')";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							
										
										echo "done";
										exit();
										
									}
?>