<?php
session_start();
include"connect.php";
$query="select m.sender as sender, m.message as message,m.message_id as id , m.red as red,m.mdate as date from message m  ,conversation c  where case when c.userone='{$_SESSION['account']}' then c.usertwo ='system' when c.usertwo='{$_SESSION['account']}' then c.userone='system' end and c.conversation_id=m.conversation_id and (c.usertwo='{$_SESSION['account']}' or c.userone='{$_SESSION['account']}') limit 20 ";
$res=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($res)<1){

echo"<h4>You have no message  yet</h4>";

}
else{
	
	echo "<h4>MESSAGES</h4>";
	echo "<div id='messages_inner'>";



	
while($row=mysqli_fetch_array($res)){
if($row['sender']==$_SESSION['account']){continue;}else{if($row['red']=="0"){  $count++;?><a href="chat.php?id=<?php echo $row['id']; ?>&receiver=<?php echo $row['sender'] ;?>"><div <?php echo "class='unread'"; ?>><b style='color:blue'> <?php echo $row['sender']."</b>   <span style='color:red'>on ".$row['date']."</span> <br><p style='color:black;margin-left:30px'>".$row['message']."</p></div></a>";}} 
}

}

echo "</div>";



?>