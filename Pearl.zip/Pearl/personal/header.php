<?php
session_start();
if(!isset($_SESSION['account'])){
	echo "<script>window.location='../login.php'</script>";
}
//include "session.php";
include"connect.php";
$query="select* from registeruser where account_number='{$_SESSION['account']}'";
$de=mysqli_query($con,$query)or die(mysqli_error($con));
$row=mysqli_fetch_array($de);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PEARL USER Dashboard</title>
	<link href="../user/css/bootstrap.min.css" rel="stylesheet">
	<link href="../user/css/font-awesome.min.css" rel="stylesheet">
	<link href="../user/css/datepicker3.css" rel="stylesheet">
	<link href="../user/css/styles.css" rel="stylesheet">
	
	<style>
  /* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
	
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add an active class to highlight the current page */
.active {
    background-color: #4CAF50;
    color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
    display: none;
} 
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}
@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive a.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
 </style>
 <script>

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
} 
function popitup(url) {
      
	   newwindow=window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=400,left=400,width=600,height=500"); 
       if (window.focus) {newwindow.focus()}
       return false;
     }
	 
	 function myFunctions() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
} 
</script>
</head>


<!------------------------top nav------------------------------------------------>
<body>


	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation"style='background:blue;' >
		<div class="container-fluid">
			<div class="navbar-header" >
				
				
					<!--<ul class="nav navbar-nav" class="navbar-left" id='mainav'>
					 
						<li class='active'><a href="personal/" >PERSONAL INFORMATION</a></li>
						<li><a href="account/" class="scroll active">Login Account</a></li> 
						 
						<li><a href="invest/" class="scroll">Pearl Invest</a></li>  
                      						
						<li><a href="loan/" class="scroll">Pearl Loan</a></li>    
						  
						
							</ul>  
						-->
						
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
						<!--<div class="topnav" id="myTopnav" style='background:blue;'>
  <!--<a href="../personal/"  class="active">Personal Information</a>
  <a href="../account/">Account</a>
  <a href="../invest/">Pearl Invest</a>
  <a href="../loan/">Pearl Loan</a>
  <a href="../food/">Pearl Food Store</a>
  <a href="../wallet/">My Wallet</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>-->

	<?php $query="select phone from ph_confirm where phone='".$row['phone']."' and confirmed='0'";
				$de=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($de)>0){
					echo"<a href='../personal/phone_conf.php'>Confirm Your Phone Number</a>";
				}
		?>
				<ul class="nav navbar-top-links navbar-right">
					<?php
$query="select*  from deposit where  confirmed='0' and rejected='0' and account_no='{$_SESSION['account']}'";$result=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($result)>0){
	?>
	
						

<li class="parent" ><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> <b style='background:red;color:white'> Confirm <?php  echo mysqli_num_rows($result)?>  Deposit(s) <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></b></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					
			<?php
	while($rowss=mysqli_fetch_array($result)){
	?><li><a href="../personal/confirmation.php?confirm_id=<?php echo $rowss['deposit_id']?>&method=<?php echo $rowss['method'] ?>">Confirm Your <?php echo $rowss['amount'] ?> Deposit </a></li>

						<?php 
						}
						echo "</ul>	</li>";
			
						
}
?>
						<li class="dropdown" id='messagee'><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span id='mee'class="label label-danger"></span>
					</a>
						
					</li>
					<li class="dropdown" id='notify'><a class="dropdown-toggle count-info"  href="../personal/notification.php">
						<em class="fa fa-bell"></em><span id='noo'class="label label-info"></span>
					</a>
						
					</li>
				</ul>

				<!--</div> -->
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		<script>
		
	var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
		function loadstuff(){

$('document').ready(function(){$("#mee").load('message_alert.php');});
$('document').ready(function(){$("#noo").load('notification_alert.php');});

 
function updatemessage(){
		
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatemessage.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {

			
			
				
				 document.getElementById("messagee").innerHTML +=ajax.responseText;
				 
			
		}
	}
	ajax.send();
 
 }
 updatemessage();

}

setInterval(loadstuff,5000);
</script>