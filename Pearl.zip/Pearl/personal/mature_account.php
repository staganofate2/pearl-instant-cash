<?php
include'connect.php';

$query="select* from  account   where maturity_date='".date("Y-m-d")."' and active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
 echo mysqli_num_rows($se);
 if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
		 
 $percent=$row['account_interest'];
 $amount=$row['amount'];
 $percent=str_replace("%,","",$percent);
 $total=($amount*$percent)/100;
  $query="update account set interest='$total' where maturity_date='".date("Y-m-d")."' and active='0' and account_id='".$row['account_id']."'";
 mysqli_query($con,$query) or die(mysqli_error($con));
 $query="update account set active='1' where maturity_date='".date("Y-m-d")."' and active='0' and account_id='".$row['account_id']."' ";
 mysqli_query($con,$query) or die(mysqli_error($con));
	 }
 }
 
 $query="select* from  food   where maturity_date='".date("Y-m-d")."' and active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
 //echo mysqli_num_rows($se);
 if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
		 
 
 $query="update food set active='1' where maturity_date='".date("Y-m-d")."' and active='0' and food_id='".$row['food_id']."' ";
 mysqli_query($con,$query) or die(mysqli_error($con));
	 }
 }
 
$query="select* from  investment   where   active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
 //echo mysqli_num_rows($se);
 if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
		 
  $amount=$row['amount'];
  $duration=$row['duration'];
  
 $duration=str_replace("Months","",$duration);
 echo $duration;
 $total=($amount*10)/100;
 for($i=0;$i<$duration;$i++){
	 $x=$i+1;
	 if(date("Y-m-d", strtotime(" -$x months"))==$row['start_date']){
		  $query="select interest from investment where active='0' and investment_id='".$row['investment_id']."'";
 $f=mysqli_query($con,$query) or die(mysqli_error($con));
 $d=mysqli_fetch_array($f);
 $totals=$d['interest']+$total;

		 $query="update investment set interest='$totals' where   active='0' and investment_id='".$row['investment_id']."'";
 mysqli_query($con,$query) or die(mysqli_error($con));
 	
	 
	 
 }
 
 
	 }
	  if($row['maturity_date']==date("Y-m-d")){
		 echo"nofate";
 $query="update investment set active='1' where  active='0' and investment_id='".$row['investment_id']."' ";
// mysqli_query($con,$query) or die(mysqli_error($con));
	 }
 }
 }
 
?>