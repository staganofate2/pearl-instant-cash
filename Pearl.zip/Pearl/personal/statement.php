<?php
include "header.php";
include"modal_box.php"; 
$bar="statement";

?>



		
		
		<!-------------------------------------the side nav bar here-------------------------------------->
		
		<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			
				<img src="../<?php echo $row['picture'] ?>" class="img-responsive" style="height:180px; width:90%;" alt="PEARL user picture"><!--------------------user picture here----------------->
			
			
			<div class="clear"></div>

		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li ><a href="info.php"><em class="fa fa-dashboard">&nbsp;</em> Reg Info</a></li>
			<li><a href="changepass.php"><em class="fa fa-calendar">&nbsp;</em> Change Password</a></li>
			<li><a href="details.php"><em class="fa fa-bar-chart">&nbsp;</em> Account Details</a></li>
			<li><a href="chat.php"><em class="fa fa-toggle-off">&nbsp;</em>Chat Online</a></li>
			<li><a href="bankinfo.php"><em class="fa fa-clone">&nbsp;</em> Bank A/C Info</a></li>
			<li><a href="order.php"><em class="fa fa-clone">&nbsp;</em>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
			Standing Order</a></li>
			<li><a href="link.php"><em class="fa fa-clone">&nbsp;</em>Introducer Link</a></li>
			<li><a href="myuploads.php"><em class="fa fa-clone">&nbsp;</em> Upploads</a></li>
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout <?php echo $row['lastname'];  ?></a></li>
		</ul>
	</div><!--/.sidebar-->
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account Statement</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Account Statement</h2>
				<p><strong><?php echo $last;  ?>, this is your Account statement in View</strong></p>
				
			</div>
		</div><!--/.row--><hr>
		
		<div class="row">
			
			
			 <div class="col-lg-12 ">
                        
						
						<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Account Summary</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
										<th>Transaction Date</th>
                                            <th>Ref No</th>
                                            <th>Description</th>
                                            <th>Debit</th>
											<th>Credit</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
									$acct=$_SESSION['acctnumber'];	
	$mysqli1="select * from transact where account_number='$acct' ";
	$myquery1=mysqli_query($con,$mysqli1) or die(mysqli_error());
		while($row2 = mysqli_fetch_object($myquery1)){

?>				
									
                                        <tr class="info">
										 <td><?php echo @$row2->transaction_date;   ?></td>
                                            <td><?php echo @$row2->refno;   ?></td>
                                            <td><?php echo @$row2->description;   ?></td>
                                            <td><?php echo @$row2->debit;   ?></td>
											 <td><?php echo @$row2->credit;   ?></td>
                                            
		</tr> <?php  }  ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
						
						
						
                       
                    </div>
			
			
			
			
			
		</div><!--/.row-->
		
		
		
		<div class="col-sm-12">
				<p class="">© 2017 E-Banking. Designed by <a href="../index.php">Global Bank Offshore</a></p>
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
		
</body>
</html>