<?php
include'connect.php';

$query="select r.phone as phone,r.firstname,r.lastname,r.email_address as email,a.amount as amount,c.account_no as account,c.account_id as id,a.account_pay_id as pid,c.account_type as name from  account_pay a, registeruser r ,account c where a.pay_date='".date("Y-m-d")."' and r.account_number=a.account_no and c.account_id=a.account_id and a.paid='0' and c.active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
 echo mysqli_num_rows($se);
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
	     
	     $account=$row['account'];
	     $id=$row['id'];
	     $amount=$row['amount'];
		  $pid=$row['pid'];
  $phone=$row['phone'];
  $firstname=$row['firstname'];
 $lastname=$row['lastname'];
  $email=$row['email'];
  $name=$row['name'];
 $querys="select amount,deposit_id from deposit where  paid='0' and account_no='$account' and authorize='1' ";
$p=mysqli_query($con,$querys)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
        $ref =rand(100000000,999999999);
        $quee="select* from wallet where  account_no='$account'";
$resx=mysqli_query($con,$quee)or die(mysqli_error($con));
$rowsa=mysqli_fetch_array($resx);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rowsa['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rowsa['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));

$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rowsa['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rowsa['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Zenith"){
		if($amountt>=100000){
			$bonus=($amountt*5)/100;
		 	$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}
        
        
    }
}

 $query="select* from account_pay where  account_no='$account' and account_pay_id='$pid' and paid='0'";
$reo=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($reo)>0){
$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$roww=mysqli_fetch_array($res);
if($roww['total']>=$amount){
	

	
	$amounts=$roww['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from account where account_no='$account' and account_id='$id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update account set start_date=date('".date("Y-m-d")."') where account_no='$account' and account_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update account set amount='$am',wallet='$am' where account_no='$account' and account_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update account_pay set paid='1',paid_date='".date("Y-m-d")."' where account_no='$account' and account_pay_id='$pid'";
mysqli_query($con,$query) or die(mysqli_error($con));

$ref =rand(100000000,999999999);
$description="$amount was credited into your $actype Account";
$query="insert into account_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,account_id) values('Account','$account','$amount','','$am','$ref','$description','".date("Y-m-d")."','$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Account Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Account','$account','','$amount','$amounts','$ref','$description','".date("Y-m-d")."','$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account' ";
	mysqli_query($con,$query) or die(mysqli_error($con));

}

$message="Your $name Account contribution payment for today ".date("Y-m-d")." Have been Paid";
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 
}
 
}
	 }
 }
?>
<?php

$query="select r.phone as phone,r.firstname,r.lastname,r.email_address as email,r.account_number as account,a.amount as amount,c.account_no as food,c.food_id as id,a.food_pay_id as pid,c.package_name as name from  food_pay a, registeruser r ,food c where a.pay_date='".date("Y-m-d")."' and r.account_number=a.account_no and c.food_id=a.food_id and a.paid='0' and c.active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
	     
	     $account=$row['account'];
	     $id=$row['id'];
	     $amount=$row['amount'];
		 echo $pid=$row['pid'];
  $phone=$row['phone'];
  $firstname=$row['firstname'];
 $lastname=$row['lastname'];
  $email=$row['email'];
  $name=$row['name'];
 $querys="select amount,deposit_id from deposit where  paid='0' and account_no='$account' and authorize='1' ";
$p=mysqli_query($con,$querys)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
        $ref =rand(100000000,999999999);
        $quee="select* from wallet where  account_no='$account'";
$resx=mysqli_query($con,$quee)or die(mysqli_error($con));
$rowsa=mysqli_fetch_array($resx);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rowsa['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rowsa['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));	
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rowsa['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
		$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));	
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rowsa['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rowsa['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rowsa['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Zenith"){
		if($amountt>=100000){
			$bonus=($amountt*5)/100;
		 	$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message','".date("Y-m-d")."','Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}
        
        
    }
}
$query="select* from food_pay where  account_no='$account' and food_pay_id='$pid' and paid='0'";
$reo=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($reo)>0){
$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$roww=mysqli_fetch_array($res);
if($roww['total']>=$amount){
	



	
	$amounts=$roww['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from food where account_no='$account' and food_id='$id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update food set start_date=date('".date("Y-m-d")."') where account_no='$account' and food_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update food set amount='$am',wallet='$am' where account_no='$account' and food_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update food_pay set paid='1',paid_date='".date("Y-m-d")."' where account_no='$account' and food_pay_id='$pid'";
mysqli_query($con,$query) or die(mysqli_error($con));

$ref =rand(100000000,999999999);
$description="$amount was credited into your $actype Food Account";
$query="insert into food_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,food_id) values('Food','$account','$amount','','$am','$ref','$description','".date("Y-m-d")."','$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Food Account Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Food','$account','','$amount','$amounts','$ref','$description','".date("Y-m-d")."','$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account' ";
	mysqli_query($con,$query) or die(mysqli_error($con));

}



 
 $message="Your $name Food contribution payment  for today ". date("Y-m-d")." have been paid";
 $messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
print_r($resp);
	 
	 }
	 }
 }
  }
?>