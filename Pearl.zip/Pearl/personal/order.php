<?php
include"header.php";
include"modal_box.php"; 
$bar="order";
?>
		
		<?php include "sidebar.php"; ?>
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">order</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">standing order</h4>
				
				
				
								<div class="col-md-8">
								<?php $query="select* from standing where account_no='{$_SESSION['account']}'";
								$de=mysqli_query($con,$query)or die(mysqli_error($con));
								if(mysqli_num_rows($de)>0){
									echo '<table class="table">
				<tr>
				<th>Type</th>
				<th>Title</th><th></th><th>Message</th><th>Date</th>
				</tr>';
									while($rows=mysqli_fetch_array($de)){
										?>
				
				
				
				<tr>
				<td><?php echo $rows['types'] ?></td>
				<td><?php echo $rows['subject']?></td><td>  <?php if($rows['image']!=''){?>
				<img  width='300px' height='100px' class='zooms'src='../<?php echo $rows['image']; ?>' alt=''> <?php
				} 
				?></td><td> <?php echo $rows['message'] ?></td><td><?php echo  $rows['regdate']; ?></td>
				
				</tr>
				
				
				<?php 
				
									}
									
				echo "</table>";
								}else{
									echo "<h3> No Order Message yet</h3>";
								}

				?>
				</div>
				
				<?php include "footer.php"; ?>