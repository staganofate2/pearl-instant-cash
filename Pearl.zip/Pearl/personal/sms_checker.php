<?php
include'connect.php';

$query="select* from sms where status='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
  while($e=mysqli_fetch_array($se)){
 
$message=$e['message'];

$phone=$e['phone'];
$sender=$e['sender'];

	$id=$e['sms_id'];
	
	
	
		$message=urlencode($message);				


 $http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);


if(strstr( $resp,"OK" )!=""){
							
									

$query="update sms set status='1',sent_date=now(),total='$amount' where  and sms_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

										
}								
									
	}
	}
	
	
	
  
      
$query="select* from smstwo where status='0' and rejected='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
  while($e=mysqli_fetch_array($se)){
      $query="select* from paystacktwo where  types_id='".$x['smstwo_id']."' and confirmed='1' and types='SMS'";
 $see=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($see)<1){
      continue;
  }
 
$message=$e['message'];

$phone=$e['phone'];
	
	$sender=$e['sender'];

	$id=$e['sms_id'];
	
	
	
		$message=urlencode($message);				


 $http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);


if(strstr( $resp,"OK" )!=""){
							
									

$query="update sms set status='1',sent_date=now() where  and sms_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

										
}								
									
	}
	}
?>