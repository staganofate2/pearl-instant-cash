<?php
session_start();
include_once"connect.php";
$sql = "SELECT* FROM notification WHERE account_no='{$_SESSION['account']}' AND red = '0' order by id desc";
	$query = mysqli_query($con,$sql)or die(mysqli_error($con));
	$numrows = mysqli_num_rows($query);
    if ($numrows >0) {
		$row=mysqli_fetch_array($query);
		echo '<ul class="dropdown-menu dropdown-alerts">';
		?>
		
		<li><a href="../personal/notification.php">
								<div><em class=""><?php echo $row['purpose'] ?></em>
									<span class="pull-right text-muted small"><?php echo $row['message'] ?></span></div>
							</a></li>
							</ul>
		<?php
	}
?>