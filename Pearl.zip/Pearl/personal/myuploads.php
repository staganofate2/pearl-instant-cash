<?php
include"header.php";
include"modal_box.php"; 
$bar="myuploads";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Personal Information</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">My Uploads</h4>
				
				<p>Hi, <?php echo$row['firstname']." .. This is Your Uploads";  ?>
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				
				<tr>
				<th>Purpose</th>
				<th>Image</th>
				<th>Date of Upload</th>
				</tr>
				<?php $query="select* from uploads where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
				while($rows=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $rows['purpose']?></td>
				<td><img src="../<?php echo $rows['image']; ?>" class='zooms' height='120px' width='120px'></td>
				<td><?php echo $rows['regdate']?></td>
				</tr>
				<?php
				}
				}
				?>
				
				
				
				
				</table>

				
				</div>
				
				
				<?php include "footer.php"; ?>