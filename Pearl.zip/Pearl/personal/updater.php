<?php
session_start();
include"db.php";

if(isset($_POST['action']) && $_POST['action']=="fname"){
$name=mysqli_real_escape_string($db,$_POST['value']);
$query="update users set fname='$name' where username='{$_SESSION['username']}'";
mysqli_query($db,$query)or die(mysqli_error($db));
echo "First Name changed";
exit();
}

if(isset($_POST['action']) && $_POST['action']=="lname"){
$name=mysqli_real_escape_string($db,$_POST['value']);
$query="update users set lname='$name' where username='{$_SESSION['username']}'";
mysqli_query($db,$query)or die(mysqli_error($db));
echo "Last Name changed";
exit();
}

if(isset($_POST['action']) && $_POST['action']=="email"){
$name=mysqli_real_escape_string($db,$_POST['value']);
$query="update users set email='$name' where username='{$_SESSION['username']}'";
mysqli_query($db,$query)or die(mysqli_error($db));
echo "Email changed";
exit();
}
if(isset($_POST['action']) && $_POST['action']=="phone"){
$name=mysqli_real_escape_string($db,$_POST['value']);
$query="update users set phone='$name' where username='{$_SESSION['username']}'";
mysqli_query($db,$query)or die(mysqli_error($db));
echo "Phone changed";
exit();
}

if(isset($_POST['action']) && $_POST['action']=="gender"){
$name=mysqli_real_escape_string($db,$_POST['value']);
$query="update users set gender='$name' where username='{$_SESSION['username']}'";
mysqli_query($db,$query)or die(mysqli_error($db));
echo "Gender changed";
exit();
}
?>