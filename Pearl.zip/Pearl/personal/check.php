<?php
session_start();
include"../db.php";


if(isset($_POST['action']) && $_POST['action']=="check"){

$pass=mysqli_real_escape_string($db,$_POST['pass']);




$query="select users_id from users where users_id='{$_SESSION['users_id']}' and password='$pass' limit 1";
$res=mysqli_query($db,$query)or die(mysqli_error($db));
if(mysqli_num_rows($res)>0){
	echo"correct";

}
else{
echo"password not correct";
}
exit();

}


if(isset($_POST['action']) && $_POST['action']=="save"){

$pass=mysqli_real_escape_string($db,$_POST['pass']);




$query="update users  set password='$pass' where users_id='{$_SESSION['users_id']}' limit 1";
$res=mysqli_query($db,$query)or die(mysqli_error($db));
echo "password changed";
exit();

}
?>