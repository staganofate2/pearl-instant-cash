<?php
include'connect.php';

$query="select r.account_number as account,r.email_address as email,r.firstname,r.lastname,c.deposit as deposit,r.phone as phone,c.loan_id,a.loan_repay_id as ids,a.amount,c.total as total from  loan_repay a, registeruser r ,loan c where a.pay_date < '".date("Y-m-d")."' and r.account_number=a.account_no and c.loan_id=a.loan_id and a.paid='0' and c.collected='1'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
			$id=$row['loan_id']; 
  $phone=$row['phone'];
   $firstname=$row['firstname'];
 $lastname=$row['lastname'];
 $total=$row['total'];
 $ids=$row['ids'];
 $deposit=$row['deposit'];
 $amount=$row['amount'];
  $account=$row['account'];
  $ref =rand(100000000,999999999);
  $email=$row['email'];
  $query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet-$amount;
  if($balance>=0){
	  $query="update loan_repay set paid='1'  , paid_date='".date("Y-m-d")."' where  account_no='$account' and loan_id='".$row['loan_id']."' and loan_repay_id='$ids'";
  mysqli_query($con,$query) or die(mysqli_error($con));
   $message="Your $total Loan  repayment reminder. N $amount has been Debited from Your Wallet for today Loan Repayment. ".date("Y-m-d");
  $dep=$deposit+$amount;
  $query="update loan set deposit='$dep' where   account_no='$account' and loan_id='".$row['loan_id']."' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
  if($dep>=$total){
      $query="update loan set paid='1' where   account_no='$account' and loan_id='$id'" ; 
      mysqli_query($con,$query) or die(mysqli_error($con));
  }
  $query="update wallet set total='$balance' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
  
  $description="$amount was debited  from your Wallet for $total Loan Repayment";
   
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$account','','$amount','$balance','$ref','$description','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$bal=$dep-$total;
$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','$account','','$amount','$bal','$ref','$description','".date("Y-m-d")."','$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
  $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
  }else{
  $query="select authorization_code from paystackloan where account_no='$account' and confirmed='1' and remove='0'";
  
  $see=mysqli_query($con,$query) or die(mysqli_error($con));
  $de=mysqli_fetch_array($see);
  
 $authorization_code=$de['authorization_code'];
 
  $amounts=$amount."00";
//Set other parameters as keys in the $postdata array
$postdata =  array("authorization_code"=>"$authorization_code", "email"=>"$email", "amount"=>"$amounts");
   
$url = "https://api.paystack.co/transaction/charge_authorization";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  
 print_r($x);
if($x['data']['status']=="success"){
	
	
  $query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet+$amount;
  
      $query="update wallet set total='$balance' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="insert into deposit  (ref_no,amount,total,method,confirmed,confirm,authorize,regdate,account_no,category) values('$ref','$amount','$amount','Instant','1','1','1','".date("Y-m-d")."','$account','Wallet')";
mysqli_query($con,$query)or die(mysqli_error($con));


$description="$amount was Credited to your Wallet Account  for Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$account','$amount','','$balance','$ref','$description','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
 $dep=$deposit+$amount;
  
  $query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet-$amount;
    $query="update wallet set total='$balance' where account_no='$account'";
  mysqli_query($con,$query) or die(mysqli_error($con));
  
   $query="update loan_repay set paid='1' , paid_date='".date("Y-m-d")."' where  account_no='$account' and loan_id='".$row['loan_id']."' and loan_repay_id='$ids'";
  mysqli_query($con,$query) or die(mysqli_error($con));
   $message="Your $total Loan  repayment reminder. N $amount has been Debited from Your Wallet for today Loan Repayment. ".date("Y-m-d");
 
  $query="update loan set deposit='$dep' where   account_no='$account' and loan_id='".$row['loan_id']."' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
  if($dep>=$total){
      $query="update loan set paid='1' where   account_no='$account' and loan_id='".$row['loan_id']."' "; 
      mysqli_query($con,$query) or die(mysqli_error($con));
      $query="select phone, firstname, lastname from registeruser where account_number='$account'";
$d=mysqli_query($con,$query) or die(mysqli_error($con));
$rowx=mysqli_fetch_array($d);
$phone=$rowx['phone'];
 
  $name=$rowx['firstname']." ".$rowx['lastname'];
 

 
 $message=" Congratulations $name !. Your $total Loan has been completed. You are free to apply for another loan.";
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
  }
  

 
  $description="$amount was debited  from your Wallet for $total Loan Repayment";
  $message2="$amount was debited  from your Wallet for $total Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$account','','$amount','$balance','$ref','$description','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$bal=$dep-$total;
$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','$account','','$amount','$bal','$ref','$description','".date("Y-m-d")."','".$row['loan_id']."')";
mysqli_query($con,$query) or die(mysqli_error($con));


$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
  

  
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 //echo "done";

   
   
 
  
  
  $messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message2</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
  
	$message=urlencode($message2);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
}
}
  }
  
  
  
	 
	 }
 }
?>