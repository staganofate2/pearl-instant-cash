<?php
include'connect.php';

 $query="select r.phone as phone,a.amount as amount,c.account_no as account,c.account_id as id,a.account_pay_id as pid,c.account_type as name from  account_pay a, registeruser r ,account c where a.pay_date='".date("Y-m-d")."' and r.account_number=a.account_no and c.account_id=a.account_id and a.paid='0' and c.active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
 echo mysqli_num_rows($se);
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
	     
	     $account=$row['account'];
	     $id=$row['id'];
	     $amount=$row['amount'];
		  $pid=$row['pid'];
  $phone=$row['phone'];
 
  $name=$row['name'];
 
$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$roww=mysqli_fetch_array($res);
if($roww['total']>=$amount){
	

	
	$amounts=$roww['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from account where account_no='$account' and account_id='$id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update account set start_date=date(now()) where account_no='$account' and account_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update account set amount='$am',wallet='$am' where account_no='$account' and account_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update account_pay set paid='1',paid_date=now() where account_no='$account' and account_pay_id='$pid'";
mysqli_query($con,$query) or die(mysqli_error($con));

$ref =rand(100000000,999999999);
$description="$amount was credited into your $actype Account";
$query="insert into account_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,account_id) values('Account','$account','$amount','','$am','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Account Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Account','$account','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account' ";
	mysqli_query($con,$query) or die(mysqli_error($con));

}

$message="Your $name Account contribution payment for today ".date("Y-m-d")." Have been Paid";;
$message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 
}
 
 
	 }
 }
    


$query="select r.phone as phone,r.account_number as account,a.amount as amount,c.account_no as food,c.food_id as id,a.food_pay_id as pid,c.package_name as name from  food_pay a, registeruser r ,food c where a.pay_date='".date("Y-m-d")."' and r.account_number=a.account_no and c.food_id=a.food_id and a.paid='0' and c.active='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
 echo mysqli_num_rows($se);
 echo mysqli_num_rows($se);
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
	     
	     $account=$row['account'];
	     $id=$row['id'];
	     $amount=$row['amount'];
		 echo $pid=$row['pid'];
  $phone=$row['phone'];
 
  $name=$row['name'];
 
$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$roww=mysqli_fetch_array($res);
if($roww['total']>=$amount){
	



	
	$amounts=$roww['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from food where account_no='$account' and food_id='$id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update food set start_date=date(now()) where account_no='$account' and food_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update food set amount='$am',wallet='$am' where account_no='$account' and food_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update food_pay set paid='1',paid_date=now() where account_no='$account' and food_pay_id='$pid'";
mysqli_query($con,$query) or die(mysqli_error($con));

$ref =rand(100000000,999999999);
$description="$amount was credited into your $actype Food Account";
$query="insert into food_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,food_id) values('Food','$account','$amount','','$am','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Food Account Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Food','$account','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account' ";
	mysqli_query($con,$query) or die(mysqli_error($con));

}

$message="Your $name Food contribution payment  for today ".date("Y-m-d")." have been paid";
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
}
 
 
	 
	 }
 }
?>