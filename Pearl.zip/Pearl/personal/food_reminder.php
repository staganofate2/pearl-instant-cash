<?php
include'connect.php';

$query="select r.phone as phone,c.package_name as name from  food_pay a, registeruser r ,food c where a.pay_date='".date("Y-m-d")."' and r.account_number=a.account_no and c.food_id=a.food_id and a.paid='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
		 
  $phone=$row['phone'];
 
  $name=$row['name'];
 $message="Your $name Food Account contribution payment reminder for today ".date("Y-m-d");
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 
	 }
 }
?>