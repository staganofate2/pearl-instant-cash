<?php
session_start();
include"connect.php";

$query="select b.first_name,b.last_name,b.bvn,b.dob as do,b.account_no,r.firstname,r.lastname,r.dob from bvn b ,registeruser r ,bank_info i where r.account_number=b.account_no and i.account_no=b.account_no and i.bvn=''";
$s=mysqli_query($con,$query) or die(mysqli_error($con));
echo mysqli_num_rows($s);
if(mysqli_num_rows($s)){
while($d=mysqli_fetch_array($s)){
	
	$first_name=  $d['first_name'];
	$last_name=$d['last_name'];
	$dob=$d['do'];
	echo $account=$d['account_no'];
		$bvn=$d['bvn'];
	$firstname=$d['firstname'];
	$lastname=$d['lastname'];
	$do=$d['dob'];
	if($first_name !=$$firstname || $last_name != $lastname or $last_name!=$firstname || $first_name!=$lastname){
		$query="update registeruser set  firstname='$first',lastname='$last',middlename='$middlename' where account_number='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	if($dob !=$do){
		$query="update registeruser set  dob='$do' where account_number='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	 
		
	}
	$query="update bank_info set bvn='$bvn' where account_no='$account'";
  mysqli_query($con,$query)or die(mysqli_error($con));
	
	}else{
	  
   $query="update bank_info set bvn='$bvn' where account_no='$account'";
  mysqli_query($con,$query)or die(mysqli_error($con));
  

	}							
	}
	


}

?>