<?php
include"connect.php";
$ref =rand(100000,999999);

$query="update ph_confirm set code='$ref' where account_no='{$_SESSION[account']}' and confirmed='0'";
$er=mysqli_query($con,$query) or die(mysqli_error($con));
$message="Confirmation code: $ref";
$query="select phone from registeruser where account_number='{$_SESSION[account']}'";
$se=mysqli_query($con,$query) or die(mysqli_error($con));
$row=mysqli_fetch_array($se);
$phone=$row['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

echo "done";
?>
		