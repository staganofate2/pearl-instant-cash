<?php
session_start();
include_once"connect.php";
$first=mysqli_real_escape_string($con,$_POST['first']);
$last=mysqli_real_escape_string($con,$_POST['last']);
$middlename=mysqli_real_escape_string($con,$_POST['middlename']);

	$query="update registeruser set  firstname='$first',lastname='$last',middlename='$middlename' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo "done";
	exit();
}
?>
	