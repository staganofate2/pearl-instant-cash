	<script src="../user/js/jquery-1.11.1.min.js"></script>
	<script src="../user/js/bootstrap.min.js"></script>
	<script src="../user/js/chart.min.js"></script>
	<script src="../user/js/chart-data.js"></script>
	<script src="../user/js/easypiechart.js"></script>
	<script src="../user/js/easypiechart-data.js"></script>
	<script src="../user/js/bootstrap-datepicker.js"></script>
	<script src="../user/js/custom.js"></script>
	 
		

			<br><br><br><br>
				</div></div>
				
		
		
		</div>
		</div>
		</body>
</html>