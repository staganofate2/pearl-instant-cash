<?php
session_start();
include"connect.php";

$query="select i.account_name,account_no from bvn b ,registeruser r ,bank_info i where r.account_number=b.account_no and i.account_no=b.account_no and r.firstname='' and r.lastname=''";
$s=mysqli_query($con,$query) or die(mysqli_error($con));
echo mysqli_num_rows($s);
if(mysqli_num_rows($s)){
while($d=mysqli_fetch_array($s)){
	$account_names=$d['account_name'];
	$account=$d['account_no'];
	$account_name=str_replace(","," ",$account_names);
	
	$s=explode(" ",$account_name);
//	print_r($s);
	
	 $last=$s[0];
	 $first=$s[1];
	if(count($s)>2){
	@$mid=$s[2];
	}else{
	    $mid="";
	}
	
		$query="update registeruser set firstname='$first',lastname='$last'";
		if($mid!=""){
			$query.=", middlename='$mid' ";
		}
		$query.=" where account_number='$account'";
		mysqli_query($con,$query) or die(mysqli_error($con));
		
						
	}
	


}

?>