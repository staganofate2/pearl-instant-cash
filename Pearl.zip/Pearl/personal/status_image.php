<div id="result" style="border: solid;width:40%;height:400px"></div>
<form method="post" id="fileinfo" name="fileinfo" >
        <label>Select a file:</label><br>
        <input type="file" name="file" required />
        <input type="button" value="Upload" onclick="submitForm()"/>
    </form>



<!--<input type="hidden" name="img" id="fimg">-->

    