<?php
include"header.php";
include"modal_box.php"; 
$bar="order";
?>
		
		<?php include "sidebar.php"; ?>
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">tickets</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">My Tickets</h4>
				
				
				
								<div class="col-md-12">
								<?php $query="select* from ticket where account_no='{$_SESSION['account']}' order by ticket_id desc";
								$de=mysqli_query($con,$query)or die(mysqli_error($con));
								if(mysqli_num_rows($de)>0){
									echo '<table class="table">
				<tr>
				
				<th>Subject</th><th>Message</th><th>Ticket Id</th><th>Created Date</th><th>status</th><th></th>
				</tr>';
									while($rows=mysqli_fetch_array($de)){
										?>
				
				
				
				<tr>
				<td><?php echo $rows['subject'] ?></td>
				<td><?php if($rows['image']!=""){
				echo"<img src='../".$rows['image']."' width='50%'><br>";	
				} echo $rows['message']?></td> <td># <?php echo $rows['ref_no']?></td><td><?php echo $rows['postdate']?></td><td>  <?php if($rows['reply']=='1'){echo "Answered";}else{echo "Response on the way";} 	?></td><td>
				<?php $query="select* from ticket_reply where ticket_id='".$rows['ticket_id']."'"; $d=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($d)>0){$c=mysqli_fetch_array($d);echo "<table><tr><th>Reply</th><th>Reply date</th></tr><tr><td>
				
				";
				if($c['image']!=""){
				echo"<img src='../".$c['image']."' width='100%'><br>";	
				} echo $c['message'] ?></td><td><?php echo  $c['postdate']; ?></td></tr></table>
				<?php
				}
				?></td></tr>
				
				</tr>
				
				
				<?php 
				
									}
									
				echo "</table>";
								}else{
									echo "<h3>You dont have any Ticket yet</h3>
									<h4><a href='ticket.php'>Create ticket now</a></h4>";
								}

				?>
				</div>
				
				<?php include "footer.php"; ?>