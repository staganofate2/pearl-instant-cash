<?php
include"header.php";

$bar="chat";
?>
		<style>
		#lt{
			text-align:left;
		}
		#rt{
			text-align:left;
		}
		</style>
		
		<?php include "sidebar.php"; ?>
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">chat</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				
				<div class="col-md-4">
				<h4 class="page-header">Online</h4>
				<div class="media"><a href="chats.php?receiver=admin" class="media-left">Admin</a>
 
 </div>
				</div>
		
				
								<div class="col-md-8">
				

<?php
if(isset($_GET['receiver'])){	
$receiver=$_GET['receiver'];
if(isset($_GET['id'])){
	$mid=$_GET['id'];
	 $query="update message me,conversation con set me.red='1' where  me.conversation_id=con.conversation_id and  con.usertwo='{$_SESSION['account']}' and me.red='0' and me.message_id='$mid'";

$result=mysqli_query($db,$query) or die(mysqli_error($db)); 
}
if(isset($_POST['submit'])){

$message=$_POST['mes'];

$q="insert ignore into conversation values('','{$_SESSION['account']}','$receiver','chat')";
$s=mysqli_query($db,$q)or die(mysqli_error($db));
$id=mysqli_insert_id();

$query="insert ignore into message values ('','{$_SESSION['account']}','$id','$message',NOW(),'0') ";
$result=mysqli_query($db,$query) or die(mysqli_error($db));
if($result>0){
$me="message_sent";
header("location:message.php?receiver=$receiver");
exit();
}
else{
$me= "message not sent";
echo $me;exit();
}}

?>
<div id="chat"> 

<h3>PRIVATE CHAT ROOM </h3>
 
<div id="messagechat">
</div>                                                                                                                                                  




		<label for="name"style='color:blue' > message:</label>
		<textarea type="text" name="mes" id="mes"></textarea>
		<input type="hidden"id="receiver" value="<?php echo $receiver ?>">
		<input type="hidden"id="sender" value="<?php echo $_SESSION['account'] ?>">
		<input type="hidden"id="img" value="">
		<div class="form-group">
		<button class='btn' id='close'onclick="closeit()" style='display:none'>Close</button>
							<form method="post" id="fileinfo" name="fileinfo" style='display:none'>
							
        <label>Select a file:</label><br>
        <input type="file" name="file" required />
		<div id='results'></div>
        <input type="button" value="Upload" onclick="submitForm()"/>
    </form>	
							</div>
		<button class='btn' onclick="loadfile()">Upload Image</button>
		<input type="submit" id="meebutton" value="SEND" onclick="sendit('message2.php')">
		 
		 <div id="target"><?php  if(isset($me)){echo $me;}?></div >
	<span style='color:green;margin-left:100px'id="result"></span>
	</div>
	<?php
}
?>
				
				</div>
				
				
				<br><br><br><br>
				</div></div>
				<div class="col-sm-12">
				
			</div>
		
		
		
		</div>
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	 
		<script src="jquery.js" type="text/javascript"></script>
<script>
$('#mes').focus(function(){
document.getElementById('result').innerHTML="";});

$('document').ready(function(){$('#but').click(function(){$('#target').load('message.php#result',{mes:$('#mes').val(),receiver:$('#receiver').val(),sender:$('#sender').val()})});});
function sendit(){
	var hr = new XMLHttpRequest();
	var url = "message2.php";
	var receiver = document.getElementById("receiver").value;
	var sender = document.getElementById("sender").value;
	var mes = document.getElementById("mes").value;
	var img = document.getElementById("img").value;
	var vars = "receiver="+receiver+"&sender="+sender+"&mes="+mes+"&img="+img;
	hr.open("POST",url,true);
	hr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	hr.onreadystatechange = function(){
		if(hr.readyState == 4 && hr.status == 200){
			var return_data = hr.responseText;
			alert(return_data);
				if(return_data != "message_sent"){
					document.getElementById('result').innerHTML="error sending message";
					
				}else{
				document.getElementById("mes").value="";
					document.getElementById("result").innerHTML="sent";
					document.getElementById("fileinfo").style.display="none";
					document.getElementById("close").style.display="none";
						document.getElementById("img").value="";
			}
		}
	}
	hr.send(vars);	
}
function loadmessage(){
$("#messagechat").load("mess.php",{receiver:$("#receiver").val(),sender:$("sender").val()});


$('document').ready(function(){$("#online").load('online.php');})
}
setInterval(loadmessage,10000);
function loadfile(){
	var file=document.getElementById("fileinfo");
	file.style.display="block";
	document.getElementById("close").style.display="block";
}
function closeit(){
	alert('nofate');
	var file=document.getElementById("fileinfo");
	file.style.display="none";
	document.getElementById("close").style.display="none";
}
function submitForm() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploads.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                
                $('#results').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#results img').attr('src','../'+data);
				$('#img').val(data);
				alert(data);
				
				
            });
            return false;
        }
</script>
</body>
</html>