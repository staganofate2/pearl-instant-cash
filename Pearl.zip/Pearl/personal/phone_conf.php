<?php
include"header.php";
$bar="index";



?>

		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Confirm phone</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h3 class="page-header">Confirm phone number</h3>
				
				
								<div class="col-md-4">
								<?php
			 
				 if (isset($_POST['change'])){

$code=$_POST['code'];

$query=mysqli_query($con, "select phone from ph_confirm where code='$code' and account_no='{$_SESSION['account']}'")or die(mysqli_error($con));

$check=mysqli_num_rows($query);

if($check > 0){
$queryup=mysqli_query($con, "UPDATE ph_confirm SET confirmed='1' where account_number='{$_SESSION['account']}'");	
	
}
else {
	echo "<p style='color:red;'>Incorrect code</p>";
}
if(@$queryup){

echo "<script>alert('your phone number has been confirmed successfully ')</script>";
	
}
else{
	echo "<script>alert('An error Occured')</script>";
	echo"<p><a href='phone_conf.php'>TRY AGAIN</a></p>";
}
				 }else{
?>
				<form action="" method="POST">

				
							
							<div class="form-group">
								<input class="form-control" placeholder="Enter Confirmation code" name="code" type="text" required>
							</div>
							
							<button class="btn btn-info" name="change" type="submit">Confirm</button>
				
				
				<br><br>
				<button class="btn btn-info" name="change" type="button">Resend Code</button>
				<span id='res'></span>
				</form>
				
				<?php
				 }
				 ?>
				 
				</div>
				
				
				
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}

	function submitForm1() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo1"));
            fd.append("label", "WEBUPLOAD");
			document.getElementById("button1").value="Uploading ...";
            $.ajax({
              url: "upload.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                
                alert(data);
				$('#outputpix1').attr('src',data);
				document.getElementById("button1").value="Upload";
				
				
            });
            return false;
        }
		
		function closediv(id){
			
			document.getElementById(id).innerHTML="";
		}
		function sendval(action,value,but,rs,change){
			
		var val=document.getElementById(value).value;
var but=document.getElementById(but);

var v=but.textContent;

but.textContent="Please Wait...";
but.style.disabled=true;
if(val==""){
	document.getElementById(value).placeholder="Please type something !";
	return false;
}
ajax.open("POST", "updater.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
document.getElementById(rs).innerHTML = ajax.responseText;

}
if(ajax.responseText){
	document.getElementById(change).innerHTML=val;
but.style.disabled=false;
but.textContent=ajax.responseText;

}
}

ajax.send("action="+action+"&value="+val);	
			
		}
		
		function spass() {

var pass =document.getElementById('pass2').value;
var reg=document.getElementById("savepass").style.color;
if(reg=="red"){
	return false;
}
if(pass==""){
	document.getElementById("pass2").placeholder="password can not be empty";
	return false;
}
var RequestObj = document.getElementById("passresult");
ajax.open("POST","check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;
document.getElementById('passres').innerHTML="";
}

}
ajax.send("action=save&pass="+pass);
}
function sendpass() {

var pass =document.getElementById('pass1').value;
var reg=document.getElementById('savepass');
var RequestObj = document.getElementById("rs");
ajax.open("POST", "check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;

}
if(ajax.responseText=="password not correct"){
reg.style.disabled=true;
reg.style.color="red";
}else{
reg.style.color="white";	
}
}

ajax.send("action=check&pass="+pass);
}
function checkpass (){
var pass1=document.getElementById('pass2').value;
var pass2=document.getElementById('pass3').value;
var reg=document.getElementById('savepass');

if(pass1 !== pass2){
document.getElementById('res').innerHTML = "Password do not match";

reg.style.disabled=true;
reg.style.color="red";

}
else{
	reg.style.disabled=false;
	document.getElementById('res').innerHTML = "matched";
	reg.style.color="white";
}
}
function resend() {



ajax.open("POST","sendcode.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {

document.getElementById('res').innerHTML="code sent";
}

}
ajax.send();
}
		</script>
		
		<?php include "footer.php"; ?>