<?php
include"header.php";
include"modal_box.php"; 
$bar="notification";
?>
		
		
		<?php
		include"sidebar.php" ;
		?>
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Personal Info</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Notification</h4>
				<?php $query="select* from notification where account_no='{$_SESSION['account']}'";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				  
				   ?>
				   
				<p>Hi, <?php echo$row['firstname']." .. This is Your Notification";  ?>
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				<tr>
				<th>Subject</th>
				<th>Message</th><th>Date</th>
				</tr>
				<?php while($rows=mysqli_fetch_array($resultt)){
					?>
				<tr>
				
				<td><?php echo $rows['purpose'] ?></td>
				
				
				<td><?php echo $rows['message']; ?></td>
				
				<td><?php echo $rows['postdate']; ?></td>
				
				</tr>
				
				
				<?php 
				$query="update notification set red='1' where account_no='{$_SESSION['account']}' and id='".$rows['id']."'";
			   mysqli_query($con,$query) or die(mysqli_error($con));
				} ?>
				
				
				
				
				</table>

				<?php
			   }else{
				   echo "<h5>You dont have a notication yet</h5>";
			   }
				?>
				</div>
				
				
				<?php include "footer.php"; ?>