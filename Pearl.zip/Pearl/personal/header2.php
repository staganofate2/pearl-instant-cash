<?php
session_start();
if(!isset($_SESSION['account'])){
	echo "<script>window.location='../login.php'</script>";
}
//include "session.php";
include"connect.php";
$query="select* from registeruser where account_number='{$_SESSION['account']}'";
$de=mysqli_query($con,$query)or die(mysqli_error($con));
$row=mysqli_fetch_array($de);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PEARL USER Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
		<link href="cs/summernote.css" rel="stylesheet">
	<style>
	#user{
		color:lime;
		margin-left:100px;
	}
	</style>
	
</head>

<body>
<!------------------------top nav------------------------------------------------>

<nav class="navbar navbar-custom navbar-fixed-top" role="navigation"style='background:blue;' >
		<div class="container-fluid">
			<div class="navbar-header" >
				
				
					<!--<ul class="nav navbar-nav" class="navbar-left" id='mainav'>
					 
						<li class='active'><a href="personal/" >PERSONAL INFORMATION</a></li>
						<li><a href="account/" class="scroll active">Login Account</a></li> 
						 
						<li><a href="invest/" class="scroll">Pearl Invest</a></li>  
                      						
						<li><a href="loan/" class="scroll">Pearl Loan</a></li>    
						  
						
							</ul>  
						-->
						
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
						<!--<div class="topnav" id="myTopnav" style='background:blue;'>
  <!--<a href="../personal/"  class="active">Personal Information</a>
  <a href="../account/">Account</a>
  <a href="../invest/">Pearl Invest</a>
  <a href="../loan/">Pearl Loan</a>
  <a href="../food/">Pearl Food Store</a>
  <a href="../wallet/">My Wallet</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>-->

	<?php $query="select phone from ph_confirm where phone='".$row['phone']."' and confirmed='0'";
				$de=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($de)>0){
					echo"<a href='../personal/phone_conf.php'>Confirm Your Phone Number</a>";
				}
		?>
				<ul class="nav navbar-top-links navbar-right">
					<?php
$query="select*  from deposit where  confirmed='0' and rejected='0' and account_no='{$_SESSION['account']}'";$result=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($result)>0){
	?>
	
						

<li class="parent" ><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> <b style='background:red;color:white'> Confirm <?php  echo mysqli_num_rows($result)?>  Deposit(s) <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></b></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					
			<?php
	while($rowss=mysqli_fetch_array($result)){
	?><li><a href="../personal/confirmation.php?confirm_id=<?php echo $rowss['deposit_id']?>&method=<?php echo $rowss['method'] ?>">Confirm Your <?php echo $rowss['amount'] ?> Deposit </a></li>

						<?php 
						}
						echo "</ul>	</li>";
			
						
}
?>
						<li class="dropdown" id='messagee'><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span id='mee'class="label label-danger"></span>
					</a>
						
					</li>
					<li class="dropdown" id='notify'><a class="dropdown-toggle count-info"  href="../personal/notification.php">
						<em class="fa fa-bell"></em><span id='noo'class="label label-info"></span>
					</a>
						
					</li>
				</ul>

				<!--</div> -->
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		<script>
		
	var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
		function loadstuff(){

$('document').ready(function(){$("#mee").load('message_alert.php');});
$('document').ready(function(){$("#noo").load('notification_alert.php');});

 
function updatemessages(){
		
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatemessages.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {

				
				
				 document.getElementById("messagee").innerHTML +=ajax.responseText;
				 
			
		}
	}
	ajax.send();
 
 }
 updatemessages();
 function updatenotification(){
		
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatenotification.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {

			
			
				
				 document.getElementById("notify").innerHTML +=ajax.responseText;
				 
			
		}
	}
	ajax.send();
 
 }
 updatenotification();

}

setInterval(loadstuff,5000);
</script>