<form method="post" id="passform" action="<?php $_SERVER['PHP_SELF'] ?>" onclick="return false;">
<button onclick="closediv('passres')" style='float:right;color:red;background:white;font-weight:bold;margin-right:45%'>X</button>

        <label>Enter Current Password</label><br>
        <input type="password" name="pass1" id="pass1"required onblur="sendpass()"/><span id='rs' style='color:red'></span><br>
		<label>Enter New Password</label><br>
        <input type="password" name="pass2" id="pass2"required /><br>
		<label>Confirm Password</label><br>
        <input type="password" name="pass3" id="pass3"onblur="checkpass()" required /><span id='res'style='color:red'></span><br>
        <br><input type="submit" value="Save"id='savepass' onclick="spass()"/><span id='re'></span>
    </form>
