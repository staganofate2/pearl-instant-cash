<?php
include'connect.php';

$query="select r.phone as phone,a.amount as amount,c.payment_structure,c.account_no as account,c.account_id as id, a.pay_date,a.account_pay_id as pid,c.account_type as name from  account_pay a, registeruser r ,account c where datediff(a.pay_date,'".date("Y-m-d")."')='1' and r.account_number=a.account_no and c.account_id=a.account_id and a.paid='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
      echo "nofate";
	 while($row=mysqli_fetch_array($se)){
	     
	     $account=$row['account'];
	      $date=$row['pay_date'];
	     $id=$row['id'];
	     $structure=$row['payment_structure'];
	     $amount=$row['amount'];
		  $pid=$row['pid'];
  $phone=$row['phone'];
 
  $name=$row['name'];
 

 
 $message="Your $structure $name Account contribution payment  of N $amount will be paid on  $date , ensure your wallet is funded.";
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 
	 }
 }
?>
<?php
/*
$query="select r.account_number as account,c.deposit as deposit,r.phone as phone,a.amount,c.loan_id,c.total as total,a.loan_repay_id as ids from  loan_repay a, registeruser r ,loan c where a.pay_date='".date("Y-m-d")."' and r.account_number=a.account_no and c.loan_id=a.loan_id and c.collected='1' and a.paid='0' and c.paid='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
		 
  $phone=$row['phone'];
 $total=$row['total'];
 $ids=$row['ids'];
  $deposit=$row['deposit'];
 $amount=$row['amount'];
  $account=$row['account'];
  $query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet-$amount;
  if($balance>=0){
	  $query="update loan_repay set paid='1' where  account_no='$account' and loan_id='".$row['loan_id']."' and loan_repay_id='$ids'";
  mysqli_query($con,$query) or die(mysqli_error($con));
   $message="Your $total Loan  repayment reminder. N $amount has been Depited from Your Wallet for today Loan Repayment. ".date("Y-m-d");
  $dep=$deposit+$amount;
  $query="update loan set deposit='$dep' where   account_no='$account' and loan_id='".$row['loan_id']."' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
  if($deposit==$dep){
      $query="update loan set paid='1' where   account_no='$account' and loan_id='".$row['loan_id']."' "; 
      mysqli_query($con,$query) or die(mysqli_error($con));
  }
  
  }else{
	  $x=abs($balance);
	  $query="update loan_repay set amount='$x' where pay_date='".date("Y-m-d")."' and account_no='$account' and loan_id='".$row['loan_id']."' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
  
  $dep=$deposit+($amount-$x);
  
  $query="update loan set deposit='$dep' where   account_no='$account' and loan_id='".$row['loan_id']."' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
	 $message="Your $total Loan  repayment reminder. You are to Deposit N $x balance of  Today Loan Repayment ".date("Y-m-d");  
  }
  $query="update wallet set total='$balance' where account_no='$account'";
  mysqli_query($con,$query) or die(mysqli_error($con));
  

 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 //echo "done";
	 }
 }
 */
?>
<?php


$query="select r.phone as phone,c.package_name as name,a.pay_date,c.package_name from  food_pay a, registeruser r ,food c where datediff(a.pay_date,'".date("Y-m-d")."')='1' and r.account_number=a.account_no and c.food_id=a.food_id";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($row=mysqli_fetch_array($se)){
		 
  $phone=$row['phone'];
 $structure=$row['package_name'];
  $name=$row['name'];
 $date=$row['pay_date'];
 $message="Your $structure $name Food contribution payment  of N $amount will be paid on  $date , ensure your wallet is funded.";
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 
	 }
 }
?>