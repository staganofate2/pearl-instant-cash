<?php
include"header.php";
include"modal_box.php"; 
$bar="bankinfo";
$banks=array("044"=>"Access Bank","023"=>"Citibank Nigeria","063"=> "Diamond Bank","050"=>"Ecobank Nigeria","084"=>"Enterprise Bank","070"=>"Fidelity Bank","011"=>"First Bank of Nigeria","214"=>"First City Monument Bank","058"=>"Guaranty Trust Bank","030"=>"Heritage Bank","082"=>"Keystone Bank","014"=>"MainStreet Bank","076"=>"Skye Bank","221"=>"Stanbic IBTC Bank","068"=>"Standard Chartered Bank","232"=>"Sterling Bank","032"=>"Union Bank of Nigeria","033"=>"United Bank For Africa","215"=>"Unity Bank","035"=>"Wema Bank","057"=>"Zenith Bank","other"=>"Others");	
?>
		
		
		<?php
		include"sidebar.php" ;
		?>
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Personal Info</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			<div class="col-md-8">
			   
				<h4 class="page-header">Bank Account Information</h4>
				<?php $query="select* from bank_info where account_no='{$_SESSION['account']}'";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				  
				   ?>
				   
				<p>Hi, <?php echo$row['firstname']." .. This is Your Bank Account Information";  ?>
				</p>
				
								
				
				<table class="table">
				<tr>
				<th>User Account Detail</th>
				<th></th>
				</tr>
				<?php while($rows=mysqli_fetch_array($resultt)){
					?>
				<tr>
				<td>Account Name</td>
				<td><?php echo $rows['account_name'] ?></td>
				
				</tr>
				<tr>
				<td>Account Number</td>
				<td><?php echo $rows['account_number']; ?></td>
				
				</tr>
				
				<tr>
				<td>Bank Name</td>
				<td><?php echo $rows['bank_name']; ?></td>
				
				</tr>
				
				<tr><td></td><td></td></tr>
				<?php } ?>
				
				
				
				
				</table>

				<?php
			   }else{
				   echo "<h5>You have not added your bank Information</h5>";
			   }
				?>
				
				</div>
				</div>
				</div>
				</div>
				
				
				
				<?php include "footer.php"; ?>