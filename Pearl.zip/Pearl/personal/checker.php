<?php
$ref="54182110023";
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/transaction/verify/$ref",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "Authorization:Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4",
   
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x['data']['authorization']);
   
   $authorization_code=$x['data']['authorization']["authorization_code"];
     $bin=$x['data']['authorization']["bin"];
       $last4=$x['data']['authorization']["last4"];
       $exp_month=$x['data']['authorization']["exp_month"];
      $exp_year=$x['data']['authorization']["exp_year"];
      $channel=$x['data']['authorization']["channel"];
      $card_type=$x['data']['authorization']["card_type"];
      $bank=$x['data']['authorization']["bank"];
	  /*$query="update paystackloan set authorization_code='$authorization_code',bin='$bin',last4='$last4',exp_month='$exp_month',exp_year='$exp_year',channel='$channel',card_type='$card_type',bank='$bank',confirmed='1' where ref_no='$ref' and account_no='$account' and id='$id'";
	  mysqli_query($con,$query) or die(mysqli_error($con));
	  */
}
   
   ?>