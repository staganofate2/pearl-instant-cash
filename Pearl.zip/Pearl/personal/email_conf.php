<?php
include"header.php";
$bar="index";



?>

		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Confirm email</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h3 class="page-header">Confirm email address</h3>
				
				
								<div class="col-md-4">
								<?php
			 
				 if (isset($_POST['change'])){

$code=$_POST['code'];

$query="select email from em_confirm where code='$code' and account_no='{$_SESSION['account']}' ";

$s=mysqli_query($con,$query )or die(mysqli_error($con));



if(mysqli_num_rows($s) > 0){
$queryup=mysqli_query($con, "UPDATE em_confirm SET confirm='1' where account_no='{$_SESSION['account']}'")or die(mysqli_error($con));	
echo "<script>alert('your Email has been confirmed successfully ');window.location='index.php'</script>";
exit();	
}
else {
	echo "<p style='color:red;'>Incorrect code</p>";

	
	echo"<p><a href='phone_conf.php'>TRY AGAIN</a></p>";
}	 }else{
				     
?>
		<p>A confirmation code has been sent to your Email, please enter the code and click on Confirm.</p>
		<form action="" method="POST">

				
							
							<div class="form-group">
								<input class="form-control" placeholder="Enter Confirmation code" name="code" type="text" required>
							</div>
							
							<button class="btn btn-info" name="change" type="submit">Confirm</button>
				
				
				<br><br>
				<button class="btn btn-info" name="change" type="button" onclick='resend()'>Resend Code</button>
				<span id='res'></span>
				</form>
				
				<?php
				 }
				 ?>
				 
				</div>
				
				
				
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}

	
		function closediv(id){
			
			document.getElementById(id).innerHTML="";
		}
		
		
		

function resend() {



ajax.open("POST","sendmailcode.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {

document.getElementById('res').innerHTML="code sent";

if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
}

}
ajax.send();
}
		</script>
		
		<?php include "footer.php"; ?>