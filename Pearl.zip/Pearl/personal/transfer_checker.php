<?php
include'connect.php';

$query="select r.phone as phone,r.firstname,r.lastname,r.email_address,t.amount,t.ref_no,t.code,t.bank_name,t.transfer_id,t.account_no,t.account_number,t.account_name from  transfer t, registeruser r  where  r.account_number=t.account_no and t.status='0' and t.code !=''";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($fes=mysqli_fetch_array($se)){
		 
$amount=$fes['amount'];
$amt=$amount;
$ref=$fes['ref_no'];
$bank_name=$fes['bank_name'];
$account_number=$fes['account_number'];
$account_name=$fes['account_name'];
$name=$fes['firstname'];
$commi=100;
$account=$fes['account_no'];
$phone=$fes['phone'];
$code=$fes['code'];
$total=$amount+$commi;
$id=$fes['transfer_id'];
$fisrtname=$fes['firstname'];
$lastname=$fes['lastname'];
$email=$fes['email_address'];

$query="select balance from adminpanel  where username='admin'";
$io=mysqli_query($con,$query) or die(mysqli_error($con));
$ce=mysqli_fetch_array($io);
$balances=$ce['balance'];
if($balances>=($amount+50)){
	
$query="select account_number from account_confirm where account_number='$account_number'";
$p=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($p)<1){
$query="insert into account_confirm (bank,account_name,account_number,postdate) values('$bank_name','$account_name','$account_number',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
}
	
$query="update transfer set account_name='$account_name',account_number='$account_number' where ref_no='$ref'";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							$id=mysqli_insert_id($con);
									$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	$amounts=($rows['total']-$total);
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$total was Debited from your Wallet for Bank Transfer";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Wallet','$account','','$total','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));


$amount=$amount."00";

//Set other parameters as keys in the $postdata array
$postdata =  array('type' => 'nuban', 'name' => "$name","description" =>"Account Transfer","account_number" => "$account_number","bank_code"=> "$code","currency"=> "NGN");
   
$url = "https://api.paystack.co/transferrecipient";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
//Use the $result array to get redirect URL




$recipient=$x['data']['recipient_code'];//$re['recipient'];
//$amount=$re['amount'];
//Set other parameters as keys in the $postdata array
}
$postdata =  array("source"=>"balance", "reason"=>"transfer", "amount"=>"$amount", "recipient" =>"$recipient");
   
$url = "https://api.paystack.co/transfer";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
 // print_r($x);
  
// echo "<h3>".$x['message']."</h3>";
//Use the $result array to get redirect URL


if($x['status']=="1"){
    $query="update transfer set status='1' ,sent_date=now() where  ref_no='$ref' and account_no='$account' and transfer_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));



$query="select balance from wallet_transact where  packages_id='$id' and packages='Transfer' and account_no='$account'";
$r=mysqli_query($con,$query) or die(mysqli_error($con));
$e=mysqli_fetch_array($r);
$amounts=$e['balance'];
$message="Your Transfer of N $amt to $account_name ($account_number - $bank_name )on Pearl was successful. Wallet Balance N $amounts . ".date('d-m-Y');


$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/bankl.png" alt="" width="50%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong> $firstname $lastname</td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Transfer Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


$message=urlencode($message);
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);




$bal=$balances-($amount+50);
$query="update adminpanel set balance='$bal'  where username='admin'";

mysqli_query($con,$query) or die(mysqli_error($con));

}
}
}
}
}
 }
 /*
 $query="select r.phone as phone,r.email_address,r.firstname,r.lastname,t.amount,t.ref_no,b.code,t.account_no,t.account_number from  withdraw t, registeruser r ,bank_info b where  r.account_number=t.account_no and t.paid='0' and b.code !='' and t.account_no=b.account_no";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 while($fes=mysqli_fetch_array($se)){
		 
$amount=$fes['amount'];
$ref=$fes['ref_no'];
$lastname=$fes['lastname'];
$account_number=$fes['account_number'];
$email=$fes['email_address'];
$name=$fes['firstname'];
$account=$fes['account_no'];
$phone=$fes['phone'];
$code=$fes['code'];
$id=$res['withdraw_id'];

	
$query="select balance from adminpanel  where username='admin'";
$io=mysqli_query($con,$query) or die(mysqli_error($con));
$ce=mysqli_fetch_array($io);
$balances=$ce['balance'];
if($balances>=($amount+50)){
$amounts=$amount."00";

//Set other parameters as keys in the $postdata array
$postdata =  array('type' => 'nuban', 'name' => "$name","description" =>"Account Transfer","account_number" => "$account_number","bank_code"=> "$code","currency"=> "NGN");
   
$url = "https://api.paystack.co/transferrecipient";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
//Use the $result array to get redirect URL




$recipient=$x['data']['recipient_code'];//$re['recipient'];
//$amount=$re['amount'];
//Set other parameters as keys in the $postdata array
}
$postdata =  array("source"=>"balance", "reason"=>"transfer", "amount"=>"$amounts", "recipient" =>"$recipient");
   
$url = "https://api.paystack.co/transfer";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
  
 echo "<h3>".$x['message']."</h3>";
//Use the $result array to get redirect URL




$query="update withdraw set paid='1' ,paid_date=now() where  ref_no='$ref' and account_no='$account' and withdraw_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$bal=$balances-($amount+50);
$query="update adminpanel set balance='$bal'  where username='admin'";

mysqli_query($con,$query) or die(mysqli_error($con));
}


 
 
				$message="Your $amount  Account Withdrawal has been Confirmed";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));

$message="Your Withdrawal of N $amount has been confirmed and your money has been paid into your bank account. Wallet  Balance N $amounts . ".date('d-m-Y');


$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/bankl.png" alt="" width="50%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong> $firstname $lastname</td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


$message=urlencode($message);
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);



}
}}
*/
?>