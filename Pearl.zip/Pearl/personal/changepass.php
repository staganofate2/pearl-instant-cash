<?php
include"header.php";
include"modal_box.php"; 
$bar="changepass";



?>

		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Change Password</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h3 class="page-header">Change Password</h3>
				
				
								<div class="col-md-4">
								<?php
			 
				 if (isset($_POST['change'])){

$confirm=$_POST['confirm'];;
$old=$_POST['old'];
$new=$_POST['new'];
if($confirm)
$query=mysqli_query($con, "select password from registeruser where password='".sha1(md5($old))."' and account_number='{$_SESSION['account']}'");

$check=mysqli_num_rows($query);

if($check > 0){
$queryup=mysqli_query($con, "UPDATE registeruser SET password='".sha1(md5($new))."' where account_number='{$_SESSION['account']}'");	
	
}
else {
	echo "<p style='color:red;'>That not your old password</p>";
}
if(@$queryup){

echo "<script>alert('your password has been changed successfully ')</script>";
	
}
else{
	echo "<script>alert('An error Occured')</script>";
	echo"<p><a href='changepass.php'>TRY AGAIN</a></p>";
}
				 }else{
?>
				<form action="" method="POST">

				
							
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Old Password</span>
								<input class="form-control" placeholder="Old Password" name="old" type="text" required>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">New Password</span>
								<input class="form-control" placeholder="New Password" name="new" type="password" required>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Confirm New Password</span>
								<input class="form-control" value="" name="confirm" type="password"  placeholder='Confirm Password'>
							</div>
							<button class="btn btn-info" name="change" type="submit">Change Password</button>
				
				
				
				</form>
				
				<?php
				 }
				 ?>
				
				</div>
				
				
				
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}

	function submitForm1() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo1"));
            fd.append("label", "WEBUPLOAD");
			document.getElementById("button1").value="Uploading ...";
            $.ajax({
              url: "upload.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                
                alert(data);
				$('#outputpix1').attr('src',data);
				document.getElementById("button1").value="Upload";
				
				
            });
            return false;
        }
		
		function closediv(id){
			
			document.getElementById(id).innerHTML="";
		}
		function sendval(action,value,but,rs,change){
			
		var val=document.getElementById(value).value;
var but=document.getElementById(but);

var v=but.textContent;

but.textContent="Please Wait...";
but.style.disabled=true;
if(val==""){
	document.getElementById(value).placeholder="Please type something !";
	return false;
}
ajax.open("POST", "updater.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
document.getElementById(rs).innerHTML = ajax.responseText;

}
if(ajax.responseText){
	document.getElementById(change).innerHTML=val;
but.style.disabled=false;
but.textContent=ajax.responseText;

}
}

ajax.send("action="+action+"&value="+val);	
			
		}
		
		function spass() {

var pass =document.getElementById('pass2').value;
var reg=document.getElementById("savepass").style.color;
if(reg=="red"){
	return false;
}
if(pass==""){
	document.getElementById("pass2").placeholder="password can not be empty";
	return false;
}
var RequestObj = document.getElementById("passresult");
ajax.open("POST","check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;
document.getElementById('passres').innerHTML="";
}

}
ajax.send("action=save&pass="+pass);
}
function sendpass() {

var pass =document.getElementById('pass1').value;
var reg=document.getElementById('savepass');
var RequestObj = document.getElementById("rs");
ajax.open("POST", "check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;

}
if(ajax.responseText=="password not correct"){
reg.style.disabled=true;
reg.style.color="red";
}else{
reg.style.color="white";	
}
}

ajax.send("action=check&pass="+pass);
}
function checkpass (){
var pass1=document.getElementById('pass2').value;
var pass2=document.getElementById('pass3').value;
var reg=document.getElementById('savepass');

if(pass1 !== pass2){
document.getElementById('res').innerHTML = "Password do not match";

reg.style.disabled=true;
reg.style.color="red";

}
else{
	reg.style.disabled=false;
	document.getElementById('res').innerHTML = "matched";
	reg.style.color="white";
}
}

		</script>
		
		<?php include "footer.php"; ?>