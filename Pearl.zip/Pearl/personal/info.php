<?php
include"header.php";
include"modal_box.php"; 
$bar="info";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Profile</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			
			<div class="col-lg-2">
			</div>
			<div class="col-lg-10">
			
			   
				<h4 class="page-header">Profile</h4>
				
				<p>Hi, <?php echo$row['firstname']." .. This is Your Profile";  ?>
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				<tr>
				<th>User Account Detail</th>
				<th></th>
				</tr>
				
				<tr>
				<td>Profile Pics</td>
				<td>	<img src="../<?php echo $row['picture'] ?>" class="img-responsive img-circle" style="height:120px; width:60%;margin-left:20%" alt="PEARL user picture"></td>
				
				</tr>
				<tr>
				<td>User FullName</td>
				<td><?php echo $row['firstname']." ".$row['middlename']." ". $row['lastname']; ?></td>
				
				</tr>
				<tr>
				<td>Email ID</td>
				<td><?php echo $row['email_address']; ?></td>
				
				</tr>
				
				<tr>
				<td>Phone Number</td>
				<td><?php echo $row['phone']; ?></td>
				
				</tr>
				<tr>
				<td>Alternate Phone Number</td>
				<td><?php echo $row['alt_phone']; ?></td>
				
				</tr>
				<tr>
				<td>Gender</td>
				<td><?php echo $row['gender']; ?></td>
				
				</tr>
				<tr>
				<td>Marital Status</td>
				<td><?php echo $row['status']; ?></td>
				
				</tr>
				<tr>
				<td>Date of Birth</td>
				<td><?php echo $row['dob']; ?></td>
				
				</tr>
				
				<tr>
				<td>Residential Address</td>
				<td><?php echo $row['address']; ?></td>
				
				</tr>
				<tr>
				<td>Office Address</td>
				<td><?php echo $row['office_address']; ?></td>
				
				</tr>
				
				<tr>
				<td>Nearest Bus stop</td>
				<td><?php echo $row['phone']; ?></td>
				
				</tr>
				
				<tr>
				<td>City, State</td>
				<td><?php echo $row['city_res'].", ".$row['state_res']; ?></td>
				
				</tr>
				
				<tr>
				<td>Home L.G.A</td>
				<td><?php echo $row['lga']; ?></td>
				
				</tr>
				<tr>
				<tr>
				<td>Educational Qualification</td>
				<td><?php echo $row['qualification']; ?></td>
				
				</tr>
				<tr>
				<td>Institution</td>
				<td><?php echo $row['institution']; ?></td>
				
				</tr>
				<tr>
				<td>Faculty</td>
				<td><?php echo $row['faculty']; ?></td>
				
				</tr>
				<tr>
				<td>Department</td>
				<td><?php echo $row['department']; ?></td>
				
				</tr>
				<tr>
				<td>Level</td>
				<td><?php echo $row['levels']; ?></td>
				
				</tr>
				<td>Means of Identification</td>
				<td><?php echo $row['id']; ?></td>
				
				</tr>
				<tr>
				<td>Identification No:</td>
				<td><?php echo $row['id_no']; ?></td>
				
				</tr>
				<tr>
				<td>Account Number</td>
				<td><?php echo $row['account_number']; ?></td>
				
				</tr>
				<tr>
				<td>Issued Date</td>
				<td><?php echo $row['issue_date']; ?></td>
				
				</tr>
				<tr>
				<td>Expiring Date</td>
				<td><?php echo $row['exp_date']; ?></td>
				
				</tr>
				<tr>
				<td>ID Image</td>
				<td><img src='../<?php echo $row['id_image']; ?>' class='zoomss'width='200px' height='120px'alt='id image'></td>
				
				</tr>
				<tr>
				<td>Next of Kin Title</td>
				<td><?php echo $row['kin_title']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Name</td>
				<td><?php echo $row['kin_name']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Phone Number</td>
				<td><?php echo $row['kin_phone']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Address</td>
				<td><?php echo $row['kin_address']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin State of Origin</td>
				<td><?php echo $row['kin_state']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Relationship</td>
				<td><?php echo $row['kin_relationship']; ?></td>
				
				</tr>
				
			<tr>
				<td>Certificate</td>
				<td><img src='../<?php echo $row['certificate']; ?>' class='zoomss'width='200px' height='120px'alt='Certificate'></td>
				
				</tr>
				
				
				
				</table>

				
				</div>
				
			<?php include "footer.php"; ?>