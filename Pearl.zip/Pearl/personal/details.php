<?php
session_start();
include "session.php";
include"connect.php";


if (!isset($_SESSION['pinn'])){
	header("location:../login.php");
	exit();
} 

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>GBO USER: Account Details</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	<link href="w3v4.css" rel="stylesheet">
	
	
</head>


<!------------------------top nav------------------------------------------------>

	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>GBO</span> User</a>
				<ul class="nav navbar-top-links navbar-right">
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span class="label label-danger">0</span>
					</a>
						
					</li>
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-bell"></em><span class="label label-info">1</span>
					</a>
						<ul class="dropdown-menu dropdown-alerts">
							<li><a href="#">
								<div><em class="fa fa-envelope"></em> We are Glad you Joined GBO
									<span class="pull-right text-muted small">Sometime ago</span></div>
							</a></li>
							
						</ul>
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		
		
		<!-------------------------------------the side nav bar here-------------------------------------->
		
		<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			
				<img src="../<?php echo $pic;  ?>" class="img-responsive" style="height:180px; width:90%;" alt="gbo user picture"><!--------------------user picture here----------------->
			
			
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li ><a href="index.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<li><a href="summary.php"><em class="fa fa-calendar">&nbsp;</em> Account Summary</a></li>
			<li class="active"><a href="details.php"><em class="fa fa-bar-chart">&nbsp;</em> Account Details</a></li>
			<li  ><a href="statement.php"><em class="fa fa-toggle-">&nbsp;</em> Account Statement</a></li>
			<li ><a href="fundtransfer.php"><em class="fa fa-clone">&nbsp;</em> Fund Transfer</a></li>
			<li class="parent"><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> Security Settings <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li ><a class="" href="changepass.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Change Password
					</a></li>
					<li><a class="" href="changepin.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Change Pin
					</a></li>
					<li><a class="" href="profile.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Account Profile
					</a></li>
				</ul>
			</li>
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout <?php echo $last;  ?></a></li>
		</ul>
	</div><!--/.sidebar-->
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account Details</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h3 class="page-header">Account Details</h3>
				
				<p>If you feel that you have a weaker Account PIN, then please change it.<br>
                 We recommend you change your Account PIN every Month.
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				<tr>
				<th>User Account Detail</th>
				<th></th>
				</tr>
				
				<tr>
				<td>User FullName</td>
				<td><?php echo "$first $last"; ?></td>
				
				</tr>
				<tr>
				<td>Email ID</td>
				<td><?php echo "$mail"; ?></td>
				
				</tr>
				
				<tr>
				<td>Phone Number</td>
				<td><?php echo "$phone"; ?></td>
				
				</tr>
				
				<tr>
				<td>Address</td>
				<td><?php echo "$address"; ?></td>
				
				</tr>
				<tr>
				<td>City, State</td>
				<td><?php echo "$city, $state"; ?></td>
				
				</tr>
				
				<tr>
				<td>Zip Code</td>
				<td><?php echo "$zip"; ?></td>
				
				</tr>
				
				<tr>
				<td>Account Number</td>
				<td><?php echo "$acct"; ?></td>
				
				</tr>
				<tr>
				<td>Account Balance</td>
				<td><?php echo "$bal"; ?></td>
				
				</tr>
				
				<tr>
				<td>Account Pin</td>
				<td><?php echo "$pin"; ?></td>
				
				</tr>
				
				
				
				</table>

				
				</div>
				
				
				<br><br><br><br>
				</div></div>
				<div class="col-sm-12">
				<p class="">© 2017 E-Banking. Designed by <a href="../index.php">Global Bank Offshore</a></p>
			</div>
		
		
		
		</div>
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	 
		
</body>
</html>