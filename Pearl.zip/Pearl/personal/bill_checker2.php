<?php
include'connect.php';

$query="select* from bill where status='0'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
  while($x=mysqli_fetch_array($se)){
 
$id=$e['bill_id'];
$account=$e['account_no'];

$phone=$e['phone'];
	$amount=$e['variation'];
	$name=$e['name'];
	$name=urlencode($name);
	$type=$e['types'];
	$cnumber=$e['cnumber'];
	$invoice=$e['invoice'];
	$id=$e['billtwo_id'];
	$number=$e['numbers'];


if($type=="startimes"){

$http="https://mobileairtimeng.com/httpapi/startimes?userid=08107302391&pass=912363232d306466ae2a1&phone=$phone&amt=$amount&smartno=$number&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){
	$query="update billtwo set status='1',sent_date=now() where  billtwo_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
							
							
									
										echo "done";
										exit();
										
	}else{
											echo "Failed !!!";
											exit();
										}
}
			}else{


$http="https://mobileairtimeng.com/httpapi/multichoice?userid=08107302391&pass=912363232d306466ae2a1&phone=$phone&amt=$amount&smartno=$number&customer=$name&invoice=$invoice&billtype=$type&customernumber=$cnumber&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){				
							
									$query="update billtwo set status='1',sent_date=now() where  billtwo_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
										
	}else{
											
										}
}

  
  }
  }
}
?>