<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>GLO Airtime VTU<b><img src='images/glo.jpg' width="20%" height="100px" alt='network image'></h3>
			
			
			<!-- about bottom-->
			
				<center><h4 class="h3-w3l"> Top Up Your Airtime Instantly</h4> 
				
				<p>Just a few steps ahead, to buy your Airtime </p></center>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-10 "> 
			<h3>ONLINE Airtime Recharge</h3>

	
								<form class="" action="recharge_payments.php" method="post" > 
			
			
			
			
			
			
						
						
						
							<input type='hidden' name="network" value='6'>
						  <div id='loaders'></div>
						<table class='table'>
						<tr><td><div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div></td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div></td></tr>
							<tr><td>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div></td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Recharging Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div></td></tr>
						
						<tr><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount'onblur="check()" name="amount" type="text" placeholder='Amount in Digits'  required>
								<span class='danger' id='result'></span>
							</div>
							</td><td><br>
						<input type="submit" class="btn btn-info " id='submit'value="BUY"name="login"> <br>
						
						<div class="clearfix"></div>
					
			</td></tr></table>
			
			
			
			
			
			
			
			</form>
		
					
				</div> 
				<div class="clearfix"> </div>
				
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
 function check(){
	
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	//alert(amount);
	var amounts=amount.replace(reg,""); 
	if(isNaN(amounts)){
		document.getElementById('submit').style.display="none";
		document.getElementById('result').innerHTML="Please Enter number in Digits";
		return;
	}else{
    document.getElementById('submit').style.display="block";
	document.getElementById('result').innerHTML="";
	
	var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "check_data.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts);
	}
 }
	
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {

	
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
<?php
include"footer.php";
?>