 <?php
include"connect.php";
$bar='login';
include"header.php";
?>



	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l"> Log In to Access your Account</h4> 
				<p>Enter your account login details and proceed</p></center><br>
			</div> 
			
			<div class="row">
			<form class="" action="" method="post"> 
			<div class="col-md-2">
			
			
			</div>
			
				
				
								<div class="col-md-8">
								<h3 class="page-header">Reset Password</h3>
								<?php
			 if(isset($_GET['re'])){
				 $account=$_GET['re'];
			 }
				 if (isset($_POST['change'])){

$confirm=$_POST['confirm'];
$new=$_POST['new'];
if($confirm)
$query=mysqli_query($con, "select password from registeruser where  account_number='$account'");

$check=mysqli_num_rows($query);

if($check > 0){
$queryup=mysqli_query($con, "UPDATE registeruser SET password='".sha1(md5($new))."' where account_number='$account'");	
	
}
else {
	echo "<p style='color:red;'>That not your old password</p>";
}
if(@$queryup){

echo "<script>alert('your password has been changed successfully ')</script>";
	
}
else{
	echo "<script>alert('An error Occured')</script>";
	echo"<p><a href='changepass.php'>TRY AGAIN</a></p>";
}
				 }else{
?>
				<form action="" method="POST">

				
							<div class="form-group">
								<input class="form-control" placeholder="New Password" name="new" id='pass1' type="password"  onblur='checkPassword()'required>
							<span id='passe'></span>
							</div>
							<div class="form-group">
								<input class="form-control" value="" name="confirm" type="password"  id='pass2' placeholder='Confirm Password' onblur='checkpass()'>
							<span id='res'></span>
							</div>
							<button class="btn btn-info" name="change"  id='submit' type="submit">Change Password</button>
				
				
				
				</form>
				
				<?php
				 }
				 ?>
				
				</div>
				</div>
				</div>
				
				</div>
				
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}

	
		}
		function sendval(action,value,but,rs,change){
			
		var val=document.getElementById(value).value;
var but=document.getElementById(but);

var v=but.textContent;

but.textContent="Please Wait...";
but.style.disabled=true;
if(val==""){
	document.getElementById(value).placeholder="Please type something !";
	return false;
}
ajax.open("POST", "updater.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
document.getElementById(rs).innerHTML = ajax.responseText;

}
if(ajax.responseText){
	document.getElementById(change).innerHTML=val;
but.style.disabled=false;
but.textContent=ajax.responseText;

}
}

ajax.send("action="+action+"&value="+val);	
			
		}
		
		function spass() {

var pass =document.getElementById('pass2').value;
var reg=document.getElementById("savepass").style.color;
if(reg=="red"){
	return false;
}
if(pass==""){
	document.getElementById("pass2").placeholder="password can not be empty";
	return false;
}
var RequestObj = document.getElementById("passresult");
ajax.open("POST","check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;
document.getElementById('passres').innerHTML="";
}

}
ajax.send("action=save&pass="+pass);
}
function sendpass() {

var pass =document.getElementById('pass1').value;
var reg=document.getElementById('savepass');
var RequestObj = document.getElementById("rs");
ajax.open("POST", "check.php",true);
ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
ajax.onreadystatechange = function()
{
if (ajax.readyState == 4 && ajax.status == 200) {
RequestObj.innerHTML = ajax.responseText;

}
if(ajax.responseText=="password not correct"){
reg.style.disabled=true;
reg.style.color="red";
}else{
reg.style.color="white";	
}
}

ajax.send("action=check&pass="+pass);
}
function checkPassword()
  {
	  var str=document.getElementById('pass1').value;
    // at least one number, one lowercase and one uppercase letter
    // at least six characters
    var re = /(?=.*\d)(?=.*[a-zA-Z]).{6,}/;
    if(!re.test(str)){
		document.getElementById('submit').style.display="none";
		document.getElementById('passe').innerHTML="Password not strong<br> at least six characters, numbers,  letters ";
	}else{
	document.getElementById('submit').style.display="block";
document.getElementById('passe').innerHTML="";	
	}
	
  }
function checkpass (){
var pass1=document.getElementById('pass1').value;
var pass2=document.getElementById('pass1').value;
var reg=document.getElementById('savepass');

if(pass1 !== pass2){
document.getElementById('res').innerHTML = "Password do not match";

reg.style.disabled=true;
reg.style.color="red";

}
else{
	reg.style.disabled=false;
	document.getElementById('res').innerHTML = "matched";
	reg.style.color="white";
}
}

		</script>
		
		<?php include "footer.php"; ?>