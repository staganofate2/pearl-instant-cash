<?php
include"header.php";
include"modal_box.php"; 
$bar="deposit"
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Deposit Slip</h4>
				
				
								<div class="col-md-8">
			<?php $query="select total from wallet where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				$ve=mysqli_fetch_array($res);
				
					?>
				<h5 class="page-header">Wallet Balance  ₦ <?php echo $ve['total'] ?></h5>
			
				

				<form action="payment.php" method="POST" enctype="multipart/form-data">
<?php
if(isset($_GET['action'])){
					?><form action="payment.php" method="POST" enctype="multipart/form-data">
						
			<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update()">
								
								<?php
						
							$query="select account_type  from account where account_no='{$_SESSION['account']}' and active='0' and account_id='".$_GET['account_id']."'";
														$re=mysqli_query($con,$query) or die(mysqli_error($con));
								while($ros=mysqli_fetch_array($re)){
									?>
								<option   value="<?php echo $ros['account_type']?>"><?php echo $ros['account_type']?></option>
								<?php
								}
								?>
								</select>
							</div>
							<?php
				}else{
				?>
			
							<?php
				}
				?>
							
							<div id='loaders'></div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Amount</span>
							<?php
							if(isset($_GET['action']) && $_GET['action']=="single"){
								$id=$_GET['id'];
								$amount=$_GET['amount'];
								$account_id=$_GET['account_id'];
								?>
								
								<input  value="<?php echo $account_id ?>"  name="account_id" type="hidden" >
								<input  value="<?php echo $id ?>"  name="account_pay_id" type="hidden" >
								<input class="form-control" value="<?php echo $amount ?>" name="amount" type="text" readonly>
								<?php
							}
							elseif(isset($_GET['action']) && $_GET['action']=="All"){
								$id=$_GET['id'];
								$amount=$_GET['amount'];
								$account_id=$_GET['account_id'];
								?>
								
								<input  value="<?php echo $account_id ?>"  name="account_id" type="hidden" >
								<input  value="<?php echo $id ?>"  name="account_pay_id" type="hidden" >
								<?php $query="select sum(p.amount) as total from account_pay p inner join account f using(account_id) where f.account_id='$account_id' and p.paid='0'";
								$rec=mysqli_query($con,$query) or die(mysqli_error($con));
								$es=mysqli_fetch_array($rec);
								?>
								<input class="form-control" value="<?php echo $es['total'] ?>" name="amount" type="text" readonly>
								<?php
							}
							
							?>
								
							</div>
							
							<button class="btn btn-info" name="change" type="submit">Continue</button>
				
				</form>
				<br>
				<button class="btn btn-info" onclick="goback()">Cancel</button>

				
				</div>
				
				
		
		
	
	 <script>
	 
		function goback(){
			window.location="procedure.php";
		}
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
<?php include "footer.php"; ?>