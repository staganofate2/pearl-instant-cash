<?php
session_start();
include_once"connect.php";
$sql = "SELECT id FROM notification WHERE account_no='{$_SESSION['account']}' AND red = '0' ";
	$query = mysqli_query($con,$sql)or die(mysqli_error($con));
	$numrows = mysqli_num_rows($query);
    if ($numrows >0) {
		echo $numrows;
	}
?>