<?php
session_start();
include_once('connect.php');
mysqli_real_escape_string($con,$amount=$_POST['amount']);
mysqli_real_escape_string($con,$type=$_POST['type']);
$que="select* from account where account_type='$type' and account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
if($row['interest']<$amount && $row['active']=="0"){
	echo "The amount you Entered is bigger than Your Withdrable Amount";
}
if($row['amount']<$amount && $row['active']=="1"){
	echo "The amount you Entered is bigger than You Total savings";
}
if($row['interest']>=$amount && $row['active']=="0"){
	echo "ok";
}
if((($row['amount']-$amount)>="0") && ($row['active']=="1")){
	echo "ok";
}
exit();


?>