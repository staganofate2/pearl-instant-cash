<?php
include"header.php";
$query="select amount,deposit_id from deposit where  paid='0' and account_no='{$_SESSION['account']}' and authorize='1' ";
$p=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
        $query="select* from wallet where  account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$query)or die(mysqli_error($con));
$rows=mysqli_fetch_array($res);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rows['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rows['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
			
		}
	}elseif($rows['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rows['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		}
	}elseif($rows['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rows['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
		}
	}elseif($rows['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rows['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		}
	}elseif($rows['category']=="Zenith"){
		if($amountt>=100000){
		echo	$bonus=($amountt*5)/100;
		echo 	$amounts=($rows['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		}
	}
        
        
    }
}

?>