<?php
session_start();;;
include_once("connect.php");
$query="select me.message from message me,conversation con  where con.usertwo='{$_SESSION['account']}' and me.red='0' and me.conversation_id=con.conversation_id";
$result=mysqli_query($con,$query) or die(mysql_error($con));
if(mysqli_num_rows($result)>0){
echo mysqli_num_rows($result);
}
?>