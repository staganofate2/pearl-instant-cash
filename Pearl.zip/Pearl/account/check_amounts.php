<?php
session_start();
include_once('connect.php');
$amount=mysqli_real_escape_string($con,$_POST['amount']);
$amount=str_replace(",","",$amount);

if($amount>=1000){
	echo "ok";
}else{
	
	echo "Deposit Amount should be at least N1000";
}
exit();



?>