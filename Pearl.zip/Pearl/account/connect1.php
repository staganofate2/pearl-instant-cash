<?php
$con=mysqli_connect("localhost","pearlin1_demo","staga09.09","pearlin1_demo") or die(mysqli_error($con));

?>