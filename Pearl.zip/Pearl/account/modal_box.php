 <style>
  /* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 100px;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% 0px 5% 10% ; /* 15% from the top and centered */
    padding: 5% ;
	
    border: 1px solid red;
    width: 85%; /* Could be more or less, depending on screen size */
	height:100%;
	background-color: rgba(0,0,0,0.3); /* Black w/ opacity */
}
#house img{
    max-width:80%;
    max-height:40%;
    margin-left:5%;
}
.modal-content p {
	
	
}
#house{
	background:white;
	width:50%;
	height:70%;
	padding:2%;
	margin:10% 15%;
	overflow:scroll;
}
p button{
	color:red;
	background:white;
}
/* The Close Button */
.close {
    color: #ff0000;
    float: right;
    font-size: 32px;
    font-weight: bolder;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
} 
 </style>
 <!-- Trigger/Open The Modal -->
<?php
$query="select* from standing where account_no='{$_SESSION['account']}' and status='1' ";
$res=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($res)>0){
		$rowss=mysqli_fetch_array($res);
		?>
	
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
  <div id='house' >
   <?php if($rowss['types']=="Simple"){
	   ?>
	   <h3><?php echo $rowss['subject'] ?></h3>
	  <div class='modalimage'> <?php if($rowss['image']!=''){?>
				<img  src='../<?php echo $rowss['image']; ?>' alt=''> <?php
				} 
				?></div>
    <p><?php echo $rowss['message'] ?></p>
	
	  <span class="close">&times;</span>
	  <p><button onclick="update()">Mark as Read</button></p>
   <?php
   }else{
	   ?>
	   <h3><?php echo $rowss['subject'] ?></h3>
	     <div class='modalimage'> <?php if($rowss['image']!=''){?>
				<img  src='../<?php echo $rowss['image']; ?>' alt=''> <?php
				} 
				?></div>
    <p><?php echo $rowss['message'] ?></p>
	   <a href='../personal/chats.php'>Contact Admin</a>
   <?php
   }
   ?>
	</div>
	
  </div>

</div> 

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal

    modal.style.display = "block";


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
} 
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_order.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert("Removed Successfully");
			if(ajax.responseText=="done"){
				document.location.reload(true);
			}
			
			
			
		}
	}
	ajax.send("id=<?php echo $rowss['standing_id']?>");
 
 }
</script>
<?php
	}
	?>