<?php
include"header.php";
include"modal_box.php";
$bar="index";
?>


<style>
  /* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add an active class to highlight the current page */
.active {
    background-color: #4CAF50;
    color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
    display: none;
} 
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}
@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive a.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
 </style>
 <script>

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
} 
</script>
<?php
include"sidebar.php";
?>
		
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Account Overview</h2>
				
			</div>
		</div><!--/.row--><hr>
		
		<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-8">
		<ul class='home'>
			
			<li><a href='index.php'>ACCOUNT</a> : online registered members are advised to create Targeted account  using  <a href='newacc.php'>ADD NEW ACCOUNT</a> to be able to belong the thrift department, because of the enormous benefit that are enshrined in saving with our institution example Interest on thrift savings, getting higher loan with reduced interest. To save in our thrift section your wallet must be funded through <a href='../wallet/deposit.php'>WALLET DEPOSIT</a> under MY WALLET before you can deposit into any account created in our thrift section. <br><strong class='text-danger'>Note :</strong> That as soon as fund is transfer to any of the account packages it is withdraw able after maturity.</li></ul>
		</div>
		</div><!--/.row-->
		
		<?php include"footer.php";
		?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		