<?php
session_start();
include_once('connect.php');

$type=$_POST['type'];

$que="select* from account where account_type='$type' and account_no='{$_SESSION['account']}' and active='1' and paid='0'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
$gtotal=$row['amount']+$row['interest'];
echo $row['maturity_date']."|".$row['start_date']."|".$row['amount']."|".$row['interest']."|".$gtotal."|".$row['interest']."|".$row['account_id']."|".$row['active'];
exit();



?>