<?php
session_start();
include_once('connect.php');

$type=$_POST['type'];

$que="select payment_structure,account_id from account where account_type='$type' and account_no='{$_SESSION['account']}' and active='0'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
$query="select amount from account_pay where account_id='".$row['account_id']."' and paid='0'";
$we=mysqli_query($con,$query)or die(mysql_error($con));
$s=mysqli_fetch_array($we);
echo $row['payment_structure']."|".$row['account_id']."|".$s['amount'];
exit();



?>