	<script src="../user/js/jquery-1.11.1.min.js"></script>
	<script src="../user/js/bootstrap.min.js"></script>
	<script src="../user/js/chart.min.js"></script>
	<script src="../user/js/chart-data.js"></script>
	<script src="j../user/s/easypiechart.js"></script>
	<script src="../user/js/easypiechart-data.js"></script>
	<script src="../user/js/bootstrap-datepicker.js"></script>
	<script src="../user/js/custom.js"></script>
	 <!-- DATA TABLE SCRIPTS -->
    <script src="../user/dataTables/jquery.dataTables.js"></script>
    <script src="../user/dataTables/dataTables.bootstrap.js"></script>
	 <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
		
<br><br><br><br>
				</div></div>
				
		
		
		</div>
		</div>
		</body>
</html>