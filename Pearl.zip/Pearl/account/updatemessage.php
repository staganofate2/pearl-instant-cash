<?php
session_start();
include_once("connect.php");
$query="select me.message, con.userone from message me,conversation con  where con.usertwo='{$_SESSION['account']}' and me.red='0' and me.conversation_id=con.conversation_id";
$result=mysqli_query($con,$query) or die(mysql_error($con));
if(mysqli_num_rows($result)>0){
	echo '<ul class="dropdown-menu dropdown-alerts">';
while($row=mysqli_fetch_array($result)){
	?>
	<li><a href="../personal/chat.php?receiver=<?php echo $row['userone'] ?> ">
								<div><em class=""><?php echo $row['userone'] ?></em>
									<span class="pull-right text-muted small"><?php echo $row['message'] ?></span></div>
							</a></li>
	
	<?php
}
echo "</ul>";
}
?>