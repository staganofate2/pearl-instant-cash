<?php
$con=mysqli_connect("localhost","pearlin1_onyeisi","papaukwu@..12mama","pearlin1_ugba") or die(mysqli_error($con));

?>