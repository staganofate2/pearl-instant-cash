<?php
include"header.php";
include"modal_box.php"; 
$bar="summary";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Account Summary</h4>
				<?php $query="select* from account where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				<p>Hi, <?php echo$row['firstname']." .. This is Your Account Summary";  ?>
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				
				<tr>
				<th>Account Type</th><th>Total Savings</th><th>Total Interest</th><th>Creation Date</th><th>Start Contribution Date</th><th>Maturity Date</th><th>Maturity Month</th><th>A/C Percentage</th><th>Status</th><th>Pay Out</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_type'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php echo $ree['start_date'] ?></td><td><?php echo $ree['maturity_date'] ?></td><td><?php echo $ree['maturity_month'] ?></td><td><?php echo $ree['account_interest'] ?></td><td><?php if($ree['active']=="0"){echo "Active";}else{echo "Matured";} ?></td><td><?php if($ree['paid']=="0" && $ree['active']=="1"){echo "<a href='withdraw.php'>Pay Out</a>";}elseif($ree['paid']=='1'){echo "Payed Out";}else{echo "Not Matured";} ?></td>
				
				
				</tr>
				<?php
				}
				?>
				
				
				</table>
				
				
				</div>
				<?php
				}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Account With Us. Click below to create one now</h4> 
				<p><a href="newacc.php">Create New Account </a> </p></center><br>
					<?php
				}
				?>
				
			<?php include "footer.php"; ?>