<?php
session_start();
include_once('connect.php');

$type=$_POST['type'];

$que="select* from account where account_type='$type' and account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
echo $row['payment_structure'];
exit();



?>