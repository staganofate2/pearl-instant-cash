
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	  <!-- DATA TABLE SCRIPTS -->
    <script src="../user/dataTables/jquery.dataTables.js"></script>
    <script src="../user/dataTables/dataTables.bootstrap.js"></script>
		<script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
<br><br><br><br>
				</div></div>
				
		
		
		</div>
		</div>
		</body>
</html>