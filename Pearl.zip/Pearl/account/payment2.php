<?php
include"header.php";
include"modal_box.php"; 
include"../function.php";
$bar="withdraw";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Pay Out  Slip</h4>
				<div class="col-md-8">
<?php	
if(isset($_POST['change'])){			
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['total']);
$amount=str_replace(",","",$amount);
$id=$_POST['id'];

	$query="select*  from account where account_no='{$_SESSION['account']}' and account_id='$id' and account_type='$actype' and active='1' and paid='0'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($rowss)>0){
$ers=mysqli_fetch_array($rowss);
$all=$ers['interest']+ $ers['amount'];
$interest=$ers['interest'];
	$query="update account set  wallet='$amount',interests='$interest',paid='1' where account_no='{$_SESSION['account']}' and account_id='$id' and account_type='$actype'";
mysqli_query($con,$query) or die(mysqli_error($con));
	$query="select total from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']+$amount;
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));
$ref =rand(100000,999999);
$description="$amount was debited from   your $actype Account";
$query="insert into account_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,account_id) values('Account','{$_SESSION['account']}','','$amount','0','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was credited  into your Wallet from $actype Account Pay Out";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Account','{$_SESSION['account']}','$amount','','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));



	

echo"<h3>Account Pay Out was Successful</h3><p class='error'>Please don't Resend  Again</p>";
}
}

?>

				
				
				</div>
				
					
					
			<?php include "footer.php"; ?>