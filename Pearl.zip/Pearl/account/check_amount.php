<?php
session_start();
include_once('connect.php');
$amount=mysqli_real_escape_string($con,$_POST['amount']);
$amount=str_replace(",","",$amount);

$que="select* from wallet where  account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
if($row['total']>=$amount){
	echo "ok";
}else{
	
	echo "The amount you Entered is bigger than Your Wallet Amount";
}
exit();



?>