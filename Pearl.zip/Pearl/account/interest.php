<?php
include"header.php";
include"modal_box.php"; 
$bar="interest";
?>
		
		
	<?php include "sidebar.php"; ?>
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Added Interest</h4>
				<?php $query="select* from account where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				<p>Hi, <?php echo$row['firstname']." .. This is Your Account Summary";  ?>
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				
				<tr>
				<th>Account Type</th><th>From Date-Date</th><th>Percentage</th><th>Interest</th><th>Amount</th><th>Maturity Month</th><th>Status</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_type'] ?></td><td><?php echo $ree['start_date']."<span style='color:lime'>=></span>".$ree['maturity_date'] ?></td><td><?php echo $ree['account_interest'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php echo $ree['maturity_month'] ?></td><td><?php if($ree['active']=="0"){echo "Active";}else{echo "Matured";} ?></td>
				
				
				</tr>
				<?php
				}
				?>
				
				
				</table>
				
				
				</div>
				<?php
				}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Account With Us. Click below to create one now</h4> 
				<p><a href="newacc.php">Create New Account </a> </p></center><br>
					<?php
				}
				?>
				
		
		
		
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("actype").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "myinterest.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("result").innerHTML = ajax.responseText;
			 
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 </script>
		
<?php include "footer.php"; ?>