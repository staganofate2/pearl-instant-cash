<?php
include"header.php";
include"modal_box.php"; 
include"../function.php";
$bar="deposit";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Deposit</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Deposit Slip</h4>
				<div class="col-md-8">
<?php	
if(isset($_POST['change'])){
    
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['amount']);
$account_id=$_POST['account_id'];
$amount=str_replace(",","",$amount);
$account_pay_id=$_POST['account_pay_id'];

$querys="select amount,deposit_id from deposit where  paid='0' and account_no='{$_SESSION['account']}' and authorize='1' ";
$p=mysqli_query($con,$querys)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
        $ref =rand(100000000,999999999);
         $query="select firstname,lastname,email_address,phone  from registeruser  where  account_number='{$_SESSION['account']}'";
$re=mysqli_query($con,$query)or die(mysqli_error($con));
$rs=mysqli_fetch_array($re);
$firstname=$rs['firstname'];
$lastname=$rs['lastname'];
$email=$rs['email_address'];
$phone=$rs['phone'];
        $quee="select* from wallet where  account_no='{$_SESSION['account']}'";
$resx=mysqli_query($con,$quee)or die(mysqli_error($con));
$rowsa=mysqli_fetch_array($resx);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rowsa['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rowsa['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
			
		}
	}elseif($rowsa['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rowsa['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rowsa['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Zenith"){
		if($amountt>=100000){
			$bonus=($amountt*5)/100;
		 	$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}
        
        
    }
}

$query="select total from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	if($rows['total']<$amount){
		echo "<h3 style='color:red'>The amount you want to pay is greater than your wallet balance</h3>";
	}else{
	
	$amounts=$rows['total']-$amount;
	
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));
if($account_pay_id !=""){
    
$query="select amount,total  from account where account_no='{$_SESSION['account']}' and account_id='$account_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update account set start_date=date(now()) where account_no='{$_SESSION['account']}' and account_id='$account_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$balance=$am-$ers['total'];
$query="update account set amount='$am' where account_no='{$_SESSION['account']}' and account_id='$account_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update account_pay set paid='1' where account_no='{$_SESSION['account']}' and account_pay_id='$account_pay_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
}else{
	$query="select amount,total  from account where account_no='{$_SESSION['account']}' and account_id='$account_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update account set start_date=date(now()) where account_no='{$_SESSION['account']}' and account_id='$account_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$balance=$am-$ers['total'];
$query="update account set amount='$am' where account_no='{$_SESSION['account']}' and account_id='$account_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select account_id  from account where account_no='{$_SESSION['account']}' and account_id='$account_id'";
$rowse=mysqli_query($con,$query) or die(mysqli_error($con));
while($erc=mysqli_fetch_array($rowse)){
	$query="update account_pay set paid='1' where account_no='{$_SESSION['account']}' and account_id='".$erc['account_id']."' and paid='0'";
mysqli_query($con,$query) or die(mysqli_error($con));
}
}

$ref =rand(100000,999999);
$description="$amount was credited into your $actype Account";
$query="insert into account_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,account_id) values('Account','{$_SESSION['account']}','$amount','','$balance','$ref','$description',now(),'$account_id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype  Account Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Account','{$_SESSION['account']}','','$amount','$amounts','$ref','$description',now(),'$account_id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select refer_id from refer_user  where account_no='{$_SESSION['account']}' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
echo"<h3>Account Deposit was Successful</h3><p class='error'>Please don't Resend  Again</p>";
		

}
}
}
?>

				
				
				</div>
				
					
					
				
				<br><br><br><br>
				</div></div>
				
				<div class="col-sm-12">
				
			</div>
		
		
		
		</div>
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	
		
</body>
</html>