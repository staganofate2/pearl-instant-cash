<?php
$result = array();
  
$url = "https://api.paystack.co/transfer/disable_otp";
$postdata =  array();
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4'

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);



$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
//Use the $result array to get redirect URL
}
?>