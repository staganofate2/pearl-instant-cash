<?php
$bar="signup";
include'header.php';
if(!isset($_SESSION['account'])){
	?>
	<script>window.location='login.php';</script>
	<?php
	exit();
}

?>


	
	<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  
  </script>
  
  
  <style>
                                                     *{
	                                                              margin:0;
	                                                                 padding:0;
                                                                                  }
																				  
#outputpix,#outputpix2{
	width:50%;
	height:130px;
	border-radius:20px;
	margin:10px;
}																				  
  </style>  
<?php

if ( isset( $_POST["step"] ) and $_POST["step"] >= 1 and $_POST["step"]<= 3 ) {
call_user_func( "processStep" . (int)$_POST["step"]);
} else {
displayStep1();
}
function setValue( $fieldName ) {
if ( isset( $_POST[$fieldName] ) ) {
echo $_POST[$fieldName];
}
}
function setChecked( $fieldName, $fieldValue ) {
if ( isset( $_POST[$fieldName] ) and $_POST[$fieldName] == $fieldValue ) {
echo ' checked="checked"';
}
}
function setSelected( $fieldName, $fieldValue ) {
if ( isset( $_POST[$fieldName] ) and $_POST[$fieldName] == $fieldValue ) {
echo ' selected="selected"';
}
}
function processStep1() {
if(isset($_POST['subone']) ){
	include'connect.php';
$firstname =sanitize($_POST['firstname']);
$firstname=escape($con,$firstname);
$lastname =sanitize($_POST['lastname']);
$lastname=escape($con,$lastname);
$title =sanitize($_POST['title']);
$title=escape($con,$title);
$middlename =sanitize($_POST['middlename']);
$middlename=escape($con,$middlename);
$phone =sanitize($_POST['phone']);
$phone=escape($con,$phone);

 $status=mysqli_real_escape_string($con,$_POST['status']);
$gender=mysqli_real_escape_string($con,$_POST['gender']);
$dob =sanitize($_POST['dob']);
$dob=escape($con,$dob);
$state =escape($con,$_POST['state']);
$lga =escape($con,$_POST['lga']);
$ostate =escape($con,$_POST['ostate']);

$pin =escape($con,$_POST['pin']);


$city =escape($con,$_POST['city']);

$address =escape($con,$_POST['address']);

 if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["files"])) {
 $fileTmpLoc = $_FILES["files"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["files"]["name"]);
$extension = end($temp);
if ((($_FILES["files"]["type"] == "image/gif")
|| ($_FILES["files"]["type"] == "image/jpeg")
|| ($_FILES["files"]["type"] == "image/jpg")
|| ($_FILES["files"]["type"] == "image/pjpeg")
|| ($_FILES["files"]["type"] == "image/x-png")
|| ($_FILES["files"]["type"] == "image/png"))
&& ($_FILES["files"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["files"]["error"] > 0) {
        echo "Return Code: " . $_FILES["files"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	$db_file_name="userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_name );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("image_resize.php");
	$target_file = $db_file_name;
	$resized_file = $db_file_name;
	$wmax = 400;
	$hmax = 400 ;                                                                                                                                                                                                                                          
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		$query="update registeruser set picture='$db_file_name' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	$query="insert into uploads(purpose,image,regdate,account_no) values('Profile Picture','$db_file_name',now(),'{$_SESSION['account']}')";
	mysqli_query($con,$query) or die(mysqli_error($con));
		
			
        }
    }
 else {
    echo "Invalid file";
}
}

$query="update registeruser set title='$title',firstname='$firstname',lastname='$lastname',middlename='$middlename',alt_phone='$phone',status='$status',gender='$gender',dob='$dob',state_res='$state',address='$address',lga='$lga',city_res='$city',state_origin='$ostate',pin='".sha1(md5($pin))."' where account_number='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));

	$query = "update registeruser set activated='1' where  account_number  ='{$_SESSION['account']}'";
								 mysqli_query($con,$query)or die(mysqli_error($con));
								 

$query="select refer_id from refer_user  where ip='$ip'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set signup='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}

unset($_SESSION['confirm']);
?>
<script>
window.location='personal/';
</script>
<?php
exit();

displayStep2();
}
}

function processStep2() {
	
if (isset($_POST["submit2"] ) && $_POST["submit2"] =="< Back" ) {
displayStep1(); 
} 

elseif(isset($_POST['subtwo']) ){
	include'connect.php';
$identification =escape($con,$_POST['identification']);
$id_no =escape($con,$_POST['id_no']);
$id_no=numchar($id_no);
$issue_date =escape($con,$_POST['issue_date']);
$exdate =escape($con,$_POST['exdate']);
$exdate=sanitize($exdate);
$institution =escape($con,$_POST['institution']);
$faculty =escape($con,$_POST['faculty']);
$department =escape($con,$_POST['department']);
$level =escape($con,$_POST['level']);
$level=sanitize($level);

$qualification =escape($con,$_POST['qualification']);

 
 if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["ufile"])) {
$fileName = $_FILES["ufile"]["name"];
 $fileTmpLoc = $_FILES["ufile"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["ufile"]["name"]);
$extension = end($temp);
if ((($_FILES["ufile"]["type"] == "image/gif")
|| ($_FILES["ufile"]["type"] == "image/jpeg")
|| ($_FILES["ufile"]["type"] == "image/jpg")
|| ($_FILES["ufile"]["type"] == "image/pjpeg")
|| ($_FILES["ufile"]["type"] == "image/x-png")
|| ($_FILES["ufile"]["type"] == "image/png"))
&& ($_FILES["ufile"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["ufile"]["error"] > 0) {
        echo "Return Code: " . $_FILES["ufile"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	$db_file_name="userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_name );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("image_resize.php");
	$target_file = $db_file_name;
	$resized_file = $db_file_name;
	$wmax = 400;
	$hmax = 400;                                                                                                                                                                                                                                         
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		$query="update registeruser set id_image='$db_file_name' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query)or die(mysqli_error($con));
		$query="insert into uploads(purpose,image,regdate,account_no) values('ID image','$db_file_name',now(),'{$_SESSION['account']}')";
	mysqli_query($con,$query) or die(mysqli_error($con));
			
        }
    }
 else {
    echo "Invalid file";
}
}
$query="update registeruser set id='$identification',department='$department',institution='$institution',levels='$level',id_no='$id_no',qualification='$qualification',issue_date='$issue_date',exp_date='$exdate',
faculty='$faculty' where account_number='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));
displayStep3();
}
}
function processStep3() {
	
if ( isset( $_POST["subm3"] ) ) {
displayStep2();
} 
elseif(isset($_POST['subthree']) ){
	include'connect.php';
$ntitle =escape($con,$_POST['ntitle']);

$kinname =escape($con,$_POST['kinname']);

$kinphone =escape($con,$_POST['kinphone']);
$kinphone=num($kinphone);
$relation =escape($con,$_POST['relation']);

$kinstate =escape($con,$_POST['kinstate']);
$pin =escape($con,$_POST['pin']);
$query="update registeruser set pin='".sha1(md5($pin))."',kin_title='$ntitle',kin_name='$kinname',kin_phone='$kinphone',kin_relationship='$relation',kin_state='$kinstate' where account_number ='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));


								$query = "update registeruser set activated='1' where  account_number  ='{$_SESSION['account']}'";
								 mysqli_query($con,$query)or die(mysqli_error($con));
								 

$query="select refer_id from refer_user  where ip='$ip'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set signup='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}

unset($_SESSION['confirm']);
?>
<script>
window.location='personal/';
</script>
<?php
exit();
}
}

function displayStep1() {
$mon=array("01"=>"JANUARY","02"=>"FEBRUARY","03"=>"MARCH","04"=>"APRIL","05"=>"MAY","06"=>"JUNE","07"=>"JULY","08"=>"AUGUST","09"=>"SEPTEMBER","10"=>"OCTOBER","11"=>"NOVEMBER","12"=>"DECEMBER");
$state=array("Abia","Abuja","Adamawa","Anambra","Akwa Ibom","Bauchi","Bayelsa","Benue","Borno","Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","Gombe","Imo","Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi","Kwara","Lagos","Nassarawa","Niger","Ondo","Ogun","Osun","Oyo","Plateau","Rivers","Sokoto","Taraba","Yobe","Zamfara");
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">New Account Registration</h4> 
				<p>Please register your account with us to take the benefit of our online E-Wallet facilities</p>
				<p class='text-warning'>Note: Fields mark with * are required</p>
				</center><br>
			
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="1" />

			<div class="col-md-3">
			<p>Select Your Profile Picture *</p>
			<img src="images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="files" id="ufile5" accept="image/*" onchange="loadFile(event)" required="" /><br>
			
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;color:red">Personal Information......</span><br><br>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Title *</span>
			<input type="text" name="title" class="form-control" placeholder="TITLE" required="" value="<?php if(isset($_POST["title"])){echo $_POST["title"];}  ?>" >
			</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">First Name *</span>
						<input type="text" name="firstname" value="<?php if(isset($_POST["firstname"])){echo $_POST["firstname"];}  ?>"class="form-control" placeholder="FIRSTNAME" required="" >
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Middle Name</span>
						<input type="text" name="middlename" value="<?php if(isset($_POST["middlename"])){echo $_POST["middlename"];}  ?>" class="form-control" placeholder="MIDDLENAME"  ><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Last Name *</span>
						<input type="text" name="lastname" value="<?php if(isset($_POST["lastname"])){echo $_POST["lastname"];}  ?>" class="form-control"  placeholder="LAST NAME" required="" ><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Alternate Phone Number</span>
						<input type="text" name="phone"value="<?php if(isset($_POST["phone"])){echo $_POST["phone"];}  ?>" class="form-control"  placeholder="ALTERNATE PHONE NUMBER" ><br>
</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Gender *</span>
						<select name="gender" class="form-control"  required="">
						<option value="">----Select Gender---</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
						</select></div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Marital Status *</span>
						<select name="status" class="form-control"  required="">
						<option value="">----Select Marital Status---</option>
						<option value="Single">Single</option>
						<option value="Married">Married</option>
						<option value="Divorced">Divorced</option>
						</select></div>
			<div class='form-group'>
			 <span class="badge" style="background-color:#3385FF;">Birth Date *</span><br><br>
						 <input type='date' name="dob" required  class="form-control">
 
</div>
			
		   <span class="badge" style="background-color:#3385FF;color:red">Address Information......</span><br><br>
						
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Home Address *</span>
						<input type="text" name="address"value="<?php if(isset($_POST["address"])){echo $_POST["address"];}  ?>" class="form-control" placeholder=" RESSIDENCE ADDRESS" required=""><br>
						</div>
		
			
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">City *</span>
						<input type="text" name="city" value="<?php if(isset($_POST["city"])){echo $_POST["city"];}  ?>"class="form-control" placeholder="CITY NAME" required=""><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">State of Residence *</span>
						<select name="state" class="form-control"  required="">
						<option value="">----Select State---</option>
						<?php foreach($state as $states){
							echo"<option value='".$states."'>".$states."</option>"; }?>
						
						</select>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">L.G.A  *</span>
						
						<input type="text" name="lga"value="<?php if(isset($_POST["lga"])){echo $_POST["lga"];}  ?>" class="form-control" placeholder="HOME LGA" required=""><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">State of Origin *</span>
						<select name="ostate" class="form-control"  required="">
						<option value="">----Select State---</option>
						<?php foreach($state as $states){
							echo"<option value='".$states."'>".$states."</option>"; }?>
						
						</select></div>
		<span class="badge" style="background-color:#3385FF;color:red">PAYMENT PIN ......</span><br><br>
						
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Payment Pin *</span>
						<input type="password" name="pin" class="form-control" onBlur="checkpin()" id="pin1"  placeholder="PAYMENT PIN" required="">
						
					</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Confirm Payment Pin *</span>
						<input type="password" name="verifypin" class="form-control" id='pin2'placeholder="VERIFY PAYMENT PIN" required=""><br>
						<span id="pin-availability-status"></span>
						

</div>

<input type="submit" name="subone" id="nextButton" class="btn btn-info" value="SAVE AND CONTINUE &gt;" /><br/>



</form>
	</div> 
			
			</div>
			
			
			
			
			</div></div>

<?php
}
function displayStep2() {
	$mon=array("01"=>"JANUARY","02"=>"FEBRUARY","03"=>"MARCH","04"=>"APRIL","05"=>"MAY","06"=>"JUNE","07"=>"JULY","08"=>"AUGUST","09"=>"SEPTEMBER","10"=>"OCTOBER","11"=>"NOVEMBER","12"=>"DECEMBER");
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">New Account Registration</h4> 
				<p>Please register your account with us to take the benefit of our online E-Wallet facilities</p></center><br>
			<p class='text-warning'>Note: Fields mark with * are required</p>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="2" />

			<div class="col-md-3">
			<p>Upload Means of Identification *</p>
			<img src="images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile" id="ufile5" accept="image/*" onchange="loadFile(event)" required="" /><br>
			
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;color:red">Identification Information ......</span><br><br>
									
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Means of Identification *</span>
						<select name="identification" class="form-control"  required="">
						<option value="">----Select Identification ---</option>
						<option value="National ID">National Id-card </option>
						<option value="Driver License">Driver License</option>
						<option value="Voters Card">Voters Card</option>
						<option value="International Passport">International Passport</option>
						<option value="Others">Others</option>
						</select></div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">ID Number *</span>
						<input type="text" name="id_no"value="<?php if(isset($_POST["id_no"])){echo $_POST["id_no"];}  ?>" class="form-control" placeholder="ID NUMBER" ><br>
						</div><div class='form-group'><span class="badge" style="background-color:#3385FF;">Issued Date</span><br><br>
						 <input type='date' name="issue_date" required  class="form-control">
</div>
<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate"   class="form-control">
 
</div>
						
						
			<span class="badge" style="background-color:#3385FF;color:red">Educational Qualification ......</span><br><br>
									
					
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Qualification</span>	<select name="qualification" class="form-control"  >
						<option value="">----Select Qualification ---</option>
						<option value="SSEC">SSCE </option>
						<option value="ND">ND</option>
						<option value="HND">HND</option>
						<option value="BSc">BSc</option>
							<option value="Other">Others</option>
						</select></div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Institution</span>
			<?php
$school=array('Abia State University',' 	Abubakar Tafawa Balewa University 	','Achievers University, Owo 	',' Adamawa State University 	',' 	Adekunle Ajasin University 	Akungba Akoko ',' 	Adeleke University 	Ede',' 	Afe Babalola University 	Ado-Ekiti',' 	African University of Science and Technology 	Abuja',' 	Ahmadu Bello University 	Zaria',' 	Ajayi Crowther University 	Oyo ',' 	Akwa Ibom State University 	',' 	Al-Hikmah University 	Ilorin ','	Al-Qalam University, Katsina 	',' 	Ambrose Alli University 	Ekpoma',' 	American University of Nigeria 	Yola',' 	Anchor Univeristy, Lagos 	','	Arthur Jarvis University ',	' 	Augustine University 	Ilara',' 	Babcock University 	Ilishan-Remo ',' 	Bauchi State University 	Gadau ',' 	Bayero University Kano 	',' 	Baze University 	Abuja',' 	Bells University of Technology 	Ota','	Benson Idahosa University 	Benin ',' 	Benue State University 	',' 	Bingham University 	Auta Balifi','Un 	Borno State University 	',' 	Bowen University 	Iwo',' 	Caleb University 	Imota',' 	Caritas University 	Enugu','	Chrisland University 	Abeokuta',' 	Chukwuemeka Odumegwu Ojukwu University 	Uli',' 	Clifford University 	Ihie',' 	Coal City University 	Enugu','	Covenant University 	Ota',' 	Crawford University 	Igbesa',' 	Crescent University, Abeokuta 	',' 	Cross River University of Technology  ',' 	Crown Hill University 	Ilorin',' 	Delta State University, Abraka 	',' 	Dominican University, Ibadan 	',' 	Eastern Palm University 	Ogboko','	Ebonyi State University 	',' 	Edo University 	Iyamho',' 	Edwin Clark University 	Kiagbodo',' 	Ekiti State University, Ado Ekiti 	',' 	Eko University of Medical and Health Sciences 	',' 	Elizade University 	Ilara-Mokin',' 	Enugu State University of Science and Technology ','Un 	Evangel University Akaeze 	Enugu',' 	Federal University of Agriculture, Abeokuta  ',' 	Federal University of Petroleum Resources 	Effurun',' 	Federal University of Technology, Akure 	','	Federal University of Technology, Minna 	 ',' 	Federal University of Technology, Owerri 	',' 	Federal University, Birnin Kebbi 	',' 	Federal University, Dutse 	',' 	Federal University, Dutsin-Ma 	',' 	Federal University, Gashua 	',' 	Federal University, Gusau 	',' 	Federal University, Kashere 	',' 	Federal University, Lafia 	',' 	Federal University, Lokoja 	',' 	Federal University, Ndufu-Alike ',' 	Federal University, Otuoke 	','	Federal University, Oye-Ekiti 	 ',' 	Federal University, Wukari 	',' 	Fountain University 	Oshogbo',' 	Godfrey Okoye University 	Ugwuomu-Nike','	Gombe State University 	Gombe','Un 	Gombe State University of Science and Technology 	',' 	Gregory University, Uturu 	',' 	Hallmark University, Ijebu-Itele 	',' 	Hezekiah University 	Umudi',' 	Ibrahim Badamasi Babangida University 	Lapai',' 	Igbinedion University Okada 	Okada ',' 	Ignatius Ajuru University of Education 	Port Harcourt',' 	Imo State University 	',' 	Joseph Ayo Babalola University 	Ikeji-Arakeji',' 	Kaduna State University 	',' 	Kano University of Science and Technology 	',' 	Kebbi State University of Science and Technology 	',' 	Kings University 	Odeomu',' 	Kogi State University 	','	Kola Daisi University 	Ibadan',' 	Kwara State University 	',' 	Kwararafa University Wukari 	',' 	Ladoke Akintola University of Technology 	Ogbomoso ',' 	Lagos State University 	',' 	Landmark University 	Omu-Aran',' 	Lead City University 	Ibadan','	Madonna University, Okija 	 ',' 	Mcpherson University 	Seriki-Sotayo',' 	Michael and Cecilia Ibru University 	Agbara-Otor',' 	Michael Okpara University of Agriculture 	Umuahia',' 	Modibbo Adama University of Technology 	Yola',' 	Mountain Top University 	Makogi Oba',' 	Nasarawa State University 	',' 	Niger Delta University 	Wilberforce Island',' 	Nile University of Nigeria 	Abuja',' 	Nnamdi Azikiwe University 	Awka ',' 	Northwest University Kano 	',' 	Novena University 	Ogume','	Obafemi Awolowo University 	Ile-Ife','Un 	Obong University 	Obong Ntak',' 	Oduduwa University 	Ile Ife',' 	Olabisi Onabanjo University 	Ago Iwoye ',' 	Ondo State University of Science and Technology 	Okitipupa',' 	Osun State University 	Oshogbo ',' 	Pan African University 	Lagos',' 	Paul University 	Awka',' 	Plateau State University 	Bokkos',' 	Redeemer\'s University 	Mowe',' 	Renaissance University 	Enugu',' 	Rhema University 	Aba ',' 	Ritman University 	Ikot Ekpene','	Rivers State University of Science and Technology 	','Un 	Salem University 	Lokoja',' 	Samuel Adegboyega University 	Ogwa ','	Sokoto State University 	Sokoto',' 	Southwestern University, Nigeria 	',' 	Sule Lamido University 	Kafin Hausa','	Summit University Offa 	Offa','	Tai Solarin University of Education 	Ijebu-Ode ','	Tansian University 	Umunya ','Taraba State University 	','	The Technical University 	Ibadan',' 	Umaru Musa Yar\'Adua University ','	University of Abuja 	','Un 	University of Africa 	Toru-Orua ',' 	University of Agriculture, Makurdi ',' 	University of Benin 	','University of Calabar','	University of Ibadan ','University of Ilorin ','	University of Jos','	University of Lagos ','	University of Maiduguri ','	University of Medical Sciences 	Ondo','University of Mkar','University of Nigeria 	Nsukka','University of Port Harcourt ','University of Uyo 	','Usmanu Danfodio University','Veritas University','Wellspring University ','Wesley University of Science and Technology','Western Delta University','Yobe State University');
?>
						<select name="institution" class="form-control"  >
						<option value="">----Select Institution ---</option>
						
						<?php foreach($school as $sch){echo "<option value='$sch'>$sch</option>";}?>
						</select></div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Department</span>
						
					<input type="text" name="department"value="<?php if(isset($_POST["department"])){echo $_POST["department"];}  ?>" class="form-control" placeholder="DEPARTMENT" ><br>
					</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Faculty</span>
			<input type="text" name="faculty"value="<?php if(isset($_POST["faculty"])){echo $_POST["faculty"];}  ?>" class="form-control" placeholder="FACULTY"  ><br>
					</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Level</span>
					<input type="text" name="level" value="<?php if(isset($_POST["level"])){echo $_POST["level"];}  ?>"class="form-control" placeholder="LEVEL" ><br>
</div>
<input type="submit" name="submit2" class="btn btn-info" id="nextButton"value="&lt; Back" style="margin-right: 20px;" />
<input type="submit" name="subtwo" class="btn btn-info" id="nextButton" value="SAVE AND CONTINUE &gt;" />


</form>
</div> 
			
			</div>
			
			
			
			
			</div></div>
<?php
}
function displayStep3() {
	$state=array("Abia","Abuja","Adamawa","Anambra","Akwa Ibom","Bauchi","Bayelsa","Benue","Borno","Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","Gombe","Imo","Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi","Kwara","Lagos","Nassarawa","Niger","Ondo","Ogun","Osun","Oyo","Plateau","Rivers","Sokoto","Taraba","Yobe","Zamfara");
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">New Account Registration</h4> 
				<p>Please register your account with us to take the benefit of our online E-Wallet facilities</p></center><br>
			<p class='text-warning'>Note: Fields mark with * are required</p>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="3" />

			<div class="col-md-3">
		
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;color:red">Next Of Kin ......</span><br><br>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Next of Title  *</span>
			<input type="text" name="ntitle"value="<?php if(isset($_POST["ntitle"])){echo $_POST["ntitle"];}  ?>" class="form-control" placeholder="TITLE" required="" ><br>
			</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Next Of Kin Full Name *</span>
			<input type="text" name="kinname"value="<?php if(isset($_POST["kinname"])){echo $_POST["kinname"];}  ?>" class="form-control" placeholder="NEXT OF KIN NAME" required="" ><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Next Of Kin Phone *</span>
						<input type="text" name="kinphone" value="<?php if(isset($_POST["kinphone"])){echo $_POST["kinphone"];}  ?>"class="form-control"  placeholder="NEXT OF KIN PHONE NUMBER" required=""><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Next Of Kin Relationship *</span>
						<input type="text" name="relation" value="<?php if(isset($_POST["relation"])){echo $_POST["relation"];}  ?>"class="form-control"  placeholder="RELATIONSHIP" required=""><br>
						</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Next of Kin State of Origin *</span>
						<select name="kinstate" class="form-control"  required="">
						<option value="">----Select State---</option>
						<?php foreach($state as $states){
							echo"<option value='".$states."'>".$states."</option>"; }?>
						
						</select>
						</div>

						<span class="badge" style="background-color:#3385FF;color:red">PAYMENT PIN ......</span><br><br>
						
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Payment Pin *</span>
						<input type="password" name="pin" class="form-control" onBlur="checkpin()" id="pin1"  placeholder="PAYMENT PIN" required="">
						
					</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Confirm Payment Pin *</span>
						<input type="password" name="verifypin" class="form-control" id='pin2'placeholder="VERIFY PAYMENT PIN" required=""><br>
						<span id="pin-availability-status"></span>
						

</div>
<input type="submit" name="subm3" class="btn btn-info" id="nextButton"value="&lt;Back" style="margin-right: 20px;" />
<input type="submit" name="subthree" class="btn btn-info" id="nextButton" value="FINISH &gt;" />


</form>
</div> 
			
			</div>
			
			
			
			
			</div></div>
			<script>
			function checkpin(){
			var pass=document.getElementById('pin1').value;
			
			var cpass=document.getElementById("pass2").value;
			
			if(pass===cpass){
				document.getElementById('pin-availability-status').innerHTML="";
				document.getElementById('nextButton').style.display="inline";
				
				
			}else{
				document.getElementById('nextButton').style.display="none";
				document.getElementById('pin-availability-status').innerHTML="PIN Mismatch";
			}
		}
			</script>
<?php
}
?>



<?php include"footer.php";
?>