<?php
$bar='signup';
include'header.php';

?>

<style>

table.table  tr td{
	color:black;
	font-weight:bold;
	font-size:16px;
}
</style>	
	
	
	
	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l"></h4> 
				
				<p>WALLET DEPOSIT</p></center><br>
			</div> 
			
			<div class="row">
			

			
			
			<div class="col-md-2">
			
			
			</div>
			<div class="col-md-10">
			
			
<?php	
if(isset($_POST['change'])){			

$account =escape($con,$_POST['account']);
$phone =escape($con,$_POST['phone']);
$email =escape($con,$_POST['email']);
$firstname =escape($con,$_POST['firstname']);
$lastname =escape($con,$_POST['lastname']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$amount=sanitize($amount);
 $amountt=$amount.".00";

$ref =rand(100000000,999999999);
$query="insert into deposit  (ref_no,amount,method,regdate,account_no,category,confirmed) values('$ref','$amount','Instant',now(),'$account','Wallet','1')";
mysqli_query($con,$query)or die(mysqli_error($con));
$id=mysqli_insert_id($con);

	$query="insert into paystackthree(account_no,ref_no,amount,deposit_id,regdate)values('$account','$ref','$amount','$id',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
	$fee=($amount*1.5)/100;
	$total=$amount+$fee;

	if(preg_match("/\.+/",$total)){
	$amounts=str_replace(".","",$total);
					$amounts=$amounts."0";
	}else{
		$amounts=$total."00";
	}
	?>
	<center><h4 class="h3-w3l">Thank You</h4> 
				<p><b>Reference NO:  <?php echo $ref ?></b><br>
				Amount:  N<?php echo $amount ?> <br>
				Service Charge : N<?php echo $fee ?><br>
				Total : N<?php echo $total ?></p></center><br>
				
  
				
				
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <button type="button" onclick="payWithPaystack()" class='btn btn-info'> Pay Now </button> 
</center><br>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $email ?>',
      amount: '<?php echo $amounts ?>',
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $firstname ?>',
      lastname: '<?php echo $lastname ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $phone ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "account_update.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
		window.location='login.php';	
			 
			
			
		}
	}
	ajax.send("ref="+response+"&account=<?php echo $account ?>");
 
 
  }
</script>
  
	<?php




				}
?>

				
				
				
				
				</div>
				
				</div>	
					</div>
					
		
	<?php include"footer.php";
?>