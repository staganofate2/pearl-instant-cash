<?php
session_start();
include 'connect.php';
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PEARL Admin- Login</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">Log in</div>
				<div class="panel-body">
					<form role="form" action="" method="POST">
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="Username" name="user" type="text" autofocus="" required>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="pass" type="password"  required>
							</div>
							<div class="checkbox">
								<label>
									<input name="remember" type="checkbox" value="Remember Me">Remember Me
								</label>
							</div>
							<button class="btn btn-primary" name="sub"> Login</a></fieldset>
					</form>
					
					
					
					<?php
      if (isset($_POST['sub'])){
								
								
								$user = $_POST['user']or die('please enter a valid username');
								$password = $_POST['pass']or die('please enter a valid password');
								$query = "select * from adminpanels where  password='".mysqli_real_escape_string($con,$password)."' AND username='".mysqli_real_escape_string($con,$user)."' ";
								$result = mysqli_query($con,$query)or die(mysqli_error($con));
                                $row = mysqli_fetch_array($result);
								$num_row = mysqli_num_rows($result);
									
									if( $num_row > 0 ) {
										
										$_SESSION['passi']=$row['password'];								
																		

										echo "<meta http-equiv='Refresh' content='1; url=dashboard.php'>";
										
									}
									else{ 
								echo "<script>alert('Invalid Username or Password! ')</script>";
								echo "<p style='color:red;'>You are not  admin!</p>";
								}
								}
								
?>
			
					
					
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
	

<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
