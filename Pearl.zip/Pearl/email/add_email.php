<?php
include"header.php";
$bar="dashboard";
?>

        
 <?php include"sidebar.php" ?>       
<!--
        <link rel="icon" type="image/ico" href="assets/image/logo2.png">

        <link rel="stylesheet" href="cs/bootstrap.css" type="text/css">
        <link rel="stylesheet" href="cs/font-awesome.css" type="text/css">
        <link rel="stylesheet" href="cs/style.css" type="text/css">

        <link href="css/cs.css" rel="stylesheet" type="text/css">

        
    <link href="css/summernote.css" rel="stylesheet">-->
    


       
        

  
       
        

    
        
     <!--   <div class="container">
            <div class="row">
            
    <div class="col-md-10 col-md-offset-1">-->
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Send Email</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">add Emails</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-8 ">
 <h4 class="page-header">Add Email  Form</h4>
 <?php 
				if(isset($_POST['submit'])){
				$email=mysqli_real_escape_string($con,$_POST['email']);
				if(strlen($email)==(strrpos($email,",")+1)){
					$phone=substr_replace($email,"",-1);
				}
				
				
					if(preg_match("/,/",$email)){
				
				$x=explode(",",$email);
				
				for($i=0;$i<(count($x));$i++){
				
				   $query="select* from email where email='".$x[$i]."'";
				   $res=mysqli_query($con,$query) or die(mysqli_error($con));
				   if(mysqli_num_rows($res)>0){
					    echo "<h3 style='color:red'>Email Exist</h3>";
				   }else{
					$query="insert into email (email) values('".$x[$i]."')";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
				
			   echo "<h5 style='color:red'>Email Added successfully</h5>";
				}}}else{
					 $query="select* from email where email='$email'";
				   $res=mysqli_query($con,$query) or die(mysqli_error($con));
				   if(mysqli_num_rows($res)>0){
					    echo "<h3 style='color:red'>Email Exist</h3>";
				   }else{
					$query="insert into email (email) values('$email')";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
				
			   echo "<h5 style='color:red'>Email Added successfully</h5>";
				}
				 echo "<h5 style='color:red'><a href='add_email.php'>Add Again</a></h5>";
				}
				}
				else{
			   ?>
			    <!--div id="imageresult"></div>
	<button id="statu_img_but">Add images</button>-->
        <form  action="" method="post" enctype="multipart/form-data" class="f12">
            
                	<input type='hidden' name='image' id='post' value=''>
            
            <div class="f1-steps">
               
            </div>

            

            <field/set style="display: block;">
               
                
							
							
							
							
                            
               <div id='loaders'></div>

                <div class="form-group ">
                   <textarea class="form-control" placeholder="ENTER YOUR MESSAGE" name="email" required></textarea>
                </div>

               
            
                

                <br class="clear clearfix"><br>

                <div class="f1-buttons">
                    
                    
                    <input type="submit" name="submit"  class="btn btn-lg btn-info btn-uga btn-submit" value="Send">
                </div>
				
            
        </form>
   <?php
				}
				?>
				<br>
				<br>
    
   </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>

       <script type="text/javascript" src="cs/jquery.js"></script>
		
        <script type="text/javascript" src="cs/bootstrap.js"></script>
        <script type="text/javascript" src="cs/bootstrap3-typeahead.js"></script>
       <script type="text/javascript" src="cs/app.js"></script>
        
    <script src="cs/summernote.js"></script>
  
   <script type="text/javascript">
        function scroll_to_class(element_class, removed_height) {
            var scroll_to = $(element_class).offset().top - removed_height;
            if($(window).scrollTop() != scroll_to) {
                $('html, body').stop().animate({scrollTop: scroll_to}, 0);
            }
        }

        function bar_progress(progress_line_object, direction) {
            var number_of_steps = progress_line_object.data('number-of-steps');
            var now_value = progress_line_object.data('now-value');
            var new_value = 0;
            if(direction == 'right') {
                new_value = now_value + ( 100 / number_of_steps );
            }
            else if(direction == 'left') {
                new_value = now_value - ( 100 / number_of_steps );
            }
            progress_line_object.attr('style', 'width: ' + new_value + '%;').data('now-value', new_value);
        }

        $(document).ready(function() {

            insertAxises();

            
                $('.f1 fieldset:first').fadeIn('slow');
            


            $('.f1 input[type="text"], .f1 input[type="password"], .f1 select').on('focus', function() {
                $(this).removeClass('input-error');
            });

            // next step
            $('.f1 .btn-next').on('click', function() {
                var parent_fieldset = $(this).parents('fieldset');
                var next_step = true;
                // navigation steps / progress steps
                var current_active_step = $(this).parents('.f1').find('.f1-step.active');
                var progress_line = $(this).parents('.f1').find('.f1-progress-line');

                // fields validation
                parent_fieldset.find('input[type="text"], input[type="password"], input[type="hidden"], select').each(function() {
                    if( $(this).val() == "" && $(this).attr("required") == "required") {
                        $(this).addClass('input-error');
                        next_step = false;
                    } else {
                        $(this).removeClass('input-error');
                    }
                    var value = $(this).val().split(",").join("");
                    if($(this).attr("id") == "price" && isNaN(value)) {
                        $(this).addClass('input-error');
                        next_step = false;
                        alert("Price must be a number e.g 300000 (comma is added for you)")
                    }
                });
                // fields validation

                if( next_step ) {
                    parent_fieldset.fadeOut(400, function() {
                        // change icons
                        current_active_step.removeClass('active').addClass('activated').next().addClass('active');
                        // progress bar
                        bar_progress(progress_line, 'right');
                        // show next step
                        $(this).next().fadeIn();
                        // scroll window to beginning of the form
                        scroll_to_class( $('.f1'), 100 );
                    });
                }
            });

            // previous step
            $('.f1 .btn-previous').on('click', function() {
                // navigation steps / progress steps
                var current_active_step = $(this).parents('.f1').find('.f1-step.active');
                var progress_line = $(this).parents('.f1').find('.f1-progress-line');

                $(this).parents('fieldset').fadeOut(400, function() {
                    // change icons
                    current_active_step.removeClass('active').prev().removeClass('activated').addClass('active');
                    // progress bar
                    bar_progress(progress_line, 'left');
                    // show previous step
                    $(this).prev().fadeIn();this
                    // scroll window to beginning of the form
                    scroll_to_class( $('.f1'), 100 );
                });
            });

            // submit
            $('.f1').on('submit', function(e) {
                // fields validation
                $(this).find('input[type="text"], input[type="password"], select').each(function() {
                    if( $(this).val() == "" && $(this).attr("required") == "required") {
                        e.preventDefault();
                        $(this).addClass('input-error');
                    }
                    else {
                        $(this).removeClass('input-error');
						alert("nofate")
                    }
                });
                // fields validation
            });

            $('#description').summernote();


        });

    </script>


         <script type="text/javascript">

            function hideAlert(){
                $.ajax({
                    type: "POST",
                    url : '/hideAlertModal',
                    complete : function(){
                    }
                });
            }

            $(document).ready(function() {
                //increase the size of post property request panel close button
                $("#alert-panel button.close").css("font-size","35px");
                $("#alert-panel2 button.close").css("font-size","35px");

                

                $('body').on('click', '.radioBtn button', function() {
                    var sel = $(this).data('title');
                    var tog = $(this).data('toggle');
                    $(this).parent().next('.' + tog).prop('value', sel);
                    $(this).parent().find('button[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
                    $(this).parent().find('button[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
                });

                $('.confirm').click(function(e){
                    if(confirm("Are You sure?")){
                        $("#ajaxWait").show();
                        $.ajax({
                            type: "POST",
                            url : $(this).attr("href"),
                            complete : function(){
                                window.location.reload();
                            }
                        });
                    }
                    e.preventDefault();
                });

                $('.confirm2').click(function(e){
                    if(confirm("Are You sure?")){
                        $("#ajaxWait").show();
                        $.ajax({
                            type: "POST",
                            url : $(this).attr("data-href"),
                            success: function(data) {
                                if(data!=="success") {
                                    alert(data);
                                }
                            },
                            complete : function(){
                                window.location.reload();
                            }
                        });
                    }
                    e.preventDefault();
                });

                $("#subscribe-btn").click(function(){
                    $('#info-box').html("");
                    $('#ajaxWait').show();
                    $.ajax({
                        type: 'POST',
                        url: $("#newsletterForm").attr("action"),
                        data: $("#newsletterForm").serialize(),
                        success: function(data) {
                            if(data==="success") {
                                $("#info-box").html("You have successfully subscribed to our home recommendation mailing list");
                            } else {
                                $("#info-box").html(data);
                            }
                            $("#ajaxWait").hide();
                            $('#info-modal').modal('show');
                        }
                    });
                    return false;
                });

                $("a[href='#top']").click(function() {
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                    return false;
                });

                $(window).scroll(function(e) {
                    checkScrollLocation();
                });

                $(window).load(function(e) {
                    checkScrollLocation();
                });

                $(".alert2-btn").click(function(){
                    var valid = true;
                    var form = $(this).parents("form");
                    form.find("input").each(function(){
                        if($(this).val().length === 0 && $(this).attr("required") === "required") {
                            $(this).addClass('error');
                            valid = false;
                        } else {
                            $(this).removeClass('error');
                        }
                    });
                    if(!valid) {
                        alert("Please enter your name and email address");
                        return;
                    }
                    $("#ajaxWait").show();
                    $.ajax({
                        type: 'POST',
                        url: form.attr("action"),
                        data: form.serialize(),
                        success: function(data) {
                            if(data==="success") {
                                alert("You have successfully subscribed");
                            } else if(data==="already") {
                                alert("You have already subscribed to this search");
                            } else {
                                alert(data);
                            }
                            $("#ajaxWait").hide();
                            $('#alert-panel').slideUp();
                        }
                    });
                    return false;
                });

                $('.close-alert-panel').click(function(e){
                    hideAlert();
                    $('#alert-panel').slideUp();
                });

                $('.hide-alert-panel').click(function(e){
                    hideAlert();
                    $('#alert-panel').slideUp();
                });

                $.get('/areas.json', function(data){
                    $(".searchInput").typeahead({ source:data });
                },'json');

                $("#nav-expo img").click(function(e) {
                    window.open('/expo', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
                });

                $("#nav-expo .expo-img span").click(function(e) {
                    $.get( "/hideExpoStrip", function(data) {
                    });
                    $("#nav-expo").slideUp('slow');
                });

                $("#jumiatolet .clicktoread").click(function(e) {
                    window.open('/blog/nigeria-uga-com-ng-acquires-jumia-house-nigeria/', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
                });

                
                    $(".push-header").css("height", "86px");
                

                $("#jumiatolet span").click(function(e) {
                    $.get( "/hideJumiaStrip", function(data) {
                    });
                    $("#jumiatolet").slideUp('slow');
                    $(".push-header").css("height", "50px");
                });


            });

            function checkScrollLocation(){
                scrollTop=$(window).scrollTop();
                intro=$('#brand').height()-70;
                if($("#header-navigation").hasClass('home')){
                    if(scrollTop > intro){
                        $('#header-navigation').fadeIn(500);
                    }
                    else{
                        $('#header-navigation').fadeOut(500);
                    }
                }
            }

            /*******************coverage collapse*******************/
            $('.collapse').on('show.bs.collapse', function (src) {
                $('#search-filter-btn').text('Close Filter');
            });


            $('.collapse').on('hidden.bs.collapse', function (src) {
                $('#search-filter-btn').text('Refine Search');
            });

        </script>
        
   

<script>
		function update(){
				var target=document.getElementById("target").value;
				if(target=="Individual"){
					document.getElementById("results").innerHTML='<input class="form-control" placeholder="Email Address" name="email" type="text" required>';
				}else{
					document.getElementById("results").innerHTML="";
				}
				
			}
			
			function submitForm() {
            //console.log("submit event");
            	var b=document.getElementById("loaders").style.display="block";
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploadd.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                	var b=document.getElementById("loaders").style.display="none";
                $('#result').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#result img').attr('src','../'+data);
				$('#post').val(data);
				
				//alert(data);
				
				
            });
            return false;
        }
		
		$('document').ready(function(){$('#statu_img_but').click(function(){$('#imageresult').load('status_image.php');});}); 
		</script>













</body></html>