<?php
session_start();
include"connect.php";
$query="select* from send_emails where sent='0'";
$x=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($x)>0){
while($er=mysqli_fetch_array($x)){
$email=$er['email'];
$id=$er['sends_email_id'];
$compose_id=$er['compose_id'];
 $query="select message,subject from compose where compose_id='$compose_id'";
 $er=mysqli_query($con,$query) or die(mysqli_error($con));
 $f=mysqli_fetch_array($er);
  $subject=$f['subject'];
 $messages=$f['message'];

$message = '<html><body>';

$message .= '<table  border="0" cellpadding="10">';

$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%">';

$message.='</td></tr>';
$message .= "<tr style='background: #eee;'><td><strong>Dear  </strong> " . strip_tags($email) . "</td></tr>";
$message .= "<tr><td><p> $messages </p></td></tr>";



$message .= "</table>";
$message .= "</body></html>";

$to = "$email";


$headers = "From: info@siteinstantcash.com\r\n";
$headers .= "Reply-To:info@siteinstant.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $message, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
				

$query="update send_emails set sent='1',sent_date=now() where sends_email_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

}
}

?>