<!-------------------------------------the side nav bar here-------------------------------------->
		
		<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		
		<div class="divider"></div>
		
		<ul class="nav menu">
			<li <?php if($bar=="dashboard"){echo 'class="active"'; }?>><a href="dashboard.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			
		<li <?php if($bar=="add"){echo 'class="active"' ; }?>><a href="add_email.php"><em class="fa fa-bar-chart">&nbsp;</em>Add email</a></li>
		<li <?php if($bar=="send_email"){echo 'class="active"' ; }?>><a href="send_email.php"><em class="fa fa-bar-chart">&nbsp;</em>send Email</a></li>
							
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
			
			
		</ul>
	</div><!--/.sidebar-->
	<script>
	function popitup(url) {
      
	   newwindow=window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=400,left=400,width=600,height=500"); 
       if (window.focus) {newwindow.focus()}
       return false;
     }
</script>