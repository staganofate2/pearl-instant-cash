
		
		
	

		
		
		</div>
		
		
	
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
           $(document).ready(function () {
                $('#dataTables-example').dataTable();
				});
			function loadmessage(){
$("#messagechat").load("mess.php",{receiver:$("#receiver").val(),sender:$("sender").val()});

$("#messagess").load("mess.php");
}
		setInterval(loadmessage,10000);	
function loadstuffs(){
	
	


$('document').ready(function(){$("#online").load('online.php');})

}
setInterval(loadstuffs,5000);
    </script>
		
		
</body>
</html>