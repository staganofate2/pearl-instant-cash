<?php
session_start();
include"connect.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Site AUTHORIZE ADMIN Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
		<link href="cs/summernote.css" rel="stylesheet">
	<style>
	#user{
		color:lime;
		margin-left:100px;
	}
	</style>
	
</head>


<!------------------------top nav------------------------------------------------>

	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style='background:#008B8B'>
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>Site</span>   Admin</a>
				<a class="navbar-brand"id='user' href="#"><b><?php //echo $_SESSION['authorize'] ?></b> Dashboard</a>
				<ul class="nav navbar-top-links navbar-right">
									<li class="dropdown" id='messagee'><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span id='mee'class="label label-danger"></span>
					</a>
						
					</li>
					<li class="dropdown" id='notify'><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-bell"></em><span id='noo'class="label label-info"></span>
					</a>
						
					</li>
				</ul>
				</div> 
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		<script>
		
	var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
	
</script>