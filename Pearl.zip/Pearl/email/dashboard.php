<?php
include"header.php";
$bar="dashboard";
?>


		
		
		<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Dashboard</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
						<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>All Emails</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
										<th>Message</th>
                                            <th>Subject</th>
                                            <th>Target</th>
                                            <th>Total Sent</th>
											<th>Total Pending</th>
											<th></th>
											
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
									
	$mysqli1="select * from compose";
	$myquery1=mysqli_query($con,$mysqli1) or die(mysqli_error());
		while($row2 = mysqli_fetch_array($myquery1)){

?>				
									
                                        <tr class="">
										 <td><?php echo @$row2['message'];   ?></td>
                                            <td><?php echo @$row2['subject'];  ?></td>
                                            <td><?php echo @$row2['target'];   ?></td>
                                           	 <td><?php $query="select email from send_emails where compose_id='".$row2['compose_id']."' and sent='1'"; $my1=mysqli_query($con,$query) or die(mysqli_error($con)); echo mysqli_num_rows($my1);?></td>
											 <td><?php $query2="select email from send_emails where compose_id='".$row2['compose_id']."' and sent='0'"; $my2=mysqli_query($con,$query2) or die(mysqli_error($con)); echo mysqli_num_rows($my2);?></td>
							                 
											 								   
											   <td><a href="info.php?id=<?php echo @$row2['compose_id'];   ?>">View More</a></td>
                                            
		</tr> <?php  }  ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						
						
						
                    </div>
						
						
						
					

<!------------------------------------------------table for message----------------------------------------->







<!-------------------------------table for message ends here------------------------------------>

					
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		<?php include"footer.php" ?>