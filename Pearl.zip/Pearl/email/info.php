<?php
include"header.php";
$bar="dashboard";
?>


		
		
		<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Dashboard</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
						<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>All Emails</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
										<th>Emails</th>
                                            <th>Status</th>
                                            
                                            <th>Sent Date</th>
											
											
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
								if(isset($_GET['id'])){
$id=$_GET['id'];
									
	$mysqli1="select * from send_emails where compose_id='$id'";
	$myquery1=mysqli_query($con,$mysqli1) or die(mysqli_error($con));
		while($row2 = mysqli_fetch_array($myquery1)){

?>				
									
                                        <tr class="">
										 <td><?php echo @$row2['email'];   ?></td>
                                            <td><?php if($row2['sent']=="1"){echo "sent";}else{echo "Not sent";}  ?></td>
                                            <td><?php if($row2['sent']=="1"){echo $row2['sent_date'];}else{echo "";}  ?></td>
                                           	
							                 
											 								   
											   
                                            
		</tr> <?php  } 
								}		?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						
						
						
                    </div>
						
						
						
					

<!------------------------------------------------table for message----------------------------------------->







<!-------------------------------table for message ends here------------------------------------>

					
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		<?php include"footer.php" ?>
		

 