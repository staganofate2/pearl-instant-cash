<?php
session_start();
unset($_SESSION['authorize']);
unset($_SESSION['passi']);
header('location:index.php');
?>