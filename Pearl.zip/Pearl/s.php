<?php
include"connect.php";
/*
$query="select account_number from registeruser where registeruser_id ='254'";
$s=mysqli_query($con,$query) or die(mysqli_error($con));
echo mysqli_num_rows($s);
while($w=mysqli_fetch_array($s)){
	$query="insert into wallet(account_no,total,category) values('".$w['account_number']."','0','Basic')";
	mysqli_query($con,$query) or die(mysqli_error($con));
}


$query="update registeruser set password='".sha1(md5("patrick1234"))."' where registeruser_id='236'";
mysqli_query($con,$query) or die(mysqli_error($con));
*/

$query="select ru.refer_user_id from refer_user ru,loan l where l.account_no= ru.account_no and l.paid='0' and ru.transact='1'";
$s=mysqli_query($con,$query) or die(mysqli_error($con));
echo mysqli_num_rows($s);
while($w=mysqli_fetch_array($s)){
	$query="update refer_user set transact='0' where refer_user_id='".$w['refer_user_id']."'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}


?>