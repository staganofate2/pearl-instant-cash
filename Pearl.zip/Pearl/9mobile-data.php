<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>9Mobile Data<b><img src='images/9mobile-data.jpg' width="20%" height="100px" alt='network image'></h3>
			
			
			<!-- about bottom-->
			
				<h4 class="h3-w3l">Just a few steps ahead, to buy your desired Data Bundle </h4> 
				
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-10 "> 
			

	
								<form class="" action="data_payments.php" method="post" > 
			
			
			
			
			
			
						
						
						<input type='hidden' name="network" value='2'>
						<table class='table'>
						<tr><td><div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Data Amount</span>
						
						<select  name="variation" id='variation' class="form-control" required  >

						<option value=''>Select Data Amount</option><option value='200'>150MB-7days = 200</option><option value='1000'>1GB-30days = 1000</option><option value='1000'>1.5GB-30days = 1200</option><option value='1200'>1.5GB-30days = 1200</option><option value='2000'>2.5GB-30days = 2000</option><option value='2500'>3.5GB-30days = 2500</option>
						</select>
						
						</div>
						</td><td>
												<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Recharging Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div>
						</td></tr>
					<tr><td><div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div>
						</td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div>
						<tr><td>	<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div>
							</td><td><br>
						<input type="submit" class="btn btn-info " id='submit'value="Buy Now" name="login"> <br>
						
						<div class="clearfix"></div>
					</td></tr></table>
			
			
			
			
			
			
			
			
			</form>
			
				</div> 
				<div class="clearfix"> </div>
					
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>