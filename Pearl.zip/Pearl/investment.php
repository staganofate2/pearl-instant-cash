<?php
$bar="product";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>INVESTMENT<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-10 "> 
			<h3>PEARL TREASURE INVESTMENT</h3>
      <p>An account package that gives an opportunity to save huge sum at ago , any amount fixed is interest yielding, the depositor has access to loan facilities. # 5,000.00 is the minimum special deposit.
Features of special deposit
<ol><li>	Interest bearing 10% monthly</li>
<li>Instant	Sms alert</li>
<li>	Monthly interest payment based on choice</li>
<li>	5,000 above for investment</li>
<li>	Access to loan facilities</li>
<li>	Instant withdrawal.</li>
<li>	Free financial advice.</li>
<li>	Monthly interest withdrawal</li>
</ol>

</p>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>