<?php

$x= '{ "status": true, "message": "BVN resolved", "data": { "first_name": "BROWN", "last_name": "NNADI", "dob": "30-May-81", "formatted_dob": "1981-05-30", "mobile": "08160523974", "bvn": "22157531183" }, "meta": { "calls_this_month": 1, "free_calls_left": 9 } }';
json_decode($x);
$de=json_decode($x,true);
//print_r($de);
echo $de['message']=="BVN resolved";

?> 