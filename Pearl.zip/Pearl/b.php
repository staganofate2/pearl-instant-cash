<?php
include"connect.php";

$account_names="AKINRIYIBI MARTINS OLAOLUWA";
	$account_name=str_replace(","," ",$account_names);
	
	$s=explode(" ",$account_name);
	print_r($s);
	
	 $last=$s[0];
	 $first=$s[1];
	if(count($s)>2){
	@$mid=$s[2];
	}
	
	$query="select firstname,lastname,middlename from registeruser where account_number='9328578773'";
	$d=mysqli_query($con,$query) or die(mysqli_error($con));
	$c=mysqli_fetch_array($d);
	echo$f=$c['firstname'];
	echo$l=$c['lastname'];
	echo$m=$c['middlename'];
	if(strtolower($last)==strtolower($l)){
		echo "Last name Matched <br>";
	}
	if(strtolower($first)==strtolower($f)){
		echo "First name Matched <br>";
	}
	
	if(strtolower($last)==strtolower($f)){
		echo "Last name  Matched  with first<br>";
	}
	if(strtolower($first)==strtolower($l)){
		echo "First name Matched with last <br>";
	}
	if(isset($mid) && strtolower($mid)==strtolower($m)){
		echo "Middle name Matched <br>";
	}
	
	?>