<?php
include"header.php";
$bar="view_withdrawal";
$banks=array("044"=>"Access Bank","023"=>"Citibank Nigeria","063"=> "Diamond Bank","050"=>"Ecobank Nigeria","084"=>"Enterprise Bank","070"=>"Fidelity Bank","011"=>"First Bank of Nigeria","214"=>"First City Monument Bank","058"=>"Guaranty Trust Bank","030"=>"Heritage Bank","082"=>"Keystone Bank","014"=>"MainStreet Bank","076"=>"Skye Bank","221"=>"Stanbic IBTC Bank","068"=>"Standard Chartered Bank","232"=>"Sterling Bank","032"=>"Union Bank of Nigeria","033"=>"United Bank For Africa","215"=>"Unity Bank","035"=>"Wema Bank","057"=>"Zenith Bank");	?>
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">confirmed Account</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Confirmed Account</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Confirmed Account</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Account Name</th><th>Bank Name</th><th>Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from account_confirm";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
						
					?>
				<tr>
				<td> <?php echo $ree['account_number'] ?></td><td><?php echo $ree['account_name'] ?></td><td><?php echo $banks[$ree['bank']] ?></td><td><?php echo $ree['postdate'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_bill.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function cancels(id,account){
	

	if(confirm("Are You sure  your want to Cancel Order ?")){
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "cancel_bill.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("cancel"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&account="+account);
	}
		}
    </script>
	<?php include"footer.php" ?>