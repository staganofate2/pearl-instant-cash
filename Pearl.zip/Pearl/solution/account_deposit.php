<?php
include"header.php";
include"../function.php";
$bar="deposit";
?>


		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">deposit</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Account Deposit</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                  
	<div class='col-lg-2'>
 	<table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table>  	
</div>	
<div class='col-lg-8'>
<h3><span id='balance'></span></h3>
	<h4 class="page-header"> Account Deposit Form</h4>
	

<?php
if(isset($_POST['change'])){
	
$account =escape($con,$_POST['account_no']);
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$id=$_POST['id'];

$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	if($rows['total']<$amount){
		echo "<h3>The amount you entered is greater than your wallet balance</h3>";
	}else{
	$amounts=$rows['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from account where account_no='$account' and account_id='$id' and account_type='$actype'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update account set start_date=date(now()) where account_no='$account' and account_id='$id' and account_type='$actype'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update account set amount='$am',wallet='$am' where account_no='$account' and account_id='$id' and account_type='$actype'";
mysqli_query($con,$query) or die(mysqli_error($con));


$ref =rand(100000,999999);
$description="$amount was credited into your $actype Account";
$description="$amount was credited into your $actype Account";
$query="insert into account_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,account_id) values('Account','$account','$amount','','$am','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Account Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Account','$account','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account' ";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
echo"<h3>Account Deposit was Successful</h3><p class='error'>Please don't Resend  Again</p>";
}

}
}else{
	?>
	<form action="" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="id" value="" id='id' />
							<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
								<span id='incorrect'></span>
							</div>
				
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update2()" >
								<option   value="">Select Account</option>
								
								</select>
								<span id='results'></span>
							</div>
							<div id='loaders'></div>
							<div class="form-group">
								<input class="form-control" id='payment' name="payment" placeholder='Payment Structure' type="text" readonly>
							</div>
							<div class="form-group">
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' onblur="check()" name="amount" type="text" placeholder='Amount in Digits' required>
								<span id='result'></span>
							</div>
							<button class="btn btn-info" name="change" id='submit' type="submit">SUBMIT</button>
				<?php	
}
?>
				</form>
</div>
				
				</div>




		
			
			
			
		</div><!--/.row-->
		
		
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			var actype=data[4];
			var id=data[5];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
		
				document.getElementById("balance").innerHTML="Balance ₦ "+balance;
			 
			document.getElementById("actype").innerHTML += actype;
			document.getElementById("incorrect").innerHTML = '';
			}
		}
	}
	ajax.send("type="+types);
 
 }
 function update2(){
	
	var types=document.getElementById("actype").value;
	var account=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("results").innerHTML = 'please wait ...';
	 ajax.open("POST", "update2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";				var data=ajax.responseText.split("|");
			var structure=data[0];
			var id=data[1];
			
				document.getElementById("payment").value = structure;
				document.getElementById("id").value = id;
			 document.getElementById("results").innerHTML = '';
			
			
		}
	}
	ajax.send("type="+types+"&account="+account);
 
 }
 function check(){
	
	var account=document.getElementById("account_no").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	//alert(amount);
	var amounts=amount.replace(reg,""); 
	var b=document.getElementById("loaders").style.display="block";
	//	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
		var b=document.getElementById("loaders").style.display="none";		
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
		document.getElementById("amount").innerHTML = '';	
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>	
<?php include"footer.php" ?>