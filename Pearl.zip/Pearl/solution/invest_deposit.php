<?php
include"header.php";
include"../function.php";
$bar="deposit";
?>


		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">deposit</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Invest Deposit</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                  
	<div class='col-lg-2'>
 <table><tr><td><img src='' id='picture' width='100px' alt=''></td><td><b id='first'></b></td><td><b id='last'></b></td> </tr> </table>   	
</div>	
<div class='col-lg-8'>
<h3><span id='balance'></span></h3>
	<h4 class="page-header"> Account Deposit Form</h4>
	

<?php
if(isset($_POST['change'])){	
$account=$_POST['account_no'];		
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$id=$_POST['id'];
$que="select* from wallet where  account_no='account'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$roww=mysqli_fetch_array($res);
if($roww['total']>=$amount){
$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from investment where account_no='$account' and investment_id='$id' and duration='$actype'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update investment set start_date=date(now()) where account_no='$account' and investment_id = '$id' and duration='$actype'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update investment set amount='$am' where account_no='$account' and duration='$actype' ";
mysqli_query($con,$query) or die(mysqli_error($con));

}
$ref =rand(100000,999999);
$description="$amount was credited into your $actype Investment";
$query="insert into transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Investment','$account','$amount','','$am','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Investment Deposit";
$query="insert into transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Wallet','$account','','$amount','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
echo"<h3>Investment Deposit was Successful</h3>";
}else{
	
	echo "<h3>The amount you Entered is bigger than Your Wallet Amount</h3>";
	echo"<a href='deposit.php'>Try Again</a>"
}
}else{
	?>
	<form action="" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="id" value="" id='id' />
							<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
							<span id='incorrect'></span>
							</div>
				
							<div class="form-group">
								<select name='type' class="form-control" id='actype'onchange="update2()"  >
								<option   value="">Select Investment</option>
								
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" id='payment' name="payment" placeholder='Payment Structure' type="text" readonly>
							</div>
							
							
							<div class="form-group">
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' onblur="check()" name="amount" type="text" placeholder='Amount in Digits' required>
								<span id='result'></span>
							</div>
							
							<button class="btn btn-info"  id='submit'name="change" type="submit">SUBMIT</button>
				<?php	
}
?>
				</form>
</div>
				
				</div>




		
			
			
			
		</div><!--/.row-->
		
		
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
	document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update_invest.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			var actype=data[4];
			
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
				document.getElementById("balance").innerHTML="Balance ₦ "+balance;
			 
			document.getElementById("actype").innerHTML += actype;
			 
			
			}
		}
	}
	ajax.send("type="+types);
 
 }
 
 function update2(){
	
	var types=document.getElementById("actype").value;
	var account=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
				var data=ajax.responseText.split("|");
			var structure=data[0];
			var id=data[1];
			
				document.getElementById("payment").value = structure;
				document.getElementById("id").value = id;
			 
			
			
		}
	}
	ajax.send("type="+types+"&account="+account);
 
 }
  function check(){
	
	var account=document.getElementById("account_no").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	alert(amount);
	var amounts=amount.replace(reg,""); 
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>	
<?php include"footer.php" ?>