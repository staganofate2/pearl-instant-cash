<?php
include"header.php";
include"../function.php";
$bar="withdraw";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Withdraw</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Account Payout</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Account Payout Form</h4>
	<?php	
if(isset($_POST['change'])){
	$account=$_POST['account_no'];
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['total']);
$amount=str_replace(",","",$amount);
$id=$_POST['id'];

	$query="select*  from account where account_no='$account' and account_id='$id' and account_type='$actype' and active='1' and paid='0'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($rowss)>0){
$ers=mysqli_fetch_array($rowss);
$all=$ers['interest']+ $ers['amount'];

	$query="update account set  wallet='$amount',paid='1' where account_no='$account' and account_id='$id' and account_type='$actype'";
mysqli_query($con,$query) or die(mysqli_error($con));
	$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']+$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$ref =rand(100000,999999);
$description="$amount was debited from   your $actype Account";
$query="insert into account_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,account_id) values('Account','$account','','$amount','0','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was credited  into your Wallet from $actype Account Pay Out";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Account','$account','$amount','','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));



	

echo"<h3>Account Pay Out was Successful</h3><p class='error'>Please don't Resend  Again</p>";
}
}
?>

	
                    </div>





		
			
			
			
		</div><!--/.row-->
		
	
	<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update2(){
	
	var types=document.getElementById("actype").value;
	var account=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update3.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				
			 var data=ajax.responseText.split("|");
			 var mat_date=data[0];
			 var start_date=data[1];
			 var total=data[2];
			 var interest=data[3];
			 var gtotal=data[4];
			 var witamount=data[5];
			 document.getElementById("maturity").value = mat_date;
			 document.getElementById("contribute").value =start_date;
			 document.getElementById("deposit").value =total ;
			 document.getElementById("interest").value =interest ;
			 document.getElementById("total").value =gtotal ;
			 document.getElementById("withdraw").value = witamount;
			 
			 
			
			
		}
	}
	ajax.send("type="+types+"&account="+account);
 
 }
 function update(){
	
	var types=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update4.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("actype").innerHTML += ajax.responseText;
			 
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 </script>
		
		
<?php include"footer.php" ?>