<?php
session_start();
include"connect.php";
				$acct=mysqli_real_escape_string($con,$_POST['id']);
				
				$query="select account_number from registeruser  where   account_number='$acct' ";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				   
				   $query="select* from loan where account_no='$acct' and approved='1'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					
					?>
				
				
							
								<?php while($ree=mysqli_fetch_array($res)){
									/*
					?>
				
				 <button class="accordions"><?php echo $ree['total'] ?> |  <?php if($ree['active']=="0"){echo "Active";}else{echo "Completed";} ?></button>
				 */ ?>
				 <div class="panel">
						
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
                                        <tr>
										<th>Date</th>
                                            <th>Ref No</th>
                                            <th>Description</th>
											<th>Debit</th>
											<th>Credit</th>
											<th>Balance</th>
											<th>Remark</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
										
	$mysqli1="select * from loan_transact where account_no='$acct' and packages='Loan' and loan_id='".$ree['loan_id']."' ";
	$myquery1=mysqli_query($con,$mysqli1) or die(mysqli_error($con));
		while($row2 = mysqli_fetch_object($myquery1)){

?>				
									
                                        <tr class="info">
										 <td><?php echo @$row2->transaction_date;   ?></td>
                                            <td><?php echo @$row2->refno;   ?></td>
                                            <td><?php echo @$row2->description;   ?></td>
                                            <td><?php echo @$row2->debit;   ?></td>
											<td><?php echo @$row2->credit;   ?></td>
											<td><?php echo @$row2->balance;   ?></td>
											 <td><?php echo @$row2->types;   ?></td>
                                            
		</tr> <?php  }  ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						</div>

				<?php
			   }
				}
			   }else{
				   echo "<h5>$acct not in our Database</h5>";
			   }
				
				?>
				