<?php
include"header.php";
$bar="view_withdrawal";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">confirmed bvn</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Confirmed BVN</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Confirmed BVN</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>BVN</th><th>First Name</th><th>Last Name</th><th>Phone</th><th>Date of Birth</th><th>Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from bvn";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
						
					?>
				<tr>
				<td> <?php echo $ree['bvn'] ?></td><td><?php echo $ree['first_name'] ?></td><td><?php echo $ree['last_name'] ?></td><td><?php echo $ree['phone'] ?></td><td><?php echo $ree['dob'] ?></td><td><?php echo $ree['postdate'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_bill.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function cancels(id,account){
	

	if(confirm("Are You sure  your want to Cancel Order ?")){
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "cancel_bill.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("cancel"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&account="+account);
	}
		}
    </script>
	<?php include"footer.php" ?>