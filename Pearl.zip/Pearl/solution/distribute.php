<?php
include"header.php";
$bar="addbankinfo";

?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">food distribute date</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Add food Distribution Dtae</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header">Bank Account Information</h4>
	<?php
				if(isset($_POST['submit'])){
				$day=mysqli_real_escape_string($con,$_POST['day']);
					$year = mysqli_real_escape_string($con,$_POST['year']);
								$id = mysqli_real_escape_string($con,$_POST['id']);
								
								
								$month = mysqli_real_escape_string($con,$_POST['month']);
								$full=$year."-".$month."-".$day;
								$query = "update food set distribute_date='$full' where food_id='$id'";
								 mysqli_query($con,$query) or die(mysqli_error($con));
								
										
										echo "<h3>Distribute Date Info added Successfully</h3>";
										
									}else{
								
?>
	<form role="form" action="" method="POST">
					<?php
					if(isset($_GET['id'])){
					$id=$_GET['id'];
					?>
<input type='hidden' name='id' value='<?php echo $id ?>'>
						<select name="year" required  class="form-control">
 
<option value=""> Select  Year</option>
<?php for($i=date("Y"); $i<=(date('Y')+1);$i++){
echo"<option value='".$i."'>".$i."</option>";} ?>
</select><br>
<select name="month" required class="form-control">

<option value=""> Select  Month</option>
<?php for($i=1;$i<=12;$i++){
echo"<option value='".$i."'>".$i."</option>";} ?>
</select><br>
<select name="day"required class="form-control">

<option value=""> Select  Day</option>
<?php for($i=01; $i<=31;$i++){
echo"<option value='".$i."'>".$i."</option>"; }?>
</select>
							<button class="btn btn-info" type="submit" name="submit">ADD</button>
							
				<?php
				}
				?>		
				</form>		
						
				<?php
				}
				?>
			
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>