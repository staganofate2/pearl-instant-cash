<?php
include"header.php";
$bar="comment";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">View Blog Comment</li>
				
			</ol>
		</div><!--/.row-->
		
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href='replied_comment.php'>View Replied Comments</a></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Confirm Blog Comments</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Date</th><th>Title</th><th>Post</th><th>Name</th><th>Email</th><th>Phone</th><th>Comments</th><th>Comment Date</th><th></th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select b.postdate as pdate,b.title,b.post as post,c.blogcomment_id,c.name,c.email,c.phone,c.post as comment,c.postdate as cdate from blog b,blogcomment c where c.blog_id=b.blog_id and c.status='1'  and c.rejected='0' and c.reply='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){				?>
				<tr>
				<td><?php echo $ree['pdate'] ?></td><td><?php  echo $ree['title']; ?></td><td><?php echo $ree['post'] ?></td><td><?php  echo $ree['name']; ?></td><td><?php  echo $ree['email']; ?></td><td><?php  echo $ree['phone']; ?></td><td><?php echo $ree['comment'] ?></td><td><?php echo $ree['cdate'] ?></td><td><a href='reply.php?id=<?php echo $ree['blogcomment_id'] ?>'>Reply</a></td>
				
				
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
	
	
	document.getElementById("confirm"+id).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_comment.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";
document.getElementById("reject"+id).innerHTML ="";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	
	function reject(id){
	
	if(confirm("Are you Sure you want to reject the deposit")){
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reject_comment.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("reject"+id).innerHTML ="Done";
document.getElementById("confirm"+id).innerHTML ="";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 }

    </script>
		<?php include"footer.php" ?>