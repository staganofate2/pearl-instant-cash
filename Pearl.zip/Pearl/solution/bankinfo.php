<?php
include"header.php";
$bar="bank_info";
?>



		
		<?php include"sidebar.php" ?>
		
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Transaction Details</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Transaction Details</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Bank Account Information</h4>
	<form role="form" action="" method="POST">
				

			
            
							
							
							<div class="form-group">
								<input class="form-control" placeholder="ACCOUNT NUMBER" name="acct" type="text" required>
							</div>
							<button class="btn btn-info" type="submit" name="submit">View</button>
							
						
				</form>		
						
				<?php
				if(isset($_POST['submit'])){
				$acct=mysqli_real_escape_string($con,$_POST['acct']);
				
				$query="select* from bank_info where  account_no='$acct'";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				   
				   ?>
				   
				   
				<p>Bank Account Information
				</p>
				
								<div class="col-md-8">
								
				<?php while($rows=mysqli_fetch_array($resultt)){
					?>
				<table class="table">
				<tr>
				<th>User Account Detail</th>
				<th></th>
				</tr>
				
				<tr>
				<td>Account Name</td>
				<td><?php echo $rows['account_name'] ?></td>
				
				</tr>
				<tr>
				<td>Account Number</td>
				<td><?php echo $rows['account_number']; ?></td>
				
				</tr>
				
				<tr>
				<td>Bank Name</td>
				<td><?php echo $rows['bank_name']; ?></td>
				
				</tr>
				
				
				
				
				
				
				</table>

				<?php
			   }
			   }else{
				   echo "<h5>$acct not in our Database</h5>";
			   }
				}
				?>
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
		
		
</body>
</html>