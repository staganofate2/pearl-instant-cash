<?php
include"connect.php";

$data=array("data"=>array());
$x=0;
									$query="select* from loan where paid='0' and calls='0' and contact_date3 < date(now()) and charges>0 ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					     if($ree['deposit']<$ree['total']){
					        continue;
					    }
						 $query="select date(pay_date) as pay, amount,paid from loan_repay where loan_id='".$ree['loan_id']."' and pay_date <'".date("Y-m-d")."'";
						$result=mysqli_query($con,$query);
						if(mysqli_num_rows($result)<1){
							continue;
						}
						$query="select sum(amount) as a from loan_repay where loan_id='".$ree['loan_id']."' and paid='0'";
						$xx=mysqli_query($con,$query) or die(mysqli_error($con));
						$e=mysqli_fetch_array($xx);
						
							$query="select firstname,phone, lastname from registeruser where account_number='".$ree['account_no']."'";
						$xs=mysqli_query($con,$query) or die(mysqli_error($con));
						$re=mysqli_fetch_array($xs);
						
						
						$query="select message,sent_date  from loan_call where account_no='".$ree['account_no']."' order by loan_call_id desc limit 1";
						$k=mysqli_query($con,$query) or die(mysqli_error($con));
						if(mysqli_num_rows($k)>0){
						$ke=mysqli_fetch_array($k); 
						$message=$ke['message'];
						$date=$ke['sent_date'];
						}else{
							$message="";
							$date="";
						}
						$data['data'][$x][]=$ree['loan_id'];
						$data['data'][$x][]=$ree['account_no'];
						$data['data'][$x][]=$re['firstname']." ".$re['lastname'];
						$data['data'][$x][]=$re['phone'];
						$data['data'][$x][]=$ree['amount'];
						$data['data'][$x][]=$ree['interest'];
						
						$data['data'][$x][]=$ree['total'];
						$data['data'][$x][]=$ree['deposit'];
						$y="";
						while($dee=mysqli_fetch_array($result)){
							if($dee['paid']=="1"){
								continue;
							}
						$y.=$dee['pay']."&nbsp; ".$dee['amount']."<br>";
						}
						$data['data'][$x][]=$y;
						$data['data'][$x][]=$message;
						$data['data'][$x][]=$date;
						$x++;
					}
				}
				//echo $x;
				//print_r($data);
				$c=json_encode($data);
				echo $c;

?>