<?php include"header.php";
$bar="dashboard"; ?>
		
		<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Dashboard</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
						<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>All Registered Users</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
										<th>Acct Number</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
											<th>Alt Phone</th>
											<th>Gender</th>
											<th>Marital Status</th>
											<th>Qualification</th>
											<th>Means Identification</th>
											<th>Join Date</th>
											<th>Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
									
	$mysqli1="select * from registeruser where activated='1'";
	$myquery1=mysqli_query($con,$mysqli1) or die(mysqli_error());
		while($row2 = mysqli_fetch_object($myquery1)){

?>				
									
                                        <tr class="">
										 <td><?php echo @$row2->account_number;   ?></td>
                                            <td><?php echo @"$row2->firstname $row2->lastname ";   ?></td>
                                            <td><?php echo @$row2->email_address;   ?></td>
                                           	 <td><?php echo @$row2->phone;   ?></td>
											 <td><?php echo @$row2->alt_phone;   ?></td>
							                  <td><?php echo @$row2->gender;   ?></td>
											  <td><?php echo @$row2->status;   ?></td>
											  <td><?php echo @$row2->qualification;   ?></td>
											  <td><?php echo @$row2->id;   ?></td>
											   <td><?php echo @$row2->regdate;   ?></td>
											   
											   <td><a href="info.php?id=<?php echo @$row2->account_number;   ?>">View More</a></td>
                                            
		</tr> <?php  }  ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						
						
						
                    </div>
						
						
						
					

<!------------------------------------------------table for message----------------------------------------->







<!-------------------------------table for message ends here------------------------------------>

					
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				<p class=""></p>
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
		
		
</body>
</html>