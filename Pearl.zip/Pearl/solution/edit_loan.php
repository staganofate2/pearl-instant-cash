<?php
include"header.php";
$bar="dashboard";
include"../function.php";
?>


<style>
.img-responsive{
	width:120px;
	height:120px;
}
</style>
		
		<?php
		include"sidebar.php";
		?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Dashboard</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-2 ">
 </div>
			<div class="col-lg-8 ">
			   
				<?php if(isset($_GET['id'])){
					$id=$_GET['id'];
					$query="select* from loan where loan_id='$id'";
					$res=mysqli_query($con,$query) or die(mysqli_error($con));
					$row=mysqli_fetch_array($res);
					$query="select* from bank_info where account_no='".$row['account_no']."'";
					$ress=mysqli_query($con,$query) or die(mysqli_error($con));
					$rows=mysqli_fetch_array($ress);
				?>
				<p>  Loan information </p>
				
								
								
                  <?php  if(isset($_POST['change'])){
				
					$emp_status =escape($con,$_POST['emp_status']);
					
$emp_sector =escape($con,$_POST['emp_sector']);
$buz_name =escape($con,$_POST['buz_name']);
$buz_address =escape($con,$_POST['buz_address']);
$buz_status =escape($con,$_POST['buz_status']);
$rc_no =escape($con,$_POST['rc_no']);
$net_profit =escape($con,$_POST['net_profit']);
$mon_turnover =escape($con,$_POST['mon_turnover']);
$start_date =escape($con,$_POST['start_date']);
$buz_email =escape($con,$_POST['buz_email']);
$buz_phone =escape($con,$_POST['buz_phone']);
$tax_no =escape($con,$_POST['tax_no']);
$pension_no =escape($con,$_POST['tax_no']);
$occupation =escape($con,$_POST['occupation']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$duration =escape($con,$_POST['duration']);
$percent =escape($con,$_POST['percent']);
$structure =escape($con,$_POST['structure']);
$reason =escape($con,$_POST['reason']);

$repay_amount=escape($con,$_POST['repay_amount']);


	$bvn=escape($con,$_POST['bvn']);
$find =escape($con,$_POST['find']);
	$interest=($percent*$amount)/100;			
			$query="update loan  set emp_status='$emp_status',emp_sector='$emp_sector',business_name='$buz_name',business_address='$buz_address',biz_status='$buz_status',rc_no='$rc_no',dialy_turnover='$net_profit',monthly_profit='$mon_turnover',biz_start='$start_date',biz_email='$buz_email',biz_phone='$buz_phone',tax_no='$tax_no',pension='$pension_no',occupation='$occupation', amount='$amount',loan_duration='$duration',interest_rate='$percent',repayment_plan='$structure',reason_for_loan='$reason',repayment_plan_amount='$repay_amount',find='$find' where loan_id='$id'"; 
			mysqli_query($con,$query)or die(mysqli_error($con));


	$query="update bank_info set bvn='$bvn' where account_no='".$row['account_no']."'";
	mysqli_query($con,$query)or die(mysqli_error($con));



                    
   











echo "<h3>Loan Application Edit was Successful</h3>";
?>

				
<?php
				}else{	
				?>
	<form action="" method="POST" enctype="multipart/form-data">
		<div class="row">
		

 <div class="col-lg-12 ">			
				<div class="col-md-3">
			
			
			</div>
			<div class="col-md-8">
			
			
			
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br>
		<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Employment Status</span>
			<select name="emp_status" class="form-control"  required="">
						<option value="<?php echo $row['emp_status']  ?>"><?php echo $row['emp_status']  ?></option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						<option value="Student">Student</option>
						
						
</select></div>
<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Employment Sector </span>
						<input type="text" name="emp_sector" value="<?php echo $row['emp_sector']  ?>"class="form-control" placeholder="EMPLOYMENT SECTOR" >
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Name</span>
						<input type="text" name="buz_name"value="<?php echo $row['business_name']  ?>" class="form-control" placeholder="BUSINESS NAME" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Address</span>
						<input type="text" name="buz_address" value="<?php echo $row['business_address']  ?>"class="form-control" placeholder="BUSINESS ADDRESS" required="">
						</div>
						
					<div class='form-group'>
					<span class="badge" style="background-color:#3385FF;">Business Registration Status</span>
						<select name="buz_status" class="form-control"  required="">
						<option value="<?php echo $row['biz_status']  ?>"><?php echo $row['biz_status']  ?></option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select>

			</div>			
					<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">RC Number</span>	
						<input type="text" name="rc_no" value="<?php  echo $row['rc_no']   ?>"class="form-control" placeholder="RC NO" >
						</div>
						
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Daily Turnover</span>
						<input type="text" name="net_profit"value="<?php echo $row['dialy_turnover']  ?>" class="form-control" placeholder="DAILY TURNOVER" required="">
						</div>
					
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Monthly Turnover</span>
						<input type="text" name="mon_turnover" value="<?php echo $row['monthly_profit'] ?>"class="form-control" placeholder="NET MONTHLY MONTHLY" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Start Date</span>
						<input type="date" name="start_date"value="<?php echo $row['biz_start']  ?>" class="form-control"  >
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Email</span>
						<input type="email" name="buz_email"value="<?php echo $row['biz_email'] ?>" class="form-control" placeholder="BUSINESS EMAIL" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Phone number</span>
						<input type="text" name="buz_phone" value="<?php echo $row['biz_phone']  ?>"class="form-control" placeholder="BUSINESS PHONE" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Tax Number</span>
						
						<input type="text" name="tax_no"value="<?php echo $row['tax_no']  ?>" class="form-control" placeholder="TAX NO" >
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Pension Number</span>
						
						<input type="text" name="pension_no"value="<?php echo $row['pension']  ?>" class="form-control" placeholder="PENSON NO">
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Occupation</span>
						<select name="occupation" class="form-control"  required="">
						<option value="<?php echo $row['occupation'] ?>"><?php echo $row['occupation'] ?></option>
						<option value="Student">Student</option>
						<option value="Trader">Trader</option>
						<option value="Technician">Technician</option>
						<option value="Accountants">Accountants</option>
							<option value="Accounting">Accounting</option>
							<option value=" Administrator"> Administrator</option>
							<option value="Administrative Assistants">Administrative Assistants</option>
							<option value="Advertiser">Advertiser</option>
							<option value="Agents">Agents</option>
							<option value="Air Conditioning Installers">Air Conditioning Installers</option>
							<option value="Analysts">Analysts</option>
							<option value="Architech">Architech</option>
							<option value="Artists">Artists</option>
							<option value="Asphalt Paving Machine Operators">Asphalt Paving Machine Operators</option>
                            <option value="Assistants">Assistants</option>
							<option value="Athletes">Athletes</option>
							<option value="Automobile Body Repair">Automobile Body Repair</option>
							<option value="Bank">Bank</option>
							<option value="Bookkeeping">Bookkeeping</option>
							<option value="Cafeteria">Cafeteria</option>
							<option value="Carpenter">Carpenter</option>
							<option value="Certified Nurse Midwives">Certified Nurse Midwives</option>
							<option value="Cleaner">Cleaner</option>
							<option value="Contractor">Contractor</option>
								<option value="Cooks">Cooks</option>
																<option value="Counselor">Counselor</option>
                                <option value="Doctor">Doctor</option>
								<option value="Comedian">Comedian</option>
                            <option value="Drivers">Drivers</option>
							<option value="Economics">Economics</option>
                                <option value=" Electricians"> Electricians</option>
								<option value="Engineer">Engineer</option>
								<option value="Equipment Installers">Equipment Installers</option>
								<option value="Equipment Operators">Equipment Operators</option>
								<option value="Feed Manager">Feed Manager</option>
								<option value="Graphic Designer">Graphic Designer</option>
								<option value="House helper">House helper</option>
                                <option value="librarian">Libralian</option>
                            
                                <option value="Lawyer">Lawyer</option>
                            
                                <option value="Security">Security</option>
                            
                                
                            
                                
                            
                                <option value="Photographer">Photographer</option>
                            
                                <option value="Web Designer">Web Designer</option>
								<option value="Phone Engineer">Phone Engineer</option>
								
								
								<option value="Sales girl">Sales girl</option>
								<option value="Sales boy">Sales boy</option>
								<option value="Radiographers">Radiographers</option>
								
								
								<option value="Spiritualist">Spiritualist</option>
								
								
								<option value="Teachers">Teachers</option>
								
								<option value="Mathematicians">Mathematicians</option>
								
								<option value="Managerial services">Managerial services</option>
								
								<option value="Photographer">Photographer</option>
								<option value="Rental">Rental</option>
								
								
								<option value="Nanny">Nanny</option>
								
								<option value="Mechanics">Mechanics</option>
								
								<option value="Medical Technician">Medical Technician</option>
								
								
								<option value="News Broadcaster">News Broadcaster</option>
								<option value="Painters">Painters</option>
								<option value="Sculptors Arts Producer">Sculptors Arts Producer</option>
								
								
								<option value="Medical laboratory Scientist">Medical laboratory Scientist</option>
								<option value="Nursing, Attendants">Nursing, Attendants</option>
								
								<option value="Social Workers">Social Workers</option>
								
								<option value="Laborer">Laborer</option>
								
								<option value="Marriage Counselor">Marriage Counselor</option>
								<option value="Doctors of Optometry">Doctors of Optometry</option>
								<option value="Public Health">Public Health</option>
								<option value="Elevator Installers">Elevator Installers</option>
								<option value="Repairers">Repairers</option>
								<option value="Epidemiologists">Epidemiologists</option>
								<option value="Physician Assistant">Physician Assistant</option>
								<option value="Firefighters">Firefighters</option>
								<option value="Drying Machine Operators">Drying Machine Operators</option>
								<option value="Health Diagnosing Practitioners">Health Diagnosing Practitioners</option>
								<option value="Tenders">Tenders</option>
								<option value="Helpers">Helpers</option>
								<option value="Plumber">Plumber</option>
								<option value="Pipefitters">Pipefitters</option>
								<option value="Home Appliance Repairers">Home Appliance Repairers</option>
								<option value="Hospital Registerers">Hospital Registerers</option>
								<option value=" Labor Economics Property Manager"> Labor Economics Property Manager</option>
								<option value="Librarians">Librarians</option>
								<option value="Clinical Mental Health Counselor">Clinical Mental Health Counselor</option>
								<option value="Logistics Planner">Logistics Planner</option>
								<option value="Mortician">Mortician</option>
								<option value="Movie Projectionists">Movie Projectionists</option>
								<option value="Nutritionists">Nutritionists</option>
								<option value="Public Health Specialist">Public Health Specialist</option>
								<option value="Pay loader Operator">Pay loader Operator</option>
								<option value="Painter">Painter</option>
								<option value="Makeup Artist">Makeup Artist</option>
								<option value="Pharmacist Technicians">Pharmacist Technicians</option>
								<option value="Pharmacists">Pharmacists</option>
								<option value="Wedding Planner">Wedding Planner</option>
								<option value="Equipment Repairers">Equipment Repairers</option>
								<option value="Physician">Physician</option>
								<option value="Surgeon">Surgeon</option>
								<option value="Marketing">Marketing</option>
								<option value="Weaving">Weaving</option>
								<option value="Fashion/dressmaking">Fashion/dressmaking</option>
								<option value="Property Managers">Property Managers</option>
								<option value="Real Estate developers">Real Estate developers</option>
								<option value="Car Repairers">Car Repairers</option>
								<option value="Real Estate Brokers">Real Estate Brokers</option>
								<option value="Rehabilitation Repairers">Rehabilitation Repairers</option>
								<option value="Sales Agents">Sales Agents</option>
								<option value="Shipping Agents">Shipping Agents</option>
								<option value="Healthcare">Healthcare</option>
								<option value="Software Developers">Software Developers</option>
								<option value="Solar Panel Installation Supervisor">Solar Panel Installation Supervisor</option>
								<option value="Supervisors">Supervisors</option>
								<option value="Gaming Supervisors">Gaming Supervisors</option>
								<option value="Urban Planner">Urban Planner</option>
								<option value="Waiter">Waiter</option>
								<option value="Waitresses">Waitresses</option>
								<option value="Gate man">Gate man</option>
																<option value="Programmer">Programmer</option>
								<option value="Seller">Seller</option>
						
						
</select>
						</div>
						<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
			
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Loan Amount</span>
						<input type="text"onkeyup="this.value = numFormat(this.value)" name="amount"value="<?php echo $row['amount']  ?>" id='amount' class="form-control" placeholder="ENTER AMOUNT" onblur="update()">
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Loan Duration</span>
								<select name='duration' class="form-control">
								<option   value="<?php echo $row['loan_duration'] ?>"><?php echo $row['loan_duration']?></option>
								<option   value="1 Month">1 Month</option>
								
								
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Loan Percentage Interest</span>
						
								<input class="form-control" id='percent' value="<?php echo $row['interest_rate'] ?>" name="percent" placeholder='30%' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Repayment Amount</span>
								<input class="form-control" id='repay' name="repay_amount" value="<?php echo $row['repayment_plan_amount'] ?>"placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Payment Structure</span>
								<select name='structure' class="form-control">
								<option   value="<?php echo $row['repayment_plan']  ?>"><?php echo $row['repayment_plan'] ?></option>
								<option   value="Weekly">Weekly</option>
								
								</select>
							</div>
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">Reason for Loan</span>
						<textarea  name="reason"value="<?php echo $row['reason']?>" class="form-control" placeholder="<?php echo $row['reason']?>" ></textarea>
</div><div class='form-group'>
													
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;"></span>BVN<input type="text"  class="form-control" value="<?php echo $rows['bvn']  ?>" name='bvn' >
						</div>
						
						

							
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">How did you find us</span>
						<textarea  name="find" class="form-control" placeholder="<?php echo $row['find'];?>" value='<?php echo $row['find'];?>'></textarea>
</div>
	<input class="btn btn-info" type="submit" name="change" value="Update Loan Record">
						
						</div>
						</div>
						</div>
					  
					  
					  
<?php
				
				}}
				?>
					  
                    


<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  </script>


		
			
			
			
		</div><!--/.row--><?php include"footer.php";?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 
		
		
</body>
</html>