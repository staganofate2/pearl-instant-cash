<?php
session_start();
include"connect.php";
				$acct=mysqli_real_escape_string($con,$_POST['id']);
				
				$query="select account_number from registeruser  where   account_number='$acct' ";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				   
				   $query="select* from loan where account_no='$acct' and approved='1' and paid='1' order by loan_id desc limit 1";
				
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					
					?>
				
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Paid</th><th>Repay Date</th><th>Duration</th><th>Authorized</th><th>Interest</th><th>Amount</th><th>Total Amount</th><th>Amount Paid</th><th></th><th>Ref NO</th><th>Payment Date</th><th>Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php if($ree['paid'] =="1"){echo "Yes";}else{echo "No";} ?></td><td>
				<table class='table'><tr><th>Repay Date</th><th>Amount</th><th>Status</th><th>Paid Date</th></tr><?php $query="select* from loan_repay where loan_id='".$ree['loan_id']."'";$result=mysqli_query($con,$query);while($dee=mysqli_fetch_array($result)){echo "<tr><td>".$dee['pay_date']."</td><td> ".$dee['amount']."</td><td> "; if($dee['paid']=="0"){echo " Unpaid ";}else{echo " Paid";} echo "</td><td> ".$dee['paid_date']."</td></tr>";} ?></table></td><td><?php echo $ree['loan_duration'] ?></td><td><?php if($ree['authorize'] =="1"){echo "Yes";}else{echo "No";} ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td>₦<?php echo $ree['total'] ?></td><td>₦<?php echo $ree['deposit'] ?></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['repay_date'] ?></td><td><?php echo $ree['regdate'] ?></td>
				
				
				</tr>
				<?php
				
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>


<?php
			   }else{
				   echo "<h5>No loan asociated with $acct </h5>"; 
				}
			   }else{
				   echo "<h5>$acct not in our Database</h5>";
			   }
				
				?>