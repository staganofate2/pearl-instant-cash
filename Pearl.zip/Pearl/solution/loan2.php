<?php
session_start();

include"connect.php";


if (!isset($_SESSION['passi'])){
	header("location:index.php");
	exit();
} 
$bar="loan";
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PEARL ADMIN Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	
</head>


<!------------------------top nav------------------------------------------------>

	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>PEARL</span> Admin</a>
				<ul class="nav navbar-top-links navbar-right">
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span class="label label-danger">0</span>
					</a>
						
					</li>
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-bell"></em><span class="label label-info">0</span>
					</a>
						
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Loan Application</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		
                        
						
	<h4 class="page-header">Loan Application Form</h4>
	<form action="" method="POST" enctype="multipart/form-data">
		<div class="row">
		

 <div class="col-lg-12 ">			
				<div class="col-md-3">
			<p>ID image</p>
			<img src="../<?php echo @$rows['id_image']?> " alt="" class="img-responsive"  align="absmiddle" id="id_image"/><br />
			
			</div>
			<div class="col-md-5">
			
			<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
								<span class='error' id='acc_err'></span>
							</div>
			
			
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br><br>
		
			<select name="emp_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];}  ?>"><?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];} else{ ?>----EMPLOYMENT STATUS---<?php } ?></option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						
						
</select><br>
						<input type="text" name="emp_sector" value="<?php if(isset($_POST["emp_sector"])){echo $_POST["emp_sector"];}  ?>"class="form-control" placeholder="EMPLOYMENT SECTOR" ><br>
						
						<input type="text" name="buz_name"value="<?php if(isset($_POST["buz_name"])){echo $_POST["buz_name"];}  ?>" class="form-control" placeholder="BUSINESS NAME" required=""><br>
						<input type="text" name="buz_address" value="<?php if(isset($_POST["buz_address"])){echo $_POST["buz_address"];}  ?>"class="form-control" placeholder="BUSINESS ADDRESS" required=""><br>
					
						<select name="buz_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}  ?>"><?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}else{  ?>----Business Registration Status---<?php } ?></option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select><br>

						
						
						<input type="text" name="rc_no" value="<?php if(isset($_POST["rc_no"])){echo $_POST["rc_no"];}  ?>"class="form-control" placeholder="RC NO" required=""><br>
						<input type="text" name="id_no"value="<?php echo @$rows['id'] ?>" class="form-control"  readonly placeholder="Means of Identification"><br>
						<input type="text" name="id_no"value="<?php echo @$rows['id_no'] ?>" class="form-control" placeholder="ID NUMBER" readonly><br>
						<input type="text" name="net_profit"value="<?php if(isset($_POST["net_profit"])){echo $_POST["net_profit"];}  ?>" class="form-control" placeholder="DAILY TURNOVER" required=""><br>
						<input type="text" name="mon_turnover" value="<?php if(isset($_POST["mon_turnover"])){echo $_POST["mon_turnover"];}  ?>"class="form-control" placeholder="NET MONTHLY MONTHLY" required=""><br>
						<input type="date" name="start_date"value="<?php if(isset($_POST["start_date"])){echo $_POST["start_date"];}  ?>" class="form-control"  ><br>
						
						<input type="email" name="buz_email"value="<?php if(isset($_POST["buz_email"])){echo $_POST["buz_email"];}  ?>" class="form-control" placeholder="BUSINESS EMAIL" required=""><br>
						<input type="text" name="buz_phone" value="<?php if(isset($_POST["buz_phone"])){echo $_POST["buz_phone"];}  ?>"class="form-control" placeholder="BUSINESS PHONE" required=""><br>
						<input type="text" name="tax_no"value="<?php if(isset($_POST["tax_no"])){echo $_POST["tax_no"];}  ?>" class="form-control" placeholder="TAX NO" ><br>
						<input type="text" name="pension_no"value="<?php if(isset($_POST["pension_no"])){echo $_POST["pension_no"];}  ?>" class="form-control" placeholder="PENSON NO"><br>
						
						<div class="form-group">
						<span>ARE YOU A STUDENT ? </span><input type="CHECKBOX" name="student" value="Student" class="form-control">
						</div>
						<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
						<input type="text" name="amount"value="<?php if(isset($_POST["amount"])){echo $_POST["amount"];}  ?>" class="form-control" placeholder="ENTER AMOUNT" onblur="update()"><br>
						<div class="form-group">
								<select name='duration' class="form-control">
								<option   value="<?php if(isset($_POST["duration"])){echo $_POST["duration"];}  ?>"><?php if(isset($_POST["duration"])){echo $_POST["duration"];}else{  ?>Select LOAN Duration <?php } ?></option>
								<option   value="6 Months">6 Months</option>
								<option   value="12 Months">12 Months</option>
								<option   value="2 Years">2 Years</option>
								<option   value="3 Years">3 Years</option>
								<option   value="4 Years">4 Years</option>
								<option   value="5 Years">5 Years</option>
								
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" id='percent' value="<?php if(isset($_POST["percent"])){echo $_POST["percent"];}  ?>" name="percent" placeholder='Monthly Investment Interest Rate' type="text" readonly>
							</div>
							<div class="form-group">
								<input class="form-control" id='repay' name="repay_amount" value="<?php if(isset($_POST["repay_amount"])){echo $_POST["repay_amount"];}  ?>"placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
							<div class="form-group">
								<select name='structure' class="form-control">
								<option   value="<?php if(isset($_POST["structure"])){echo $_POST["structure"];}  ?>"><?php if(isset($_POST["structure"])){echo $_POST["structure"];} else{ ?>Select Repayment Structure <?php } ?></option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
						<textarea  name="reason"value="<?php if(isset($_POST["reason"])){echo $_POST["reason"];}  ?>" class="form-control" placeholder="Reason for loan" required=""></textarea><br>
						</div>
						</div>
						</div>
					
<div class="row">
		

 <div class="col-lg-12 ">					
						<div class="col-md-3">
			<div class="form-group">
				<p> Passport</p>
			<img src="../<?php echo @$rows['passport'] ?>" alt="" class="img-responsive"  align="absmiddle" id="passport"/><br />
                
				</div>
				<div class="form-group">
							<p> Signature</p>
			<img src="../<?php echo @$rows['signature'] ?>" alt="" class="img-responsive"  align="absmiddle" id="signature"/><br />
               
				</div>
			
			</div>
			<div class="col-md-5">
			
			
		

	<input type="text" name="account_name" value=""class="form-control" id='ac_name'placeholder="Bank Account Name" required=""><br>
						<input type="text" name="account_number" class="form-control" id='ac_number'value="" placeholder="Bank Account Number"required=""><br>
						<input type="text" name="bank" class="form-control" id='bank'value="" required="" placeholder="Bank Name"><br>
	
					<input type="text" name="bvn" class="form-control" id='bvn'placeholder="BVN NO" required=""><br>
						<textarea  name="find" class="form-control" placeholder="How did you find us" required=""></textarea><br>
				<button class="btn btn-info" name="change" type="submit">SUBMIT</button>
				<?php
				if(isset($_POST['change'])){
					include'../function.php';
					$emp_status =escape($con,$_POST['emp_status']);
					$account =escape($con,$_POST['account_no']);
$emp_sector =escape($con,$_POST['emp_sector']);
$buz_name =escape($con,$_POST['buz_name']);
$buz_address =escape($con,$_POST['buz_address']);
$buz_status =escape($con,$_POST['buz_status']);
$rc_no =escape($con,$_POST['rc_no']);
$net_profit =escape($con,$_POST['net_profit']);
$mon_turnover =escape($con,$_POST['mon_turnover']);
$start_date =escape($con,$_POST['start_date']);
$buz_email =escape($con,$_POST['buz_email']);
$buz_phone =escape($con,$_POST['buz_phone']);
$tax_no =escape($con,$_POST['tax_no']);
$pension_no =escape($con,$_POST['tax_no']);
$student =escape($con,$_POST['student']);
$amount =escape($con,$_POST['amount']);

$duration =escape($con,$_POST['duration']);
$percent =escape($con,$_POST['percent']);
$structure =escape($con,$_POST['structure']);
$reason =escape($con,$_POST['reason']);
$repay_amount =escape($con,$_POST['repay_amount']);
if(isset($_POST['account_no'])){
		$account_number =escape($con,$_POST['account_number']);
	}
	if(isset($_POST['account_name'])){
		$account_name =escape($con,$_POST['account_name']);
	}
	if(isset($_POST['bank'])){
		$bank =escape($con,$_POST['bank']);
	}
	$bvn=escape($con,$_POST['bvn']);
$find =escape($con,$_POST['find']);
				
			$query="insert into loan  (emp_status,emp_sector,business_name,business_address,biz_status,rc_no,dialy_turnover,monthly_profit,biz_start,biz_email,biz_phone,tax_no,pension,student,account_no, amount,loan_duration,interest_rate,repayment_plan,reason_for_loan,repayment_plan_amount,find ) values(
'$emp_status','$emp_sector','$buz_name','$buz_address','$buz_status','$rc_no','$net_profit','$mon_turnover','$start_date','$buz_email','$buz_phone','$tax_no','$pension_no','$student','$account','$amount','$duration','$percent','$structure','$reason','$repay_amount','$find')";
mysqli_query($con,$query)or die(mysqli_error($con));
if(isset($_POST['account_no']) || isset($_POST['account_name']) || isset($_POST['bank'])){
	$query="insert into bank_info(bank_name,account_name,account_number,bvn,account_no)values('$bank','$account_name','$account_number','$bvn','$account')";
	mysqli_query($con,$query)or die(mysqli_error($con));
}
else{
	$query="update bank_info set bvn='$bvn' where account_no='$account_no'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
echo "<h3>Loan Application ws Successful</h3>";
				}	
				?>
				</div>
				</form>
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				<p class="">© 2017 E-Banking. Designed by <a href="../index.php">PEARL</a></p>
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "check.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			if(ajax.responseText=="Invalid"){
				document.getElementById("acc_err").innerHTML = ajax.responseText;
			}
			else{
				var data=ajax.responseText.split("|");
				var id_image=data[0];
				var passport=data[1];
				var signature=data[2];
				var name=data[3];
				var number=data[4];
				var bank=data[5];
				var bvn=data[6];
				document.getElementById("id_image").src="../"+id_image;
				document.getElementById("passport").src="../"+passport;
				document.getElementById("signature").src="../"+signature;
				document.getElementById("ac_name").value=name;
				document.getElementById("ac_number").value=number;
				document.getElementById("bank").value=bank;
				document.getElementById("bvn").value=bvn;
			}
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 </script>
		
</body>
</html>