<?php
include"header.php";
$bar="changepass";
?>


		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">changepass</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Change Admin Password</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                  
		
<div class='col-lg-8'>
<h3><span id='balance'></span></h3>
	<h4 class="page-header">Change Admin Password</h4>
	

<form action="" method="POST">

				
							
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Old Admin Password</span>
								<input class="form-control" placeholder="Old Payment Pin" name="old" type="text" required>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">New Admin Password</span>
								<input class="form-control" placeholder="New Payment Pin" name="new" type="password" required>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Confirm New Admin Password</span>
								<input class="form-control" value="" name="confirm" type="password"  placeholder='Confirm Payment Pin'>
							</div>
							<button class="btn btn-info" name="change" type="submit">Change Password</button>
				
				
				
				</form>
				
				<?php
			 
				 if (isset($_POST['change'])){

$confirm=$_POST['confirm'];;
$old=$_POST['old'];
$new=$_POST['new'];
if($confirm)
$query=mysqli_query($con, "select password from adminpanel where password='$old' and username='admin' ");

$check=mysqli_num_rows($query);

if($check > 0){
$queryup=mysqli_query($con, "UPDATE adminpanel SET password='$new' where username='admin'");	
	
}
else {
	echo "<p style='color:red;'>That not your old password</p>";
}
if(@$queryup){
	
echo "<script>alert('your password has been changed successfully ')</script>";
	
}
else{
	echo "<script>alert('An error Occured')</script>";
}
				 }
?>
</div>
				
				</div>




		
			
			
			
		</div><!--/.row-->
		
		</div>
	
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
	document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			var actype=data[4];
			var id=data[5];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
		
				document.getElementById("balance").innerHTML="Balance ₦ "+balance;
			 
			document.getElementById("actype").innerHTML += actype;
			document.getElementById("incorrect").innerHTML = '';
			}
		}
	}
	ajax.send("type="+types);
 
 }
 function update2(){
	
	var types=document.getElementById("actype").value;
	var account=document.getElementById("account_no").value;
	document.getElementById("results").innerHTML = 'please wait ...';
	 ajax.open("POST", "update2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var data=ajax.responseText.split("|");
			var structure=data[0];
			var id=data[1];
			
				document.getElementById("payment").value = structure;
				document.getElementById("id").value = id;
			 document.getElementById("results").innerHTML = '';
			
			
		}
	}
	ajax.send("type="+types+"&account="+account);
 
 }
 function check(){
	
	var account=document.getElementById("account_no").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	//alert(amount);
	var amounts=amount.replace(reg,""); 
	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
		document.getElementById("amount").innerHTML = '';	
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>	
<?php include"footer.php" ?>