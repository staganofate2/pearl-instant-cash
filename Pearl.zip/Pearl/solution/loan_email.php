<?php
include"connect.php";
$subject=$_POST['subject'];
$email=$_POST['email'];
$image=$_POST['image'];
$message=$_POST['message'];
$account=$_POST['account'];

$query="insert into loan_email (subject,email,image,message,account_no,sent_date) values('$subject','$email','$image','$message','$account',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select firstname,lastname from registeruser where account_number='$account'";
	$xx=mysqli_query($con,$query) or die(mysqli_error($con));

		$c=mysqli_fetch_array($xx);
			$firstname=$c['firstname'];
			$lastname=$c['lastname'];
			$messagess=htmlentities($message);
			$messagess=nl2br($message);
			
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td><h2>From: Pearl Instant Cash</h2></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="40%" height="40%"></td></tr>';
//$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/ThuOct17946092019124600048875.jpeg" alt="" width="100%" height="50%"></td></tr>';
if($image!=""){
    $messages.="<img  width='100%' height='200px'src='https://www.pearlinstantcash.com/$image' alt=''>";
			
}
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $messagess</p></td></tr><tr><td><p style='padding-left:10%;border:solid 1px'><a href='https://www.pearlinstantcash.com'> visit our website</a> | <a href='https://www.pearlinstantcash.com/login.php'>log in to your account </a>|<a href='https://www.pearlinstantcash.com/support.php'> get support</a><br>
Copyright &copy; Pearl Instant Cash, All rights reserved. </p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";
		/*	$message = '<html><body>';

$message .= '<table  border="0" cellpadding="10">';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%">';

$message.='</td></tr>';
$message .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%">';
if($image!=""){
    $message.="<img  width='100%' height='200px'src='https://www.pearlinstantcash.com/$image' alt=''>";
			
}
$message.='</td></tr>';
$message .= "<tr><td><p>$messages</p></td></tr>";



$message .= "</table>";
$message .= "</body></html>";*/

$to = "$email";


$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
			
		
	
	echo "done";	
	
exit();

								?>