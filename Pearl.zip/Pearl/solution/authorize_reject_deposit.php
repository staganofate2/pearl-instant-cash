<?php
session_start();
include"connect.php";
 $id=$_POST['id'];
$query="update deposit set rejected='1',confirm_user='admin',confirm_date=now() where deposit_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
exit();
?>