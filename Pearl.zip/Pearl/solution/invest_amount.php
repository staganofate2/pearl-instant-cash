<?php
session_start();
include_once('connect.php');
$amount=$_POST['amount'];
$amount=str_replace(",","",$amount);
$type=$_POST['type'];
$account=$_POST['account'];
$que="select* from investment where duration='$type' and account_no='$account' and active='0'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
if($row['interest']<$amount && $row['active']=="0"){
	echo "The amount you Entered is bigger than Your Withdrable Amount";
}
if($row['amount']<$amount && $row['active']=="1"){
	echo "The amount you Entered is bigger than You Total savings";
}
if($row['interest']>=$amount && $row['active']=="0"){
	echo "ok";
}
if((($row['amount']-$amount)>="0") && ($row['active']=="1")){
	echo "ok";
}
exit();



?>