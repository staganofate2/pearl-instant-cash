<?php
session_start();
include_once"connect.php";
$id=$_POST['id'];
$query="update loan  set rejected='1',authorize_user='admin',authorize_date=now() where loan_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
exit();
?>
	