<?php include"header.php";
$bar="new_accoount"; ?>
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">new account</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
		<div class='col-lg-2'>
 <table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table>   	
</div>
</div>	
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">New Account</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
 <div class="col-lg-2 ">
 </div>
 <div class="col-lg-8 ">
			   
				<h4 class="page-header">New Account Registration Form</h4>
					<?php
				if(isset($_POST['change'])){
					
					$structure=$_POST['structure'];
					$type=$_POST['type'];
					$account=$_POST['account_no'];
					$amount=$_POST['amount'];
					$amount=str_replace(",","",$amount);
					$mmonth=$_POST['mmonth'];
					$mdate=$_POST['mdate'];
					$mdate=trim($mdate);
					$percent=$_POST['percent'];
						if($mdate==""){
						if($type=="Vintage"){
		$mont="4";
	}
	else if($type=="Prime"){
		$mont="3";
	}
	else if($type=="Premium"){
		$mont="6";
	}
	else if($type=="Treasure"){
		$mont="8";
	}
	else if($type=="Partnership"){
		$mont="12";
	}
	if($type=="Coop Retirement"){
		$mont="24";
	}

    $date = date("Y-m-d", strtotime(" +$mont months"));
 
 $mdate=$date;
					}
					
						if($mmont==""){
						if($type=="Vintage"){
		$mmont="4 Months";
	}
	else if($type=="Prime"){
		$mmont="3 Months";
	}
	else if($type=="Premium"){
		$mmont="6 Months";
	}
	else if($type=="Treasure"){
		$mmont="8 Months";
	}
	else if($type=="Partnership"){
		$mmont="12 Months";
	}
	if($type=="Coop Retirement"){
		$mmont="24 Months";
	}
	}	
	if($percent==""){
						if($type=="Vintage"){
		$percent="2 %";
	}
	else if($type=="Prime"){
		$percent="1 %";
	}
	else if($type=="Premium"){
		$percent="3 %";
	}
	else if($type=="Treasure"){
		$percent="4 %";
	}
	else if($type=="Partnership"){
		$percent="5 %";
	}
	if($type=="Coop Retirement"){
		$percent="15 %";
	}
}
					if($amount>=1000){
					$query="select active from account where account_type='$type' and active='0' and account_no='$account'";
					$qwe=mysqli_query($con,$query) or die(mysqli_error($con));
					if(mysqli_num_rows($qwe)>0){
						echo "<h3 class='error'> Please you have an Active $type Account.<br>Choose a Different Account </h3>";
					}else{
					$query="insert into account (account_type,payment_structure,maturity_month,maturity_date,account_interest,account_no,regdate) values('$type','$structure','$mmonth','$mdate','$percent,','$account',now())";
					mysqli_query($con,$query)or die(mysqli_error($con));
					
					$id=mysqli_insert_id($con);
					
					echo "<h3>Your Account has been created Successfully</h3>";
					//echo "<h4>Date of Contributions </h4>";
	//echo "<table class='table'>";
	//echo "<tr><th>Dates</th></tr>";
if($type=="Prime"){
	
	if($structure=="Monthly"){
		$amounts=$amount*3;
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount',$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}else{
	    $amounts=$amount*13;
		for($i=0;$i<13;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
	}
	
}    
   elseif($type=="Vintage"){
	
	if($structure=="Monthly"){
		$amounts=$amount*4;
		for($i=0;$i<4;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}else{
	    $amounts=$amount*17;
		for($i=0;$i<17;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}
	
}    
elseif($type=="Premium"){
	
	if($structure=="Monthly"){
		$amounts=$amount*6;
		for($i=0;$i<6;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}else{
	    $amounts=$amount*26;
		for($i=0;$i<26;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
	}
	
}
elseif($type=="Treasure"){
	
	if($structure=="Monthly"){
		$amounts=$amount*8;
		for($i=0;$i<8;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}else{
	    $amounts=$amount*34;
		for($i=0;$i<34;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
		$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));	
	}
	
}  
elseif($type=="Partnership"){
	
	if($structure=="Monthly"){
		$amounts=$amount*12;
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}else{
	    $amounts=$amount*52;
		for($i=0;$i<52;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
	}
	
}
elseif($type=="Coop Retirement"){
	
			
	if($structure=="Monthly"){
		$amounts=$amount*24;
		for($i=0;$i<24;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
	}else{
	    $amounts=$amount*104;
		for($i=0;$i<104;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into account_pay(account_id,amount,account_no,pay_date)values('$id','$amount','$account','$date')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			//echo "<tr><td>$date</td><td>₦ 5000</td></tr>";
		}
			$query="update account set total='$amounts' where account_id='$id'";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
	}
	
}

	

//echo '</table>';
					





				}
					}else{
                        	echo "Deposit Amount should be at least N1000";
					}
				}else{
				?>
				<form action="" method="POST" enctype="multipart/form-data">
	<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update2()"placeholder='Enter Account Number' type="text">
							<span id='incorrect'></span>
							</div>
				<div class="form-group">
								<select name='structure' class="form-control">
								<option   value="">Select Payment Structure</option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
							
							
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update()">
								<option   value="">Select Account Type</option>
								<option   value="Prime">Prime</option>
								<option   value="Vintage">Vintage</option>
								<option   value="Premium">Premium</option>
								<option   value="Treasure">Treasure</option>
								<option   value="Partnership">Partnership</option>
								<option   value="Coop Retirement">Coop Retirement</option>
								</select>
								<span id='results'></span>
								
							</div>
							<div id='loaders'></div>
							<div class="form-group">
								<input class="form-control" id='percent' name="percent" placeholder='Percentage' type="text" readonly>
							</div>
							<div class="form-group">
								<input class="form-control" id='mmonth' name="mmonth" placeholder='Maturity Month' type="text" readonly>
							</div>
							<div class="form-group">
								<input class="form-control" value="" id='mdate' name="mdate" type="text" placeholder='Maturity Date' readonly>
								<input value="" id='mdate2' name="mdate2" type="hidden" >
							</div>
								<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Contribution Amount</span>
							<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount'  name="amount" type="text" placeholder='Amount in Digits' required>
								<span id='result'></span>
							</div>
							<button class="btn btn-info" name="change" type="submit">SUBMIT</button>
			
				</form>
				<?php
				}
				?>
			
 </div>





		
			
			
			
		</div><!--/.row-->
	
		
		
		</div>
		
	
				
				
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	 
	<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
 
 
 
 		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
function update2(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "updatee.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
				
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var actype=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first+" ";
			document.getElementById("last").innerHTML=last;
			
		document.getElementById("incorrect").innerHTML = '';
			}
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 function update(){
	
	var types=document.getElementById("actype").value;
	if(types=="Vintage"){
		var type="4";
	}
	else if(types=="Prime"){
		var type="3";
	}
	else if(types=="Premium"){
		var type="6";
	}
	else if(types=="Treasure"){
		var type="8";
	}
	else if(types=="Partnership"){
		var type="12";
	}
	if(types=="Coop Retirement"){
		var type="24";
	}
var b=document.getElementById("loaders").style.display="block";
//	document.getElementById("results").innerHTML = 'please wait ...';
	 ajax.open("POST", "date.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("mdate").value = ajax.responseText;
			 var data=ajax.responseText.split("/");
			 var day=data[0];
			 var mont=data[1];
			 var year=data[2];
			 var full=year+"/"+mont+"/"+day;
			  document.getElementById("mdate2").value=full;
			if(types=="Vintage"){
		  document.getElementById("percent").value="2%";
		  
		  
		  document.getElementById("mmonth").value="4 Months";
		  
		
		  
	  }
	  else if(types=="Prime"){
		
		  document.getElementById("percent").value="1%";
		  
		  document.getElementById("mmonth").value="3 Months";
		  
		  //document.getElementById("mdate2").value=mdate2;
		  
		  
	  }
	  else if (types=="Premium"){
		  document.getElementById("percent").value="3%";
		 
		  document.getElementById("mmonth").value="6 Months";
		  
		  //document.getElementById("mdate2").value=mdate2;
		  
		  
	  }
	  else if(types=="Treasure"){
		  document.getElementById("percent").value="4%";
		  
		  document.getElementById("mmonth").value="8 Months";
		  
		 // document.getElementById("mdate2").value=mdate2;
		  
		  
	  }
	 else if(types=="Partnership"){
		  document.getElementById("percent").value="5%";
		  
		  document.getElementById("mmonth").value="12 Months";

		  
		  //document.getElementById("mdate2").value=mdate2;
		  
		  
	  }
	  else if(types=="Coop Retirement"){
		  document.getElementById("percent").value="15%";
		 
		  document.getElementById("mmonth").value="24 Months";
		  
		  //document.getElementById("mdate2").value=mdate2;
	  }
		document.getElementById("results").innerHTML = '';	
		}
	}
	ajax.send("month="+type);
 
 }
  
   function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
  
  </script>	
</body>
</html>