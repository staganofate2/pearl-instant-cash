<?php
include"header.php";
$bar="view_deposit";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Messages</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href='my_message.php'>BACK</a></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Users Messages</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                   
                                   <thead>
<tr><th>Account Number</th><th>Phone</th><th>Title</th><th>Message</th><th>Sent Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from site_messages";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['phone'] ?></td><td> <?php echo $ree['title'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                
                                </table>
                            </div>
                            
                        </div><!-- end of panel-body -->




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
	if(confirm("Are you Sure you want to remove Suspension")){
	
//	document.getElementById("confirm"+id).innerHTML = 'please wait ...';
	var b=document.getElementById("loaders").style.display="block";
	
	 ajax.open("POST", "remove_suspension.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";	
			
				document.getElementById("confirm"+id).innerHTML ="suspension Removed Successfully";


		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	}
	
    </script>
		<?php include"footer.php" ?>