<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$types=$_POST['types'];
$types_id=$_POST['types_id'];
if($types=="Recharge"){
	
	$query="select* from rechargetwo  where status='0' and rechargetwo_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$amount=$e['amount'];

	$network=$e['network'];
	$query="update paystacktwo set confirmed='1' , sent_date=now() where confirmed='0' and paystacktwo_id='$id' and types_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

$http="https://mobileairtimeng.com/httpapi/?userid=08107302391&pass=912363232d306466ae2a1&network=$network&phone=$phone&amt=$amount&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 // print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
							$query="update rechargetwo set confirmed='1', sent_date=now() where confirmed='0'  and rechargetwo_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
										echo "done";
										exit();
} else{
	
											echo "Failed";
												exit();
										
}									
}

}
	
	
	
}elseif($types=="Bill"){
	$query="select* from billtwo where status='0' and billtwo_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$amount=$e['variation'];
	$name=$e['name'];
	$type=$e['types'];
	$cnumber=$e['cnumber'];
	$invoice=$e['invoice'];

	$number=$e['numbers'];
	$query="update paystacktwo set confirmed='1' where confirmed='0' and paystacktwo_id='$id' and types_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

if($type=="startimes"){

$http="https://mobileairtimeng.com/httpapi/startimes?userid=08107302391&pass=2513935&phone=$phone&amt=$amount&smartno=$number&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){
	$query="update billtwo set confirmed='1' , sent_date=now() where confirmed='0'  and billtwo_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
							
									
										echo "done";
											exit();
										
	}else{
											echo "Failed !!!";
												exit();
										}
}
			}else{


$http="https://mobileairtimeng.com/httpapi/multichoice?userid=08107302391&pass=2513935&phone=$phone&amt=$amount&smartno=$number&customer=$name&invoice=$invoice&billtype=$type&customernumber=$cnumber&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){				
							
									$query="update billtwo set confirmed='1' , sent_date=now() where confirmed='0'  and billtwo_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
										echo "done";
											exit();
										
	}else{
											echo "failed";
												exit();
										}
}



			}
}
	
	
	
}elseif($types=="Data"){
	

$query="select* from datastwo  where status='0' and datastwo_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$variation=$e['amount'];

	$network=$e['network'];
	$query="update paystacktwo set confirmed='1' where confirmed='0' and paystacktwo_id='$id' and types_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

$http="https://mobileairtimeng.com/httpapi/datatopup.php?userid=08107302391&pass=912363232d306466ae2a1&network=$network&phone=$phone&amt=$variation&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 // print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
							$query="update datastwo set confirmed='1' where  , sent_date=now() confirmed='0'  and datastwo_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
										echo "done";
											exit();
} else{
	
											echo "Failed";
												exit();
										
}									
}
}
	
}elseif($types=="SMS"){
	
	$query="select* from smstwo  where status='0' and smstwo_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$message=$e['message'];
	$sender=$e['sender'];
	$query="update paystacktwo set confirmed='1' where confirmed='0' and paystacktwo_id='$id' and types_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

$message=urlencode($message);				


 $http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);


if(strstr( $resp,"OK" )!=""){
	$query="update smstwo set confirmed='1' , sent_date=now() where confirmed='0'  and  smstwo_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
							
										echo "done";
											exit();
}else{
	
											echo "failed";
												exit();
										
}									
									
	}
	
}

?>