<?php
include"connect.php";
$query="update adminpanel set means='1' where username='admin'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
exit();
?>