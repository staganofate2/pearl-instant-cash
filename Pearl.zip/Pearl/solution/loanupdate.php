<?php
include"connect.php";
$account=$_POST['type'];
$x="";
$query="select*  from registeruser where account_number='$account'";
$er=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($er)>0){
	$we=mysqli_fetch_array($er);
	$x.=$we['picture']."|";
	$x.=$we['firstname']."|";
	$x.=$we['lastname']."|";
	$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
$x.=$row['total']."|";
 
								$query="select* from loan where account_no='$account' and active='0' and paid='0'";
								$fee=mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($fee)>0){
									$rows=mysqli_fetch_array($fee);
									
									$amount=$rows['total'];



if(($row['total']-$amount)>="500"){
	
									$x.="<option value='".$rows['amount']."'>". $rows['total']." Loan</option>"."|";
									$x.=$rows['repayment_plan']."|".$rows['total']."|".$rows['loan_id'];
}else{
	$x.="big";
}
									
									
								}else{
									$x.="Dont";
								}
								echo $x;
								exit();
}else{
	echo "Incorrect";
	exit();
}
								?>