<?php include"header.php";
$bar="remove_admin";
 ?>
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Amin User</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href="remove_admin.php">View removed Staff</a></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header"> Admin  Staff</h4>
	
				   
				
								<div class="col-md-8">
				
				

				
<table>

			
            
							
							<table class="table">
				<tr>
				
				<th>Username</th><th>Role</th><th>View Password</th><th>Action</th>
				</tr>
							
							
								<?php 
								$query="select* from adminpanel where username !='admin' and remove = '0'";
							$result=mysqli_query($con,$query) or die(mysqli_error($con));
							if(mysqli_num_rows($result)>0){
								while($rows=mysqli_fetch_array($result)){
								?>
						
						
				<tr>
				
				<td><?php echo $rows['username'] ?></td>
				
				
				<td><?php echo $rows['role']; ?></td>
				
				
				<td><input  type='password' readonly value="<?php echo $rows['password']; ?>" id='pass<?php echo $rows['id']?>'><button onclick="showpass('<?php echo $rows['id'] ?>')">View<button></td>
				<td id="confirm<?php echo $rows['id'] ?>"><button  onclick='update("<?php echo $rows['id'] ?>")'>Remove</button></td>				</tr>
				
				
				
				
				<?php
				}
				}
				?>
				</table>

						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>
		
		
	
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
			 
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
if(confirm("Are You sure You want to Remove User ?")){
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "remove_user.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
			}
	function showpass(id){
		var type=document.getElementById("pass"+id).type;
		if(type=="password"){
			document.getElementById("pass"+id).type="text";
		}else{
			document.getElementById("pass"+id).type="password"
		}
	}
    </script>
		
		
</body>
</html>