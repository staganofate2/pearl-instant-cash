<?php
include"header.php";
$bar="chat";
?>


		<style>
#unread{
	background:green;
}
</style
		
		<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Chat</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header" >Chat</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
						
<!------------------------------------------------table for message----------------------------------------->



<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Message Sent by User</strong>
							 
                        </div>
                        <div class="panel-body">
                            
							
					<?php

$query="select con.userone as sender ,m.message as message,m.mdate as date,m.red,  con.usertwo as reve from  message m , conversation con ,registeruser r where case when con.userone='admin' then con.usertwo =r.account_number when con.usertwo='admin' then con.userone=r.account_number end and con.conversation_id=m.conversation_id  and con.usertwo='admin'";
$res=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($res)<1){

echo"<h4>You have no message  yet</h4>";

}
else{
	
	echo "<h4>MESSAGES FROM USERS</h4>";


$arr=array();

	
while($row=mysqli_fetch_array($res)){
	
	if(in_array($row['sender'],$arr)){
		continue;
	}else{
		array_push($arr,$row['sender']);
	}
	
if($row['sender']=="admin"){
?>
<a href="chats.php?receiver=<?php echo $row['reve'] ;?>"><div ><b> <?php echo $row['reve']."</b>   <span style='color:red'>on ".$row['date']."</span> <br><p style='color:black;margin-left:30px'>".$row['message']."</p></a>";

}
else{	$query="select firstname,lastname from registeruser where account_number='".$row['sender']."'";
	$aq=mysqli_query($con,$query)or die(mysqli_error($con));
	$x=mysqli_fetch_array($aq);
	$sender=$x['firstname']." ".$x['lastname'];

	?><a href="chats.php?receiver=<?php echo $row['sender'] ;?>"><div <?php if($row['red']=="0"){ echo "id='unread'";} ?>><b style='color:blue'><?php echo $sender."</b>   <span style='color:red'>on ".$row['date']."</span> <br><p style='color:black;margin-left:30px'>".$row['message']."</p></div></a>";
}
	
	
		}
	?>
	
<?php	
}



echo "</div>";



?>		


						
						
                    </div>



<!-------------------------------table for message ends here------------------------------------>

					
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<?php include"footer.php" ?>