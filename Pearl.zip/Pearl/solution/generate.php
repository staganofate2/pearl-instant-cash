<?php include"header.php";
$bar="generate" ;?>
		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">generate</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Generate Account Number</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-2 ">
 </div>
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header"> Account Number Generation Form</h4>
	<form role="form" action="" method="POST">
				<?php
				if(isset($_POST['submit'])){
				$acct=mysqli_real_escape_string($con,$_POST['acct']);
				
								
								for($i=0;$i<$acct;$i++){
								$code=rand(1000000000,9999999999);
									$query="select account_no from account_number where account_no='$code'";
								$ac=mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($ac)<1){
									$query="insert into account_number (account_no,regdate) values('$code',now())";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							
								}
								
										
									}
									echo "<h3>Account Number Generateed Successfully</h3><h4><a href='generate.php'>Generate Another Account Number</a></h4>";
										
				}else{
				   ?>
			

						
						
						<div class="form-group">
								<input class="form-control" placeholder="ENTER HOW MANY NUMBER TO GENERATE" name="acct" id='account_no' type="text"  required>
							</div>
							<button class="btn btn-info" type="submit" name="submit">GENERATE</button>
							
						<?php
				}
				?>
				</form>		
						
				
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
			<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(){
	

	id=document.getElementById("account_no").value;
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updates.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				if(ajax.responseText=="Incorrect"){
					alert("Incorrect Account Number");
				}else{
					var data=ajax.responseText.split("|");
					var picture=data[0];
					var first=data[1];
					var last=data[2];
					document.getElementById("picture").src="../"+picture;
					document.getElementById("first").innerHTML=first;
					document.getElementById("last").innerHTML=last;
				}

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
    </script>
		<?php include"footer.php" ?>