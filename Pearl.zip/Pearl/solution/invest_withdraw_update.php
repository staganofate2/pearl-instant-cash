<?php
session_start();
include_once('connect.php');
$type=$_POST['type'];
$account=$_POST['account'];
$que="select* from investment where duration='$type' and account_no='$account'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
if(mysqli_num_rows($res)>0){
$row=mysqli_fetch_array($res);
$gtotal=$row['amount']+$row['interest'];
echo $row['maturity_date']."|".$row['start_date']."|".$row['amount']."|".$row['interest']."|".$gtotal."|".$row['interest']."|".$row['investment_id']."|".$row['active'];
exit();
}else{
    exit();
}
?>