<?php
include"header.php";
$bar="addbankinfo";

?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">food delivery</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Add Food Delivery Information</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class='col-lg-2'>
 <table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table>   	
</div>	
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header">Food Delivery Information</h4>
	<?php
								if(isset($_POST['change'])){
					
					
					
					$type=$_POST['type'];
					
					$account=$_POST['account_no'];
					$name=$_POST['name'];
					$address=$_POST['address'];
					$lga=$_POST['lga'];
					$state=$_POST['state'];
					$phone=$_POST['phone'];
					$query="select food_id  from delivery where food_id='$type'  and account_no='$account'";
					$qwe=mysqli_query($con,$query) or die(mysqli_error($con));
					if(mysqli_num_rows($qwe)>0){
						echo "<h3> Please you have Delivery Information for the selected Food Account.<br>Choose a Different Account </h3>";
					}else{
					$query="insert into delivery (food_id,name,phone,address,lga,states,account_no) values('$type','$name','$phone','$address','$lga','$state','{$_SESSION['account']}')";
					
					mysqli_query($con,$query)or die(mysqli_error($con));
					$query="update food set delivery='1'  where food_id='$type'";
					mysqli_query($con,$query)or die(mysqli_error($con));
					
echo "<h3>Your Food Delivery has been created Successfully</h3>";
                                        
				}
				}else{
								
?>
	<form role="form" action="" method="POST">
				
<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
							<span id='incorrect'></span>
							</div>
						
											<div class="form-group">
								<select name='type' class="form-control" id='actype' >
								<option   value="">Select Package Plan</option>
								
								</select>
							</div>
							<div id='loaders'></div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Receiver Name</span>
								<input class="form-control" id='duration' name="name" placeholder='Full Name' type="text" >
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Receiver Address</span>
								<input class="form-control" id='due' name="address" placeholder='Address' type="text" >
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Receiver Phone</span>
								<input class="form-control" id='amount' name="phone" placeholder='Phone Number' type="text" >
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">L.G.A</span>
								<input class="form-control" value="" id='mdate' name="lga" type="text" placeholder='L.G.A'>
							
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">State</span>
								<input class="form-control" value="" id='mdate' name="state" type="text" placeholder='State'>
							
							</div>
							
							
							
							<button class="btn btn-info" name="change" id='submit'type="submit">SUBMIT</button>
							
						
				</form>		
						
				<?php
				}
				?>
			
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
		var b=document.getElementById("loaders").style.display="block";
		//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update_delivery.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var actype=data[3];
	
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
		
			 if(actype=="Dont"){
				 alert("You Dont Have any food account to add delivery information");
			 }else{
			document.getElementById("actype").innerHTML += actype;
			 }
			document.getElementById("incorrect").innerHTML = '';
			}
			 
		}
	}
	ajax.send("type="+types);
 
 }
 </script>
		<?php include"footer.php" ?>