<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$query="update transfer set status='1' ,sender='{$_SESSION['confirm']}',sent_date=now() where transfer_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
?>