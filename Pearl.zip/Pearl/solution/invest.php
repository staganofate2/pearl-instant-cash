<?php
include"header.php"; 
$bar="invest";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Invest</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Invest</h2>
				<table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table> 
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
         <h3><span id='balance'></span></h3>               
						
	<h4 class="page-header">Investment Form</h4>
	<form action="payments.php" method="POST" enctype="multipart/form-data">
<div class="form-group">
	<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update2()"placeholder='Enter Account Number' type="text">
							</div>
							<span class="badge" style="background-color:#3385FF;">Investment Name</span>
								<input class="form-control"  id="name"name="name" type="text" placeholder="Enter A name for you Investment" required>
								</div>
								<div class="form-group">
								<span class="badge" style="background-color:#3385FF;">Investment Amount</span>
									
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' onblur="check()" name="amount" type="text" placeholder='Amount in Digits' required>
								<span id='result'></span>
							
							</div>
							<div id='loaders'></div>
				<div class="form-group">
								<select name='duration' id='duration' class="form-control" onchange="update()">
								<option   value="">Select Investment Duration</option>
								<option   value="3 Months">3 Months</option>
								<option   value="6 Months">6 Months</option>
								<option   value="9 Months">9 Months</option>
								<option   value="12 Months">12 Months</option>
								
								
								</select>
							</div>
							
							
							
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Monthly Investment Interest Rate</span>
								<input class="form-control" id='percent' name="percent" placeholder='Monthly Investment Interest Rate' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Monthly Interest Withdrawable</span>
								<input class="form-control" id='imonth' name="imonth" placeholder='Monthly Interest Withdrawable' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Investment Maturity Date</span>
								<input class="form-control" value="" id='mdate' name="mdate" type="text" placeholder='Investment Maturity Date' readonly>
							
								
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Duration Interest</span>
								<input class="form-control" value="" id='total' name="total" type="text" placeholder='Total Duration Interest' readonly>
								
							</div>
						
				
							<button class="btn btn-info" id='submit'name="change" type="submit">SUBMIT</button>
				
				</form>
				
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		
				<script>
 
 		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("duration").value;
	var amount=document.getElementById('amount').value;
	var reg=/,/;
	var amounts=amount.replace(reg,""); 
	if(types=="3 Months"){
		var type="3";
	}
	else if(types=="6 Months"){
		var type="6";
	}
	
	else if(types=="9 Months"){
		var type="9";
	}
	else if(types=="12 Months"){
		var type="12";
	}
	
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "date.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("mdate").value = ajax.responseText;
				var interest=(10*amounts)/100;
				document.getElementById("imonth").value=interest;
			 
			if(types=="3 Months"){
		  document.getElementById("percent").value="10%";
		  var total=(10*amounts*3)/100;
		  document.getElementById("total").value=total;
		  
		 // document.getElementById("mmonth").value="3 Months";
		  
	  }
	  else if(types=="6 Months"){
		
		  document.getElementById("percent").value="10%";
		  
		  //document.getElementById("mmonth").value="6 Months";
		  var total=(10*amounts*6)/100;
		  document.getElementById("total").value=total;
		 
		  
	  }
	  else if (types=="9 Months"){
		  document.getElementById("percent").value="10%";
		 
		  //document.getElementById("mmonth").value="9 Months";
		  
		 var total=(10*amounts*9)/100;
		  document.getElementById("total").value=total;
	  }
	  else if(types=="12 Months"){
		  document.getElementById("percent").value="10%";
		  
		 // document.getElementById("mmonth").value="12 Months";
		  
		var total=(10*amounts*12)/100;
		  document.getElementById("total").value=total;
		 
	  }
	
			
		}
	}
	ajax.send("month="+type);
 
 }
 function update2(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatee.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Incorrect"){
				
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			document.getElementById("balance").innerHTML="Balance ₦ "+balance;
			
	
			 
			}
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	var account=document.getElementById("account_no").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	
	var amounts=amount.replace(reg,""); 
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "check_invest_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
  
  </script>	
		
<?php include"footer.php" ?>