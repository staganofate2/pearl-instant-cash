<?php
include"header.php";
$bar="view_withdrawal";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">send bill</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Email confirmation Code</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All emai code</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Email</th><th>Account No</th><th>Phone</th><th>Code</th><th>Used</th><th>Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from em_confirm";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						$query="select phone from registeruser where account_number='".$ree['account_no']."'";
						$re=mysqli_query($con,$query) or die(mysqli_error($con));
						$ress=mysqli_fetch_array($re);
					?>
				<tr>
				<td> <?php echo $ree['email'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ress['phone'] ?></td><td><?php echo $ree['code'] ?></td><td><?php if($ree['confirm']=="1"){echo "Yes";}else{echo "No";} ?></td><td><?php echo $ree['regdate'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_bill.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function cancels(id,account){
	

	if(confirm("Are You sure  your want to Cancel Order ?")){
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "cancel_bill.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("cancel"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&account="+account);
	}
		}
    </script>
	<?php include"footer.php" ?>