<?php
include_once"connect.php";
$account=$_POST['account'];
$amount=$_POST['amount'];
$id=$_POST['id'];
$ref=$_POST['ref'];
$method=$_POST['method'];
$remark="";
$query="select* from deposit where authorize='1' and deposit_id='$id'";
$k=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($k)<1){
	$s=mysqli_fetch_array($k);
	if($s['category']=='Account'){
		$query="update registeruser set paid='1' where account_number='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
	}
	elseif($s['category']=='DSHA'){
	}else{
$query="select* from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	$amounts=$rows['total']+$amount;
			
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
if($rows['active']=="0"){
	if($amounts >="1000"){
	$query="update wallet set active='1' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
	$query="update registeruser set paid='1' where account_number='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
}
}
$query="update deposit set authorize='1', total='$amount',authorize_user='admin',authorize_date=now() where deposit_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was credited into your Wallet Account";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$account','$amount','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$id','$method','$account','$amount','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
}
	}


$message="Your $amount  Account Deposit has been Confirmed";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));



$query="select phone,firstname,lastname,email_address from registeruser where account_number='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$roo=mysqli_fetch_array($de);
$emessage="<table><tr><td>Date</td><td>".date('d-m-Y')."</td></tr>
<tr><td>Description</td><td> $description</td></tr>
<tr><td>Reference No </td><td>$ref</td></tr>
<tr><td>Wallet Id </td><td>$account</td></tr>
<tr><td>Amount </td><td>N $amount</td></tr>
<tr><td>Balance</td><td>N $amounts</td></tr></table>";
$firstname=$roo['firstname'];
$lastname=$roo['lastname'];
$email=$roo['email_address'];

	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td><h2>From: Pearl Instant Cash</h2></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="40%" height="40%"></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/ThuOct17946092019124600048875.jpeg" alt="" width="100%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $emessage</p></td></tr><tr><p style='padding-left:10%;border:solid 1px'><a href='https://www.pearlinstantcash.com'> visit our website</a> | <a href='https://www.pearlinstantcash.com/login.php'>log in to your account </a>|<a href='https://www.pearlinstantcash.com/support.php'> get support</a><br>
Copyright &copy; Pearl Instant Cash, All rights reserved. </p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
/*
//$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
$ch = curl_init();
  
  $fields = array( "username"=>"09011050718","password"=>"41cdc627060c593b70240c","message"=>"$message","mobile"=>"$phone","sender"=>"$sender","route"=>"1","vtype"=>"1");
  $postvars = '';
  foreach($fields as $key=>$value) {
    $postvars .= $key . "=" . $value . "&";
  }
  $url = "https://www.mobileairtimeng.com/smsapi/bulksms.php";
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_POST, 1);                //0 for a get request
  curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
  curl_setopt($ch,CURLOPT_TIMEOUT, 20);
  $response = curl_exec($ch);
  //print "curl response is:" . $response;
  curl_close ($ch);
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource


$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
   $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);*/
echo "done";
exit();
}else{
echo "failed";
exit();	
}

?>