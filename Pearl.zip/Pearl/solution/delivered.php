<?php include"header.php";
$bar="view_account"; ?>
		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">view Delivered food</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">View Delivered Food</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Food Account</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Package Name</th><th>Date</th><th>Targeted Amount</th><th>Contributed Amount</th><th> Items</th><th> Duration</th><th>Start Date</th><th>Maturity Date</th><th>Payment Structure</th><th>Distribution Date</th><th>Delivery Info</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from food where delivery='1'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no']  ?></td><td><?php echo $ree['package_name'] ?></td><td> <?php echo  $ree['regdate']?></td><td>₦ <?php echo $ree['total'] ?></td><td>₦ <?php echo $ree['amount'] ?></td>
				<td> <?php echo $ree['items'] ?></td><td> <?php echo $ree['duration'] ?></td><td><?php echo $ree['start_date'] ?></td><td><?php echo $ree['maturity_date'] ?></td>
				<td><?php echo $ree['payment_structure'] ?></td><td><?php  if($ree['distribute_date']=="0000-00-00"){echo "<a href='distribute.php?id=".$ree['food_id']."'>Add Distribute Date</a>";}else{echo $ree['distribute_date'];} ?></td><td><?php if($ree['delivery']=="0"){echo "No delivery Info";}else{echo "<a href='delivery_info.php?id=".$ree['food_id']."'>View Delivery Info</a>";} ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		
	<?php include"footer.php" ?>