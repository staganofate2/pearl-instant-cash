<?php
include"header.php";
?>

    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
    <!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
    
    <style type="text/css" rel="stylesheet">
        body {
            background: #fff;
        }
        #container {
            width: 940px;
            margin: 0 auto;
        }
        @media only screen and (max-width: 768px) {
            #container {
                width: 90%;
                margin: 0 auto;
            }
        }
    </style>
<style>
  /* Style the buttons that are used to open and close the accordion panel */
.accordion {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    text-align: left;
    border: none;
    outline: none;
    transition: 0.4s;
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.active, .accordion:hover {
    background-color: #ccc;
}

/* Style the accordion panel. Note: hidden by default */
.panel {
    padding: 0 18px;
    background-color: white;
    display: none;
    overflow: hidden;
} 
 </style>
    <div id="container">

       

        <h2>Horizontal Tab with (Nested Tabs) </h2>
        <br/>
        <!--Horizontal Tab-->
        <div id="parentHorizontalTab">
            <ul class="resp-tabs-list hor_1">
                <li>Activities</li>
                <li>Loan Profile</li>
                <li>Loan Statement</li>
            </ul>
            <div class="resp-tabs-container hor_1">
                <div>
                    <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_1">
                            <ul class="resp-tabs-list ver_1">
                                <li>Reminders</li>
                                <li>Messages</li>
                                <li>Calls</li>
                                <li>Emails</li>
                            </ul>
                            <div class="resp-tabs-container ver_1">
                               <!-- reminders -->
							   <div>     
							   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Title</th><th>Message</th><th>Remind Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_reminder";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td><?php echo $ree['title']  ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    
                                </div>
								<p>Reminders</p>
								</div>
								<!-- end of reminders -->
                                <div>
								   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Messages</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Title</th><th>Message</th><th>Remind Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_message";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td> <?php echo $ree['title'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    
                                </div>
                                    <p>Messages</p>
                                </div>
                                <div>
								   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Phone</th><th>Message</th><th>Status</th><th>Call Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_call";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td><td><?php echo $ree['phone'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['status'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    
                                </div>
                                    <p>Calls</p>
                                </div>
                                <div>
								   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Subject</th><th>Message</th><th>Sent Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_email";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td>₦ <?php echo $ree['subject'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        
                                    
                                </div>
                                    <p>Emails</p>
                                </div>
                            
                        
                    </p>
                    <p>Tab 1 Container</p>
                </div>
                <!--form -->
				<div>
				
				<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no2'  style='width:60%' name="account_no2" onblur="update_profile()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
				profile
				
				
                    
                    <br>
                    <br>
                    <p>Tab 2 Container</p>
                </div><!-- end of form -->
                <!--  statement -->
				<div>
				<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no2' style='width:60%'name="account_no2" onblur="update_statement()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
                    <br>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
				<!-- end of statement -->
            </div>
        </div>
        <div id="nested-tabInfo">
            Selected Item: <span class="tabName"></span>
        </div>
        <br/>
        <br/>
        <br/>


        
        <!--Vertical Tab-->
        <div id="parentVerticalTab">
            <ul class="resp-tabs-list hor_1">
                <li>Confirm Loan</li>
                <li>Authorize Loan</li>
                <li>Loan Form</li>
            </ul>
            <div class="resp-tabs-container hor_1">
                <div>
				
				
                </div>
				
				 <div>
				
				<h4 class="page-header">Authorize Loan</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <div id='loaders'></div>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Category</th><th>Account No</th><th>Repayment Plan Amount</th><th>Duration</th><th>Interest</th><th>Requested Amount</th><th>Amount</th><th>Total Deposit</th><th>Ref NO</th><th>Date</th><th>Confirmed</th><th>Action</th><th></th><th></th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan where confirm='0' and rejected='0' and amount !='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
					?>
				<tr>
				<td><?php echo $ree['category'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['repayment_plan_amount']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['req_amount'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php  $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td><td id="confirm<?php echo $ree['loan_id'] ?>">
				    <?php $query="select* from paystackloan where account_no='".$ree['account_no']."' and paid='1' and remove='0' and authorization_code !=''"; $x=mysqli_query($con,$query) or  die(mysqli_error($con));if(mysqli_num_rows($x)>0){
				    ?>
				    <button  onclick='update("<?php echo $ree['loan_id'] ?>")'>Confirm</button>
				    <?php
				    }
				    ?>
				    </td><td id="reject<?php echo $ree['loan_id'] ?>"><button  onclick='reject("<?php echo $ree['loan_id'] ?>")'>Reject</button></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
				
				
				
                  Confirm <br>
                    <br>
                    <p>Tab 1 Container</p>
                </div>
				
				
				
				
               
				
				
				
                <div>
                   <form action="" method="POST" enctype="multipart/form-data">
		
			<p>ID image</p>
			
				<img src="../images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile" id="ufile5" accept="image/*" onchange="loadFile(event)"  /><br>
				
				
			
			<div id='loaders'></div>
			
			
			<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err'></span>
							</div>
			
				
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br><br>
		<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Employment Status</span>
			<select name="emp_status" class="form-control" id='emp_status'  required="">
						<option value="">---EMPLOYMENT STATUS---</option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						
						
</select>	</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Employment Sector</span>
						<input type="text" name="emp_sector" id='emp_sector' value=""class="form-control" placeholder="EMPLOYMENT SECTOR" ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Name</span>
						<input type="text" id='buz_name'name="buz_name"value="" class="form-control" placeholder="BUSINESS NAME" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Busiess Address</span>
						<input type="text" name="buz_address" id='buz_address'value=""class="form-control" placeholder="BUSINESS ADDRESS" required=""><br>
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Status</span>
						<select name="buz_status" id='buz_status'class="form-control"  required="">
						<option value="">----Business Registration Status---</option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select><br>

				</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">RC Number</span>			
						
						<input type="text" name="rc_no" value=""class="form-control" id='rc_no' placeholder="RC NO" required=""><br>
							</div>
							<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Means of Identification</span>
				<select name="id" class="form-control" id='id' required="">
						<option value="">----Select Identification ---</option>
						<option value="National ID">National Id-card </option>
						<option value="Driver License">Driver License</option>
						<option value="Voters Card">Voters Card</option>
						<option value="International Passport">International Passport</option>
						</select>
						
			
						
						</div>
						<div class='form-group'>
						
<span class="badge" style="background-color:#3385FF;">ID Number</span>

						<input type="text" name="id_no" id='id_no'value="" class="form-control" title="ID NUMBER" >	
					
						</div>
						
							<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Issue Date *</span><br><br>
						 <input type='date' name="isdate"  id='isdate' class="form-control" value="" >
 
</div><div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate" id='exdate'  class="form-control" value=''>
 
</div>
							
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Daily Turnover</span>
						<input type="text" name="net_profit" id='net_profit'value="" class="form-control" placeholder="DAILY TURNOVER" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Monthly Turnover</span>
						<input type="text" name="mon_turnover" id='mon_turnover'value=""class="form-control" placeholder="NET MONTHLY MONTHLY" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Start date</span>
						<input type="date" name="start_date" id='start_date'value="" class="form-control"  ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Email</span>
						<input type="email" name="buz_email" id='buz_email'value="" class="form-control" placeholder="BUSINESS EMAIL" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Phone</span>
						<input type="text" name="buz_phone" id='buz_phone' value=""class="form-control" placeholder="BUSINESS PHONE" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Tax Number</span>
						<input type="text" name="tax_no" id='tax_no'value="" class="form-control" placeholder="TAX NO" ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Pension Number</span>
						<input type="text" name="pension_no" id='pension_no'value="" class="form-control" placeholder="PENSON NO"><br>
						
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Occupation</span>
						<select name="occupation" id='occupation' class="form-control"  required="">
						<option value=""> ----Occupation---</option>
						<option value="Student">Student</option>
						<option value="Trader">Trader</option>
						<option value="Technician">Technician</option>
						<option value="Accountants">Accountants</option>
							<option value="Accounting">Accounting</option>
							<option value=" Administrator"> Administrator</option>
							<option value="Administrative Assistants">Administrative Assistants</option>
							<option value="Advertiser">Advertiser</option>
							<option value="Agents">Agents</option>
							<option value="Air Conditioning Installers">Air Conditioning Installers</option>
							<option value="Analysts">Analysts</option>
							<option value="Architech">Architech</option>
							<option value="Artists">Artists</option>
							<option value="Asphalt Paving Machine Operators">Asphalt Paving Machine Operators</option>
                            <option value="Assistants">Assistants</option>
							<option value="Athletes">Athletes</option>
							<option value="Automobile Body Repair">Automobile Body Repair</option>
							<option value="Bank">Bank</option>
							<option value="Bookkeeping">Bookkeeping</option>
							<option value="Cafeteria">Cafeteria</option>
							<option value="Carpenter">Carpenter</option>
							<option value="Certified Nurse Midwives">Certified Nurse Midwives</option>
							<option value="Cleaner">Cleaner</option>
							<option value="Contractor">Contractor</option>
								<option value="Cooks">Cooks</option>
																<option value="Counselor">Counselor</option>
                                <option value="Doctor">Doctor</option>
								<option value="Comedian">Comedian</option>
                            <option value="Drivers">Drivers</option>
							<option value="Economics">Economics</option>
                                <option value=" Electricians"> Electricians</option>
								<option value="Engineer">Engineer</option>
								<option value="Equipment Installers">Equipment Installers</option>
								<option value="Equipment Operators">Equipment Operators</option>
								<option value="Feed Manager">Feed Manager</option>
								<option value="Graphic Designer">Graphic Designer</option>
								<option value="House helper">House helper</option>
                                <option value="librarian">Libralian</option>
                            
                                <option value="Lawyer">Lawyer</option>
                            
                                <option value="Security">Security</option>
                            
                                
                            
                                
                            
                                <option value="Photographer">Photographer</option>
                            
                                <option value="Web Designer">Web Designer</option>
								<option value="Phone Engineer">Phone Engineer</option>
								
								
								<option value="Sales girl">Sales girl</option>
								<option value="Sales boy">Sales boy</option>
								<option value="Radiographers">Radiographers</option>
								
								
								<option value="Spiritualist">Spiritualist</option>
								
								
								<option value="Teachers">Teachers</option>
								
								<option value="Mathematicians">Mathematicians</option>
								
								<option value="Managerial services">Managerial services</option>
								
								<option value="Photographer">Photographer</option>
								<option value="Rental">Rental</option>
								
								
								<option value="Nanny">Nanny</option>
								
								<option value="Mechanics">Mechanics</option>
								
								<option value="Medical Technician">Medical Technician</option>
								
								
								<option value="News Broadcaster">News Broadcaster</option>
								<option value="Painters">Painters</option>
								<option value="Sculptors Arts Producer">Sculptors Arts Producer</option>
								
								
								<option value="Medical laboratory Scientist">Medical laboratory Scientist</option>
								<option value="Nursing, Attendants">Nursing, Attendants</option>
								
								<option value="Social Workers">Social Workers</option>
								
								<option value="Laborer">Laborer</option>
								
								<option value="Marriage Counselor">Marriage Counselor</option>
								<option value="Doctors of Optometry">Doctors of Optometry</option>
								<option value="Public Health">Public Health</option>
								<option value="Elevator Installers">Elevator Installers</option>
								<option value="Repairers">Repairers</option>
								<option value="Epidemiologists">Epidemiologists</option>
								<option value="Physician Assistant">Physician Assistant</option>
								<option value="Firefighters">Firefighters</option>
								<option value="Drying Machine Operators">Drying Machine Operators</option>
								<option value="Health Diagnosing Practitioners">Health Diagnosing Practitioners</option>
								<option value="Tenders">Tenders</option>
								<option value="Helpers">Helpers</option>
								<option value="Plumber">Plumber</option>
								<option value="Pipefitters">Pipefitters</option>
								<option value="Home Appliance Repairers">Home Appliance Repairers</option>
								<option value="Hospital Registerers">Hospital Registerers</option>
								<option value=" Labor Economics Property Manager"> Labor Economics Property Manager</option>
								<option value="Librarians">Librarians</option>
								<option value="Clinical Mental Health Counselor">Clinical Mental Health Counselor</option>
								<option value="Logistics Planner">Logistics Planner</option>
								<option value="Mortician">Mortician</option>
								<option value="Movie Projectionists">Movie Projectionists</option>
								<option value="Nutritionists">Nutritionists</option>
								<option value="Public Health Specialist">Public Health Specialist</option>
								<option value="Pay loader Operator">Pay loader Operator</option>
								<option value="Painter">Painter</option>
								<option value="Makeup Artist">Makeup Artist</option>
								<option value="Pharmacist Technicians">Pharmacist Technicians</option>
								<option value="Pharmacists">Pharmacists</option>
								<option value="Wedding Planner">Wedding Planner</option>
								<option value="Equipment Repairers">Equipment Repairers</option>
								<option value="Physician">Physician</option>
								<option value="Surgeon">Surgeon</option>
								<option value="Marketing">Marketing</option>
								<option value="Weaving">Weaving</option>
								<option value="Fashion/dressmaking">Fashion/dressmaking</option>
								<option value="Property Managers">Property Managers</option>
								<option value="Real Estate developers">Real Estate developers</option>
								<option value="Car Repairers">Car Repairers</option>
								<option value="Real Estate Brokers">Real Estate Brokers</option>
								<option value="Rehabilitation Repairers">Rehabilitation Repairers</option>
								<option value="Sales Agents">Sales Agents</option>
								<option value="Shipping Agents">Shipping Agents</option>
								<option value="Healthcare">Healthcare</option>
								<option value="Software Developers">Software Developers</option>
								<option value="Solar Panel Installation Supervisor">Solar Panel Installation Supervisor</option>
								<option value="Supervisors">Supervisors</option>
								<option value="Gaming Supervisors">Gaming Supervisors</option>
								<option value="Urban Planner">Urban Planner</option>
								<option value="Waiter">Waiter</option>
								<option value="Waitresses">Waitresses</option>
								<option value="Gate man">Gate man</option>
																<option value="Programmer">Programmer</option>
								<option value="Seller">Seller</option>
						
</select>
						</div>
						<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
						
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Amount</span>
						<input type="text" id='amount'name="amount"onkeyup="this.value = numFormat(this.value)" value="<?php if(isset($_POST["amount"])){echo $_POST["amount"];}  ?>" class="form-control" placeholder="ENTER AMOUNT" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Duration</span>
								<select name='duration' class="form-control" id='duration'required="">
								<option   value="">Select LOAN Duration </option>
								<option   value="1 Month">1 Month</option>
								<option   value="2 Months">2 Months</option>
								<option   value="3 Months">3 Months</option>
								<option   value="4 Months">4 Months</option>
								<option   value="6 Months">6 Months</option>
								<option   value="12 Months">12 Months</option>
								
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Loan Percentage</span>
								
								<select name="percent" class="form-control" id='percent' required="" onchange="calculate()">
						<option value="">----Monthly Investment Interest Rate</option>
						
						
						<option value="30">30%</option>
						<option value="20">20%</option>
						<option value="10">10%</option>
						
						
</select><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Payback Amount</span>
								<input class="form-control" id='total' name="total" value=""placeholder='Payback Amount' readonly type="text">
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Repayment Plan Amount</span>
								<input class="form-control" id='repay'required=""  name="repay_amount" value=""placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Payment Structure</span>
								<select name='structure'  class="form-control"required="" >
								<option   value="">Select Repayment Structure </option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Reason for Loan</span>
						<textarea  name="reason"value="" id='reason'class="form-control" placeholder="Reason for loan" required=""></textarea><br>
						</div>
					
				
					

			
			
		
	
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Account Name </span>
	<input type="text" name="account_name" value=""class="form-control" id='ac_name'readonly><br>
		</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Account Number</span>
						<input type="text" name="account_number" class="form-control" id='ac_number'value="" readonly><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Name</span>
						<input type="text" name="bank" class="form-control" id='bank'value="" readonly><br>
		</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">BVN</span>
					<input type="text" name="bvn" class="form-control" id='bvn'placeholder="BVN NO" required=""><br>
						<textarea  name="find" class="form-control" placeholder="How did you find us" required=""></textarea><br>
				<button class="btn btn-info" id='submit' name="change" type="submit">SUBMIT</button>
				
				</div>
				</form>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
            </div>
        </div>
        <div id="nested-tabInfo2">
            Selected tab: <span class="tabName"></span>
        </div>

        <br>
        <br>
        <br/>
       
    </div>
	</div>
	

									
							<table>		
									
									<?php 
									$query="select* from loan where confirm='0' and rejected='0' and amount !='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
					?>
				<tr>
				<td><?php echo $ree['category'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['repayment_plan_amount']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['req_amount'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php  $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td>
				<td id="confirm<?php echo $ree['loan_id'] ?>">
				    <?php echo $query="select* from paystackcard where account_no='".$ree['account_no']."' and paid='1' and remove='0' and authorization_code !=''"; 
					$x=mysqli_query($con,$query) or  die(mysqli_error($con));
					if(mysqli_num_rows($x)>0){
				    ?>
				    <button  onclick='update("<?php echo $ree['loan_id'] ?>")'>Confirm</button>
				    <?php
				    }
				    ?>
				    </td><td id="reject<?php echo $ree['loan_id'] ?>"><button  onclick='reject("<?php echo $ree['loan_id'] ?>")'>Reject</button></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                   </table>                     
                                  
	 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
           $(document).ready(function () {
                $('#dataTables-example').dataTable();
				});
				</script>
	<!--Plug-in Initialisation-->
	<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

        // Child Tab
        $('#ChildVerticalTab_1').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true,
            tabidentify: 'ver_1', // The tab groups identifier
            activetab_bg: '#fff', // background color for active tabs in this group
            inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
            active_border_color: '#c1c1c1', // border color for active tabs heads in this group
            active_content_border_color: '#5AB1D0' // border color for active tabs contect in this group so that it matches the tab head border
        });

        //Vertical Tab
        $('#parentVerticalTab').easyResponsiveTabs({
            type: 'vertical', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo2');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
    });
	
	
</script>
</body>
</html>
