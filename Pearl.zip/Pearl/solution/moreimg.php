<?php
include"header.php";
$bar="chat";
?>


		
		
		<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Chat</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header" >Chat</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
						
<!------------------------------------------------table for message----------------------------------------->



<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>View More</strong>
							 
                        </div>
                        <div class="panel-body">
                            
							
					<?php
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$query="select image from message where message_id='$id'";
	$s=mysqli_query($con,$query)or die(mysqli_error());
	$row=mysqli_fetch_array($s);
	?>
	
	<img src='../<?php echo $row['image'] ?>' width='100%' height='100%'>
	<?php
}

?>
						
						
                    </div>



<!-------------------------------table for message ends here------------------------------------>

					
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<?php include"footer.php" ?>