<?php
include"header.php";
$bar="dashboard";
include"../function.php";
?>


<style>
.img-responsive{
	width:120px;
	height:120px;
}
</style>
		
		<?php
		include"sidebar.php";
		?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Dashboard</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-2 ">
 </div>
			<div class="col-lg-8 ">
			   
				<?php if(isset($_GET['id'])){
					$id=$_GET['id'];
					$query="select* from registeruser where account_number='$id'";
					$res=mysqli_query($con,$query) or die(mysqli_error($con));
					$row=mysqli_fetch_array($res);
				?>
				<p> <?php echo$row['firstname']." Registeration information";  ?>
				</p>
				
								
								
                        <?php
						$state=array("Abia","Abuja","Adamawa","Anambra","Akwa Ibom","Bauchi","Bayelsa","Benue","Borno","Cross River","Delta","Ebonyi","Edo","Ekiti","Enugu","Gombe","Imo","Jigawa","Kaduna","Kano","Katsina","Kebbi","Kogi","Kwara","Lagos","Nassarawa","Niger","Ondo","Ogun","Osun","Oyo","Plateau","Rivers","Sokoto","Taraba","Yobe","Zamfara");
						if(isset($_POST['edit'])){
						$firstname =escape($con,$_POST['firstname']);
$lastname =escape($con,$_POST['lastname']);
$title =escape($con,$_POST['title']);
$middlename =escape($con,$_POST['middlename']);
$phone =escape($con,$_POST['phone']);
$status =escape($con,$_POST['status']);
$gender =escape($con,$_POST['gender']);
$dob =escape($con,$_POST['dob']);
$state =escape($con,$_POST['state']);
$lga =escape($con,$_POST['lga']);
$ostate =escape($con,$_POST['ostate']);
$bustop =escape($con,$_POST['bustop']);
$office =escape($con,$_POST['office']);
$city =escape($con,$_POST['city']);
$address =escape($con,$_POST['address']);
$identification =escape($con,$_POST['identification']);

$id_no =escape($con,$_POST['id_no']);
$issue_date =escape($con,$_POST['issue_date']);

$exdate =escape($con,$_POST['exdate']);

$institution =escape($con,$_POST['institution']);
$faculty =escape($con,$_POST['faculty']);
$department =escape($con,$_POST['department']);
$level =escape($con,$_POST['level']);
$ntitle =escape($con,$_POST['ntitle']);
$kinname =escape($con,$_POST['kinname']);
$kinphone =escape($con,$_POST['kinphone']);
$kin_address =escape($con,$_POST['kin_address']);
$relation =escape($con,$_POST['relation']);
$kinstate =escape($con,$_POST['kinstate']);

$qualification =escape($con,$_POST['qualification']);

$query="update registeruser set title='$title',firstname='$firstname',department='$department',institution='$institution',faculty='$faculty',levels='$level',lastname='$lastname',middlename='$middlename',alt_phone='$phone',status='$status',gender='$gender',dob='$dob',state_res='$state',address='$address',lga='$lga',city_res='$city',bustop='$bustop',state_origin='$ostate',office_address='$office',kin_title='$ntitle',kin_name='$kinname',kin_phone='$kinphone',kin_relationship='$relation',kin_address='$kin_address',kin_state='$kinstate' where  account_number='$id'";
mysqli_query($con,$query)or die(mysqli_error($con));
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["files"])) {
 $fileTmpLoc = $_FILES["files"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["files"]["name"]);
$extension = end($temp);
if ((($_FILES["files"]["type"] == "image/gif")
|| ($_FILES["files"]["type"] == "image/jpeg")
|| ($_FILES["files"]["type"] == "image/jpg")
|| ($_FILES["files"]["type"] == "image/pjpeg")
|| ($_FILES["files"]["type"] == "image/x-png")
|| ($_FILES["files"]["type"] == "image/png"))
&& ($_FILES["files"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["files"]["error"] > 0) {
        echo "Return Code: " . $_FILES["files"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		$db_file_namee="userphoto/$db_file_name";
	$db_file_names="../userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_names;
	$resized_file = $db_file_names;
	$wmax = 400;
	$hmax = 400 ;                                                                                                                                                                                                                                          00;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		$query="update registeruser set picture='$db_file_namee' where account_number='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	$query="update uploads set image='$db_file_namee' where account_no='$id' and purpose='Profile Picture'";
	mysqli_query($con,$query) or die(mysqli_error($con));
		
			
        }
		
    }
 else {
    //echo "Invalid file";
}
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["ufile"])) {
$fileName = $_FILES["ufile"]["name"];
 $fileTmpLoc = $_FILES["ufile"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["ufile"]["name"]);
$extension = end($temp);
if ((($_FILES["ufile"]["type"] == "image/gif")
|| ($_FILES["ufile"]["type"] == "image/jpeg")
|| ($_FILES["ufile"]["type"] == "image/jpg")
|| ($_FILES["ufile"]["type"] == "image/pjpeg")
|| ($_FILES["ufile"]["type"] == "image/x-png")
|| ($_FILES["ufile"]["type"] == "image/png"))
&& ($_FILES["ufile"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["ufile"]["error"] > 0) {
        echo "Return Code: " . $_FILES["ufile"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		$db_file_namee="userphoto/$db_file_name";
	$db_file_names="../userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_names;
	$resized_file = $db_file_names;
	$wmax = 400;
	$hmax = 400;                                                                                                                                                                                                                                          00;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
	
	
		$query="update registeruser set id_image='$db_file_namee' where account_number='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	$query="update uploads set image='$db_file_namee' where account_no='$id' and purpose='ID image'";
	mysqli_query($con,$query) or die(mysqli_error($con));	
        }
    }
 else {
    //echo "Invalid file";
}
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["file2"])) {
 $fileTmpLoc = $_FILES["file2"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file2"]["name"]);
$extension = end($temp);
if ((($_FILES["file2"]["type"] == "image/gif")
|| ($_FILES["file2"]["type"] == "image/jpeg")
|| ($_FILES["file2"]["type"] == "image/jpg")
|| ($_FILES["file2"]["type"] == "image/pjpeg")
|| ($_FILES["file2"]["type"] == "image/x-png")
|| ($_FILES["file2"]["type"] == "image/png"))
&& ($_FILES["file2"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["file2"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file2"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		$db_file_namee="userphoto/$db_file_name";
	$db_file_names="../userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_names;
	$resized_file = $db_file_names;
	$wmax = 400;
	$hmax = 400 ;                                                                                                                                                                                                                                          00;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		
	$query="update registeruser set passport='$db_file_namee' where account_number='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	$query="update uploads set image='$db_file_namee' where account_no='$id' and purpose='Passport'";
	mysqli_query($con,$query) or die(mysqli_error($con));
		
			
        }
    }
 else {
    //echo "Invalid file";
}
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["ufile3"])) {
$fileName = $_FILES["ufile3"]["name"];
 $fileTmpLoc = $_FILES["ufile3"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["ufile3"]["name"]);
$extension = end($temp);
if ((($_FILES["ufile3"]["type"] == "image/gif")
|| ($_FILES["ufile3"]["type"] == "image/jpeg")
|| ($_FILES["ufile3"]["type"] == "image/jpg")
|| ($_FILES["ufile3"]["type"] == "image/pjpeg")
|| ($_FILES["ufile3"]["type"] == "image/x-png")
|| ($_FILES["ufile3"]["type"] == "image/png"))
&& ($_FILES["ufile3"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["ufile3"]["error"] > 0) {
        echo "Return Code: " . $_FILES["ufile3"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		$db_file_namee="userphoto/$db_file_name";
	$db_file_names="../userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_names;
	$resized_file = $db_file_names;
	$wmax = 400;
	$hmax = 400;                                                                                                                                                                                                                                          00;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		
		
$query="update registeruser set signnature='$db_file_namee' where account_number='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	$query="update uploads set image='$db_file_namee' where account_no='$id' and purpose='Signature'";
	mysqli_query($con,$query) or die(mysqli_error($con));		
        }
    }
 else {
   // echo "Invalid file";
}
}
echo"<h3>User Reg Info Update Successfully</h3>";

						}else
						{

						?>
						
						
				<form role="form" action="" method="POST" enctype="multipart/form-data">
				

			

			
			<p>Select Your Profile Picture</p>
			<img src="../<?php echo $row['picture']?>" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="files" id="ufile5" accept="image/*" onchange="loadFile(event)" /><br>
			
			
			
			<span class="badge" style="background-color:#3385FF;">Login Information......</span><br><br>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Email Address</span>
			<input type="text" name="email" class="form-control" value="<?php echo $row['email_address'] ?>" id='email'  required=""><br>
			
			</div>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Phone Number</span>
						<input type="text" name="phone" class="form-control" value="<?php echo $row['phone'] ?>" id='phone' required=""><br>
						</div>
						
						
			<span class="badge" style="background-color:#3385FF;">Personal Information......</span><br><br>
			<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Title</span>
			<input type="text" name="title" class="form-control"  value="<?php echo $row['title'] ?>" required ><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">First Name</span>
						<input type="text" name="firstname" value="<?php echo $row['firstname'] ?>"class="form-control"  required="" ><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Middle Name</span>
						<input type="text" name="middlename" value="<?php echo $row['middlename'] ?>" class="form-control" placeholder="MIDDLENAME" required="" ><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="<?php echo $row['lastname'] ?>" class="form-control"  placeholder="LAST NAME" required="" ><br>
						
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Alternate Phone Number</span>
			<input type="text" name="altphone"value="<?php echo $row['alt_phone'] ?>" class="form-control"  placeholder="ALTERNATE PHONE NUMBER" ><br>
</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Gender</span>
						<select name="gender" class="form-control"  required="">
						<option value="value="<?php echo $row['gender'] ?>""><?php echo $row['gender'] ?></option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
						</select><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Marital Status</span>
						<select name="status" class="form-control"  required="">
						<option value="<?php echo $row['status'] ?>"><?php echo $row['status'] ?></option>
						<option value="Mingle">Single</option>
						<option value="Married">Married</option>
						<option value="Divorced">Divorced</option>
						</select><br> 
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Birth Date</span><br><br>
						 <input type='date' name="dob" required  class="form-control" value="<?php echo $row['dob'] ?>">
 
</div>
						
		   <span class="badge" style="background-color:#3385FF;">Address Information......</span><br><br>
						
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Residence Address</span>
						<input type="text" name="address"value="<?php echo $row['address'] ?>" class="form-control" placeholder=" RESSIDENCE ADDRESS" required=""><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Office Address</span>
						<input type="text" name="office" value="<?php echo $row['office_address'] ?>"class="form-control" placeholder="OFFICE ADDRESS" ><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Nearest Bus stop</span>
						<input type="text" name="bustop"value="<?php echo $row['bustop'] ?>" class="form-control" placeholder="NEAREST BUS STOP" required=""><br>
						
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">City of Residence</span><input type="text" name="city" value="<?php echo $row['city_res'] ?>"class="form-control" placeholder="CITY NAME" required=""><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">State of Residence</span>
						<select name="state" class="form-control"  required="">
						<option value="<?php echo $row['state_res'] ?>"><?php echo $row['state_res'] ?></option>
						<?php foreach($state as $states){
							echo"<option value='".$states."'>".$states."</option>"; }?>
						
						</select>
						<br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">L.G.A</span>
						<input type="text" name="lga"value="<?php echo $row['lga'] ?>" class="form-control" placeholder="HOME LGA" required=""><br>
						<select name="ostate" class="form-control"  required="">
						<option value="<?php echo $row['state_origin'] ?>"><?php echo $row['state_origin'] ?></option>
						<?php foreach($state as $states){
							echo"<option value='".$states."'>".$states."</option>"; }?>
						
						</select>
						</div>
						


			
			<p>Upload Means of Identification</p>
			<img src="../<?php echo $row['id_image'] ?>" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile" id="ufile5" accept="image/*" onchange="loadFile(event)"  /><br>
			
			
			
			
			
			
			<span class="badge" style="background-color:#3385FF;">Identification Information ......</span><br><br>
							
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Means of Identification</span>		
						<select name="identification" class="form-control"  required="">
						<option value="<?php echo $row['id'] ?>"><?php echo $row['id'] ?></option>
						<option value="National ID">National Id-card </option>
						<option value="Driver License">Driver License</option>
						<option value="Voters Card">Voters Card</option>
						<option value="International Passport">International Passport</option>
						</select><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">ID Number</span>
						<input type="text" name="id_no"value="<?php echo $row['id_no'] ?>" class="form-control" placeholder="ID NUMBER" ><br>
						
						</div>
						<div class='form-group'>
			 <span class="badge" style="background-color:#3385FF;">Issued Date</span><br>
						 <input type='date' name="issue_date" required  class="form-control" value="<?php echo $row['issue_date'] ?>">
 </div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Expiring Date</span>
 <input type='date' name="exdate" required  class="form-control" value="<?php echo $row['exp_date'] ?>">
				</div>
							
						
			<span class="badge" style="background-color:#3385FF;">Educational Qualification ......</span><br><br>
							
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Qualification</span>		
						<select name="qualification" class="form-control"  required="">
						<option value="<?php echo $row['qualification'] ?>"><?php echo $row['qualification'] ?></option>
						<option value="SSEC">SSCE </option>
						<option value="ND">ND</option>
						<option value="HND">HND</option>
						<option value="BSc">BSc</option>
						</select><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">Institution</span>
						<select name="institution" class="form-control"  >
						<option value="<?php echo $row['institution'] ?>"><?php echo $row['institution'] ?></option>
						<option value="Alvan">IMSU </option>
						<option value="FPNO">FPNO</option>
						<option value="FUTO">FUTO</option>
						<option value="ABSU">ABSU</option>
						</select><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">DEPARTMENT</span>
					<input type="text" name="department"value="<?php echo $row['department'] ?>" class="form-control" placeholder="DEPARTMENT" ><br>
					</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">FACULTY</span>
					<input type="text" name="faculty"value="<?php echo $row['faculty'] ?>" class="form-control" placeholder="FACULTY"  ><br>
					</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">LEVEL</span>
					<input type="text" name="level" value="<?php echo $row['levels'] ?>"class="form-control" placeholder="LEVEL" required="" ><br>

</div>
			
			<p>Upload your Passport</p>
			<img src="../<?php echo $row['passport'] ?>" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="file2" id="ufile5" accept="image/*" onchange="loadFile(event)" /><br>
			
			<p>Upload your Signture</p>
			<img src="../<?php echo $row['signnature'] ?>" alt="" class="img-responsive"  align="absmiddle" id="outputpix2"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile3" id="ufile5" accept="image/*" onchange="loadFile2(event)"  /><br>
			
			
			
			
			
			
			<span class="badge" style="background-color:#3385FF;">Next Of Kin ......</span><br><br>
			
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">NEXT OF KIN TITLE</span>
			<input type="text" name="ntitle"value="<?php echo $row['kin_title'] ?>" class="form-control" placeholder="TITLE" required="" ><br>
			</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">NEXT OF KIN NAME</span>
						<input type="text" name="kinname"value="<?php echo $row['kin_name'] ?>" class="form-control" placeholder="NEXT OF KIN NAME" required="">
</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">NEXT OF KIN ADDRESS</span>						
						<input type="text" name="kin_address" value="<?php echo $row['kin_address'] ?>" class="form-control" placeholder="NEXT OF KIN ADDRESS" required="" ><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">NEXT OF KIN PHONE NUMBER</span>
						<input type="text" name="kinphone" value="<?php echo $row['kin_phone'] ?>"class="form-control"  placeholder="NEXT OF KIN PHONE NUMBER" required=""><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">RELATIONSHIP</span>
						<input type="text" name="relation" value="<?php echo $row['kin_relationship'] ?>"class="form-control"  placeholder="RELATIONSHIP" required=""><br>
						</div>
						<div class='form-group'>
			<span class="badge" style="background-color:#3385FF;">STATE OF ORIGIN</span>
						<input type="text" name="kinstate" value="<?php echo $row['kin_state'] ?>"class="form-control"  placeholder="STATE OF ORIGIN" required=""><br>
						</div>
						
							
							
							

							<input class="btn btn-info" type="submit" name="edit" value="Update User Record">
						
				</form>		
						
                      

					<?php
					}
				}
?>						

				
					  
					  
					  

					  
                    


<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  </script>


		
			
			
			
		</div><!--/.row--><br><br>
		
		<div class="col-sm-12">
				<p class="">© 2017 E-Banking. Designed by <a href="../index.php">PEARL</a></p>
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 
		
		
</body>
</html>