<?php
include"connect.php";
$title=$_POST['title'];
$phone=$_POST['phone'];
$message=$_POST['message'];
$account=$_POST['account'];

$query="insert into loan_message (title,phone,message,account_no,sent_date) values('$title','$phone','$message','$account',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

//$message=urlencode($message);
$sender="pearl";
$ch = curl_init();
  
  $fields = array( "username"=>"09011050718","password"=>"41cdc627060c593b70240c","message"=>"$message","mobile"=>"$phone","sender"=>"$sender","route"=>"1","vtype"=>"1");
  $postvars = '';
  foreach($fields as $key=>$value) {
    $postvars .= $key . "=" . $value . "&";
  }
  $url = "https://www.mobileairtimeng.com/smsapi/bulksms.php";
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_POST, 1);                //0 for a get request
  curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
  curl_setopt($ch,CURLOPT_TIMEOUT, 20);
  $response = curl_exec($ch);
  //print "curl response is:" . $response;
  curl_close ($ch);
  /*
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
*/

echo "done";
exit();

								?>