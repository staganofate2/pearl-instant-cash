<?php
include"header.php";
$bar="withdraw";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Data</li>
				
			</ol>
		</div><!--/.row-->
		
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Data</h2>
				<table><tr><td><img src='' id='picture' width='100px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table> 
				<div id='balance'></div>
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-2 ">
 </div>
 <div class="col-lg-8 ">
                        
		<?php
      if (isset($_POST['login'])){
								
								$account = mysqli_real_escape_string($con,$_POST['account_no']);
								$network = mysqli_real_escape_string($con,$_POST['network']);
								$phone = mysqli_real_escape_string($con,$_POST['phone']);
								$pin = mysqli_real_escape_string($con,$_POST['pin']);
								$variation = mysqli_real_escape_string($con,$_POST['variation']);
								
								$ref =rand(100000000000,999999999999);
								$que="select pin from registeruser  where  account_number='$account' and pin='".sha1(md5($pin))."'";
$ret=mysqli_query($con,$que)or die(mysqli_error($con));
if(mysqli_num_rows($ret)<1){
	echo "Incorrect Account Pin";
}else{
								$query="select total from wallet where account_no='$account'";
								$roww=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($roww)>0){
	$rowss=mysqli_fetch_array($roww);
	if($rowss['total']<$variation){
		echo "<h3>The amount you want to pay greater than your wallet balance</h3>";
	}else{
		$net=array("15"=>"MTN","6"=>"GLO","2"=>"9Mobile","1"=>"Airtel");
								$networks=$net[$network];	
								$query="insert into datas (ref_no,network,phone,account_no,amount,regdate) values('$ref','$networks','$phone','$account','$variation',now())";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							 $id=mysqli_insert_id($con);
							 //$amount=$amount.".00";
							
									
$http="https://mobileairtimeng.com/httpapi/datatopup.php?userid=08107302391&pass=912363232d306466ae2a1&network=$network&phone=$phone&amt=$variation&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 // print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
							
										$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	$amounts=($rows['total']-$amount);
$query="update wallet set total='$amounts' where account_no='$account";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$amount was Debited from your Wallet for Data Recharge of $phone";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Data','$account','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update datas set status='1',sent_date=now(),total='$amount' where account_no='$account' and ref_no='$ref'";
mysqli_query($con,$query) or die(mysqli_error($con));

										echo "<h3>Your Data Recharge was Successful</h3>";
}

										
}										else{
											echo "<h3>Failed !!! Please <a href='recharge.php'>Try Again</a></h3>";
										}									
}}}
	  }
	  }else{
								
?>				
	<h4 class="page-header">Data Recharge  Form</h4>
	<form action="" method="POST" enctype="multipart/form-data">

				<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
								<span class='danger' id='incorrect'></span>
							</div>
								<div class="form-group">
							<select name="network" class="form-control"  required="" id='type' onchange='update2()'>
						<option value="">----Select Network---</option>
						<option value="15">MTN</option>
						<option value="1">Airtel</option>
						<option value="6">GLO</option>
						<option value="2">9Mobile</option>
						</select>
						</div>
						<div id='loaders'></div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Data Amount</span>
						
						<select  name="variation" id='variation' class="form-control" required  >
						<option value="">Select Data</option>
						</select>
						
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Payment Pin</span>
								<input class="form-control" value="" id='pin' name="pin" type="password"  onblur="checkpin()" required>
								<span class='danger' id='results'></span>
							</div>
						
						<input type="submit" class="btn btn-info " id='submit'value="Submit" name="login"> <br>
						
						<div class="clearfix"></div>
					
				
				</form>

	<?php
									}
									?>
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
 function update(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update4.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
		var b=document.getElementById("loaders").style.display="none";		if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
				document.getElementById("balance").innerHTML ="Balance ₦ "+balance;
				document.getElementById("incorrect").innerHTML = '';
			
			 
			}
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	var amounts=amount.replace(reg,""); 
	var account=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";	
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				document.getElementById("result").innerHTML="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 
  function checkpin(){
	
	var pin=document.getElementById("pin").value;
	
	var account=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("results").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_pin.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				document.getElementById("results").innerHTML="";
			}
			else{
				
			 
			 document.getElementById("results").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("pin="+pin+"&account="+account);
 
 }
 function update2(){
	 var type=document.getElementById("type").value;
	 if(type=="15"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='100'>50MB-1day = 100</option><option value='500'>750MB-14days = 500</option><option value='1000'>1GB-30days = 1000</option><option value='1200'>1.5GB-30days = 1200</option><option value='2000'>2.5GB-30days = 2000</option><option value='3500'>5GB-30days = 3500</option><option value='5000'>10GB-30days = 5000</option><option value='10000'>22GB-30days = 10000</option>"; 
	 }
	if(type=="2"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='200'>150MB-7days = 200</option><option value='1000'>1GB-30days = 1000</option><option value='1000'>1.5GB-30days = 1200</option><option value='1200'>1.5GB-30days = 1200</option><option value='2000'>2.5GB-30days = 2000</option><option value='2500'>3.5GB-30days = 2500</option>"; 
	 }
	 if(type=="6"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='100'>80MB-24hrs = 100</option><option value='200'>210MB-5days = 200</option><option value='500'>800MB-14days = 500</option><option value='1000'>1.6GB-30days = 1000</option><option value='2000'>3.65GB-30days = 2000</option><option value='2500'>5.75GB-30days = 2500</option><option value='3000'>7GB-30days = 3000</option><option value='4000'>10GB-30days = 4000</option><option value='5000'>12.5GB-30days = 5000</option><option value='8000'>20GB-30days = 8000</option>"; 
	 }
	 if(type=="1"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='50'>20MB-1day = 50</option><option value='100'>75MB-1day = 100</option><option value='200'>200MB-3days = 200</option><option value='300'>350MB-3days  = 300</option>	<option value='500'>750MB-14days = 500</option><option value='1000'>1.5GB-30days = 1000</option>	<option value='1500'>3.5GB-30days = 1500</option><option value='2500'>5.5GB-30days = 2500</option><option value='4000'>9.5GB-30days = 4000</option><option value='5000'>12GB-30days = 5000</option>"; 
	 }
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
		
