<?php
include"header.php";
?>

    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
    <!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
    
    <style type="text/css" rel="stylesheet">
        body {
            background: #fff;
        }
        #container {
            width: 940px;
            margin: 0 auto;
        }
        @media only screen and (max-width: 768px) {
            #container {
                width: 90%;
                margin: 0 auto;
            }
        }
    </style>
<style>
  /* Style the buttons that are used to open and close the accordion panel */
.accordion {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    text-align: left;
    border: none;
    outline: none;
    transition: 0.4s;
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.active, .accordion:hover {
    background-color: #ccc;
}

/* Style the accordion panel. Note: hidden by default */
.panel {
    padding: 0 18px;
    background-color: white;
    display: none;
    overflow: hidden;
} 
 </style>
    <div id="container">

       

        <h2>Horizontal Tab with (Nested Tabs) </h2>
        <br/>
        <!--Horizontal Tab-->
        <div id="parentHorizontalTab">
            <ul class="resp-tabs-list hor_1">
                <li>Activities</li>
                <li>Loan Profile</li>
                <li>Loan Statement</li>
            </ul>
            <div class="resp-tabs-container hor_1">
                <div>
                    <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_1">
                            <ul class="resp-tabs-list ver_1">
                                <li>Reminders</li>
                                <li>Messages</li>
                                <li>Calls</li>
                                <li>Emails</li>
                            </ul>
                            <div class="resp-tabs-container ver_1">
                               <!-- reminders -->
							   <div>     
							   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Title</th><th>Message</th><th>Remind Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_reminder";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td><?php echo $ree['title']  ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    
                                </div>
								<p>Reminders</p>
								</div>
								<!-- end of reminders -->
                                <div>
								   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Messages</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Title</th><th>Message</th><th>Remind Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_message";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td> <?php echo $ree['title'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    
                                </div>
                                    <p>Messages</p>
                                </div>
                                <div>
								   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Phone</th><th>Message</th><th>Status</th><th>Call Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_call";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td><td><?php echo $ree['phone'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['status'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    
                                </div>
                                    <p>Calls</p>
                                </div>
                                <div>
								   <div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Loan Amount</th><th>Subject</th><th>Message</th><th>Sent Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_email";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td>₦ <?php $query="select total from loan where loan_id='".$ree['loan_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['amount'] ?></td><td>₦ <?php echo $ree['subject'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        
                                    
                                </div>
                                    <p>Emails</p>
                                </div>
                            
                        
                    </p>
                    <p>Tab 1 Container</p>
                </div>
                <!--form -->
				<div>
				
				<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no2'  style='width:60%' name="account_no2" onblur="update_profile()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
				profile
				
				
                    
                    <br>
                    <br>
                    <p>Tab 2 Container</p>
                </div><!-- end of form -->
                <!--  statement -->
				<div>
				<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no2' style='width:60%'name="account_no2" onblur="update_statement()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
                    <br>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
				<!-- end of statement -->
            </div>
        </div>
        <div id="nested-tabInfo">
            Selected Item: <span class="tabName"></span>
        </div>
        <br/>
        <br/>
        <br/>


        
        <!--Vertical Tab-->
        <div id="parentVerticalTab">
            <ul class="resp-tabs-list hor_1">
                <li>Confirm Loan</li>
                <li>Authorize Loan</li>
                <li>Loan Form</li>
            </ul>
            <div class="resp-tabs-container hor_1">
                <div>
				
				
                </div>
				
				 <div>
				
				<h4 class="page-header">Authorize Loan</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <div id='loaders'></div>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Category</th><th>Account No</th><th>Repayment Plan Amount</th><th>Duration</th><th>Interest</th><th>Requested Amount</th><th>Amount</th><th>Total Deposit</th><th>Ref NO</th><th>Date</th><th>Confirmed</th><th>Action</th><th></th><th></th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan where confirm='0' and rejected='0' and amount !='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
					?>
				<tr>
				<td><?php echo $ree['category'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['repayment_plan_amount']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['req_amount'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php  $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td><td id="confirm<?php echo $ree['loan_id'] ?>">
				    <?php $query="select* from paystackloan where account_no='".$ree['account_no']."' and paid='1' and remove='0' and authorization_code !=''"; $x=mysqli_query($con,$query) or  die(mysqli_error($con));if(mysqli_num_rows($x)>0){
				    ?>
				    <button  onclick='update("<?php echo $ree['loan_id'] ?>")'>Confirm</button>
				    <?php
				    }
				    ?>
				    </td><td id="reject<?php echo $ree['loan_id'] ?>"><button  onclick='reject("<?php echo $ree['loan_id'] ?>")'>Reject</button></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
				
				
				
                  Confirm <br>
                    <br>
                    <p>Tab 1 Container</p>
                </div>
				
				
				
				
               
				
				
				
                <div>
                   form
                    <br>
                    <p>Tab 3 Container</p>
                </div>
           
        
        <div id="nested-tabInfo2">
            Selected tab: <span class="tabName"></span>
        </div>

        <br>
        <br>
        <br/>
       
   
	</div>
	

									
							<table>		
									
									<?php 
									$query="select* from loan where confirm='0' and rejected='0' and amount !='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
					?>
				<tr>
				<td><?php echo $ree['category'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['repayment_plan_amount']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['req_amount'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php  $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td>
				<td id="confirm<?php echo $ree['loan_id'] ?>">
				    <?php echo $query="select* from paystackcard where account_no='".$ree['account_no']."' and paid='1' and remove='0' and authorization_code !=''"; 
					$x=mysqli_query($con,$query) or  die(mysqli_error($con));
					if(mysqli_num_rows($x)>0){
				    ?>
				    <button  onclick='update("<?php echo $ree['loan_id'] ?>")'>Confirm</button>
				    <?php
				    }
				    ?>
				    </td><td id="reject<?php echo $ree['loan_id'] ?>"><button  onclick='reject("<?php echo $ree['loan_id'] ?>")'>Reject</button></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                   </table>                     
                                  
	 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
           $(document).ready(function () {
                $('#dataTables-example').dataTable();
				});
				</script>
	<!--Plug-in Initialisation-->
	<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

        // Child Tab
        $('#ChildVerticalTab_1').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true,
            tabidentify: 'ver_1', // The tab groups identifier
            activetab_bg: '#fff', // background color for active tabs in this group
            inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
            active_border_color: '#c1c1c1', // border color for active tabs heads in this group
            active_content_border_color: '#5AB1D0' // border color for active tabs contect in this group so that it matches the tab head border
        });

        //Vertical Tab
        $('#parentVerticalTab').easyResponsiveTabs({
            type: 'vertical', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo2');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
    });
	
	
</script>
</body>
</html>
