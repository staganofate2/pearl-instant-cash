<?php
session_start();
include_once('connect.php');
$amount=$_POST['amount'];
 $amount=str_replace(",","",$amount);
 $account=$_POST['account'];
$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);

if($row['total']<$amount){
	echo "The amount you Entered is bigger than Your Wallet Amount";
	exit();
}
if($amount<5000){
	echo "Amount should not be less than 5000";
	exit();
}
if(($row['total']-$amount)>="0"){
	echo "ok";
}
exit();



?>