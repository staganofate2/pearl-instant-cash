<?php include"header.php" ;
$bar="new_admin";?>
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">add new Admin User</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Assign new Admin User</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">New  Admin User Form</h4>
	
				   
				
								<div class="col-md-8">
				
						
				<?php
				if(isset($_POST['submit'])){
				$username=mysqli_real_escape_string($con,$_POST['username']);
				$password=mysqli_real_escape_string($con,$_POST['password']);
				$role=mysqli_real_escape_string($con,$_POST['role']);
				$query="select username from adminpanel where username='$username'";
$result=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($result)<1){
				$query="insert into adminpanel (username,password,role) values('$username','$password','$role')";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   echo "<h3>User Added Successfully</h3><p><a href='new_admin.php'>Add Another User</a></p>";
				}
				else{
					echo "<h3>Username already Exists</h3>";
				}
				}else{
			   ?>
						
				<form role="form" action="" method="POST">
				

			
            
							
							
							<div class="form-group">
								<input class="form-control" placeholder="USERNAME" name="username" id='username'type="text" onblur="update()"required>
								<span class="danger" style='color:red' id="user"></span>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="PASSWORD" name="password" type="password" required>
							</div>
							<div class="form-group">
								<select name="role" class="form-control"  required="">
						<option value="">----Select Role ---</option>
						<option value="Confirm">Confirm Transactions</option>
						<option value="Authorize">Authorize Transaction</option>
						<option value="Staff">Staff</option>
						
						</select>
							</div>
							<button class="btn btn-info" type="submit" name="submit">ADD</button>
							
						
				</form>		
				
                   <?php
				}
?>				
						
						
						
                       
                    </div>





		
			
			
			
		<?php include"footer.php"; ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
           var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(){
	

	id=document.getElementById("username").value;
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "checkuser.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				if(ajax.responseText=="exists"){
					document.getElementById("user").innerHTML="Username Exists";
				}else{
					
				}

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
    </script>
		
		
