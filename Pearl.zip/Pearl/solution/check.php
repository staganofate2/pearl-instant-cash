<?php
include"connect.php";
$account=$_POST['type'];
$err="";
$query="select*  from registeruser where account_number='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$we=mysqli_fetch_array($de);
	$err.=$we['id_image']."|".$we['id']."|".$we['id_no']."|";
		$query="select total  from loan where collected='1' and approved='1' and paid='0' and account_no='$account'";
$we=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($we)>0){
	$fe=mysqli_fetch_array($we);
	$err.=$fe['total']."|";
}else{
	$err.="0"."|";
}
	$query="select* from bank_info where account_no='$account'";
	$er=mysqli_query($con,$query)or die(mysqli_error($con));
	if(mysqli_num_rows($er)>0){
		$row=mysqli_fetch_array($er);
		 $err.=$row['account_name']."|".$row['account_number']."|".$row['bank_name']."|".$row['bvn'];
	}

	echo $err;
	exit();
}else{
	echo "Invalid";
	exit();
}