<?php
include"header.php";
$bar="view_deposit";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Paystack Three</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Initial Loan Deposit Payment Details</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Completed Payment</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Amount</th><th>Ref NO</th><th>Reg Date</th><th> Paid Date</th><th>Status</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from paystackthree where confirmed='1' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td> <?php echo $ree['account_no'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php echo $ree['sent_date'] ?></td><td>Confirmed</td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id,account){
	
	
	
	document.getElementById("confirm"+id).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_paystack.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";


		 
	  }
	
			
		}
	
	ajax.send("id="+id+"account="+account);
	}
	
    </script>
		<?php include"footer.php" ?>