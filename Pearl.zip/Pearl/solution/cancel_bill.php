<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$account=$_POST['account'];
$query="update bill set rejected='1', total='0',sender='{$_SESSION['staff']}' where bill_id='$id' and account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select amount,commission from bill where bill_id='$id' and account_no='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$rea=mysqli_fetch_array($de);
$amount=$rea['amount']+$rea['commission'];
$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	$amounts=($rows['total']+$amount);
	
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$ref =rand(100000,999999);
$description="$amount was Credited to your Wallet for Bill Payment Order Canceled ";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Bill','$account','$amount','','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
}
?>