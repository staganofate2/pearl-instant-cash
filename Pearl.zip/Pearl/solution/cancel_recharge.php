<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$account=$_POST['account'];
$query="update recharge set rejected='1',total='0',sender='{$_SESSION['staff']}' where recharge_id='$id' and account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select amount from recharge where recharge_id='$id' and account_no='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$rea=mysqli_fetch_array($de);
$amount=$rea['amount'];
$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));

	$rows=mysqli_fetch_array($row);
	$amounts=($rows['total']+$amount);
	
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$ref =rand(100000,999999);
$description="$amount was Credited to your Wallet for Airtime Recharge Order Canceled ";
$query="insert into wallet_ransact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Recharge','$account','$amount','','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
?>