<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$account=$_POST['account'];
$query="update paystackcard set active='0' where  account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update paystackcard set active='1' where id='$id' and account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";

?>