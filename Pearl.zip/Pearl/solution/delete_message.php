<?php
session_start();
include"connect.php";
$id=$_POST['id'];
  $query="update site_message  set deleted='1',delete_user='admin' where site_message_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
exit();
?>