<?php
include"header.php";
$bar="withdraw";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">bill</li>
				
			</ol>
		</div><!--/.row-->
		
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Bill Payment</h2>
				<table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table> 
				<div id='balance'></div>
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-2 ">
 </div>
  <div class="col-lg-8 ">
                        
		<?php
       if (isset($_POST['login'])){
								
								$account_no = mysqli_real_escape_string($con,$_POST['account_no']);
								$type = mysqli_real_escape_string($con,$_POST['type']);
								$number = mysqli_real_escape_string($con,$_POST['number']);
								$phone = mysqli_real_escape_string($con,$_POST['phone']);
								$variation = mysqli_real_escape_string($con,$_POST['variation']);
								$amount = mysqli_real_escape_string($con,$_POST['amount']);
								$amount=str_replace(",","",$amount);
								$pin = mysqli_real_escape_string($con,$_POST['pin']);
								$http="https://mobileairtimeng.com/httpapi/customercheck?userid=08107302391&pass=2513935&bill=$type&smartno=$number&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
   if($type=="startimes"){
echo "<h3>CUSTOMER INFORMATION</h3><table class='table'> <tr><td>Customer Name </td><td>".$x['customerName']."</td></tr><tr><td>Balance </td><td>".$x['balance']."</td></tr></table>";
   }else{
	 echo "<h3>CUSTOMER INFORMATION</h3><table class='table'> <tr><td>Customer Name </td><td>".$x['customerName']."</td></tr><tr><td>Decoder Status </td><td>".$x['decoderStatus']."</td></tr><tr><td>Subscription expiration date</td><td>".$x['dueDate']."</td></tr><tr><td>Invoice Period</td><td>".$x['invoicePeriod']."</td></tr><tr><td>Customer Number</td><td>".$x['customerNumber']."</td></tr></table>";  
   }
	  
								
?>
			
			<form class="" action="bill_payment.php" method="post" > 
			<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
			
			<input type="hidden" name='type' value='<?php echo $type ?>'>
			<input type="hidden" name='account_no' value='<?php echo $account_no ?>'>
			<input type="hidden" name='pin' value='<?php echo $pin ?>'>
			<input type="hidden" name='number' value='<?php echo $number ?>'>
			<input type="hidden" name='phone' value='<?php echo $phone ?>'>
			<input type="hidden" name='variation' value='<?php echo $variation ?>'>
			<input type="hidden" name='amount' value='<?php echo $amount ?>'>
			<input type="hidden" name='name' value='<?php echo @$x['customerName'] ?>'>
			<input type="hidden" name='invoice' value='<?php echo @$x['invoicePeriod'] ?>'>
			<input type="hidden" name='cnumber' value='<?php echo @$x['customerNumber'] ?>'>
			
			
						
					
						<input type="submit" class="btn btn-info " id='submit'value="Continue" name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			
			
			
			
			
			
			</div> 
			</form>
			<?php
								}
	  }
								?>
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function updates(){
	 var type=document.getElementById("type").value;
	 if(type=="gotv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>GOtv Lite N400</option><option value='02'>GOtv value N1250</option><option value='03'>GOtv plus N1900</option><option value='04'>GOtv Max N3200</option>"; 
	 }
	 if(type=="startimes"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>Nova - 900 Naira</option><option value='02'>Basic - 1,300 Naira</option><option value='03'>Smart - 1,900 Naira</option><option value='04'>Classic - 2,600 Naira </option><option value='05'>Unique - 3,800 Naira</option><option value='06'>Super - 3,800 Naira</option>"; 
	 }
	  if(type=="dstv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>DStv Access N2000</option><option value='02'>DStv Family N4000</option><option value='03'>DStv Compact N6,800</option><option value='04'>DStv Compact Plus N10,650</option><option value='05'>DStv Premium N15,800</option><option value='06'>DStv  Premium + HD/Exra View - N18,000</option>"; 
	 }
 }
 function update2(){
	  var type=document.getElementById("type").value;
		 var types=document.getElementById("variation").value;
	 if(type=="gotv" && types=="01"){
	document.getElementById("amount").value="400.00"; 
	document.getElementById("total").value="500.00";
	 }	 if(type=="gotv" && types=="02"){
	document.getElementById("amount").value="1250.00";
document.getElementById("total").value="1350.00";	
	 }	 if(type=="gotv" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="gotv" && types=="04"){
	document.getElementById("amount").value="3200.00"; 
	document.getElementById("total").value="3300.00";
	 }	
	 if(type=="startimes" && types=="01"){
	document.getElementById("amount").value="900.00";
document.getElementById("total").value="1000.00";	
	 }	 if(type=="startimes" && types=="02"){
	document.getElementById("amount").value="1300.00"; 
	document.getElementById("total").value="1400.00";
	 }	 if(type=="startimes" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="startimes" && types=="04"){
	document.getElementById("amount").value="2600.00";
document.getElementById("total").value="2700.00";	
	 }	
	  if(type=="startimes" && types=="05"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	
	 if(type=="startimes" && types=="06"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	


	 if(type=="dstv" && types=="01"){
	document.getElementById("amount").value="2000.00"; 
	document.getElementById("total").value="2100.00";
	 }if(type=="dstv" && types=="02"){
	document.getElementById("amount").value="4000.00";
document.getElementById("total").value="4100.00";	
	 }	 if(type=="dstv" && types=="03"){
	document.getElementById("amount").value="6800.00"; 
	document.getElementById("total").value="6900.00";
	 }	
	  if(type=="dstv" && types=="04"){
	document.getElementById("amount").value="10650.00"; 
	document.getElementById("total").value="10750.00";
	 }	
	 if(type=="dstv" && types=="05"){
	document.getElementById("amount").value="15800.00"; 
	document.getElementById("total").value="15900.00";
	 }	
	 if(type=="dstv" && types=="06"){
	document.getElementById("amount").value="18000.00"; 
	document.getElementById("total").value="18100.00";
	 }	
			 
 }
 function update(){
	
	var types=document.getElementById("account_no").value;
document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update4.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
				document.getElementById("balance").innerHTML ="Balance ₦ "+balance;
				document.getElementById("incorrect").innerHTML = '';
			 
			}
		
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	var amounts=amount.replace(reg,""); 
	var account=document.getElementById("account_no").value;
	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
				 var amountt=Number(amounts);
				 var total=amountt+100;
				 alert(total);
				 document.getElementById("total").value =total;
			}
			else{
				document.getElementById("total").value ="";
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 function checkpin(){
	
	var pin=document.getElementById("pin").value;
	
	var account=document.getElementById("account_no").value;
	document.getElementById("results").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_pin.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				document.getElementById("results").innerHTML="";
			}
			else{
				
			 
			 document.getElementById("results").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("pin="+pin+"&account="+account);
 
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
		
