<?php
include"header.php";
$bar="invest";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Invest</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Invest</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Investment Form</h4>
	<?php	
if(isset($_POST['change'])){			
$duration=mysqli_real_escape_string($con,$_POST['duration']);
$account=mysqli_real_escape_string($con,$_POST['account_no']);
					$name=mysqli_real_escape_string($con,$_POST['name']);
					$amount=mysqli_real_escape_string($con,$_POST['amount']);
					$amount=str_replace(",","",$amount);
					$imonth=mysqli_real_escape_string($con,$_POST['imonth']);
					$mdate2=mysqli_real_escape_string($con,$_POST['mdate']);
					$total=mysqli_real_escape_string($con,$_POST['total']);
					$percent=mysqli_real_escape_string($con,$_POST['percent']);
					
					$query="select amount,deposit_id from deposit where bonus='0' and paid='0' and account_no='$account' ";
$p=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
         $ref =rand(100000000,999999999);
         $query="select firstname,lastname,email_address,phone  from registeruser  where  account_number='$account'";
$re=mysqli_query($con,$query)or die(mysqli_error($con));
$rs=mysqli_fetch_array($re);
$firstname=$rs['firstname'];
$lastname=$rs['lastname'];
$email=$rs['email_address'];
$phone=$rs['phone'];
        $que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$rows=mysqli_fetch_array($res);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rows['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rows['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$que)or die(mysql_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$que)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
			
		}
	}elseif($rows['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rows['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$que)or die(mysql_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$que)or die(mysql_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
			$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rows['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rows['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$que)or die(mysql_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$que)or die(mysql_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rows['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rows['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$que)or die(mysql_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$que)or die(mysql_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rows['category']=="Zenith"){
		if($amountt>=100000){
			$bonus=($amountt*5)/100;
			$amounts=($rows['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='$account'";
			mysqli_query($con,$que)or die(mysql_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='$account' and deposit_id='$did'";
			mysqli_query($con,$que)or die(mysql_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','$account','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
			$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}
        
        
    }
}

					if($amount>=5000){
					
					$query="select duration from investment where duration='$duration' and active='0' and account_no='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	echo "<h3>You already have similar Investment </h3><p>Please Choose Different Investment. <br><a href='invest.php'>Back</a></p>";
}else{
						$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	if($rows['total']<$amount){
		echo "<h3>The amount you want to pay greater than your wallet balance</h3>";
	}else{
		$amounts=$rows['total']-$amount;
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));


					$query="insert into investment (invest_name,duration,ref_no,amount,interest_rate,maturity_date,mont_interest_witdra,total_duration_interest,account_no,regdate,invest_date,start_date) values('$name','$duration','$ref',$amount','$percent','$mdate2','0','0','$account',now(),now(),now())";
					mysqli_query($con,$query)or die(mysqli_error($con));
					$ref =rand(100000,999999);
					$id=mysqli_insert_id($con);
$description="$amount was credited into your $duration Investment";
$query="insert into investment_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,investment_id) values('Investment','$account','$amount','','$amount','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$amount was debited  from your Wallet for $duration Investment Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Investment','$account','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
					echo "<h3>Your Investment has been Created Successfully</h3><p class='error'>Please don't Resend  Again</p>";
}
}
}
}else{
	echo"<h3>Invest Amount should not be less than 5000</h3>";
}
}
?>
	
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		
				<script>
 
 		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("duration").value;
	var amount=document.getElementById('amount').value;
	if(types=="3 Months"){
		var type="3";
	}
	else if(types=="6 Months"){
		var type="6";
	}
	
	else if(types=="9 Months"){
		var type="9";
	}
	else if(types=="12 Months"){
		var type="12";
	}
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "date.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("mdate").value = ajax.responseText;
				var interest=(10*amount)/100;
				document.getElementById("imonth").value=interest;
			 var data=ajax.responseText.split("/");
			 var day=data[0];
			 var mont=data[1];
			 var year=data[2];
			 var full=year+"/"+mont+"/"+day;
			  document.getElementById("mdate2").value=full;
			if(types=="3 Months"){
		  document.getElementById("percent").value="10%";
		  var total=(10*amount*3)/100;
		  document.getElementById("total").value=total;
		  
		  document.getElementById("mmonth").value="3 Months";
		  
	  }
	  else if(types=="6 Months"){
		
		  document.getElementById("percent").value="10%";
		  
		  document.getElementById("mmonth").value="6 Months";
		  var total=(10*amount*6)/100;
		  document.getElementById("total").value=total;
		 
		  
	  }
	  else if (types=="9 Months"){
		  document.getElementById("percent").value="10%";
		 
		  document.getElementById("mmonth").value="9 Months";
		  
		 var total=(10*amount*9)/100;
		  document.getElementById("total").value=total;
	  }
	  else if(types=="12 Months"){
		  document.getElementById("percent").value="10%";
		  
		  document.getElementById("mmonth").value="12 Months";
		  
		var total=(10*amount*12)/100;
		  document.getElementById("total").value=total;
		 
	  }
	
			
		}
	}
	ajax.send("month="+type);
 
 }
  
  </script>	
		
<?php include"footer.php" ?>