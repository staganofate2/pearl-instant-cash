<?php
session_start();
include_once('connect.php');
$pin=$_POST['pin'];
 
 $account=$_POST['account'];
$que="select pin from registeruser  where  account_number='$account' and pin='".sha1(md5($pin))."'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
if(mysqli_num_rows($res)<1){
	echo "Incorrect Account Pin";
	exit();
}else{
	echo "ok";
	exit();
}
exit();



?>