<?php
include"connect.php";

$data=array("data"=>array());
$x=0;
									$query="select * from registeruser";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						 
						$data['data'][$x][]=$ree['registeruser_id'];
						$data['data'][$x][]=$ree['account_number'];
						$data['data'][$x][]=$ree['firstname']." ".$ree['lastname'];
						$data['data'][$x][]=$ree['email_address'];
						$data['data'][$x][]=$ree['phone'];
						$data['data'][$x][]=$ree['alt_phone'];
						$data['data'][$x][]=$ree['gender'];
						$data['data'][$x][]=$ree['status'];
						$data['data'][$x][]=$ree['regdate'];
						
						$x++;
					}
				}
				//echo $x;
				//print_r($data);
				$c=json_encode($data);
				echo $c;

?>