<?php
include"header.php";
$bar="send_message";

?>
  <style>
	.reg{
		border:solid green;
		margin:50px auto;
		width:60%;
		padding:20px;
	}
	button,input[type=file]{
		margin:20px;
	}
	input{
		width:200px;
		margin:10px 20px 100px 2px;
	}
	</style>		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">blog</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Blog Post</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Blog Form</h4>
	<div class="col-md-4">
			<div id="imageresult"></div>
	<button id="statu_img_but">Add images</button><button id="statu_hd_but">Add Heading</button>
	<span id="results"></span>
		   
			</div>	
								<div class="col-md-8">
				
				
				<form method="post" action="" enctype="multipart/form-data">
		
				<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Title</span>
                <input type="text" class="form-control" name="title"placeholder="title">
				</div>
				<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Description</span>
                <input type="text" class="form-control" name="descripton"placeholder="descripton">
				</div>
                <div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Post</span>
                <textarea rows="6" class="form-control" name="message"id='post'  placeholder="Message" required></textarea>
      </div>
	 
			<p>Upload Primary Image</p>
			<img src="images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="5000000">
                <input type="file"  name="file" id="ufile" accept="image/*" onchange="loadFile(event)" required="" /><br>
			
			<br><br>
			<input type="submit" class="btn btn-success" name="Submit" value="Submit">
	 <?php if(isset($_POST['Submit'])){
		  $title=mysqli_real_escape_string($con ,$_POST['title']);
		  $descripton=mysqli_real_escape_string($con ,$_POST['descripton']);
		  
		  $message=$_POST['message'];
		$messagedb=mysqli_real_escape_string($con ,$message);
		
		
		 $fileName = $_FILES["file"]["name"];
 $fileTmpLoc = $_FILES["file"]["tmp_name"];
list($width, $height) = getimagesize($fileTmpLoc);
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(10000000000,99999999999).".".$extension;
		
		
	$idcard="../blog/userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$idcard );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $idcard;
	$resized_file = $idcard;
	$wmax = 700;
	$hmax = 500;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		
		
		
			
        }
    }
 else {
    echo "Invalid file";
}


$page=str_replace(" ","-",$title);
		  $query="insert into blog (title,page,description,post,image,postdate)values('$title','$page','$descripton','$messagedb','$idcard',now())";
		  $result=mysqli_query($con ,$query) or die(mysqli_error($con ));
		  
		  
$script=" <?php $bar='product';include'headers.php'; ?>";
$script.='$query="select* from ';
$script.="blog where page='";
$script.="$page'\";";
$script.='$result=mysqli_query($con ,$query) or die(mysqli_error($con ));$row=mysqli_fetch_array($result); ?>';
$script.="<div class=' w3ls-section' id='inner-about'>
		<div class='container'>
			<h3 class='h3-w3l'><b>ONLINE FOOD STORE<b></h3>
			
			
			<!-- about bottom-->
			<div class='about-bottom'>
				
				<div class='col-md-10'> ";
$script.= <<<'DOCT'
 <!-- blog detail -->
  <h2><?php echo $row['title'] ?></h2>
  <div class="info">Posted on:<?php echo $row['postdate'] ?></div>
  <img src="../<?php echo $row['image'] ?>" class="thumbnail img-responsive"  alt="<?php echo $row['title'] ?>">
<p>
DOCT;
 $script.="$message</p>";
 $script.=<<<'DOCT'
  
 </div>

  <div class="col-lg-2 ">

              
                <h3>Recent Post</h3>
                
              
              <div class="tab-content">
                
                  <ul class="list-unstyled">
				 <?php  $query="select* from 
DOCT;
$script.="blog order by postdate desc limit 5 \";";
$script.=<<<'DOCT'
$re=mysqli_query($con ,$query) or die(mysqli_error($con ));
while($red=mysqli_fetch_array($re)){
	
	?>
                  <li>
                  <h5><a href="../<?php echo $red['page'] ?>/"><?php echo $red['title'] ?></a></h5>
                            <div class="info">Posted on: <?php echo $red['postdate'] ?></div>  
                            </li>
							<?php 
}
?>
                
DOCT;
$script.='
                            
              
            </div>
  <!-- tabs -->


  </div>
</div>
</div>
</div>

<?php include\'../footers.php\';?>';	
 $filenam = basename( $page );
$filenam = preg_replace( "/[^A-Za-z0-9_\- ]/", "", $filenam  );

 $mytable=$filenam;
if (!file_exists($mytable)) {
			mkdir($mytable, 0755);
		}

$file = "index.php";
$filepath = "$mytable/$file";
if ( file_exists( $filepath ) ) {

} else {
if ( file_put_contents( $filepath, $script ) === false ) die( "Couldn’t createfile" );
chmod( $filepath, 0666 );

}	  
		  
	echo "success";	  
	  }
	  
	  ?>
          
</form>

						
                       
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		<script type="text/javascript" src="jquery.js"></script>
		<script>
		function submitForm() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploads.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                alert(data);
                $('#result').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#result img').attr('src',data);
				$('#img').val(data);
				document.getElementById("post").value +="<div class='clear'></div><img src='../"+data+"' class='postimg' alt='' >";
				//alert($('#img').val());
				
				
            });
            return false;
        }
		
		$('document').ready(function(){$('#statu_img_but').click(function(){$('#imageresult').load('status_image.php');});});   
			$('document').ready(function(){$('#statu_hd_but').click(function(){$('#results').load('status_input.php');});}); 
			function addHd(){
				var hd=document.getElementById("hd").value;
				if(hd==""){
					alert("Please Enter heading name");
					return false;
				}
				document.getElementById("post").value +="<h3>"+hd+"</h3>";
				document.getElementById("hd").value="";
			}

var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
		
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };	
  function closediv(id){
	  document.getElementById(id).innerHTML="";
	  
  }
		</script>
		
		<?php include"footer.php" ?>