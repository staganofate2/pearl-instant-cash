<?php
include"header.php";
$bar="withdraw";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Withdraw</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Account Withdraw</h2>
				<table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table> 
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		<div class="col-lg-2 ">
		</div>

 <div class="col-lg-8 ">
            <h3><span id='balance'></span></h3>            
						
	<h4 class="page-header">Account Withdraw Form</h4>
	<form action="payment.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="id" value="" id='id' />
				<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
							<span id='incorrect'></span>
							</div>
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update2()" >
								<option   value="">Select Account</option>
								
								</select>
								<span id='results'></span>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Maturity Date</span>
								<input class="form-control" id='maturity' name="maturity" placeholder='Maturity Date' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Start Account Contribution Date</span>
								<input class="form-control" id='contribute' name="contribute" placeholder='Start Account Contribution Date' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Deposit</span>
								<input class="form-control" id='deposit' name="deposit" placeholder='Total Deposit' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Added Interest</span>
								<input class="form-control" id='interest' name="interest" placeholder='Added Interest' type="text" readonly>
							</div>
							<div id='loaders'></div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Grand Total</span>
								<input class="form-control" id='total' name="total" placeholder='Grand Total' type="text" readonly>
							</div>
							
							
							
							<button class="btn btn-info" name="change" id='submit'type="submit">Transfer to Wallet</button>
				
				</form>

	
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update2(){
	
	var types=document.getElementById("actype").value;
	
	var account=document.getElementById("account_no").value;
	
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("results").innerHTML = 'please wait ...';
	
	 ajax.open("POST", "account_withdraw_update.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			
			document.getElementById("results").innerHTML = '';
				if(ajax.responseText=="not"){
					document.getElementById("results").innerHTML = 'Account not Matured';
				}else{
			
			 var data=ajax.responseText.split("|");
			 var mat_date=data[0];
			 var start_date=data[1];
			 var total=data[2];
			 var interest=data[3];
			 var gtotal=data[4];
			 var witamount=data[5];
			 var id=data[6];
			  var status=data[7];
			 document.getElementById("maturity").value = mat_date;
			 document.getElementById("contribute").value =start_date;
			 document.getElementById("deposit").value =total ;
			 document.getElementById("interest").value =interest ;
			 document.getElementById("total").value =gtotal ;
			 document.getElementById("id").value =id;
			 document.getElementById("withdraw").value = witamount;
			 if(status=="1"){
				 document.getElementById("am").innerHTML ="<select name='amount'><option value='All'>All</option><option value='Capital'>Capital</option><option value='Interest'>Interest</option></select>";
			 }else{
				document.getElementById("am").innerHTML ="<input class='form-control' value=''onkeyup='this.value = numFormat(this.value)' id='amount' name='amount' type='text' placeholder='Amount in Digits' onblur='check()' required>";
			 }
			
			 
				}
			
		}
	}
	ajax.send("type="+types+"&account="+account);
 
 }
 function update(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update4.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
		var b=document.getElementById("loaders").style.display="none";		if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			var actype=data[4];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			document.getElementById("balance").innerHTML=innerHTML="Balance ₦ "+balance;
				document.getElementById("actype").innerHTML += actype;
			
			 document.getElementById("incorrect").innerHTML = '';
			
			}
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	var types=document.getElementById("actype").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	var amounts=amount.replace(reg,""); 
	var account=document.getElementById("account_no").value;
		var b=document.getElementById("loaders").style.display="block";
		//document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_withdraw_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				document.getElementById("result").innerHTML = '';
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("type="+types+"&amount="+amounts+"&account="+account);
 
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
		
