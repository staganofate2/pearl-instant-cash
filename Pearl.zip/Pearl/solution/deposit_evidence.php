<?php
include"header.php";
$bar="bankinfo";
?>



	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">deposit evidence</li>
				
			</ol>
		</div><!--/.row-->
		<div class="col-lg-12">
				<h2 class="page-header">View Evidence of Payment</a></h2>
				
				</div>
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Evidence of Payment</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header"> Account Payment Evidence</h4>
	
		
						
				<?php
				
				if(isset($_GET['id'])){
					$id=$_GET['id'];
				
				
				$query="select* from deposit  where deposit_id='$id'";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				  $row=mysqli_fetch_array($resultt); 
				?>
				
								<div class="col-md-8">
								<table class="table">
								<tr>
				<td>Account Number</td>
				<td><?php echo $row['account_no']; ?></td>
				
				</tr>
				<tr>
				<td>Name of Depositor</td>
				<td><?php echo $row['depositor_name']; ?></td>
				
				</tr>
								<tr>
				<td>Amount</td>
				<td><?php echo $row['amount']; ?></td>
				
				</tr>
				<tr>
				<td>Payment Method</td>
				<td><?php echo $row['method']; ?></td>
				
				</tr>
				<tr>
				<td>Description</td>
				<td><?php echo $row['description']; ?></td>
				
				</tr>
				<tr>
				<td>Reference No:</td>
				<td><?php echo $row['ref_no']; ?></td>
				
				</tr>
				<tr>
				<td>Confirmed by User</td>
				<td><?php if($row['confirmed'] =="1"){echo "Yes";}else{echo "No";} ?></td>
				</table>
                    </div>


<?php
			   }
				}
			   ?>


		
			
			
			
		</div><!--/.row-->
		
        <script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
function loadform(id,x){
	var input="<button  class='close'onclick='closediv(\""+x+"\")' >Close X</button><input class='form-control' id='account_no' placeholder='Account Number'type='text' ><input class='form-control' id='bank' placeholder='Bank Name'type='text' ><button onclick='update("+id+")'>Save</button>";
document.getElementById("result"+id).innerHTML=input;
	}
	function closediv(id){
		document.getElementById(id).innerHTML="";
	}
 function update(id){
	
	var account_no=document.getElementById("account_no").value;
	var bank=document.getElementById('bank').value;
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "bank_update.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("result"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("account_no="+account_no+"&bank="+bank+"&id="+id);
	}
		function update(id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_bank.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
    </script>
		
		
<?php include"footer.php" ?>