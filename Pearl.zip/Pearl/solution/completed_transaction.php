<?php
include"header.php";
$bar="view_deposit";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">completed Transactions</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All  Completed Trasactions</h4>
	<div id='loaders'></div>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Name</th><th>Package</th><th>Amount</th><th>Balance</th><th>Trasaction Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from control where sent='1'  and reversed='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					  $query="select firstname,lastname from registeruser where account_number='".$ree['account_no']."'";
						$x=mysqli_query($con,$query) or die(mysqli_error($con));
						$c=mysqli_fetch_array($x);
					?>
				<tr>
				<td> <?php echo $ree['account_no'] ?></td><td><?php echo $c['firstname']." ".$c['lastname'] ?></td><td> <?php echo $ree['packages'] ?></td><td>₦  <?php echo $ree['amount'] ?></td><td> <?php echo $ree['balance'] ?></td><td> <?php echo $ree['transaction_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                 </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id,types_id,types){
	
	
	var b=document.getElementById("loaders").style.display="block";
//	document.getElementById("confirm"+id).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_paystack2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";		
			
				document.getElementById("confirm"+id).innerHTML ="Payment Confirmed";


		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&types_id="+types_id+"&types="+types);
	}
	function reject(id){
	
	if(confirm("Are you Sure you want to reject the Payment")){
		var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	document.getElementById("confirm"+id).innerHTML ="";
	 ajax.open("POST", "reject_paystack2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("reject"+id).innerHTML ="Payment Rejected";
document.getElementById("confirm"+id).innerHTML ="";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 }
	
    </script>
		<?php include"footer.php" ?>