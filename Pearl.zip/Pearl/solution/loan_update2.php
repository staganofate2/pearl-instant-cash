<?php
include"connect.php";
$account=$_POST['account'];
$type=$_POST['type'];
$x="";
       
								
								$query="select repayment_plan,amount  from loan where account_no='$account' and active='0'";
								$fee=mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($fee)>0){
									while($rows=mysqli_fetch_array($fe)){
									$x.=$rows['repayment_plan']."|".$rows['amount'];	
									}
								}
								echo $x;                           
?>