<?php include"header.php";
$bar="bankinfo" ?>
		<style>
  /* Style the buttons that are used to open and close the accordion panel */
.accordion {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    text-align: left;
    border: none;
    outline: none;
    transition: 0.4s;
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.active, .accordion:hover {
    background-color: #ccc;
}

/* Style the accordion panel. Note: hidden by default */
.panel {
    padding: 0 18px;
    background-color: white;
    display: none;
    overflow: hidden;
} 
 </style>
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Food Account Statement</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Food Account Statement</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 
 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">User Food Account Statement</h4>
	<form role="form" action="" method="POST">
				

			
            
							
							
							<div class="form-group">
								<input class="form-control" placeholder="ACCOUNT NUMBER" name="acct" type="text" required>
							</div>
							<button class="btn btn-info" type="submit" name="submit">View</button>
							
						
				</form>		
						
				<?php
				if(isset($_POST['submit'])){
				$acct=mysqli_real_escape_string($con,$_POST['acct']);
				
				$query="select account_number from registeruser  where   account_number='$acct'";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   if(mysqli_num_rows($resultt)>0){
				   
				   ?>

                     

<?php $query="select* from food where account_no='$acct'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					
					?>
				
				
							
								<?php while($ree=mysqli_fetch_array($res)){
					?>
				
				 <button class="accordion"><?php echo $ree['package_name'] ?> |  <?php if($ree['active']=="0"){echo "Active";}else{echo "Completed";} ?></button>
				 
				 <div class="panel">
						
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
										<th>Date</th>
                                            <th>Ref No</th>
                                            <th>Description</th>
											<th>Debit</th>
											<th>Credit</th>
											<th>Balance</th>
											<th>Remark</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
										
	$mysqli1="select * from food_transact where account_no='$acct' and packages='Food' and food_id='".$ree['food_id']."' ";
	$myquery1=mysqli_query($con,$mysqli1) or die(mysqli_error($con));
		while($row2 = mysqli_fetch_object($myquery1)){

?>				
									
                                        <tr class="info">
										 <td><?php echo @$row2->transaction_date;   ?></td>
                                            <td><?php echo @$row2->refno;   ?></td>
                                            <td><?php echo @$row2->description;   ?></td>
                                            <td><?php echo @$row2->debit;   ?></td>
											<td><?php echo @$row2->credit;   ?></td>
											<td><?php echo @$row2->balance;   ?></td>
											 <td><?php echo @$row2->types;   ?></td>
                                            
		</tr> <?php  }  ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						</div>




					 
								
				
				
				<?php
			   }
				}
			   }else{
				   echo "<h5>$acct not in our Database</h5>";
			   }
				}
				?>
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
			
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
} 
</script>
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
		
		
</body>
</html>