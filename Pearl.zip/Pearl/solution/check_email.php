<?php
include"connect.php";
$account=$_POST['type'];
$x="";
$query="select* from registeruser where account_number='$account'";
$er=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($er)>0){
	$we=mysqli_fetch_array($er);
	$x.=$we['picture']."|";
	$x.=$we['firstname']."|";
	$x.=$we['lastname']."|";
 $x.=$we['email_address'];
						
echo $x;
								exit();
}else{
	echo "Incorrect";
	exit();
}
								?>