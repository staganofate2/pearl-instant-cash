<?php
include"header.php";
include"../function.php";
$bar="deposit";
?>


		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">deposit</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Loan Deposit</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                  
	<div class='col-lg-2'>
 <table><tr><td><img src='' id='picture' width='100px' alt=''></td><td><b id='first'></b></td><td><b id='last'></b></td> </tr> </table>   	
</div>	
<div class='col-lg-8'>
<h3><span id='balance'></span></h3>
	<h4 class="page-header"> Loan Deposit Form</h4>
	

<?php
if(isset($_POST['change'])){
	
$account =escape($con,$_POST['account_no']);
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['amount']);
$loan_id=$_POST['loan_id'];
$amount=str_replace(",","",$amount);
$loan_repay_id=$_POST['loan_repay_id'];
$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']-$amount;
	
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select deposit  from loan where account_no='$account' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['deposit']=="0"){
	$query="update loan set start_date=date(now()) where account_no='$account' and loan_id='$loan_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['deposit']+$amount;
$query="update loan set deposit='$am' where account_no='$account' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update loan_repay set paid='1' ,paid_date=now() where account_no='$account' and loan_repay_id='$loan_repay_id'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select loan_id,total,deposit  from loan where account_no='$account' and loan_id='$loan_id'";
$rowsee=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($rowsee)>0){
	$z=mysqli_fetch_array($rowsee);
	if($z['total']==$z['deposit']){
	$query="update loan set paid='1' where account_no='$account' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));	
	}
}

$ref =rand(100000,999999);
$description="$amount was credited into your $actype Account";
$query="insert into transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('loan','$account','$amount','','$am','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Loan Deposit";
$query="insert into transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Wallet','$account','','$amount','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
echo"<h3>Loan  Deposit was Successful</h3>";
}
}else{
	?>
	<form action="" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="loan_id" value="" id='loan_id' />
	<input type="hidden" name="loan_repay_id" value="" id='loan_repay_id' />
							<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
							<span id='incorrect'>
							</div>
				
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update2()" >
								<option   value="">Select Loan Account</option>
								
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" id='payment' name="payment" placeholder='Payment Structure' type="text" readonly>
							</div>
							<div class="form-group">
								<input class="form-control" value="" id='amount' name="amount" type="text" readonly required>
								<span id='result'></span>
							</div>
							<button class="btn btn-info" name="change" id='submit' type="submit">SUBMIT</button>
				<?php	
}
?>
				</form>
</div>
				
				</div>




		
			
			
			
		</div><!--/.row-->
		
		
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
	document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update_loans.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			var actype=data[4];
			var structure=data[5]
			var loan_id=data[6];
			var amount=data[7];
			alert(loan_id);
			var loan_repay_id=data[8];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
		
				document.getElementById("balance").innerHTML="Balance ₦ "+balance;
			 
			document.getElementById("actype").innerHTML = actype;
			document.getElementById("amount").value = amount;
			document.getElementById("payment").value = structure;
			document.getElementById("loan_id").value = loan_id;
			document.getElementById("loan_repay_id").value = loan_repay_id;
			
		}
		}
	}
	ajax.send("type="+types);
 
 }
 function update2(){
	
	var types=document.getElementById("actype").value;
	var account=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_loan2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
				var data=ajax.responseText.split("|");
			var structure=data[0];
			var id=data[1];
			var amount=data[2];
			var loan_repay_id=data[3];
			
				document.getElementById("payment").value = structure;
				document.getElementById("id").value = id;
			 document.getElementById("amount").value = amount;
			 document.getElementById("loan_repay_id").value = loan_repay_id;
			 
			
			
		}
	}
	ajax.send("type="+types+"&account="+account);
 
 }
 function check(){
	
	var account=document.getElementById("account_no").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	alert(amount);
	var amounts=amount.replace(reg,""); 
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>	
<?php include"footer.php" ?>