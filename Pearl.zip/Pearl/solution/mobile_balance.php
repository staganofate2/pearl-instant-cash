<?php
include"header.php";
$bar="addbankinfo";

?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">verify Mobileng Balance</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Verify Mobileng Balance</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header">Verify Mobileng BALANCE Information</h4>
	<?php
				if(isset($_POST['submit'])){
				
					
								
								
								

$http="https://mobileairtimeng.com/httpapi/balance.php?userid=08107302391&pass=912363232d306466ae2a1";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
 // print_r($x);
 //  $b=$x['data'][0]['balance'];
 //$d= substr($b,0,(strlen($b)-2));
  echo "<h3>Balance:  N ".$x."</h3>";
  }
  
}else{
		
		
								
?>
	<form role="form" action="" method="POST">
				

						
						
						
						
						
						
						
							<button class="btn btn-info" type="submit" name="submit">VERIFY BALANCE</button>
							
						
				</form>		
						
				<?php
				}
				?>
			
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>