<?php include"header.php";
$bar="introducer";
 ?>
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Introducer Link</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href="paid_introducer.php">View Paid Introducer</a></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Introducer Details</h4>
	
				   
				
								<div class="col-md-8">
				
				

				<?php $query="select* from refer ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					

				
						?>
							
				<h4 class="center"> Referal Summary</h4>
				<table class="table">
				
				<tr>
				<th>Name</th><th>Total Referral</th><th>Visit</th><th>Signup</th><th>Transact</th><th>Paid</th><th>Action</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($res)){
					$query="select firstname,lastname from registeruser where account_number='".$ree['account_no']."'";
					$de=mysqli_query($con,$query) or die(mysqli_error($con));
					$te=mysqli_fetch_array($de);
					?>
				<tr>
				<td><?php echo $te['firstname']." ".$te['lastname'] ?></td><td><?php $query="select account_no from refer_user where refer_id='".$ree['refer_id']."'";
				$fe=mysqli_query($con,$query) or die(mysqli_error($con));
				echo mysqli_num_rows($fe); ?></td>
				<td><?php $query="select account_no from refer_user where refer_id='".$ree['refer_id']."' and visit='1'";
				$fe=mysqli_query($con,$query) or die(mysqli_error($con));
				echo mysqli_num_rows($fe); ?></td><td> <?php $query="select account_no from refer_user where refer_id='".$ree['refer_id']."' and signup='1'";
				$fe=mysqli_query($con,$query) or die(mysqli_error($con));
				echo mysqli_num_rows($fe); ?></td><td><?php $query="select account_no from refer_user where refer_id='".$ree['refer_id']."' and transact='1'";
				$fe=mysqli_query($con,$query) or die(mysqli_error($con));
				echo mysqli_num_rows($fe); ?></td><td> <?php $query="select account_no from refer_user where refer_id='".$ree['refer_id']."' and paid='1'";$fe=mysqli_query($con,$query) or die(mysqli_error($con));
				echo mysqli_num_rows($fe); ?>  </td><td><a href='morelink.php?account=<?php echo $ree['refer_id']?>'> View More</a></td>
				
				
				</tr>
				<?php
				}
				?>
				
				
				</table>
				
				
				
				<?php
					}
				
				else{
					?>
					<center><h4 class="h3-w3l">NO Referral Account yet</h4> 
				
				
				
					<?php
				}
				?>

						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>
		
		
	
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
			 
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id){
	
if(confirm("Are You sure You want to Remove User ?")){
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "remove_user.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
			}
	function showpass(id){
		var type=document.getElementById("pass"+id).type;
		if(type=="password"){
			document.getElementById("pass"+id).type="text";
		}else{
			document.getElementById("pass"+id).type="password"
		}
	}
    </script>
		
		
</body>
</html>