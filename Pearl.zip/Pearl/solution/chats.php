<?php
include"header.php";
$bar="chat";
?>

<style>
#rt{
	text-align:right;
	
}
#lt{
	text-align:left;
	
}
</style>
		
		
		<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Chat</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header" >Chat</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-8 ">
                        
						
						
<!------------------------------------------------table for message----------------------------------------->



<div class="panel panel-default">
                        <div class="panel-heading">
                             <strong>Message Sent by User</strong>
							 
                        </div>
                        <div class="panel-body">
                            
							
							<div id='messages'>


<?php
if(isset($_GET['receiver'])){	
$receiver=$_GET['receiver'];
if(isset($_GET['id'])){
	$mid=$_GET['id'];
	 $query="update message me,conversation con set me.red='1' where  me.conversation_id=con.conversation_id and  con.usertwo='admin' and me.red='0' and me.message_id='$mid'";

$result=mysqli_query($con,$query) or die(mysqli_error($con)); 
}
if(isset($_POST['submit'])){

$message=$_POST['mes'];

$q="insert ignore into conversation values('','admin','$receiver','chat')";
$s=mysqli_query($con,$q)or die(mysqli_error($con));
$id=mysqli_insert_id();

$query="insert ignore into message values ('','admin','$id','$message',NOW(),'0') ";
$result=mysqli_query($con,$query) or die(mysqli_error($con));
if($result>0){
$me="message_sent";
header("location:message.php?receiver=$receiver");
exit();
}
else{
$me= "message not sent";
echo $me;exit();
}}

?>
<div id="chat"> 

<h3>PRIVATE CHAT ROOM </h3>
<h4>Account Number:  <?php echo $receiver; ?></h4>
 
<div id="messagechat">
</div>                                                                                                                                                  



<form id="form1"   method="post" action="<?php $_SERVER['PHP_SELF'] ?>" onsubmit="return false">
		<label for="name"style='color:blue' > message:</label>
		<textarea type="text" name="mes" id="mes" colspan="150"></textarea>
		<input type="hidden"id="receiver" value="<?php echo $receiver ?>">
		<input type="hidden"id="sender" value="admin">
		
		<input type="submit" id="meebutton" value="SEND" onclick="sendit('message2.php')">
		 </form>
		 <div id="target"><?php  if(isset($me)){echo $me;}?></div >
	<span style='color:green;margin-left:100px'id="result"></span>
	</div>
	<script>
	function sendit(){

	var hr = new XMLHttpRequest();
	var url = "message2.php";
	var receiver = document.getElementById("receiver").value;
	var sender = document.getElementById("sender").value;
	var mes = document.getElementById("mes").value;
	var vars = "receiver="+receiver+"&sender="+sender+"&mes="+mes;
	hr.open("POST",url,true);
	hr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	hr.onreadystatechange = function(){
		if(hr.readyState == 4 && hr.status == 200){
			var return_data = hr.responseText;
			//alert(return_data);
				if(return_data != "message_sent"){
					document.getElementById('result').innerHTML="error sending message";
					
				}else{
				document.getElementById("mes").value="";
					document.getElementById("result").innerHTML="sent";
			}
		}
	}
	hr.send(vars);	
}
	</script>
	<?php
}
?>
				
                            
                        </div>
						
						
						
                    </div>



<!-------------------------------table for message ends here------------------------------------>

					
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		
		
		
	
		
		<?php include"footer.php" ?>