<?php
session_start();

include"connect.php";


if (!isset($_SESSION['passi'])){
	header("location:index.php");
	exit();
} 

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PEARL ADMIN Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
		<link href="cs/summernote.css" rel="stylesheet">
	
	
</head>


<!------------------------top nav------------------------------------------------>

	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation" style='background:#191970'>
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>PEARL</span> Admin</a>
				<ul class="nav navbar-top-links navbar-right">
									<li class="dropdown" id='messagee'><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span id='mee'class="label label-danger"></span>
					</a>
						
					</li>
					<li class="dropdown" id='notify'><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-bell"></em><span id='noo'class="label label-info"></span>
					</a>
						
					</li>
				</ul>
				</div> 
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		<script>
		
	var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
		function loadstuff(){

$('document').ready(function(){$("#mee").load('message_alert.php');});
$('document').ready(function(){$("#noo").load('notification_alert.php');});

 
function updatemessage(){
		
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatemessage.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {

			
			
				
				 document.getElementById("messagee").innerHTML +=ajax.responseText;
				 
			
		}
	}
	ajax.send();
 
 }
 updatemessage();
 function updatenotification(){
		
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatenotification.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {

			
			
				
				 document.getElementById("notify").innerHTML +=ajax.responseText;
				 
			
		}
	}
	ajax.send();
 
 }
 updatenotification();

}

setInterval(loadstuff,5000);
</script>