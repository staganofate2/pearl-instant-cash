<?php
session_start();
include_once('connect.php');
$amount=$_POST['amount'];
$type=$_POST['type'];
$account=$_POST['account'];
$que="select* from account where account_type='$type' and account_no='$account'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
if($row['interest']<$amount && $row['active']=="0"){
	echo "The amount you Entered is bigger than Your Withdrable Amount";
	exit();
}
if($row['amount']<$amount && $row['active']=="1"){
	echo "The amount you Entered is bigger than You Total savings";
	exit();
}
if($row['interest']>=$amount && $row['active']=="0"){
	echo "ok";
	exit();
}
if((($row['amount']-$amount)=="500") && ($row['active']=="1")){
	echo "ok";
	exit();
}
exit();



?>