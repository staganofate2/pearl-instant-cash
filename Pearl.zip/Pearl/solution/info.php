<?php
include"header.php";
$bar="dashboard";
?>



		
		<?php
		include"sidebar.php";
		?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Dashboard</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		<h2 style='text-align:center'><a href="edit.php?id=<?php echo $_GET['id'] ?> ">Edit Info</a></h2>
		

 <div class="col-lg-12 ">
			
			   
				<?php if(isset($_GET['id'])){
					$id=$_GET['id'];
					$query="select* from registeruser where account_number='$id'";
					$res=mysqli_query($con,$query) or die(mysqli_error($con));
					$row=mysqli_fetch_array($res);
				?>
				<p> <?php echo$row['firstname']." Registeration information";  ?>
				</p>
				
								<div class="col-md-8">
				
				<table class="table">
				<tr>
				<th>User Account Detail</th>
				<th></th>
				</tr>
				
				<tr>
				<td>User FullName</td>
				<td><?php echo $row['firstname']." ".$row['middlename']." ". $row['lastname']; ?></td>
				
				</tr>
				<tr>
				<td>Email ID</td>
				<td><?php echo $row['email_address']; ?></td>
				
				</tr>
				
				<tr>
				<td>Phone Number</td>
				<td><?php echo $row['phone']; ?></td>
				
				</tr>
				<tr>
				<td>Alternate Phone Number</td>
				<td><?php echo $row['alt_phone']; ?></td>
				
				</tr>
				<tr>
				<td>Gender</td>
				<td><?php echo $row['gender']; ?></td>
				
				</tr>
				<tr>
				<td>Marital Status</td>
				<td><?php echo $row['status']; ?></td>
				
				</tr>
				<tr>
				<td>Date of Birth</td>
				<td><?php echo $row['dob']; ?></td>
				
				</tr>
				
				<tr>
				<td>Residential Address</td>
				<td><?php echo $row['address']; ?></td>
				
				</tr>
				<tr>
				<td>Office Address</td>
				<td><?php echo $row['office_address']; ?></td>
				
				</tr>
				
				<tr>
				<td>Nearest Bus stop</td>
				<td><?php echo $row['phone']; ?></td>
				
				</tr>
				
				<tr>
				<td>City, State</td>
				<td><?php echo $row['city_res'].", ".$row['state_res']; ?></td>
				
				</tr>
				
				<tr>
				<td>Home L.G.A</td>
				<td><?php echo $row['lga']; ?></td>
				
				</tr>
				<tr>
				<tr>
				<td>Educational Qualification</td>
				<td><?php echo $row['qualification']; ?></td>
				
				</tr>
				<tr>
				<td>Institution</td>
				<td><?php echo $row['institution']; ?></td>
				
				</tr>
				<tr>
				<td>Faculty</td>
				<td><?php echo $row['faculty']; ?></td>
				
				</tr>
				<tr>
				<td>Department</td>
				<td><?php echo $row['department']; ?></td>
				
				</tr>
				<tr>
				<td>Level</td>
				<td><?php echo $row['levels']; ?></td>
				
				</tr>
				<td>Means of Identification</td>
				<td><?php echo $row['id']; ?></td>
				
				</tr>
				<tr>
				<td>Identification No:</td>
				<td><?php echo $row['id_no']; ?></td>
				
				</tr>
				<tr>
				<td>Account Number</td>
				<td><?php echo $row['account_number']; ?></td>
				
				</tr>
				<tr>
				<td>Issued Date</td>
				<td><?php echo $row['issue_date']; ?></td>
				
				</tr>
				<tr>
				<td>Expiring Date</td>
				<td><?php echo $row['exp_date']; ?></td>
				
				</tr>
				<tr>
				<td>ID Image</td>
				<td><img src='../<?php echo $row['id_image']; ?>' width='120px' height='120px'alt='id image'></td>
				
				</tr>
				<tr>
				<td>Next of Kin Title</td>
				<td><?php echo $row['kin_title']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Name</td>
				<td><?php echo $row['kin_name']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Phone Number</td>
				<td><?php echo $row['kin_phone']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Address</td>
				<td><?php echo $row['kin_address']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin State of Origin</td>
				<td><?php echo $row['kin_state']; ?></td>
				
				</tr>
				<tr>
				<td>Next of Kin Relationship</td>
				<td><?php echo $row['kin_relationship']; ?></td>
				
				</tr>
				
				
				<tr>
				<td>Passport</td>
				<td><img src='../<?php echo $row['passport']; ?>' width='120px' height='120px'alt='id image'></td>
				
				</tr>
				<tr>
				<td>Signature</td>
				<td><img src='../<?php echo $row['signnature']; ?>' width='120px' height='120px'alt='id image'></td>
				
				</tr>
				<tr>
				<td>Certificate</td>
				<td><?php if($row['certificate']==""){
					?>
					<div id='result'></div>
					<form method="post" id="fileinfo" name="fileinfo" >
        <label>Select a picture:</label>
        <input type="file" name="files" required />
        <input type="button" value="Upload" id='upload' onclick="submitForm()"/>
    </form>
				<?php
				}else{
					?>
<img src='../<?php echo $row['certificate']; ?>' width='120px' height='120px'alt='id image'><?php
				}
				?></td>
				
				</tr>
				
				</table>

				<?php 
				}
				?>
				</div>
				
				
				<br><br><br><br>
				  </div>





		
			
			
			
		</div><!--/.row-->
		
	
        <script>
          
			function submitForm() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("account", "<?php echo $row['account_number'] ?>");
			$("#upload").val("Uploading wait..");
            $.ajax({
              url: "upload.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                
                $('#result').html('<img alt="picture" style="width:100px ;height:100px">');
				$('#result img').attr('src',data);
				$('#fimg').val(data);
				$("#upload").val("Upload");
				alert(data);

				
				
            });
            return false;
        }
    </script>
		
		
<?php include"footer.php" ?>