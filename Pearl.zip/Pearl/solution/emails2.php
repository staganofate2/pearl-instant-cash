<?php
include"header.php";
$bar="view_deposit";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Emails</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				
				
				</div>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href='my_mail.php'>BACK</a></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Users Emails</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                   
                                   <thead>
<tr><th>Account Number</th><th>Email</th><th>Subject</th><th>Message</th><th>Sent Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from site_emails";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['email'] ?></td><td> <?php echo $ree['subject'] ?></td><td><?php if($ree['image']!=""){
				 echo "<img src='../".$ree['image']."' width='100%'><br>" ;} echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                
                                </table>
                            </div>
                            
                        </div><!-- end of panel-body -->




		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>