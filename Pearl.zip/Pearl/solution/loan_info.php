<?php
include"header.php";
$bar="dashboard";
?>



		
		<?php
		include"sidebar.php";
		?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Loan Info</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<h2 style='text-align:center'><a href="edit_loan.php?id=<?php echo $_GET['id'] ?> ">Edit Loan Info</a></h2>
 <div class="col-lg-12 ">
			
			   
				<?php if(isset($_GET['id'])){
					$id=$_GET['id'];
					$query="select* from loan where loan_id='$id'";
					$res=mysqli_query($con,$query) or die(mysqli_error($con));
					$row=mysqli_fetch_array($res);
				?>
				
				
								<div class="col-md-8">
				
				<table class="table">
				<tr>
				<th>Loan Application  Detail</th>
				<th></th>
				</tr>
				
				<tr>
				<td>Account Number</td>
				<td><?php echo $row['account_no']; ?></td>
				
				</tr>
				<tr>
				<td>Employment Status</td>
				<td><?php echo $row['emp_status']; ?></td>
				
				</tr>
				
				<tr>
				<td>Employment Sector</td>
				<td><?php echo $row['emp_sector']; ?></td>
				
				</tr>
				<tr>
				<td>Occupation</td>
				<td><?php echo $row['occupation']; ?></td>
				
				</tr>
				<tr>
				<td>Business Name</td>
				<td><?php echo $row['business_name']; ?></td>
				
				</tr>
				<tr>
				<td>Business Address</td>
				<td><?php echo $row['business_address']; ?></td>
				
								<tr>
				<td>Business Email</td>
				<td><?php echo $row['biz_email']; ?></td>
								<tr>
				<td>Business Phone</td>
				<td><?php echo $row['biz_phone']; ?></td>
				</tr>
				<tr>
				<td>Business Status</td>
				<td><?php echo $row['biz_status']; ?></td>
				
				</tr>
				
				<tr>
				<td>RC Number</td>
				<td><?php echo $row['rc_no']; ?></td>
				
				</tr>
				<tr>
				<td>Monthly Profit</td>
				<td><?php echo $row['monthly_profit']; ?></td>
				
				</tr>
				
				<tr>
				<td>Daily Turnover</td>
				<td><?php echo $row['dialy_turnover']; ?></td>
				
				</tr>
				
				<tr>
				<td>Business Start Date</td>
				<td><?php echo $row['biz_start']; ?></td>
				
				</tr>
				
				<tr>
				<td>Tax Number</td>
				<td><?php echo $row['tax_no']; ?></td>
				
				</tr>
				<tr>
				<tr>
				<td>Pension Number</td>
				<td><?php echo $row['pension']; ?></td>
				
				</tr>
				<tr>
				<td>Interest Rate</td>
				<td><?php echo $row['interest_rate']; ?></td>
				
				</tr>
				<tr>
				<td>Requested Amount</td>
				<td><?php echo $row['req_amount']; ?></td>
				
				</tr>
				<tr>
				<td>Approved Amount</td>
				<td><?php echo $row['amount']; ?></td>
				
				</tr>
				<tr>
				<td>Interest</td>
				<td><?php echo $row['interest']; ?></td>
				
				</tr>
				<tr>
				<td>Total Amount</td>
				<td><?php echo $row['total']; ?></td>
				
				</tr>
				<td>Loan Duration</td>
				<td><?php echo $row['loan_duration']; ?></td>
				
				</tr>
				<tr>
				<td>Repayment Plan</td>
				<td><?php echo $row['repayment_plan']; ?></td>
				
				</tr>
				<tr>
				<td>Repayment Plan Amount</td>
				<td><?php echo $row['repayment_plan_amount']; ?></td>
				
				</tr>
				<tr>
				<td>Reason for Loan</td>
				<td><?php echo $row['reason_for_loan']; ?></td>
				
				</tr>
				<tr>
				<td>How did you Find Us</td>
				<td><?php echo $row['find']; ?></td>
				
				</tr>
				<tr>
				<td>Reference Number</td>
				<td><?php echo $row['ref_no']; ?></td>
				
				</tr>
				
				<tr>
				<td>BVN Number</td>
				<td><?php $query="select bvn from bank_info where account_no='". $row['account_no']."'";$s=mysqli_query($con,$query) or die(mysqli_error($con));$c=mysqli_fetch_array($s); echo $c['bvn']; ?></td>
				
				</tr>
				
				</table>
				<table class="table">
				<tr>
				<th>Card Information  Detail</th>
				<th></th>
				</tr>
				<?php $query="select*  from paystackloan where account_no='". $row['account_no']."' and confirmed='1' and remove='0'";$ss=mysqli_query($con,$query) or die(mysqli_error($con)); ?>
				<?php
				while($d=mysqli_fetch_array($ss)){
				?>
				<tr>
				<td>Card Type</td>
				<td><?php echo @$d['card_type']; ?></td>
				
				</tr>
				<tr>
				<td>Last Four Digit</td>
				<td><?php echo @$d['last4']; ?></td>
				
				</tr>
				
				<tr>
				<td>Expiring Month</td>
				<td><?php echo @$d['exp_month']; ?></td>
				
				</tr>
				<tr>
				<td>Expiring Year</td>
				<td><?php echo @$d['exp_year']; ?></td>
				
				</tr>
				<tr>
				<td>Bank</td>
				<td><?php echo @$d['bank']; ?></td>
				
				</tr>
				
				<?php
				}
				?>
				</table>

				<?php 
				}
				?>
				</div>
				
				
				<br><br><br><br>
				  </div>





		
			
			
			
		</div><!--/.row-->
		
	
        <script>
          
			function submitForm() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("account", "<?php echo $row['account_number'] ?>");
			$("#upload").val("Uploading wait..");
            $.ajax({
              url: "upload.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                
                $('#result').html('<img alt="picture" style="width:100px ;height:100px">');
				$('#result img').attr('src',data);
				$('#fimg').val(data);
				$("#upload").val("Upload");
				alert(data);

				
				
            });
            return false;
        }
    </script>
		
		
<?php include"footer.php" ?>