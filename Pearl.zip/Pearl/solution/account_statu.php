<?php
session_start();
include"connect.php";
				$acct=mysqli_real_escape_string($con,$_POST['id']);
				$query="select* from registeruser  where   account_number='$acct' ";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   
			   if(mysqli_num_rows($resultt)>0){
				   $ree=mysqli_fetch_array($resultt);
				   ?>
	<h4 class="page-header">User Account Status</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account Number</th><th>Name</th><th>Email</th><th>Phone</th><th>Wallet Balance</th><th>Loan Balance</th><th>Last Date of Transaction</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									
						$query="select total  from wallet where account_no='$acct'";
				$ret=mysqli_query($con,$query) or die(mysqli_error($con));
				$num=mysqli_fetch_array($ret);
						
					?>
				<tr>
				<td> <?php echo $ree['account_number'] ?></td><td><?php echo $ree['firstname']." ".$ree['middlename']." ".$ree['lastname'] ?></td><td><?php echo $ree['email_address'] ?></td><td><?php echo $ree['phone'] ?></td><td>₦ <?php echo $num['total'] ?></td>
				<td><?php
				$query="select total, deposit   from loan where paid='0' and rejected='0' and authorize='1' and account_no='".$ree['account_number']."'";
				$ress=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($ress)>0){
				    $es=mysqli_fetch_array($ress);
				    echo "₦ ". ($es['total']-$es['deposit']);
				}
				?></td>
				<td><?php
				$query="select transaction_date as date,packages   from wallet_transact where account_no='".$ree['account_number']."' order by transact_id desc";
				$rese=mysqli_query($con,$query) or die(mysqli_error($con));
			
				if(mysqli_num_rows($rese)>0){
				    $ess=mysqli_fetch_array($rese);
				    echo $ess['packages']." - ".$ess['date'];
				} ?></td>
				</tr>
				
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						<?php
				
				}else{
				   echo "<h5>$acct not in our Database</h5>";
			   }
				?>