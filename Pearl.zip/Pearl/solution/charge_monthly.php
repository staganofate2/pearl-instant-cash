<?php
include"connect.php";

$loan_id=$_POST['loan_id'];
$account=$_POST['account'];
$query="select sum(amount) from loan_repay where paid='0' and loan_id='$loan_id'";
$r=mysqli_query($con,$query) or die(mysqli_error($con));
$d=mysqli_fetch_array($r);
$charge=$d['amount']*0.1;
$query="select charges from loan where loan_id='$loan_id'";
$d=mysqli_query($con,$query) or die(mysqli_error($con));
$s=mysqli_fetch_array($d);
$cha=$s['charges'];
$total=$cha+$charge;
$query="update loan set charges='$total' charge_status='1' where loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
exit();

								?>