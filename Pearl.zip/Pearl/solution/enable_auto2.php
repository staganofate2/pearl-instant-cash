<?php
include"connect.php";
$query="update adminpanel set means1='0' where username='admin'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
exit();
?>