<?php
include"header.php";
$bar="loan";
if(isset($_SESSION['id'])){
	unset($_SESSION['id']);
}
?>



	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Loan Application</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		
                        
						
	<h4 class="page-header">Loan Application Form</h4>
	<?php
				if(isset($_POST['change'])){
					include'../function.php';
					$emp_status =escape($con,$_POST['emp_status']);
					$account =escape($con,$_POST['account_no']);
$emp_sector =escape($con,$_POST['emp_sector']);
$buz_name =escape($con,$_POST['buz_name']);
$buz_address =escape($con,$_POST['buz_address']);
$buz_status =escape($con,$_POST['buz_status']);
$rc_no =escape($con,$_POST['rc_no']);
$net_profit =escape($con,$_POST['net_profit']);
$mon_turnover =escape($con,$_POST['mon_turnover']);
$start_date =escape($con,$_POST['start_date']);
$buz_email =escape($con,$_POST['buz_email']);
$buz_phone =escape($con,$_POST['buz_phone']);
$tax_no =escape($con,$_POST['tax_no']);
$pension_no =escape($con,$_POST['tax_no']);
$occupation =escape($con,$_POST['occupation']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$duration =escape($con,$_POST['duration']);
$percent =escape($con,$_POST['percent']);
$structure =escape($con,$_POST['structure']);
$reason =escape($con,$_POST['reason']);
$total =escape($con,$_POST['total']);
$repay_amount =escape($con,$_POST['repay_amount']);
$ref =rand(100000,999999);
	 $bvn=escape($con,$_POST['bvn']);
$find =escape($con,$_POST['find']);
	$interest=($percent*$amount)/100;			
			$query="insert into loan  (category,total,interest,emp_status,emp_sector,business_name,business_address,biz_status,rc_no,dialy_turnover,monthly_profit,biz_start,biz_email,biz_phone,tax_no,pension,occupation,account_no, amount,loan_duration,interest_rate,repayment_plan,reason_for_loan,repayment_plan_amount,find,regdate,ref_no ) values(
'Office','$total','$interest','$emp_status','$emp_sector','$buz_name','$buz_address','$buz_status','$rc_no','$net_profit','$mon_turnover','$start_date','$buz_email','$buz_phone','$tax_no','$pension_no','$occupation','$account','$amount','$duration','$percent','$structure','$reason','$repay_amount','$find',now(),$ref)";
mysqli_query($con,$query)or die(mysqli_error($con));
$id=mysqli_insert_id($con);
if(isset($_POST['bvn']) ){

	$query="update bank_info set bvn='$bvn' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}


if(isset($_POST[['id'])){
$id =escape($con,$_POST['id']);
$id_no =escape($con,$_POST['id_no']);
$issue_date =escape($con,$_POST['issue_date']);
$exdate =escape($con,$_POST['exdate']);

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["ufile"])) {
$fileName = $_FILES["ufile"]["name"];
 $fileTmpLoc = $_FILES["ufile"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["ufile"]["name"]);
$extension = end($temp);
if ((($_FILES["ufile"]["type"] == "image/gif")
|| ($_FILES["ufile"]["type"] == "image/jpeg")
|| ($_FILES["ufile"]["type"] == "image/jpg")
|| ($_FILES["ufile"]["type"] == "image/pjpeg")
|| ($_FILES["ufile"]["type"] == "image/x-png")
|| ($_FILES["ufile"]["type"] == "image/png"))
&& ($_FILES["ufile"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["ufile"]["error"] > 0) {
        echo "Return Code: " . $_FILES["ufile"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	$db_file_name="userphoto/$db_file_name";
	$db_file_names="../userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
			$query="update registeruser set id_image='$db_file_name' where account_number='$account'";
	mysqli_query($con,$query)or die(mysqli_error($con));
		$query="insert into uploads(purpose,image,regdate,account_no) values('ID image','$db_file_name',now(),'$accout')";
	mysqli_query($con,$query) or die(mysqli_error($con));
			
        }
    }
 else {
    echo "Invalid file";
}
}
$query="update registeruser set id='$id',id_no='$id_no',issue_date='$issue_date',exp_date='$exdate' where account_number='$account'";
mysqli_query($con,$query)or die(mysqli_error($con));
}





		$query="select account_no from paystackloan where account_no='$account' and confirmed='1' and remove='0'";
	$ee=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($ee)<1){
	    $_SESSION['accounts']=$account;
		?>
		<script>window.location="loan_payment.php"</script>
		<?php
		exit();
	}
			






echo "<h3>Loan Application was Successful</h3>";
?>
<center><h4 class="h3-w3l">Thanks for your Interest </h4> <p>Your Wallet will be credited when your Loan is approved</p></center>
				
<?php
				}else{	
				   $query="select* from registeruser where account_number='$account'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
$rows=mysqli_fetch_array($dee); 
				?>
	<form action="" method="POST" enctype="multipart/form-data">
		<div class="row">
		

 <div class="col-lg-12 ">			
				<div class="col-md-3">
			<p>ID image</p>
			<?php
			if($rows['image']==""){
				?>
				<img src="../images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile" id="ufile5" accept="image/*" onchange="loadFile(event)" required="" /><br>
				
				<?php
			}else{
				?>
			<img src="../<?php echo $rows['id_image']?> " alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
			<?php
			}
			?>
			<div id='loaders'></div>
			</div>
			<div class="col-md-5">
			
			<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err'></span>
							</div>
			
				
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br><br>
		<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Employment Status</span>
			<select name="emp_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];}  ?>"><?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];} else{ ?>----EMPLOYMENT STATUS---<?php } ?></option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						
						
</select>	</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Employment Sector</span>
						<input type="text" name="emp_sector" value="<?php if(isset($_POST["emp_sector"])){echo $_POST["emp_sector"];}  ?>"class="form-control" placeholder="EMPLOYMENT SECTOR" ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Name</span>
						<input type="text" name="buz_name"value="<?php if(isset($_POST["buz_name"])){echo $_POST["buz_name"];}  ?>" class="form-control" placeholder="BUSINESS NAME" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Busiess Address</span>
						<input type="text" name="buz_address" value="<?php if(isset($_POST["buz_address"])){echo $_POST["buz_address"];}  ?>"class="form-control" placeholder="BUSINESS ADDRESS" required=""><br>
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Status</span>
						<select name="buz_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}  ?>"><?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}else{  ?>----Business Registration Status---<?php } ?></option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select><br>

				</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">RC Number</span>			
						
						<input type="text" name="rc_no" value="<?php if(isset($_POST["rc_no"])){echo $_POST["rc_no"];}  ?>"class="form-control" placeholder="RC NO" required=""><br>
							</div>
						<?php
			if($rows['id']==""){
				?>
				<select name="id" class="form-control"  required="">
						<option value="">----Select Identification ---</option>
						<option value="National ID">National Id-card </option>
						<option value="Driver License">Driver License</option>
						<option value="Voters Card">Voters Card</option>
						<option value="International Passport">International Passport</option>
						</select>
						<?php
			}else{
				?>
						<input type="text" name="id_no"value="<?php echo $rows['id'] ?>" class="form-control"  readonly title="Means of Identification">
						<?php
			} 
			?>
						</div>
						<div class='form-group'>
						
<span class="badge" style="background-color:#3385FF;">ID Number</span>
<?php
						if($rows['id_no']==""){
				?>
						<input type="text" name="id_no"value="" class="form-control" title="ID NUMBER" >
						<?php
						}else{
							?>
						<input type="text" name="id_no"value="<?php echo $rows['id_no'] ?>" class="form-control" title="ID NUMBER" readonly>	
						<?php
						}
						?>
						</div>
						<?php
						if($rows['id_no']==""){
							?>
							<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Issue Date *</span><br><br>
						 <input type='date' name="isdate"   class="form-control" value="<?php echo $rows ?>" >
 
</div><div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate"   class="form-control">
 
</div>
							
							<?php
							
							
						}else{
						?>
							<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Issue Date *</span><br><br>
						 <input type='date' name="isdate" value="<?php echo $rows['issue_date'] ?>"  class="form-control" readonly>
 
</div><div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate"   value="<?php echo $rows['exp_date'] ?>" class="form-control" readonly>
 
</div>
						<?php	
						}
				?>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Daily Turnover</span>
						<input type="text" name="net_profit" value="<?php if(isset($_POST["net_profit"])){echo $_POST["net_profit"];}  ?>" class="form-control" placeholder="DAILY TURNOVER" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Monthly Turnover</span>
						<input type="text" name="mon_turnover" value="<?php if(isset($_POST["mon_turnover"])){echo $_POST["mon_turnover"];}  ?>"class="form-control" placeholder="NET MONTHLY MONTHLY" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Start date</span>
						<input type="date" name="start_date"value="<?php if(isset($_POST["start_date"])){echo $_POST["start_date"];}  ?>" class="form-control"  ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Email</span>
						<input type="email" name="buz_email"value="<?php if(isset($_POST["buz_email"])){echo $_POST["buz_email"];}  ?>" class="form-control" placeholder="BUSINESS EMAIL" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Phone</span>
						<input type="text" name="buz_phone" value="<?php if(isset($_POST["buz_phone"])){echo $_POST["buz_phone"];}  ?>"class="form-control" placeholder="BUSINESS PHONE" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Tax Number</span>
						<input type="text" name="tax_no"value="<?php if(isset($_POST["tax_no"])){echo $_POST["tax_no"];}  ?>" class="form-control" placeholder="TAX NO" ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Pension Number</span>
						<input type="text" name="pension_no"value="<?php if(isset($_POST["pension_no"])){echo $_POST["pension_no"];}  ?>" class="form-control" placeholder="PENSON NO"><br>
						
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Occupation</span>
						<select name="occupation" class="form-control"  required="">
						<option value="<?php if(isset($_POST["occupation"])){echo $_POST["occupation"];}  ?>"><?php if(isset($_POST["occupation"])){echo $_POST["occupation"];} else{ ?>----Occupation---<?php } ?></option>
						<option value="Student">Student</option>
						<option value="Trader">Trader</option>
						<option value="Technician">Technician</option>
						<option value="Accountants">Accountants</option>
							<option value="Accounting">Accounting</option>
							<option value=" Administrator"> Administrator</option>
							<option value="Administrative Assistants">Administrative Assistants</option>
							<option value="Advertiser">Advertiser</option>
							<option value="Agents">Agents</option>
							<option value="Air Conditioning Installers">Air Conditioning Installers</option>
							<option value="Analysts">Analysts</option>
							<option value="Architech">Architech</option>
							<option value="Artists">Artists</option>
							<option value="Asphalt Paving Machine Operators">Asphalt Paving Machine Operators</option>
                            <option value="Assistants">Assistants</option>
							<option value="Athletes">Athletes</option>
							<option value="Automobile Body Repair">Automobile Body Repair</option>
							<option value="Bank">Bank</option>
							<option value="Bookkeeping">Bookkeeping</option>
							<option value="Cafeteria">Cafeteria</option>
							<option value="Carpenter">Carpenter</option>
							<option value="Certified Nurse Midwives">Certified Nurse Midwives</option>
							<option value="Cleaner">Cleaner</option>
							<option value="Contractor">Contractor</option>
								<option value="Cooks">Cooks</option>
																<option value="Counselor">Counselor</option>
                                <option value="Doctor">Doctor</option>
								<option value="Comedian">Comedian</option>
                            <option value="Drivers">Drivers</option>
							<option value="Economics">Economics</option>
                                <option value=" Electricians"> Electricians</option>
								<option value="Engineer">Engineer</option>
								<option value="Equipment Installers">Equipment Installers</option>
								<option value="Equipment Operators">Equipment Operators</option>
								<option value="Feed Manager">Feed Manager</option>
								<option value="Graphic Designer">Graphic Designer</option>
								<option value="House helper">House helper</option>
                                <option value="librarian">Libralian</option>
                            
                                <option value="Lawyer">Lawyer</option>
                            
                                <option value="Security">Security</option>
                            
                                
                            
                                
                            
                                <option value="Photographer">Photographer</option>
                            
                                <option value="Web Designer">Web Designer</option>
								<option value="Phone Engineer">Phone Engineer</option>
								
								
								<option value="Sales girl">Sales girl</option>
								<option value="Sales boy">Sales boy</option>
								<option value="Radiographers">Radiographers</option>
								
								
								<option value="Spiritualist">Spiritualist</option>
								
								
								<option value="Teachers">Teachers</option>
								
								<option value="Mathematicians">Mathematicians</option>
								
								<option value="Managerial services">Managerial services</option>
								
								<option value="Photographer">Photographer</option>
								<option value="Rental">Rental</option>
								
								
								<option value="Nanny">Nanny</option>
								
								<option value="Mechanics">Mechanics</option>
								
								<option value="Medical Technician">Medical Technician</option>
								
								
								<option value="News Broadcaster">News Broadcaster</option>
								<option value="Painters">Painters</option>
								<option value="Sculptors Arts Producer">Sculptors Arts Producer</option>
								
								
								<option value="Medical laboratory Scientist">Medical laboratory Scientist</option>
								<option value="Nursing, Attendants">Nursing, Attendants</option>
								
								<option value="Social Workers">Social Workers</option>
								
								<option value="Laborer">Laborer</option>
								
								<option value="Marriage Counselor">Marriage Counselor</option>
								<option value="Doctors of Optometry">Doctors of Optometry</option>
								<option value="Public Health">Public Health</option>
								<option value="Elevator Installers">Elevator Installers</option>
								<option value="Repairers">Repairers</option>
								<option value="Epidemiologists">Epidemiologists</option>
								<option value="Physician Assistant">Physician Assistant</option>
								<option value="Firefighters">Firefighters</option>
								<option value="Drying Machine Operators">Drying Machine Operators</option>
								<option value="Health Diagnosing Practitioners">Health Diagnosing Practitioners</option>
								<option value="Tenders">Tenders</option>
								<option value="Helpers">Helpers</option>
								<option value="Plumber">Plumber</option>
								<option value="Pipefitters">Pipefitters</option>
								<option value="Home Appliance Repairers">Home Appliance Repairers</option>
								<option value="Hospital Registerers">Hospital Registerers</option>
								<option value=" Labor Economics Property Manager"> Labor Economics Property Manager</option>
								<option value="Librarians">Librarians</option>
								<option value="Clinical Mental Health Counselor">Clinical Mental Health Counselor</option>
								<option value="Logistics Planner">Logistics Planner</option>
								<option value="Mortician">Mortician</option>
								<option value="Movie Projectionists">Movie Projectionists</option>
								<option value="Nutritionists">Nutritionists</option>
								<option value="Public Health Specialist">Public Health Specialist</option>
								<option value="Pay loader Operator">Pay loader Operator</option>
								<option value="Painter">Painter</option>
								<option value="Makeup Artist">Makeup Artist</option>
								<option value="Pharmacist Technicians">Pharmacist Technicians</option>
								<option value="Pharmacists">Pharmacists</option>
								<option value="Wedding Planner">Wedding Planner</option>
								<option value="Equipment Repairers">Equipment Repairers</option>
								<option value="Physician">Physician</option>
								<option value="Surgeon">Surgeon</option>
								<option value="Marketing">Marketing</option>
								<option value="Weaving">Weaving</option>
								<option value="Fashion/dressmaking">Fashion/dressmaking</option>
								<option value="Property Managers">Property Managers</option>
								<option value="Real Estate developers">Real Estate developers</option>
								<option value="Car Repairers">Car Repairers</option>
								<option value="Real Estate Brokers">Real Estate Brokers</option>
								<option value="Rehabilitation Repairers">Rehabilitation Repairers</option>
								<option value="Sales Agents">Sales Agents</option>
								<option value="Shipping Agents">Shipping Agents</option>
								<option value="Healthcare">Healthcare</option>
								<option value="Software Developers">Software Developers</option>
								<option value="Solar Panel Installation Supervisor">Solar Panel Installation Supervisor</option>
								<option value="Supervisors">Supervisors</option>
								<option value="Gaming Supervisors">Gaming Supervisors</option>
								<option value="Urban Planner">Urban Planner</option>
								<option value="Waiter">Waiter</option>
								<option value="Waitresses">Waitresses</option>
								<option value="Gate man">Gate man</option>
																<option value="Programmer">Programmer</option>
								<option value="Seller">Seller</option>
						
</select>
						</div>
						<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
						
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Amount</span>
						<input type="text" id='amount'name="amount"onkeyup="this.value = numFormat(this.value)" value="<?php if(isset($_POST["amount"])){echo $_POST["amount"];}  ?>" class="form-control" placeholder="ENTER AMOUNT" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Duration</span>
								<select name='duration' class="form-control" id='duration'required="">
								<option   value="<?php if(isset($_POST["duration"])){echo $_POST["duration"];}  ?>"><?php if(isset($_POST["duration"])){echo $_POST["duration"];}else{  ?>Select LOAN Duration <?php } ?></option>
								<option   value="1 Month">1 Month</option>
								<option   value="2 Months">2 Months</option>
								<option   value="3 Months">3 Months</option>
								<option   value="4 Months">4 Months</option>
								<option   value="6 Months">6 Months</option>
								<option   value="12 Months">12 Months</option>
								
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Loan Percentage</span>
								
								<select name="percent" class="form-control" id='percent' required="" onchange="calculate()">
						<option value="<?php if(isset($_POST["percent"])){echo $_POST["percent"];}  ?>"><?php if(isset($_POST["percent"])){echo $_POST["percent"];}else{  ?>----Monthly Investment Interest Rate---<?php } ?></option>
						
						
						<option value="30">30%</option>
						<option value="20">20%</option>
						<option value="10">10%</option>
						
						
</select><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Payback Amount</span>
								<input class="form-control" id='total' name="total" value="<?php if(isset($_POST["total"])){echo $_POST["total"];}  ?>"placeholder='Payback Amount' readonly type="text">
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Repayment Plan Amount</span>
								<input class="form-control" id='repay'required=""  name="repay_amount" value="<?php if(isset($_POST["repay_amount"])){echo $_POST["repay_amount"];}  ?>"placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Payment Structure</span>
								<select name='structure'  class="form-control"required="" >
								<option   value="<?php if(isset($_POST["structure"])){echo $_POST["structure"];}  ?>"><?php if(isset($_POST["structure"])){echo $_POST["structure"];} else{ ?>Select Repayment Structure <?php } ?></option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Reason for Loan</span>
						<textarea  name="reason"value="<?php if(isset($_POST["reason"])){echo $_POST["reason"];}  ?>" class="form-control" placeholder="Reason for loan" required=""></textarea><br>
						</div>
						</div>
				
					
<div class="row">
		

 <div class="col-lg-12 ">					
						<div class="col-md-3">
			
			
			</div>
			<div class="col-md-5">
			
			
		
	
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Account Name </span>
	<input type="text" name="account_name" value=""class="form-control" id='ac_name'readonly><br>
		</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Account Number</span>
						<input type="text" name="account_number" class="form-control" id='ac_number'value="" readonly><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Name</span>
						<input type="text" name="bank" class="form-control" id='bank'value="" readonly><br>
		</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">BVN</span>
					<input type="text" name="bvn" class="form-control" id='bvn'placeholder="BVN NO" required=""><br>
						<textarea  name="find" class="form-control" placeholder="How did you find us" required=""></textarea><br>
				<button class="btn btn-info" id='submit' name="change" type="submit">SUBMIT</button>
				
				</div>
				</form>
                      <?php
				} 
?>				
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "check.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Invalid"){
				document.getElementById("acc_err").innerHTML = ajax.responseText;
			}
			else{
								
				var data=ajax.responseText.split("|");
				var id_image=data[0];
				var id=data[1];
					var id_no=data[2];
				var name=data[4];
				var number=data[5];
				var bank=data[6];
				var bvn=data[7];
				var ow=data[3];
				document.getElementById("id_image").src="../"+id_image;
				document.getElementById("ac_name").value=name;
				document.getElementById("ac_number").value=number;
				document.getElementById("bank").value=bank;
				document.getElementById("bvn").value=bvn;
				document.getElementById("id_no").value=id_no;
				document.getElementById("id").value=id;
				if(ow=="0"){
				document.getElementById("submit").style.display="block";
				document.getElementById("acc_err").innerHTML ="";				
				}else{
					document.getElementById("acc_err").innerHTML ="<p>Please You need to Complete Your ₦ "+ow+" Loan Repayment before applying for another one.</p>";
					document.getElementById("submit").style.display="none";
				}
				
			}
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 function calculate(){
	
	//alert("nofate");
	var amoun=document.getElementById("amount").value;
	var reg=/,/;
	var amount=amoun.replace(reg,""); 
	var duration=document.getElementById("duration").value;
	var percent=document.getElementById("percent").value;
	ajax.open("POST", "calculate.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("total").value=ajax.responseText;
				
		}
	}
	ajax.send("amount="+amount+"&duration="+duration+"&percent="+percent);
	 
 
 }
 function reject(id,account){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reject.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			 
			window.location="index.php";
			
		}
		}
	}
	ajax.send("id="+id+"&account="+account);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
<?php include"footer.php" ?>