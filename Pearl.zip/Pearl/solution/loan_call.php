<?php
include"connect.php";
$title=$_POST['title'];
$phone=$_POST['phone'];
$message=$_POST['message'];
$account=$_POST['account'];

$query="insert into loan_call (title,phone,message,account_no,sent_date) values('$title','$phone','$message','$account',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
echo"done";
exit();

								?>