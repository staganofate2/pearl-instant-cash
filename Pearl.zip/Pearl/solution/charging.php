<?php
include"header.php";
$bar="addbankinfo";

?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Loan Repayment</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Loan Repayment</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header">Loan Repayment</h4>
	<?php
				if(isset($_POST['submit'])){
				
			$account=$_POST['account'];	
				
				$loan_id=$_POST['loan_id'];
$loan_repay_id=$_POST['loan_repay_id'];
$amount=$_POST['amount'];				
 $action=$_POST['action'];
$amount=str_replace(",","",$amount);
$amountt=$amount."00";
$ref =rand(100000000,999999999);
$query="select email_address as email,phone, firstname,lastname from registeruser where account_number='$account'";
$x=mysqli_query($con,$query) or die(mysqli_error($con));
$re=mysqli_fetch_array($x);
$firstname=$re['firstname'];
$lastname=$re['lastname'];
$email=$re['email'];
$phone=$re['phone'];
$query="select total  from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));

	$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']-$amount;
	if($amounts>=0){
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

if($action=="single"){
$query="select deposit,total,charges  from loan where account_no='$account' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);

 $am=$ers['deposit']+$amount;
 $total=$ers['total'];
$deposit=$ers['deposit'];
$balance=$am-($total+$ers['charges']);
$query="update loan set deposit='$am' where account_no='$account' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update loan_repay set paid='1',paid_date=now() where account_no='$account' and loan_repay_id='$loan_repay_id'";
mysqli_query($con,$query) or die(mysqli_error($con));

if($am >= ($total+$ers['charges'])){
     $query="update loan set paid='1' where   account_no='$account' and loan_id='$loan_id' "; 
      mysqli_query($con,$query) or die(mysqli_error($con));
  }
}else{
	$query="select deposit,total,charges from loan where account_no='$account' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
$am=$ers['deposit']+$amount;
$total=$ers['total'];
$balance=$am-($total+$ers['charges']);
$query="update loan set deposit='$am' where account_no='$account' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select loan_id  from loan where account_no='$account' and loan_id='$loan_id'";
$rowse=mysqli_query($con,$query) or die(mysqli_error($con));
while($erc=mysqli_fetch_array($rowse)){
	$query="update loan_repay set paid='1', paid_date=now() where account_no='$account' and loan_id='".$erc['loan_id']."' and paid='0'";
mysqli_query($con,$query) or die(mysqli_error($con));
if($am >= ($total+$ers['charges'])){
     $query="update loan set paid='1' where   account_no='$account' and loan_id='$loan_id' "; 
      mysqli_query($con,$query) or die(mysqli_error($con));
  }
}
}
	
	



$description="$amount was debited  from your Wallet for $total Loan Repayment";
$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','$account','','$amount','$balance','$ref','$description',now(),'$loan_id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $total Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Loan','$account','','$amount','$amounts','$ref','$description',now(),'$loan_id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$loan_id','','$account','','$amount','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$message="$amount was debited  from your Wallet for $total Loan Repayment";
$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
  $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
echo"<h3>Loan Payment was Successful</h3><p class='error'>Please don't Resend  Again</p>";




}else{




	if($action=="single"){							

$query="select r.email_address as email,r.firstname,r.lastname,c.deposit as deposit,r.phone as phone,c.total as total from  registeruser r ,loan c where  r.account_number='$account' and c.loan_id='$loan_id'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 $row=mysqli_fetch_array($se);
		 
  $phone=$row['phone'];
 $total=$row['total'];
 $deposit=$row['deposit'];
  $firstname=$row['firstname'];
  $lastname=$row['lastname'];
  
  $email=$row['email'];
  $query="select authorization_code from paystackcard where account_no='$account' and active='1' and authorization_code !=''";
  
  $see=mysqli_query($con,$query) or die(mysqli_error($con));
  $de=mysqli_fetch_array($see);
  
 $authorization_code=$de['authorization_code'];
 
  
//Set other parameters as keys in the $postdata array
$postdata =  array("authorization_code"=>"$authorization_code", "email"=>"$email", "amount"=>"$amountt");
   
$url = "https://api.paystack.co/transaction/charge_authorization";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  
   //print_r($x);
 
if($x['data']['status']=="success"){
	
$query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet+$amount;
  
  $query="update wallet set total='$balance' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="insert into deposit  (ref_no,amount,total,method,confirmed,confirm,authorize,regdate,account_no,category) values('$ref','$amount','$amount','Instant','1','1','1','".date("Y-m-d")."','$account','Wallet')";
mysqli_query($con,$query)or die(mysqli_error($con));
$id=mysqli_insert_id($con);

$description="$amount was Credited to your Wallet Account  for Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$account','$amount','','$balance','$ref','$description','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$id','','$account','$amount','','$balance','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet-$amount;
    $query="update wallet set total='$balance' where account_no='$account'";
  mysqli_query($con,$query) or die(mysqli_error($con));

 $query="select deposit,charges,total  from loan where account_no='$account' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
$am=$ers['deposit']+$amount;
$total=$ers['total'];
$balances=$am-($total+$ers['charges']);
$query="update loan set deposit='$am' where account_no='$account' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));

    $query="update loan_repay set paid='1',paid_date=now() where loan_repay_id='$loan_repay_id' and account_no='$account' and loan_id='$loan_id' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
   $message="Your $total Loan  repayment . N $amount has been Credited into Your Wallet for today Loan Repayment. ".date("Y-m-d");
  





   
   $message2="Your $total Loan  repayment reminder. N $amount has been Debited from Your Wallet for today Loan Repayment. ".date("Y-m-d");
  
  
  if($am>=($total+$ers['charges'])){
      $query="update loan set paid='1',active='1' where   account_no='$account' and loan_id='$loan_id' "; 
      mysqli_query($con,$query) or die(mysqli_error($con));
  }
  

 
  $description="$amount was debited  from your Wallet for $total Loan Repayment";
 
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$account','','$amount','$balance','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$loan_id','','$account','','$amount','$balance','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','$account','','$amount','$balances','$ref','$description',now(),'$loan_id')";
mysqli_query($con,$query) or die(mysqli_error($con));


$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
  
    
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 //echo "done";

   
   
   
  
  
  
  $messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message2</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
  
	$message=urlencode($message2);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
}else{
    
      echo "<h3>".$x['data']['gateway_response']."</h3>";
      $query="update loan set charge_date=now() where loan_id='$loan_id'";

//mysqli_query($con,$query) or die(mysqli_error($con));
  
}
}
  
   
	 
	 
 }
	}else{
		
		$query="select r.email_address as email,r.firstname,r.lastname,c.deposit as deposit,r.phone as phone,c.total as total from  registeruser r ,loan c where  r.account_number='$account' and c.loan_id='$loan_id'";
 $se=mysqli_query($con,$query) or die(mysqli_error($con));
  if(mysqli_num_rows($se)>0){
	 $row=mysqli_fetch_array($se);
	$phone=$row['phone'];	 
  $firstname=$row['firstname'];
  $lastname=$row['lastname'];
 $total=$row['total'];
 $deposit=$row['deposit'];
 
  
  $email=$row['email'];
  $query="select authorization_code from paystackcard where account_no='$account' and active='1' and authorization_code !=''";
  
  $see=mysqli_query($con,$query) or die(mysqli_error($con));
  $de=mysqli_fetch_array($see);
  
 $authorization_code=$de['authorization_code'];
 
  
//Set other parameters as keys in the $postdata array
$postdata =  array("authorization_code"=>"$authorization_code", "email"=>"$email", "amount"=>"$amountt");
   
$url = "https://api.paystack.co/transaction/charge_authorization";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  
  //print_r($x);
  
if($x['data']['status']=="success"){
$query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet+$amount;
   $query="update wallet set total='$balance' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
    $query="insert into deposit  (ref_no,amount,total,method,confirmed,confirm,authorize,regdate,account_no,category) values('$ref','$amount','$amount','Instant','1','1','1','".date("Y-m-d")."','$account','Wallet')";
mysqli_query($con,$query)or die(mysqli_error($con));
$id=mysqli_insert_id($con);

$description="$amount was Credited to your Wallet Account  for Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$account','$amount','','$balance','$ref','$description','".date("Y-m-d")."')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$id','','$account','$amount','','$balance','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select total from wallet where account_no='$account'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  $balance=$wallet-$amount;
    $query="update wallet set total='$balance' where account_no='$account'";
  mysqli_query($con,$query) or die(mysqli_error($con));


$query="select deposit, charges,total  from loan where account_no='$account' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
$am=$ers['deposit']+$amount;
$total=$ers['total'];
$balances=$am-($total+$ers['charges']);
$query="update loan set deposit='$am' where account_no='$account' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select loan_id  from loan where account_no='$account' and loan_id='$loan_id'";
$rowse=mysqli_query($con,$query) or die(mysqli_error($con));
while($erc=mysqli_fetch_array($rowse)){
	$query="update loan_repay set paid='1',paid_date=now() where account_no='$account' and loan_id='".$erc['loan_id']."' and paid='0'";
mysqli_query($con,$query) or die(mysqli_error($con));

  
  
  $query="update loan set deposit='$am' where   account_no='$account' and loan_id='$loan_id' ";
  mysqli_query($con,$query) or die(mysqli_error($con));
  
 

$query="insert into deposit  (ref_no,amount,total,method,confirmed,confirm,authorize,regdate,account_no,category) values('$ref','$amount','$amount','Instant','1','1','1',now(),'$account','Wallet')";
mysqli_query($con,$query)or die(mysqli_error($con));


$description="$amount was Credited to your Wallet Account  for Loan Repayment";


  
   $message="Your $total Loan  repayment reminder. N $amount has been Debited from Your Wallet for today Loan Repayment. ".date("Y-m-d");
  
  
  if($am>=($total+$ers['charges'])){
      $query="update loan set paid='1',active='1' where   account_no='$account' and loan_id='$loan_id' "; 
      mysqli_query($con,$query) or die(mysqli_error($con));
  }
 

 
  $description="$amount was debited  from your Wallet for $total Loan Repayment";
  $message2="$amount was debited  from your Wallet for $total Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$account','','$amount','$balance','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$loan_id','','$account','','$amount','$balance','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','$account','','$amount','$balances','$ref','$description',now(),'$loan_id')";
mysqli_query($con,$query) or die(mysqli_error($con));


$query="select refer_id from refer_user  where account_no='$account' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
  
 
  
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	 //echo "done";

   
   
   
   
  
  
  $messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message2</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
  
	$message=urlencode($message2);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
}
}else{
    
      echo "<h3>".$x['data']['gateway_response']."</h3>";
      $query="update loan set charge_date=now() where loan_id='$loan_id'";

//mysqli_query($con,$query) or die(mysqli_error($con));
  
}
  
   
	 
	 
 }
		
		
	}



}
}
echo"<h4><a href='unpaid_loan.php'>Back</a></h4>";
}else{
		
		
								
?>
	<form role="form" action="" method="POST">
				

						
						
						
					<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Amount</span>
							<?php
							if(isset($_GET['action']) && $_GET['action']=="single"){
								$id=$_GET['id'];
								$amount=$_GET['amount'];
								$account=$_GET['account'];
								$loan_id=$_GET['loan_id'];
								?>
								<input  value="<?php echo $account ?>"  name="account" type="hidden" >
								<input  value="single"  name="action" type="hidden" >
								<input  value="<?php echo $loan_id ?>"  name="loan_id" type="hidden" >
								<input  value="<?php echo $id ?>"  name="loan_repay_id" type="hidden" >
								<input class="form-control" value="<?php echo $amount ?>" name="amount" type="text" readonly>
								<?php
							}
							elseif(isset($_GET['action']) && $_GET['action']=="All"){
								$id=$_GET['id'];
								$amount=$_GET['amount'];
								$loan_id=$_GET['loan_id'];
								$account=$_GET['account'];
								?>
								<input  value="All"  name="action" type="hidden" >
								<input  value="<?php echo $loan_id ?>"  name="loan_id" type="hidden" >
								<input  value="<?php echo $id ?>"  name="loan_repay_id" type="hidden" >
								<input  value="<?php echo $account ?>"  name="account" type="hidden" >
								<input class="form-control" value="<?php echo $amount ?>" name="amount" type="text" readonly>
								<?php
							}
							
							?>
								
							</div>
							
							<button class="btn btn-info" name="submit" type="submit">Continue</button>
				
				</form>

						
			
						
				<?php
				}
				?>
			
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>