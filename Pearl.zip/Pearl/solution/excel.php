<?php
include"connect.php";
				$account=$_GET['account'];
						$limit=$_GET['limit'];
						$querys="select (@row_number :=@row_number +1) as num,transaction_date,refno,description,debit,credit,balance,remark,packages from statements,(select @row_number:=0) as t where account_no='$account' $limit";
						//$q="select email_address from registeruser where account_number='$account'";
						//$w=mysqli_query($con,$q)or die(mysqli_error($con));
						//$c=mysqli_fetch_array($w);
					
						

   
			
				$query="select firstname,lastname,middlename  from registeruser  where account_number='$account'";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				
				    $w=mysqli_fetch_array($res4); 
				    $file_name=$w['firstname']." ".$w['lastname']." ".$w['middlename']."account statement.xls";
					//header("Content-Type: application/xls"); 
					header("Content-Type: application/vnd.ms-excel");
	header("Content-Disposition: attachment; filename=$file_name");  
	header("Pragma: no-cache"); 
	header("Expires: 0");
				
			$messages='<table><thead>
                                        <tr>
										<th>SN</th>
										<th>Date</th>
										<th>Packages</th>
                                            <th>Ref No</th>
                                            <th>Description</th>
											<th>Debit</th>
											<th>Credit</th>
											<th>Balance</th>
											<th>Remark</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>';
									
	@$myquery1=mysqli_query($con,$querys) or die(mysqli_error($con));
		while(@$row2 = mysqli_fetch_object($myquery1)){
			
                                       $messages.=" <tr><td>". @$row2->num ."</td><td>". @$row2->transaction_date ."</td>                                    <td>". @$row2->packages ."</td>
											 <td>". @$row2->refno ."</td>
                                            <td>". @$row2->description ."</td>
                                            <td>". @$row2->debit ."</td>
											<td>". @$row2->credit ."</td>
											<td>". @$row2->balance ."</td>
											 <td>". @$row2->remark ."</td>
                                            
		</tr> ";
		  }  
                                        
                                $messages.="</tbody></table>";
				
		echo $messages;		
				
			
  ?>