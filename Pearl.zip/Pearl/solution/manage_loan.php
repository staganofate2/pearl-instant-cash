<?php
include"header.php";
?>

    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css " />
    <script src="js/jquery-1.9.1.min.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
    <!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
    
    <style type="text/css" rel="stylesheet">
        body {
            background: #fff;
        }
        #container {
            width: 940px;
            margin: 0 auto;
        }
        @media only screen and (max-width: 768px) {
            #container {
                width: 90%;
                margin: 0 auto;
            }
        }
        
    </style>
<style>
  /* Style the buttons that are used to open and close the accordion panel */
.accordions {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    text-align: left;
    border: none;
    outline: none;
    transition: 0.4s;
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.active, .accordion:hover {
    background-color: #ccc;
}

/* Style the accordion panel. Note: hidden by default */
.panels {
    padding: 0 18px;
    background-color: white;
    display: none;
    overflow: hidden;
} 
.hide{
	display:none;
}
.show{
	display:block;
}
.event {
	background:green;
	color:white;
}
 </style>
    <div id="container">

       
        <hr>
        <br/>
        <br/>
		<h3><a href='dashboard.php'>Back to Dashboard</a><span style='margin-left:20%;margin-right:3%'><?php echo date("Y F d  D, h :i s") ?></span><button style='margin-right:5%;background:green;color:white'onclick='refresh()'>Refresh</button><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></h3>
        <br/>
		<table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table> 
        <!--Horizontal Tab-->
        <div id="parentHorizontalTab">
            <ul class="resp-tabs-list hor_1">
			<?php $query="select* from loan_reminder where status='0' and datediff('".date("Y-m-d")."',remind_date)>-1";
				$p=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($p)>0){
				echo " <li > <span class='event'>".mysqli_num_rows($p)." Activities</span></li>";
				}else{
					echo "<li>Activities</li>";
				}?>
                <li>Unpaid Loan Profile</li>
                <li>Paid Loan Profile</li>
                <li>Loan Statement</li>
				<li>Account Status</li>
				<li>Tickets</li>
				<li>Suspend account</li>
					<li>Phone Code</li></li>
            </ul>
            <div class="resp-tabs-container hor_1">
                <div>
                    <p>
                        <!--vertical Tabs-->

                        <div id="ChildVerticalTab_1">
                            <ul class="resp-tabs-list ver_1">
							<?php $query="select* from loan_reminder where status='0' and  datediff('".date("Y-m-d")."',remind_date)>-1";
				$p=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($p)>0){
				echo " <li ><span class='event'> ".mysqli_num_rows($p)." Reminders</span></li>";
				}else{
					echo "<li>Reminders</li>";
				}?>
                              
                                <li>Messages</li>
                                <li>Calls</li>
                                <li>Emails</li>
								<li>Reset Password</li>
                            </ul>
                            <div class="resp-tabs-container ver_1">
							<!-- Reminders -->
                                <div>
                                    <h3><a href='reminder.php'>View Reminders</a></h3>
								 <div class="panel-heading">
                             <strong>Loan Reminders</strong>
							 
                        </div>
								<h4><button onclick="opennew('reminder_result','but1')" id='but1'>Add New</button></h4>
								<div id='reminder_result' class='hide'>
								
								<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Title</span>
						<input type="text" name="r_title" id='r_title'value=""class="form-control" placeholder="Title" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Message</span>
						<textarea  name="r_message" id='r_message'value="" class="form-control"  ></textarea>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Remind Date</span>
						<input type="date" name="r_date" id='r_date'value="" class="form-control" placeholder="2019/12/30" required=""><br>
							</div>
						<div class='form-group'>
						<button id='r_submit' onclick='save_reminder()'>Save</button>
						</div>
									
								
								</div>
								<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
<tr><th>Title</th><th>Message</th><th>Remind Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_reminder where status='0' order by loan_reminder_id limit 5";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['title']  ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['remind_date'] ?></td><td><?php if($ree['status']=='0' && $ree['remind_date']<date("Y-m-d")){?><button onclick="remove_reminder('<?php echo $ree['loan_reminder_id'] ?>')">Remove Reminder</button>
				<?php
				}
				?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div><!-- end of panel-body -->
                                   
							   </div>
								<!--end  of Reminders -->
								
								<!-- Messages -->
                                <div>
                                    <h3><a href='messages.php'>View Messages</a></h3>
								 <div class="panel-heading">
                             <strong>Loan Messages</strong>
							 
                        </div><h4><button onclick="opennew('message_result','but2')" id='but2'>Add New</button></h4>
								<div id='message_result' class='hide'>
								    
								    	<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Account Number</span>
						<input type="text" name="m_account_no" id='m_account_no'value="" class="form-control" onblur="check_phone('m_phone','m_submit','Incorrect_m',this.value)" placeholder="Account Number" required=""><br>
							<div id='Incorrect_m'></div>
							</div>
								<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Phone</span>
						<input type="text" name="m_phone" id='m_phone'value=""class="form-control" placeholder="Phone" required=""><br>
							</div>
								<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Title</span>
						<input type="text" name="m_title" id='m_title'value=""class="form-control" placeholder="Title" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Message</span>
						<textarea  name="m_message" id='m_message'value="" class="form-control"  ></textarea>
							</div>
					
						<div class='form-group'>
						<button id='m_submit' onclick='save_message()'>Send</button>
						</div>
									
								</div>
                                    
<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
<tr><th>Account Number</th><th>Phone</th><th>Title</th><th>Message</th><th>Sent Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_message where sent_date='".date('Y-m-d')."' order by loan_message_id limit 2";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['phone'] ?></td><td> <?php echo $ree['title'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                    

									</div>
								<!--  end of Messages -->
								
								<!-- Calls -->
                                <div>
                                    <h3><a href='calls.php'>View Calls</a></h3>
								 <div class="panel-heading">
                             <strong>Loan Calls</strong>
							 
                        </div>
						<h4><button onclick="opennew('call_result','but3')" id='but3'>Add New</button></h4>
								<div id='call_result' class='hide'>
								<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Title</span>
						<input type="text" name="c_title" id='c_title'value=""class="form-control" placeholder="Title" required=""><br>
							</div>
								<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Phone</span>
						<input type="text" name="c_phone" id='c_phone'value=""class="form-control" placeholder="Phone" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Discussion</span>
						<textarea  name="c_message" id='c_message'value="" class="form-control"  ></textarea>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Account Number</span>
						<input type="text" name="c_account_no" id='c_account_no'value="" class="form-control" onblur="check_phone('c_phone','c_submit','Incorrect_c',this.value)" placeholder="Account Number" required=""><br>
							<div id='Incorrect_c'></div>
							
							</div>
							
						<div class='form-group'>
						<button id='c_submit' onclick='save_call()'>Save</button>
						</div>
								
							
								</div>
						 
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
<tr><th>Account Number</th><th>Phone</th><th>Discussion</th><th>Call Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_call order by loan_call_id desc limit 2";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['phone'] ?></td><td><?php echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                                      </div>
								<!-- end of calls  -->
								
								<!-- Emails -->
								
                                <div>
                                    <h3><a href='emails.php'>View Emails</a></h3>
								<div class="panel-heading">
                             <strong>Loan Emails</strong>
							 
                        </div>
								<h4><button onclick="opennew('email_result','but4')" id='but4'>Add New</button></h4>
								<div id='email_result' class='hide'>
								
								
								<div id="imageresult2"></div>
	<button id="statu_img_but2">Add images</button>
							
							<form  action="" method="post" enctype="multipart/form-data" class="f12">
            
                	<input type='hidden' name='post3' id='post3' value=''>
                	<input type='hidden' name='id' id='id2' value=''>
            
            <div class="f1-steps">
               
            </div>

            

            <field/set style="display: block;">
               
                
							
								<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Email Address</span>
						<input type="text" name="e_email" id='e_email'value=""class="form-control" placeholder="Email" required=""><br>
							</div>
							<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Subject</span>
						<input type="text" name="e_subbject" id='e_subbject'value=""class="form-control" placeholder="Subject" required=""><br>
							</div>
							
                            
               

                <div class="form-group ">
                    <label class="control-label">Message</label>
                    <textarea style="display: none;" name="message" id="description" placeholder="Message" rows="0" class="form-control"></textarea><div class="note-editor"><div class="note-dropzone"><div class="note-dropzone-message"></div></div><div class="note-dialog"><div class="note-image-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" aria-hidden="true" tabindex="-1">×</button><h4 class="modal-title">Insert Image</h4></div><form class="note-modal-form"><div class="modal-body"><div class="form-group row-fluid note-group-select-from-files"><label>Select from files</label><input class="note-image-input" name="files" accept="image/*" multiple="multiple" type="file"></div><div class="form-group row-fluid"><label>Image URL</label><input class="note-image-url form-control span12" type="text"></div></div><div class="modal-footer"><button href="#" class="btn btn-primary note-image-btn disabled" disabled="disabled">Insert Image</button></div></form></div></div></div><div class="note-link-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" aria-hidden="true" tabindex="-1">×</button><h4 class="modal-title">Insert Link</h4></div><form class="note-modal-form"><div class="modal-body"><div class="form-group row-fluid"><label>Text to display</label><input class="note-link-text form-control span12" type="text"></div><div class="form-group row-fluid"><label>To what URL should this link go?</label><input class="note-link-url form-control span12" type="text"></div><div class="checkbox"><label><input checked="checked" type="checkbox"> Open in new window</label></div></div><div class="modal-footer"><button href="#" class="btn btn-primary note-link-btn disabled" disabled="disabled">Insert Link</button></div></form></div></div></div><div class="note-help-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><form class="note-modal-form"><div class="modal-body"><a class="modal-close pull-right" aria-hidden="true" tabindex="-1">Close</a><div class="title">Keyboard shortcuts</div><div class="note-shortcut-row row"><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Action</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Z</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Undo</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + Z</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Redo</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + ]</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Indent</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + [</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Outdent</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + ENTER</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Insert Horizontal Rule</div></div></div><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Text formatting</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + B</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Bold</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + I</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Italic</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + U</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Underline</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + \</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Remove Font Style</div></div></div></div><div class="note-shortcut-row row"><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Document Style</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM0</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Normal</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM1</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 1</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM2</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 2</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM3</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 3</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM4</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 4</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM5</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 5</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM6</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 6</div></div></div><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Paragraph formatting</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + L</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align left</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + E</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align center</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + R</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align right</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + J</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Justify full</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + NUM7</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Ordered list</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + NUM8</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Unordered list</div></div></div></div><p class="text-center"><a href="https://summernote.org/" target="_blank">Summernote 0.6.1</a> · <a href="https://github.com/summernote/summernote" target="_blank">Project</a> · <a href="https://github.com/summernote/summernote/issues" target="_blank">Issues</a></p></div></form></div></div></div></div><div class="note-handle"><div class="note-control-selection"><div class="note-control-selection-bg"></div><div class="note-control-holder note-control-nw"></div><div class="note-control-holder note-control-ne"></div><div class="note-control-holder note-control-sw"></div><div class="note-control-sizing note-control-se"></div><div class="note-control-selection-info"></div></div></div><div class="note-popover"><div class="note-link-popover popover bottom in" style="display: none;"><div class="arrow"></div><div class="popover-content"><a href="http://www.google.com/" target="_blank">www.google.com</a>&nbsp;&nbsp;<div class="note-insert btn-group"><button data-original-title="Edit (CTRL+K)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showLinkDialog" data-hide="true" tabindex="-1"><i class="fa fa-edit"></i></button><button data-original-title="Unlink" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="unlink" tabindex="-1"><i class="fa fa-unlink"></i></button></div></div></div><div class="note-image-popover popover bottom in" style="display: none;"><div class="arrow"></div><div class="popover-content"><div class="btn-group"><button data-original-title="Resize Full" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="1" tabindex="-1"><span class="note-fontsize-10">100%</span></button><button data-original-title="Resize Half" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="0.5" tabindex="-1"><span class="note-fontsize-10">50%</span></button><button data-original-title="Resize Quarter" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="0.25" tabindex="-1"><span class="note-fontsize-10">25%</span></button></div><div class="btn-group"><button data-original-title="Float Left" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="left" tabindex="-1"><i class="fa fa-align-left"></i></button><button data-original-title="Float Right" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="right" tabindex="-1"><i class="fa fa-align-right"></i></button><button data-original-title="Float None" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="none" tabindex="-1"><i class="fa fa-align-justify"></i></button></div><div class="btn-group"><button data-original-title="Shape: Rounded" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-rounded" tabindex="-1"><i class="fa fa-square"></i></button><button data-original-title="Shape: Circle" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-circle" tabindex="-1"><i class="fa fa-circle-o"></i></button><button data-original-title="Shape: Thumbnail" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-thumbnail" tabindex="-1"><i class="fa fa-picture-o"></i></button><button data-original-title="Shape: None" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" tabindex="-1"><i class="fa fa-times"></i></button></div><div class="btn-group"><button data-original-title="Remove Image" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="removeMedia" data-value="none" tabindex="-1"><i class="fa fa-trash-o"></i></button></div></div></div></div><div class="note-toolbar btn-toolbar"><div class="note-style btn-group"><button data-original-title="Style" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-magic"></i> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="formatBlock" href="#" data-value="p">Normal</a></li><li><a data-event="formatBlock" href="#" data-value="blockquote"><blockquote>Quote</blockquote></a></li><li><a data-event="formatBlock" href="#" data-value="pre">Code</a></li><li><a data-event="formatBlock" href="#" data-value="h1"><h1>Header 1</h1></a></li><li><a data-event="formatBlock" href="#" data-value="h2"><h2>Header 2</h2></a></li><li><a data-event="formatBlock" href="#" data-value="h3"><h3>Header 3</h3></a></li><li><a data-event="formatBlock" href="#" data-value="h4"><h4>Header 4</h4></a></li><li><a data-event="formatBlock" href="#" data-value="h5"><h5>Header 5</h5></a></li><li><a data-event="formatBlock" href="#" data-value="h6"><h6>Header 6</h6></a></li></ul></div><div class="note-font btn-group"><button data-original-title="Bold (CTRL+B)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="bold" tabindex="-1"><i class="fa fa-bold"></i></button><button data-original-title="Italic (CTRL+I)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="italic" tabindex="-1"><i class="fa fa-italic"></i></button><button data-original-title="Underline (CTRL+U)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="underline" tabindex="-1"><i class="fa fa-underline"></i></button><button data-original-title="Remove Font Style (CTRL+\)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="removeFormat" tabindex="-1"><i class="fa fa-eraser"></i></button></div><div class="note-fontname btn-group"><button data-original-title="Font Family" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><span class="note-current-fontname">Helvetica Neue</span> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="fontName" href="#" data-value="Arial" style="font-family:'Arial'"><i class="fa fa-check"></i> Arial</a></li><li><a data-event="fontName" href="#" data-value="Arial Black" style="font-family:'Arial Black'"><i class="fa fa-check"></i> Arial Black</a></li><li><a data-event="fontName" href="#" data-value="Comic Sans MS" style="font-family:'Comic Sans MS'"><i class="fa fa-check"></i> Comic Sans MS</a></li><li><a data-event="fontName" href="#" data-value="Courier New" style="font-family:'Courier New'"><i class="fa fa-check"></i> Courier New</a></li><li><a data-event="fontName" href="#" data-value="Impact" style="font-family:'Impact'"><i class="fa fa-check"></i> Impact</a></li><li><a data-event="fontName" href="#" data-value="Tahoma" style="font-family:'Tahoma'"><i class="fa fa-check"></i> Tahoma</a></li><li><a data-event="fontName" href="#" data-value="Times New Roman" style="font-family:'Times New Roman'"><i class="fa fa-check"></i> Times New Roman</a></li><li><a data-event="fontName" href="#" data-value="Verdana" style="font-family:'Verdana'"><i class="fa fa-check"></i> Verdana</a></li></ul></div><div class="note-color btn-group"><button data-original-title="Recent Color" type="button" class="btn btn-default btn-sm btn-small note-recent-color" title="" data-event="color" data-value="{&quot;backColor&quot;:&quot;yellow&quot;}" tabindex="-1"><i class="fa fa-font" style="color:black;background-color:yellow;"></i></button><button data-original-title="More Color" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"> <span class="caret"></span></button><ul class="dropdown-menu"><li><div class="btn-group"><div class="note-palette-title">Background Color</div><div class="note-color-reset" data-event="backColor" data-value="inherit" title="Transparent">Set transparent</div><div class="note-color-palette" data-target-event="backColor"><div class="note-color-row"><button data-original-title="#000000" type="button" class="note-color-btn" style="background-color:#000000;" data-event="backColor" data-value="#000000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#424242" type="button" class="note-color-btn" style="background-color:#424242;" data-event="backColor" data-value="#424242" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#636363" type="button" class="note-color-btn" style="background-color:#636363;" data-event="backColor" data-value="#636363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C9C94" type="button" class="note-color-btn" style="background-color:#9C9C94;" data-event="backColor" data-value="#9C9C94" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEC6CE" type="button" class="note-color-btn" style="background-color:#CEC6CE;" data-event="backColor" data-value="#CEC6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFEFEF" type="button" class="note-color-btn" style="background-color:#EFEFEF;" data-event="backColor" data-value="#EFEFEF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7F7F7" type="button" class="note-color-btn" style="background-color:#F7F7F7;" data-event="backColor" data-value="#F7F7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFFFF" type="button" class="note-color-btn" style="background-color:#FFFFFF;" data-event="backColor" data-value="#FFFFFF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#FF0000" type="button" class="note-color-btn" style="background-color:#FF0000;" data-event="backColor" data-value="#FF0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF9C00" type="button" class="note-color-btn" style="background-color:#FF9C00;" data-event="backColor" data-value="#FF9C00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFF00" type="button" class="note-color-btn" style="background-color:#FFFF00;" data-event="backColor" data-value="#FFFF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FF00" type="button" class="note-color-btn" style="background-color:#00FF00;" data-event="backColor" data-value="#00FF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FFFF" type="button" class="note-color-btn" style="background-color:#00FFFF;" data-event="backColor" data-value="#00FFFF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#0000FF" type="button" class="note-color-btn" style="background-color:#0000FF;" data-event="backColor" data-value="#0000FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C00FF" type="button" class="note-color-btn" style="background-color:#9C00FF;" data-event="backColor" data-value="#9C00FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF00FF" type="button" class="note-color-btn" style="background-color:#FF00FF;" data-event="backColor" data-value="#FF00FF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#F7C6CE" type="button" class="note-color-btn" style="background-color:#F7C6CE;" data-event="backColor" data-value="#F7C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE7CE" type="button" class="note-color-btn" style="background-color:#FFE7CE;" data-event="backColor" data-value="#FFE7CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFEFC6" type="button" class="note-color-btn" style="background-color:#FFEFC6;" data-event="backColor" data-value="#FFEFC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6EFD6" type="button" class="note-color-btn" style="background-color:#D6EFD6;" data-event="backColor" data-value="#D6EFD6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEDEE7" type="button" class="note-color-btn" style="background-color:#CEDEE7;" data-event="backColor" data-value="#CEDEE7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEE7F7" type="button" class="note-color-btn" style="background-color:#CEE7F7;" data-event="backColor" data-value="#CEE7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6D6E7" type="button" class="note-color-btn" style="background-color:#D6D6E7;" data-event="backColor" data-value="#D6D6E7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E7D6DE" type="button" class="note-color-btn" style="background-color:#E7D6DE;" data-event="backColor" data-value="#E7D6DE" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E79C9C" type="button" class="note-color-btn" style="background-color:#E79C9C;" data-event="backColor" data-value="#E79C9C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFC69C" type="button" class="note-color-btn" style="background-color:#FFC69C;" data-event="backColor" data-value="#FFC69C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE79C" type="button" class="note-color-btn" style="background-color:#FFE79C;" data-event="backColor" data-value="#FFE79C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5D6A5" type="button" class="note-color-btn" style="background-color:#B5D6A5;" data-event="backColor" data-value="#B5D6A5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A5C6CE" type="button" class="note-color-btn" style="background-color:#A5C6CE;" data-event="backColor" data-value="#A5C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9CC6EF" type="button" class="note-color-btn" style="background-color:#9CC6EF;" data-event="backColor" data-value="#9CC6EF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5A5D6" type="button" class="note-color-btn" style="background-color:#B5A5D6;" data-event="backColor" data-value="#B5A5D6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6A5BD" type="button" class="note-color-btn" style="background-color:#D6A5BD;" data-event="backColor" data-value="#D6A5BD" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E76363" type="button" class="note-color-btn" style="background-color:#E76363;" data-event="backColor" data-value="#E76363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7AD6B" type="button" class="note-color-btn" style="background-color:#F7AD6B;" data-event="backColor" data-value="#F7AD6B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFD663" type="button" class="note-color-btn" style="background-color:#FFD663;" data-event="backColor" data-value="#FFD663" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#94BD7B" type="button" class="note-color-btn" style="background-color:#94BD7B;" data-event="backColor" data-value="#94BD7B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#73A5AD" type="button" class="note-color-btn" style="background-color:#73A5AD;" data-event="backColor" data-value="#73A5AD" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BADDE" type="button" class="note-color-btn" style="background-color:#6BADDE;" data-event="backColor" data-value="#6BADDE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#8C7BC6" type="button" class="note-color-btn" style="background-color:#8C7BC6;" data-event="backColor" data-value="#8C7BC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#C67BA5" type="button" class="note-color-btn" style="background-color:#C67BA5;" data-event="backColor" data-value="#C67BA5" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#CE0000" type="button" class="note-color-btn" style="background-color:#CE0000;" data-event="backColor" data-value="#CE0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E79439" type="button" class="note-color-btn" style="background-color:#E79439;" data-event="backColor" data-value="#E79439" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFC631" type="button" class="note-color-btn" style="background-color:#EFC631;" data-event="backColor" data-value="#EFC631" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BA54A" type="button" class="note-color-btn" style="background-color:#6BA54A;" data-event="backColor" data-value="#6BA54A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A7B8C" type="button" class="note-color-btn" style="background-color:#4A7B8C;" data-event="backColor" data-value="#4A7B8C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#3984C6" type="button" class="note-color-btn" style="background-color:#3984C6;" data-event="backColor" data-value="#3984C6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#634AA5" type="button" class="note-color-btn" style="background-color:#634AA5;" data-event="backColor" data-value="#634AA5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A54A7B" type="button" class="note-color-btn" style="background-color:#A54A7B;" data-event="backColor" data-value="#A54A7B" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#9C0000" type="button" class="note-color-btn" style="background-color:#9C0000;" data-event="backColor" data-value="#9C0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B56308" type="button" class="note-color-btn" style="background-color:#B56308;" data-event="backColor" data-value="#B56308" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#BD9400" type="button" class="note-color-btn" style="background-color:#BD9400;" data-event="backColor" data-value="#BD9400" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#397B21" type="button" class="note-color-btn" style="background-color:#397B21;" data-event="backColor" data-value="#397B21" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#104A5A" type="button" class="note-color-btn" style="background-color:#104A5A;" data-event="backColor" data-value="#104A5A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#085294" type="button" class="note-color-btn" style="background-color:#085294;" data-event="backColor" data-value="#085294" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#311873" type="button" class="note-color-btn" style="background-color:#311873;" data-event="backColor" data-value="#311873" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#731842" type="button" class="note-color-btn" style="background-color:#731842;" data-event="backColor" data-value="#731842" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#630000" type="button" class="note-color-btn" style="background-color:#630000;" data-event="backColor" data-value="#630000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#7B3900" type="button" class="note-color-btn" style="background-color:#7B3900;" data-event="backColor" data-value="#7B3900" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#846300" type="button" class="note-color-btn" style="background-color:#846300;" data-event="backColor" data-value="#846300" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#295218" type="button" class="note-color-btn" style="background-color:#295218;" data-event="backColor" data-value="#295218" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#083139" type="button" class="note-color-btn" style="background-color:#083139;" data-event="backColor" data-value="#083139" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#003163" type="button" class="note-color-btn" style="background-color:#003163;" data-event="backColor" data-value="#003163" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#21104A" type="button" class="note-color-btn" style="background-color:#21104A;" data-event="backColor" data-value="#21104A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A1031" type="button" class="note-color-btn" style="background-color:#4A1031;" data-event="backColor" data-value="#4A1031" title="" data-toggle="button" tabindex="-1"></button></div></div></div><div class="btn-group"><div class="note-palette-title">Foreground Color</div><div class="note-color-reset" data-event="foreColor" data-value="inherit" title="Reset">Reset to default</div><div class="note-color-palette" data-target-event="foreColor"><div class="note-color-row"><button data-original-title="#000000" type="button" class="note-color-btn" style="background-color:#000000;" data-event="foreColor" data-value="#000000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#424242" type="button" class="note-color-btn" style="background-color:#424242;" data-event="foreColor" data-value="#424242" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#636363" type="button" class="note-color-btn" style="background-color:#636363;" data-event="foreColor" data-value="#636363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C9C94" type="button" class="note-color-btn" style="background-color:#9C9C94;" data-event="foreColor" data-value="#9C9C94" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEC6CE" type="button" class="note-color-btn" style="background-color:#CEC6CE;" data-event="foreColor" data-value="#CEC6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFEFEF" type="button" class="note-color-btn" style="background-color:#EFEFEF;" data-event="foreColor" data-value="#EFEFEF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7F7F7" type="button" class="note-color-btn" style="background-color:#F7F7F7;" data-event="foreColor" data-value="#F7F7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFFFF" type="button" class="note-color-btn" style="background-color:#FFFFFF;" data-event="foreColor" data-value="#FFFFFF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#FF0000" type="button" class="note-color-btn" style="background-color:#FF0000;" data-event="foreColor" data-value="#FF0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF9C00" type="button" class="note-color-btn" style="background-color:#FF9C00;" data-event="foreColor" data-value="#FF9C00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFF00" type="button" class="note-color-btn" style="background-color:#FFFF00;" data-event="foreColor" data-value="#FFFF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FF00" type="button" class="note-color-btn" style="background-color:#00FF00;" data-event="foreColor" data-value="#00FF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FFFF" type="button" class="note-color-btn" style="background-color:#00FFFF;" data-event="foreColor" data-value="#00FFFF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#0000FF" type="button" class="note-color-btn" style="background-color:#0000FF;" data-event="foreColor" data-value="#0000FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C00FF" type="button" class="note-color-btn" style="background-color:#9C00FF;" data-event="foreColor" data-value="#9C00FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF00FF" type="button" class="note-color-btn" style="background-color:#FF00FF;" data-event="foreColor" data-value="#FF00FF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#F7C6CE" type="button" class="note-color-btn" style="background-color:#F7C6CE;" data-event="foreColor" data-value="#F7C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE7CE" type="button" class="note-color-btn" style="background-color:#FFE7CE;" data-event="foreColor" data-value="#FFE7CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFEFC6" type="button" class="note-color-btn" style="background-color:#FFEFC6;" data-event="foreColor" data-value="#FFEFC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6EFD6" type="button" class="note-color-btn" style="background-color:#D6EFD6;" data-event="foreColor" data-value="#D6EFD6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEDEE7" type="button" class="note-color-btn" style="background-color:#CEDEE7;" data-event="foreColor" data-value="#CEDEE7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEE7F7" type="button" class="note-color-btn" style="background-color:#CEE7F7;" data-event="foreColor" data-value="#CEE7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6D6E7" type="button" class="note-color-btn" style="background-color:#D6D6E7;" data-event="foreColor" data-value="#D6D6E7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E7D6DE" type="button" class="note-color-btn" style="background-color:#E7D6DE;" data-event="foreColor" data-value="#E7D6DE" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E79C9C" type="button" class="note-color-btn" style="background-color:#E79C9C;" data-event="foreColor" data-value="#E79C9C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFC69C" type="button" class="note-color-btn" style="background-color:#FFC69C;" data-event="foreColor" data-value="#FFC69C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE79C" type="button" class="note-color-btn" style="background-color:#FFE79C;" data-event="foreColor" data-value="#FFE79C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5D6A5" type="button" class="note-color-btn" style="background-color:#B5D6A5;" data-event="foreColor" data-value="#B5D6A5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A5C6CE" type="button" class="note-color-btn" style="background-color:#A5C6CE;" data-event="foreColor" data-value="#A5C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9CC6EF" type="button" class="note-color-btn" style="background-color:#9CC6EF;" data-event="foreColor" data-value="#9CC6EF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5A5D6" type="button" class="note-color-btn" style="background-color:#B5A5D6;" data-event="foreColor" data-value="#B5A5D6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6A5BD" type="button" class="note-color-btn" style="background-color:#D6A5BD;" data-event="foreColor" data-value="#D6A5BD" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E76363" type="button" class="note-color-btn" style="background-color:#E76363;" data-event="foreColor" data-value="#E76363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7AD6B" type="button" class="note-color-btn" style="background-color:#F7AD6B;" data-event="foreColor" data-value="#F7AD6B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFD663" type="button" class="note-color-btn" style="background-color:#FFD663;" data-event="foreColor" data-value="#FFD663" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#94BD7B" type="button" class="note-color-btn" style="background-color:#94BD7B;" data-event="foreColor" data-value="#94BD7B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#73A5AD" type="button" class="note-color-btn" style="background-color:#73A5AD;" data-event="foreColor" data-value="#73A5AD" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BADDE" type="button" class="note-color-btn" style="background-color:#6BADDE;" data-event="foreColor" data-value="#6BADDE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#8C7BC6" type="button" class="note-color-btn" style="background-color:#8C7BC6;" data-event="foreColor" data-value="#8C7BC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#C67BA5" type="button" class="note-color-btn" style="background-color:#C67BA5;" data-event="foreColor" data-value="#C67BA5" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#CE0000" type="button" class="note-color-btn" style="background-color:#CE0000;" data-event="foreColor" data-value="#CE0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E79439" type="button" class="note-color-btn" style="background-color:#E79439;" data-event="foreColor" data-value="#E79439" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFC631" type="button" class="note-color-btn" style="background-color:#EFC631;" data-event="foreColor" data-value="#EFC631" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BA54A" type="button" class="note-color-btn" style="background-color:#6BA54A;" data-event="foreColor" data-value="#6BA54A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A7B8C" type="button" class="note-color-btn" style="background-color:#4A7B8C;" data-event="foreColor" data-value="#4A7B8C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#3984C6" type="button" class="note-color-btn" style="background-color:#3984C6;" data-event="foreColor" data-value="#3984C6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#634AA5" type="button" class="note-color-btn" style="background-color:#634AA5;" data-event="foreColor" data-value="#634AA5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A54A7B" type="button" class="note-color-btn" style="background-color:#A54A7B;" data-event="foreColor" data-value="#A54A7B" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#9C0000" type="button" class="note-color-btn" style="background-color:#9C0000;" data-event="foreColor" data-value="#9C0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B56308" type="button" class="note-color-btn" style="background-color:#B56308;" data-event="foreColor" data-value="#B56308" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#BD9400" type="button" class="note-color-btn" style="background-color:#BD9400;" data-event="foreColor" data-value="#BD9400" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#397B21" type="button" class="note-color-btn" style="background-color:#397B21;" data-event="foreColor" data-value="#397B21" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#104A5A" type="button" class="note-color-btn" style="background-color:#104A5A;" data-event="foreColor" data-value="#104A5A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#085294" type="button" class="note-color-btn" style="background-color:#085294;" data-event="foreColor" data-value="#085294" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#311873" type="button" class="note-color-btn" style="background-color:#311873;" data-event="foreColor" data-value="#311873" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#731842" type="button" class="note-color-btn" style="background-color:#731842;" data-event="foreColor" data-value="#731842" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#630000" type="button" class="note-color-btn" style="background-color:#630000;" data-event="foreColor" data-value="#630000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#7B3900" type="button" class="note-color-btn" style="background-color:#7B3900;" data-event="foreColor" data-value="#7B3900" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#846300" type="button" class="note-color-btn" style="background-color:#846300;" data-event="foreColor" data-value="#846300" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#295218" type="button" class="note-color-btn" style="background-color:#295218;" data-event="foreColor" data-value="#295218" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#083139" type="button" class="note-color-btn" style="background-color:#083139;" data-event="foreColor" data-value="#083139" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#003163" type="button" class="note-color-btn" style="background-color:#003163;" data-event="foreColor" data-value="#003163" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#21104A" type="button" class="note-color-btn" style="background-color:#21104A;" data-event="foreColor" data-value="#21104A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A1031" type="button" class="note-color-btn" style="background-color:#4A1031;" data-event="foreColor" data-value="#4A1031" title="" data-toggle="button" tabindex="-1"></button></div></div></div></li></ul></div><div class="note-para btn-group"><button data-original-title="Unordered list (CTRL+SHIFT+NUM7)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertUnorderedList" tabindex="-1"><i class="fa fa-list-ul"></i></button><button data-original-title="Ordered list (CTRL+SHIFT+NUM8)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertOrderedList" tabindex="-1"><i class="fa fa-list-ol"></i></button><button data-original-title="Paragraph" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-align-left"></i> <span class="caret"></span></button><div class="dropdown-menu"><div class="note-align btn-group"><button data-original-title="Align left (CTRL+SHIFT+L)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyLeft" tabindex="-1"><i class="fa fa-align-left"></i></button><button data-original-title="Align center (CTRL+SHIFT+E)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyCenter" tabindex="-1"><i class="fa fa-align-center"></i></button><button data-original-title="Align right (CTRL+SHIFT+R)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyRight" tabindex="-1"><i class="fa fa-align-right"></i></button><button data-original-title="Justify full (CTRL+SHIFT+J)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyFull" tabindex="-1"><i class="fa fa-align-justify"></i></button></div><div class="note-list btn-group"><button data-original-title="Indent (CTRL+])" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="indent" tabindex="-1"><i class="fa fa-indent"></i></button><button data-original-title="Outdent (CTRL+[)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="outdent" tabindex="-1"><i class="fa fa-outdent"></i></button></div></div></div><div class="note-height btn-group"><button data-original-title="Line Height" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-text-height"></i> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="lineHeight" href="#" data-value="1"><i class="fa fa-check"></i> 1.0</a></li><li><a data-event="lineHeight" href="#" data-value="1.2"><i class="fa fa-check"></i> 1.2</a></li><li><a data-event="lineHeight" href="#" data-value="1.4"><i class="fa fa-check"></i> 1.4</a></li><li><a data-event="lineHeight" href="#" data-value="1.5"><i class="fa fa-check"></i> 1.5</a></li><li><a data-event="lineHeight" href="#" data-value="1.6"><i class="fa fa-check"></i> 1.6</a></li><li><a data-event="lineHeight" href="#" data-value="1.8"><i class="fa fa-check"></i> 1.8</a></li><li><a data-event="lineHeight" href="#" data-value="2"><i class="fa fa-check"></i> 2.0</a></li><li><a data-event="lineHeight" href="#" data-value="3"><i class="fa fa-check"></i> 3.0</a></li></ul></div><div class="note-table btn-group"><button data-original-title="Table" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-table"></i> <span class="caret"></span></button><ul class="note-table dropdown-menu"><div class="note-dimension-picker"><div style="width: 10em; height: 10em;" class="note-dimension-picker-mousecatcher" data-event="insertTable" data-value="1x1"></div><div class="note-dimension-picker-highlighted"></div><div class="note-dimension-picker-unhighlighted"></div></div><div class="note-dimension-display"> 1 x 1 </div></ul></div><div class="note-insert btn-group"><button data-original-title="Link (CTRL+K)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showLinkDialog" data-hide="true" tabindex="-1"><i class="fa fa-link"></i></button><!--<button data-original-title="Picture" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showImageDialog" data-hide="true" tabindex="-1"><i class="fa fa-picture-o"></i></button>--><button data-original-title="Insert Horizontal Rule (CTRL+ENTER)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertHorizontalRule" tabindex="-1"><i class="fa fa-minus"></i></button></div><div class="note-view btn-group"><button data-original-title="Full Screen" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="fullscreen" tabindex="-1"><i class="fa fa-arrows-alt"></i></button><button data-original-title="Code View" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="codeview" tabindex="-1"><i class="fa fa-code"></i></button></div><div class="note-help btn-group"><button data-original-title="Help" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showHelpDialog" data-hide="true" tabindex="-1"><i class="fa fa-question"></i></button></div></div><textarea class="note-codable"></textarea><div data-placeholder="Description" class="note-editable" contenteditable="true" id='data'></div></div>
                    <span class="help-block desc-error"></span>
                </div>

               
            <div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Account Number</span>
						<input type="text" name="e_account_no" id='e_account_no'value="" class="form-control" onblur="check_email('e_email','e_submit','Incorrect_e',this.value)" placeholder="Account Number" required=""><br>
							<div id='Incorrect_e'></div>
							</div>
                

                <br class="clear clearfix"><br>

                <div class="f1-buttons">
                    
                    
                    <input type="button" name="submit"  class="btn btn-lg btn-info btn-uga btn-submit" id='e_submit' onclick='save_email()' value="Send Email">
                </div>
				
            
        </form>
								
								
								
							
								
								</div>
                                   <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
<tr><th>Account Number</th><th>Subject</th><th>Message</th><th>Sent Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan_email order by loan_email_id desc limit 2";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['subject'] ?></td><td><?php if($ree['image']!=""){
				 echo "<img src='../".$ree['image']."' width='100%'><br>" ;} echo $ree['message'] ?></td><td><?php echo $ree['sent_date'] ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        
                                    
                                </div>     </div>
								<!-- end of Emails -->
								
								
								
								
								<!-- reset pass -->
								
                                <div>
                                   
								<div class="panel-heading">
                             <strong>Reset Password</strong>
							 
                        </div>
								<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number,Phone or Email</span>
								<input class="form-control" id='reset' style='width:60%'name="account_no2" onblur="reset_status()"placeholder='Enter Account Number, Email or Phone' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
							<div id='reset_result'></div>
							<br>
								
                                     </div>
								<!-- end of reset password -->
								
								
							
                            </div> <!--  end of resp-tabs-container ver_1 -->
                        </div><!-- end of ChildVerticalTab_1-->
                    </p> 
                    <p>Activities</p>
                </div>
				<!--  -->
								
				<!--Profile  -->
                <div>
				 <div class="panel-heading">
                             <strong>Unpaid Loan Profile</strong>
							 
                        </div>
                    <div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='profile'  style='width:60%' name="account_no2" onblur="update_profile()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
							<div id='profile_result'></div>
                    <br>
                    <p>Unpaid Loan Profile</p>
                </div>
				<!-- end of Profile -->
								
								
									<!--Profile  -->
                <div>
				 <div class="panel-heading">
                             <strong>Paid Loan Profile</strong>
							 
                        </div>
                    <div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='profile2'  style='width:60%' name="account_no2" onblur="update_profiles()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err3'></span>
							</div>
							<div id='profile_result2'></div>
                    <br>
                    <p>Paid Loan Profile</p>
                </div>
				<!-- end of Profile -->
								
								<!-- Loan  form -->
                <div>
				 <div class="panel-heading">
                             <strong>Loan Statement</strong>
							 
                        </div>
					<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='statement' style='width:60%'name="account_no2" onblur="update_statement()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
							<div id='statement_result'></div>
							<br>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
				<!-- end of form  -->
				
				
				 <div>
				 <div class="panel-heading">
                             <strong>Account Status</strong>
							 
                        </div>
					<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='status' style='width:60%'name="account_no2" onblur="update_status()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err2'></span>
							</div>
							<div id='account_result'></div>
							<br>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
								
				<!--Tickets -->
				 <div>
				 <div class="panel-heading">
                             <strong>Tickets</strong>
							 
                        </div>
					
							<div id='ticket_result' class='hide'>
							<div id="imageresult"></div>
	<button id="statu_img_but">Add images</button>
							
							<form  action="" method="post" enctype="multipart/form-data" class="f12">
            
                	<input type='hidden' name='post' id='post' value=''>
                	<input type='hidden' name='id' id='id' value=''>
            
            <div class="f1-steps">
               
            </div>

            

            <field/set style="display: block;">
               
                
							<div class="form-group">
							  <label class="control-label">Subject</label>
								<input class="form-control" placeholder="SUBJECT"id='titles' name="subject" type="text"readonly >
							</div>
							
							
                            
               

                <div class="form-group ">
                    <label class="control-label">Reply</label>
                    <textarea style="display: none;" name="message" id="descriptions" placeholder="Message" rows="0" class="form-control"></textarea><div class="note-editor"><div class="note-dropzone"><div class="note-dropzone-message"></div></div><div class="note-dialog"><div class="note-image-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" aria-hidden="true" tabindex="-1">×</button><h4 class="modal-title">Insert Image</h4></div><form class="note-modal-form"><div class="modal-body"><div class="form-group row-fluid note-group-select-from-files"><label>Select from files</label><input class="note-image-input" name="files" accept="image/*" multiple="multiple" type="file"></div><div class="form-group row-fluid"><label>Image URL</label><input class="note-image-url form-control span12" type="text"></div></div><div class="modal-footer"><button href="#" class="btn btn-primary note-image-btn disabled" disabled="disabled">Insert Image</button></div></form></div></div></div><div class="note-link-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" aria-hidden="true" tabindex="-1">×</button><h4 class="modal-title">Insert Link</h4></div><form class="note-modal-form"><div class="modal-body"><div class="form-group row-fluid"><label>Text to display</label><input class="note-link-text form-control span12" type="text"></div><div class="form-group row-fluid"><label>To what URL should this link go?</label><input class="note-link-url form-control span12" type="text"></div><div class="checkbox"><label><input checked="checked" type="checkbox"> Open in new window</label></div></div><div class="modal-footer"><button href="#" class="btn btn-primary note-link-btn disabled" disabled="disabled">Insert Link</button></div></form></div></div></div><div class="note-help-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><form class="note-modal-form"><div class="modal-body"><a class="modal-close pull-right" aria-hidden="true" tabindex="-1">Close</a><div class="title">Keyboard shortcuts</div><div class="note-shortcut-row row"><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Action</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Z</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Undo</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + Z</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Redo</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + ]</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Indent</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + [</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Outdent</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + ENTER</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Insert Horizontal Rule</div></div></div><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Text formatting</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + B</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Bold</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + I</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Italic</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + U</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Underline</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + \</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Remove Font Style</div></div></div></div><div class="note-shortcut-row row"><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Document Style</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM0</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Normal</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM1</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 1</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM2</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 2</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM3</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 3</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM4</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 4</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM5</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 5</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM6</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 6</div></div></div><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Paragraph formatting</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + L</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align left</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + E</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align center</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + R</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align right</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + J</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Justify full</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + NUM7</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Ordered list</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + NUM8</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Unordered list</div></div></div></div><p class="text-center"><a href="https://summernote.org/" target="_blank">Summernote 0.6.1</a> · <a href="https://github.com/summernote/summernote" target="_blank">Project</a> · <a href="https://github.com/summernote/summernote/issues" target="_blank">Issues</a></p></div></form></div></div></div></div><div class="note-handle"><div class="note-control-selection"><div class="note-control-selection-bg"></div><div class="note-control-holder note-control-nw"></div><div class="note-control-holder note-control-ne"></div><div class="note-control-holder note-control-sw"></div><div class="note-control-sizing note-control-se"></div><div class="note-control-selection-info"></div></div></div><div class="note-popover"><div class="note-link-popover popover bottom in" style="display: none;"><div class="arrow"></div><div class="popover-content"><a href="http://www.google.com/" target="_blank">www.google.com</a>&nbsp;&nbsp;<div class="note-insert btn-group"><button data-original-title="Edit (CTRL+K)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showLinkDialog" data-hide="true" tabindex="-1"><i class="fa fa-edit"></i></button><button data-original-title="Unlink" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="unlink" tabindex="-1"><i class="fa fa-unlink"></i></button></div></div></div><div class="note-image-popover popover bottom in" style="display: none;"><div class="arrow"></div><div class="popover-content"><div class="btn-group"><button data-original-title="Resize Full" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="1" tabindex="-1"><span class="note-fontsize-10">100%</span></button><button data-original-title="Resize Half" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="0.5" tabindex="-1"><span class="note-fontsize-10">50%</span></button><button data-original-title="Resize Quarter" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="0.25" tabindex="-1"><span class="note-fontsize-10">25%</span></button></div><div class="btn-group"><button data-original-title="Float Left" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="left" tabindex="-1"><i class="fa fa-align-left"></i></button><button data-original-title="Float Right" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="right" tabindex="-1"><i class="fa fa-align-right"></i></button><button data-original-title="Float None" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="none" tabindex="-1"><i class="fa fa-align-justify"></i></button></div><div class="btn-group"><button data-original-title="Shape: Rounded" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-rounded" tabindex="-1"><i class="fa fa-square"></i></button><button data-original-title="Shape: Circle" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-circle" tabindex="-1"><i class="fa fa-circle-o"></i></button><button data-original-title="Shape: Thumbnail" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-thumbnail" tabindex="-1"><i class="fa fa-picture-o"></i></button><button data-original-title="Shape: None" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" tabindex="-1"><i class="fa fa-times"></i></button></div><div class="btn-group"><button data-original-title="Remove Image" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="removeMedia" data-value="none" tabindex="-1"><i class="fa fa-trash-o"></i></button></div></div></div></div><div class="note-toolbar btn-toolbar"><div class="note-style btn-group"><button data-original-title="Style" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-magic"></i> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="formatBlock" href="#" data-value="p">Normal</a></li><li><a data-event="formatBlock" href="#" data-value="blockquote"><blockquote>Quote</blockquote></a></li><li><a data-event="formatBlock" href="#" data-value="pre">Code</a></li><li><a data-event="formatBlock" href="#" data-value="h1"><h1>Header 1</h1></a></li><li><a data-event="formatBlock" href="#" data-value="h2"><h2>Header 2</h2></a></li><li><a data-event="formatBlock" href="#" data-value="h3"><h3>Header 3</h3></a></li><li><a data-event="formatBlock" href="#" data-value="h4"><h4>Header 4</h4></a></li><li><a data-event="formatBlock" href="#" data-value="h5"><h5>Header 5</h5></a></li><li><a data-event="formatBlock" href="#" data-value="h6"><h6>Header 6</h6></a></li></ul></div><div class="note-font btn-group"><button data-original-title="Bold (CTRL+B)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="bold" tabindex="-1"><i class="fa fa-bold"></i></button><button data-original-title="Italic (CTRL+I)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="italic" tabindex="-1"><i class="fa fa-italic"></i></button><button data-original-title="Underline (CTRL+U)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="underline" tabindex="-1"><i class="fa fa-underline"></i></button><button data-original-title="Remove Font Style (CTRL+\)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="removeFormat" tabindex="-1"><i class="fa fa-eraser"></i></button></div><div class="note-fontname btn-group"><button data-original-title="Font Family" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><span class="note-current-fontname">Helvetica Neue</span> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="fontName" href="#" data-value="Arial" style="font-family:'Arial'"><i class="fa fa-check"></i> Arial</a></li><li><a data-event="fontName" href="#" data-value="Arial Black" style="font-family:'Arial Black'"><i class="fa fa-check"></i> Arial Black</a></li><li><a data-event="fontName" href="#" data-value="Comic Sans MS" style="font-family:'Comic Sans MS'"><i class="fa fa-check"></i> Comic Sans MS</a></li><li><a data-event="fontName" href="#" data-value="Courier New" style="font-family:'Courier New'"><i class="fa fa-check"></i> Courier New</a></li><li><a data-event="fontName" href="#" data-value="Impact" style="font-family:'Impact'"><i class="fa fa-check"></i> Impact</a></li><li><a data-event="fontName" href="#" data-value="Tahoma" style="font-family:'Tahoma'"><i class="fa fa-check"></i> Tahoma</a></li><li><a data-event="fontName" href="#" data-value="Times New Roman" style="font-family:'Times New Roman'"><i class="fa fa-check"></i> Times New Roman</a></li><li><a data-event="fontName" href="#" data-value="Verdana" style="font-family:'Verdana'"><i class="fa fa-check"></i> Verdana</a></li></ul></div><div class="note-color btn-group"><button data-original-title="Recent Color" type="button" class="btn btn-default btn-sm btn-small note-recent-color" title="" data-event="color" data-value="{&quot;backColor&quot;:&quot;yellow&quot;}" tabindex="-1"><i class="fa fa-font" style="color:black;background-color:yellow;"></i></button><button data-original-title="More Color" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"> <span class="caret"></span></button><ul class="dropdown-menu"><li><div class="btn-group"><div class="note-palette-title">Background Color</div><div class="note-color-reset" data-event="backColor" data-value="inherit" title="Transparent">Set transparent</div><div class="note-color-palette" data-target-event="backColor"><div class="note-color-row"><button data-original-title="#000000" type="button" class="note-color-btn" style="background-color:#000000;" data-event="backColor" data-value="#000000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#424242" type="button" class="note-color-btn" style="background-color:#424242;" data-event="backColor" data-value="#424242" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#636363" type="button" class="note-color-btn" style="background-color:#636363;" data-event="backColor" data-value="#636363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C9C94" type="button" class="note-color-btn" style="background-color:#9C9C94;" data-event="backColor" data-value="#9C9C94" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEC6CE" type="button" class="note-color-btn" style="background-color:#CEC6CE;" data-event="backColor" data-value="#CEC6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFEFEF" type="button" class="note-color-btn" style="background-color:#EFEFEF;" data-event="backColor" data-value="#EFEFEF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7F7F7" type="button" class="note-color-btn" style="background-color:#F7F7F7;" data-event="backColor" data-value="#F7F7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFFFF" type="button" class="note-color-btn" style="background-color:#FFFFFF;" data-event="backColor" data-value="#FFFFFF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#FF0000" type="button" class="note-color-btn" style="background-color:#FF0000;" data-event="backColor" data-value="#FF0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF9C00" type="button" class="note-color-btn" style="background-color:#FF9C00;" data-event="backColor" data-value="#FF9C00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFF00" type="button" class="note-color-btn" style="background-color:#FFFF00;" data-event="backColor" data-value="#FFFF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FF00" type="button" class="note-color-btn" style="background-color:#00FF00;" data-event="backColor" data-value="#00FF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FFFF" type="button" class="note-color-btn" style="background-color:#00FFFF;" data-event="backColor" data-value="#00FFFF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#0000FF" type="button" class="note-color-btn" style="background-color:#0000FF;" data-event="backColor" data-value="#0000FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C00FF" type="button" class="note-color-btn" style="background-color:#9C00FF;" data-event="backColor" data-value="#9C00FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF00FF" type="button" class="note-color-btn" style="background-color:#FF00FF;" data-event="backColor" data-value="#FF00FF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#F7C6CE" type="button" class="note-color-btn" style="background-color:#F7C6CE;" data-event="backColor" data-value="#F7C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE7CE" type="button" class="note-color-btn" style="background-color:#FFE7CE;" data-event="backColor" data-value="#FFE7CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFEFC6" type="button" class="note-color-btn" style="background-color:#FFEFC6;" data-event="backColor" data-value="#FFEFC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6EFD6" type="button" class="note-color-btn" style="background-color:#D6EFD6;" data-event="backColor" data-value="#D6EFD6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEDEE7" type="button" class="note-color-btn" style="background-color:#CEDEE7;" data-event="backColor" data-value="#CEDEE7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEE7F7" type="button" class="note-color-btn" style="background-color:#CEE7F7;" data-event="backColor" data-value="#CEE7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6D6E7" type="button" class="note-color-btn" style="background-color:#D6D6E7;" data-event="backColor" data-value="#D6D6E7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E7D6DE" type="button" class="note-color-btn" style="background-color:#E7D6DE;" data-event="backColor" data-value="#E7D6DE" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E79C9C" type="button" class="note-color-btn" style="background-color:#E79C9C;" data-event="backColor" data-value="#E79C9C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFC69C" type="button" class="note-color-btn" style="background-color:#FFC69C;" data-event="backColor" data-value="#FFC69C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE79C" type="button" class="note-color-btn" style="background-color:#FFE79C;" data-event="backColor" data-value="#FFE79C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5D6A5" type="button" class="note-color-btn" style="background-color:#B5D6A5;" data-event="backColor" data-value="#B5D6A5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A5C6CE" type="button" class="note-color-btn" style="background-color:#A5C6CE;" data-event="backColor" data-value="#A5C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9CC6EF" type="button" class="note-color-btn" style="background-color:#9CC6EF;" data-event="backColor" data-value="#9CC6EF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5A5D6" type="button" class="note-color-btn" style="background-color:#B5A5D6;" data-event="backColor" data-value="#B5A5D6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6A5BD" type="button" class="note-color-btn" style="background-color:#D6A5BD;" data-event="backColor" data-value="#D6A5BD" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E76363" type="button" class="note-color-btn" style="background-color:#E76363;" data-event="backColor" data-value="#E76363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7AD6B" type="button" class="note-color-btn" style="background-color:#F7AD6B;" data-event="backColor" data-value="#F7AD6B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFD663" type="button" class="note-color-btn" style="background-color:#FFD663;" data-event="backColor" data-value="#FFD663" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#94BD7B" type="button" class="note-color-btn" style="background-color:#94BD7B;" data-event="backColor" data-value="#94BD7B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#73A5AD" type="button" class="note-color-btn" style="background-color:#73A5AD;" data-event="backColor" data-value="#73A5AD" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BADDE" type="button" class="note-color-btn" style="background-color:#6BADDE;" data-event="backColor" data-value="#6BADDE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#8C7BC6" type="button" class="note-color-btn" style="background-color:#8C7BC6;" data-event="backColor" data-value="#8C7BC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#C67BA5" type="button" class="note-color-btn" style="background-color:#C67BA5;" data-event="backColor" data-value="#C67BA5" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#CE0000" type="button" class="note-color-btn" style="background-color:#CE0000;" data-event="backColor" data-value="#CE0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E79439" type="button" class="note-color-btn" style="background-color:#E79439;" data-event="backColor" data-value="#E79439" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFC631" type="button" class="note-color-btn" style="background-color:#EFC631;" data-event="backColor" data-value="#EFC631" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BA54A" type="button" class="note-color-btn" style="background-color:#6BA54A;" data-event="backColor" data-value="#6BA54A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A7B8C" type="button" class="note-color-btn" style="background-color:#4A7B8C;" data-event="backColor" data-value="#4A7B8C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#3984C6" type="button" class="note-color-btn" style="background-color:#3984C6;" data-event="backColor" data-value="#3984C6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#634AA5" type="button" class="note-color-btn" style="background-color:#634AA5;" data-event="backColor" data-value="#634AA5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A54A7B" type="button" class="note-color-btn" style="background-color:#A54A7B;" data-event="backColor" data-value="#A54A7B" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#9C0000" type="button" class="note-color-btn" style="background-color:#9C0000;" data-event="backColor" data-value="#9C0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B56308" type="button" class="note-color-btn" style="background-color:#B56308;" data-event="backColor" data-value="#B56308" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#BD9400" type="button" class="note-color-btn" style="background-color:#BD9400;" data-event="backColor" data-value="#BD9400" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#397B21" type="button" class="note-color-btn" style="background-color:#397B21;" data-event="backColor" data-value="#397B21" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#104A5A" type="button" class="note-color-btn" style="background-color:#104A5A;" data-event="backColor" data-value="#104A5A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#085294" type="button" class="note-color-btn" style="background-color:#085294;" data-event="backColor" data-value="#085294" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#311873" type="button" class="note-color-btn" style="background-color:#311873;" data-event="backColor" data-value="#311873" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#731842" type="button" class="note-color-btn" style="background-color:#731842;" data-event="backColor" data-value="#731842" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#630000" type="button" class="note-color-btn" style="background-color:#630000;" data-event="backColor" data-value="#630000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#7B3900" type="button" class="note-color-btn" style="background-color:#7B3900;" data-event="backColor" data-value="#7B3900" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#846300" type="button" class="note-color-btn" style="background-color:#846300;" data-event="backColor" data-value="#846300" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#295218" type="button" class="note-color-btn" style="background-color:#295218;" data-event="backColor" data-value="#295218" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#083139" type="button" class="note-color-btn" style="background-color:#083139;" data-event="backColor" data-value="#083139" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#003163" type="button" class="note-color-btn" style="background-color:#003163;" data-event="backColor" data-value="#003163" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#21104A" type="button" class="note-color-btn" style="background-color:#21104A;" data-event="backColor" data-value="#21104A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A1031" type="button" class="note-color-btn" style="background-color:#4A1031;" data-event="backColor" data-value="#4A1031" title="" data-toggle="button" tabindex="-1"></button></div></div></div><div class="btn-group"><div class="note-palette-title">Foreground Color</div><div class="note-color-reset" data-event="foreColor" data-value="inherit" title="Reset">Reset to default</div><div class="note-color-palette" data-target-event="foreColor"><div class="note-color-row"><button data-original-title="#000000" type="button" class="note-color-btn" style="background-color:#000000;" data-event="foreColor" data-value="#000000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#424242" type="button" class="note-color-btn" style="background-color:#424242;" data-event="foreColor" data-value="#424242" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#636363" type="button" class="note-color-btn" style="background-color:#636363;" data-event="foreColor" data-value="#636363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C9C94" type="button" class="note-color-btn" style="background-color:#9C9C94;" data-event="foreColor" data-value="#9C9C94" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEC6CE" type="button" class="note-color-btn" style="background-color:#CEC6CE;" data-event="foreColor" data-value="#CEC6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFEFEF" type="button" class="note-color-btn" style="background-color:#EFEFEF;" data-event="foreColor" data-value="#EFEFEF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7F7F7" type="button" class="note-color-btn" style="background-color:#F7F7F7;" data-event="foreColor" data-value="#F7F7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFFFF" type="button" class="note-color-btn" style="background-color:#FFFFFF;" data-event="foreColor" data-value="#FFFFFF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#FF0000" type="button" class="note-color-btn" style="background-color:#FF0000;" data-event="foreColor" data-value="#FF0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF9C00" type="button" class="note-color-btn" style="background-color:#FF9C00;" data-event="foreColor" data-value="#FF9C00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFF00" type="button" class="note-color-btn" style="background-color:#FFFF00;" data-event="foreColor" data-value="#FFFF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FF00" type="button" class="note-color-btn" style="background-color:#00FF00;" data-event="foreColor" data-value="#00FF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FFFF" type="button" class="note-color-btn" style="background-color:#00FFFF;" data-event="foreColor" data-value="#00FFFF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#0000FF" type="button" class="note-color-btn" style="background-color:#0000FF;" data-event="foreColor" data-value="#0000FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C00FF" type="button" class="note-color-btn" style="background-color:#9C00FF;" data-event="foreColor" data-value="#9C00FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF00FF" type="button" class="note-color-btn" style="background-color:#FF00FF;" data-event="foreColor" data-value="#FF00FF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#F7C6CE" type="button" class="note-color-btn" style="background-color:#F7C6CE;" data-event="foreColor" data-value="#F7C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE7CE" type="button" class="note-color-btn" style="background-color:#FFE7CE;" data-event="foreColor" data-value="#FFE7CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFEFC6" type="button" class="note-color-btn" style="background-color:#FFEFC6;" data-event="foreColor" data-value="#FFEFC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6EFD6" type="button" class="note-color-btn" style="background-color:#D6EFD6;" data-event="foreColor" data-value="#D6EFD6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEDEE7" type="button" class="note-color-btn" style="background-color:#CEDEE7;" data-event="foreColor" data-value="#CEDEE7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEE7F7" type="button" class="note-color-btn" style="background-color:#CEE7F7;" data-event="foreColor" data-value="#CEE7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6D6E7" type="button" class="note-color-btn" style="background-color:#D6D6E7;" data-event="foreColor" data-value="#D6D6E7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E7D6DE" type="button" class="note-color-btn" style="background-color:#E7D6DE;" data-event="foreColor" data-value="#E7D6DE" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E79C9C" type="button" class="note-color-btn" style="background-color:#E79C9C;" data-event="foreColor" data-value="#E79C9C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFC69C" type="button" class="note-color-btn" style="background-color:#FFC69C;" data-event="foreColor" data-value="#FFC69C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE79C" type="button" class="note-color-btn" style="background-color:#FFE79C;" data-event="foreColor" data-value="#FFE79C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5D6A5" type="button" class="note-color-btn" style="background-color:#B5D6A5;" data-event="foreColor" data-value="#B5D6A5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A5C6CE" type="button" class="note-color-btn" style="background-color:#A5C6CE;" data-event="foreColor" data-value="#A5C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9CC6EF" type="button" class="note-color-btn" style="background-color:#9CC6EF;" data-event="foreColor" data-value="#9CC6EF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5A5D6" type="button" class="note-color-btn" style="background-color:#B5A5D6;" data-event="foreColor" data-value="#B5A5D6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6A5BD" type="button" class="note-color-btn" style="background-color:#D6A5BD;" data-event="foreColor" data-value="#D6A5BD" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E76363" type="button" class="note-color-btn" style="background-color:#E76363;" data-event="foreColor" data-value="#E76363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7AD6B" type="button" class="note-color-btn" style="background-color:#F7AD6B;" data-event="foreColor" data-value="#F7AD6B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFD663" type="button" class="note-color-btn" style="background-color:#FFD663;" data-event="foreColor" data-value="#FFD663" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#94BD7B" type="button" class="note-color-btn" style="background-color:#94BD7B;" data-event="foreColor" data-value="#94BD7B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#73A5AD" type="button" class="note-color-btn" style="background-color:#73A5AD;" data-event="foreColor" data-value="#73A5AD" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BADDE" type="button" class="note-color-btn" style="background-color:#6BADDE;" data-event="foreColor" data-value="#6BADDE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#8C7BC6" type="button" class="note-color-btn" style="background-color:#8C7BC6;" data-event="foreColor" data-value="#8C7BC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#C67BA5" type="button" class="note-color-btn" style="background-color:#C67BA5;" data-event="foreColor" data-value="#C67BA5" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#CE0000" type="button" class="note-color-btn" style="background-color:#CE0000;" data-event="foreColor" data-value="#CE0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E79439" type="button" class="note-color-btn" style="background-color:#E79439;" data-event="foreColor" data-value="#E79439" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFC631" type="button" class="note-color-btn" style="background-color:#EFC631;" data-event="foreColor" data-value="#EFC631" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BA54A" type="button" class="note-color-btn" style="background-color:#6BA54A;" data-event="foreColor" data-value="#6BA54A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A7B8C" type="button" class="note-color-btn" style="background-color:#4A7B8C;" data-event="foreColor" data-value="#4A7B8C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#3984C6" type="button" class="note-color-btn" style="background-color:#3984C6;" data-event="foreColor" data-value="#3984C6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#634AA5" type="button" class="note-color-btn" style="background-color:#634AA5;" data-event="foreColor" data-value="#634AA5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A54A7B" type="button" class="note-color-btn" style="background-color:#A54A7B;" data-event="foreColor" data-value="#A54A7B" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#9C0000" type="button" class="note-color-btn" style="background-color:#9C0000;" data-event="foreColor" data-value="#9C0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B56308" type="button" class="note-color-btn" style="background-color:#B56308;" data-event="foreColor" data-value="#B56308" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#BD9400" type="button" class="note-color-btn" style="background-color:#BD9400;" data-event="foreColor" data-value="#BD9400" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#397B21" type="button" class="note-color-btn" style="background-color:#397B21;" data-event="foreColor" data-value="#397B21" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#104A5A" type="button" class="note-color-btn" style="background-color:#104A5A;" data-event="foreColor" data-value="#104A5A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#085294" type="button" class="note-color-btn" style="background-color:#085294;" data-event="foreColor" data-value="#085294" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#311873" type="button" class="note-color-btn" style="background-color:#311873;" data-event="foreColor" data-value="#311873" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#731842" type="button" class="note-color-btn" style="background-color:#731842;" data-event="foreColor" data-value="#731842" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#630000" type="button" class="note-color-btn" style="background-color:#630000;" data-event="foreColor" data-value="#630000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#7B3900" type="button" class="note-color-btn" style="background-color:#7B3900;" data-event="foreColor" data-value="#7B3900" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#846300" type="button" class="note-color-btn" style="background-color:#846300;" data-event="foreColor" data-value="#846300" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#295218" type="button" class="note-color-btn" style="background-color:#295218;" data-event="foreColor" data-value="#295218" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#083139" type="button" class="note-color-btn" style="background-color:#083139;" data-event="foreColor" data-value="#083139" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#003163" type="button" class="note-color-btn" style="background-color:#003163;" data-event="foreColor" data-value="#003163" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#21104A" type="button" class="note-color-btn" style="background-color:#21104A;" data-event="foreColor" data-value="#21104A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A1031" type="button" class="note-color-btn" style="background-color:#4A1031;" data-event="foreColor" data-value="#4A1031" title="" data-toggle="button" tabindex="-1"></button></div></div></div></li></ul></div><div class="note-para btn-group"><button data-original-title="Unordered list (CTRL+SHIFT+NUM7)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertUnorderedList" tabindex="-1"><i class="fa fa-list-ul"></i></button><button data-original-title="Ordered list (CTRL+SHIFT+NUM8)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertOrderedList" tabindex="-1"><i class="fa fa-list-ol"></i></button><button data-original-title="Paragraph" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-align-left"></i> <span class="caret"></span></button><div class="dropdown-menu"><div class="note-align btn-group"><button data-original-title="Align left (CTRL+SHIFT+L)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyLeft" tabindex="-1"><i class="fa fa-align-left"></i></button><button data-original-title="Align center (CTRL+SHIFT+E)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyCenter" tabindex="-1"><i class="fa fa-align-center"></i></button><button data-original-title="Align right (CTRL+SHIFT+R)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyRight" tabindex="-1"><i class="fa fa-align-right"></i></button><button data-original-title="Justify full (CTRL+SHIFT+J)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyFull" tabindex="-1"><i class="fa fa-align-justify"></i></button></div><div class="note-list btn-group"><button data-original-title="Indent (CTRL+])" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="indent" tabindex="-1"><i class="fa fa-indent"></i></button><button data-original-title="Outdent (CTRL+[)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="outdent" tabindex="-1"><i class="fa fa-outdent"></i></button></div></div></div><div class="note-height btn-group"><button data-original-title="Line Height" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-text-height"></i> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="lineHeight" href="#" data-value="1"><i class="fa fa-check"></i> 1.0</a></li><li><a data-event="lineHeight" href="#" data-value="1.2"><i class="fa fa-check"></i> 1.2</a></li><li><a data-event="lineHeight" href="#" data-value="1.4"><i class="fa fa-check"></i> 1.4</a></li><li><a data-event="lineHeight" href="#" data-value="1.5"><i class="fa fa-check"></i> 1.5</a></li><li><a data-event="lineHeight" href="#" data-value="1.6"><i class="fa fa-check"></i> 1.6</a></li><li><a data-event="lineHeight" href="#" data-value="1.8"><i class="fa fa-check"></i> 1.8</a></li><li><a data-event="lineHeight" href="#" data-value="2"><i class="fa fa-check"></i> 2.0</a></li><li><a data-event="lineHeight" href="#" data-value="3"><i class="fa fa-check"></i> 3.0</a></li></ul></div><div class="note-table btn-group"><button data-original-title="Table" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-table"></i> <span class="caret"></span></button><ul class="note-table dropdown-menu"><div class="note-dimension-picker"><div style="width: 10em; height: 10em;" class="note-dimension-picker-mousecatcher" data-event="insertTable" data-value="1x1"></div><div class="note-dimension-picker-highlighted"></div><div class="note-dimension-picker-unhighlighted"></div></div><div class="note-dimension-display"> 1 x 1 </div></ul></div><div class="note-insert btn-group"><button data-original-title="Link (CTRL+K)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showLinkDialog" data-hide="true" tabindex="-1"><i class="fa fa-link"></i></button><!--<button data-original-title="Picture" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showImageDialog" data-hide="true" tabindex="-1"><i class="fa fa-picture-o"></i></button>--><button data-original-title="Insert Horizontal Rule (CTRL+ENTER)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertHorizontalRule" tabindex="-1"><i class="fa fa-minus"></i></button></div><div class="note-view btn-group"><button data-original-title="Full Screen" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="fullscreen" tabindex="-1"><i class="fa fa-arrows-alt"></i></button><button data-original-title="Code View" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="codeview" tabindex="-1"><i class="fa fa-code"></i></button></div><div class="note-help btn-group"><button data-original-title="Help" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showHelpDialog" data-hide="true" tabindex="-1"><i class="fa fa-question"></i></button></div></div><textarea class="note-codable"></textarea><div data-placeholder="Description" class="note-editable" contenteditable="true" id='data2'></div></div>
                    <span class="help-block desc-error"></span>
                </div>

               
            
                

                <br class="clear clearfix"><br>

                <div class="f1-buttons">
                    
                    
                    <input type="button" name="submit"  class="btn btn-lg btn-info btn-uga btn-submit" onclick="reply()" value="Submit">
                </div>
				
            
        </form>
							
							
							
							</div>
							<h3><a href='ticket.php'>View Answered Tickets</a></h3>
							<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
<tr><th>Account Number</th><th>Name</th><th>Ticket Id</th><th>Subject</th><th>Message</th><th>Action</th><th> Date</th><th>Reply</th><th>Reply Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from ticket where reply='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php $query="select firstname, lastname from registeruser where account_number='".$ree['account_no']."'";
				$d=mysqli_query($con,$query) or die(mysqli_error($con));$v=mysqli_fetch_array($d); echo $v['firstname']." ".$v['lastname']; ?></td>
				<td>#<?php echo $ree['ref_no'] ?></td><td><?php echo $ree['subject'] ?></td><td><?php if($ree['image']!=""){
				echo"<img src='../".$ree['image']."' width='60%'><br>";	
				}
				
				echo $ree['message'] ?></td><td><button id='ticket_but<?php echo $ree['ticket_id'] ?>'onclick='opennewticket("ticket_result","ticket_but<?php echo $ree['ticket_id'] ?>","<?php echo $ree['ticket_id'] ?>","<?php echo $ree['subject'] ?>")'>Reply</button></td><td><?php echo $ree['postdate'] ?></td>
				<td> <?php $query="select message, postdate from ticket_reply where ticket_reply_id='".$ree['ticket_id']."'";$re=mysqli_query($con,$query) or die(mysqli_error($con));$wee=mysqli_fetch_array($re); echo $wee['message'] ?></td><td><?php echo $wee['postdate']  ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div><!-- end of panel-body -->
							
							<br>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
				<!--end of Tickets -->
				<!--suspend account -->
				<div>
				<h3><a href='suspended_account.php'>View Suspended Account</a></h3>
				<div class="panel-heading">
                             <strong>Suspend Account</strong>
							 
                        </div>
                    <div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='suspend'  style='width:60%' name="account_no2" onblur="update_profile2()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err3'></span>
							</div>
							<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Message</span>
								<input class="form-control" id='smessage'  style='width:60%' name="smessage" placeholder='Enter message' type="text" required="">
								
							</div>
							<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Category</span>
								<select name='category' class="form-control" id='category' >
								    <option value='Loan'>Loan</option>
								    <option value='Withdraw'>Widthdraw</option>
								</select> 
								
							</div>
							<div id='suspend_result'></div>
							
				</div>
				<!--end of suspend -->
				
				
					<!--phone Confirm -->
				<div>
			
				<div class="panel-heading">
                             <strong>Phone  Confirmation Code</strong>
							 
                        </div>
                    <div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='phonec'  style='width:60%' name="account_no2" onblur="update_profile3()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err4'></span>
							</div>
							
							<div id='phone_result'></div>
							
				</div>
				<!--end of phone Confirm -->
				
				
				
            </div><!--  end of resp-tabs-container hor_1 -->
        </div><!-- end of parentHorizontalTab -->
        <div id="nested-tabInfo">
            Selected tab: <span class="tabName"></span>
        </div>
        <br/>
        
        <div id='loaders'></div>
        <br/>
        <!--Vertical Tab-->
        <div id="parentVerticalTab">
            <ul class="resp-tabs-list hor_1">
                 <li>Confirm Loan</li>
                <li>Authorize Loan</li>
                <li>Loan Form</li>
				<li>Confirm Deposit</li>
				<li>Authorize Deposit</li>
				
            </ul>
            <div class="resp-tabs-container hor_1">
			
								
								<!--confirm -->
                <div>
				
				<h4 class="page-header">Confirm Loan</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" >	
								<thead>
<tr><th>Category</th><th>Account No</th><th>Repayment Plan Amount</th><th>Duration</th><th>Interest</th><th>Picture</th><th>Amount</th><th>Total Deposit</th><th>Ref NO</th><th>Date</th><th>Confirmed</th><th>Action</th><th></th><th></th></tr>
                                    </thead>
                                    <tbody>	
									<?php 
									$query="select* from loan where confirm='0' and rejected='0' and amount !='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
					?>
				<tr>
				<td><?php echo $ree['category'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['repayment_plan_amount']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td><?php  $query="select picture  from registeruser where account_number='".$ree['account_no']."'"; $xx=mysqli_query($con,$query) or  die(mysqli_error($con)); $c=mysqli_fetch_array($xx);echo"<img src='../".$c['picture']."' width='100px'>"?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php  $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td>
				<td id="confirm<?php echo $ree['loan_id'] ?>">
				    <?php
					$query="select* from paystackcard where account_no='".$ree['account_no']."' and paid='1' and remove='0' and authorization_code !=''"; 
					$x=mysqli_query($con,$query) or  die(mysqli_error($con));
					if(mysqli_num_rows($x)>0){
					    $query="select bvn from bank_info where bvn !='' and account_no='".$ree['account_no']."'";
				        $y=mysqli_query($con,$query) or  die(mysqli_error($con));
				        
				        if(mysqli_num_rows($y)>0){
				    ?>
				    <button  onclick='confirm_update("<?php echo $ree['loan_id'] ?>")'>Confirm</button>
				    <?php
				        }
				    }
				    ?>
				    </td><td id="reject<?php echo $ree['loan_id'] ?>"><button  onclick='confirm_reject("<?php echo $ree['loan_id'] ?>")'>Reject</button></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                   </table>        

</div>
</div>
				   <br>
                    <br>
                    <p>Tab 1 Container</p>
                </div>
				<!-- end of confirm -->
								
				<!-- authorize -->
                <div>
                    
<h4 class="page-header">Authorize Loan</h4>
	<div class="panel-body">
                            <div class="table-responsive">
                               
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
<tr><th>Category</th><th>Account No</th><th>Repayment Plan Amount</th><th>Duration</th><th>Interest</th><th>Requested Amount</th><th>Amount</th><th>Total Deposit</th><th>Ref NO</th><th>Date</th><th>Confirmed</th><th>Action</th><th></th><th></th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan where confirm='1' and authorize='0' and rejected='0' and amount !='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						
					?>
				<tr>
				<td><?php echo $ree['category'] ?></td><td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['repayment_plan_amount']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['req_amount'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php  $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td><td id="confirm2<?php echo $ree['loan_id'] ?>">
				    <?php $query="select* from paystackcard where account_no='".$ree['account_no']."' and paid='1' and remove='0' and authorization_code !=''"; $x=mysqli_query($con,$query) or  die(mysqli_error($con));if(mysqli_num_rows($x)>0){
				    ?>
				    <button  onclick='authorize_update("<?php echo $ree['loan_id'] ?>")'>Authorize</button>
				    <?php
				    }
				    ?>
				    </td><td id="reject2<?php echo $ree['loan_id'] ?>"><button  onclick='authorize_reject("<?php echo $ree['loan_id'] ?>")'>Reject</button></td><td><a href='loan_info.php?id=<?php echo $ree['loan_id'] ?>'>View More</a></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
					<br>
                    <br>
                    <p>Tab 2 Container</p>
                </div>
				<!-- end of authorize -->
								
				<!-- loan form -->
                <div>
                   
						
	<h4 class="page-header">Loan Application Form</h4>
	<?php
				if(isset($_POST['change'])){
					include'../function.php';
					$emp_status =escape($con,$_POST['emp_status']);
					$account =escape($con,$_POST['account_no']);
$emp_sector =escape($con,$_POST['emp_sector']);
$buz_name =escape($con,$_POST['buz_name']);
$buz_address =escape($con,$_POST['buz_address']);
$buz_status =escape($con,$_POST['buz_status']);
$rc_no =escape($con,$_POST['rc_no']);
$net_profit =escape($con,$_POST['net_profit']);
$mon_turnover =escape($con,$_POST['mon_turnover']);
$start_date =escape($con,$_POST['start_date']);
$buz_email =escape($con,$_POST['buz_email']);
$buz_phone =escape($con,$_POST['buz_phone']);
$tax_no =escape($con,$_POST['tax_no']);
$pension_no =escape($con,$_POST['tax_no']);
$occupation =escape($con,$_POST['occupation']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$duration =escape($con,$_POST['duration']);
$percent =escape($con,$_POST['percent']);
$structure =escape($con,$_POST['structure']);
$reason =escape($con,$_POST['reason']);
$total =escape($con,$_POST['total']);
$repay_amount =escape($con,$_POST['repay_amount']);
$ref =rand(100000,999999);
	 $bvn=escape($con,$_POST['bvn']);
$find =escape($con,$_POST['find']);
	$interest=($percent*$amount)/100;			
			$query="insert into loan  (category,total,interest,emp_status,emp_sector,business_name,business_address,biz_status,rc_no,dialy_turnover,monthly_profit,biz_start,biz_email,biz_phone,tax_no,pension,occupation,account_no, amount,loan_duration,interest_rate,repayment_plan,reason_for_loan,repayment_plan_amount,find,regdate,ref_no ) values(
'Office','$total','$interest','$emp_status','$emp_sector','$buz_name','$buz_address','$buz_status','$rc_no','$net_profit','$mon_turnover','$start_date','$buz_email','$buz_phone','$tax_no','$pension_no','$occupation','$account','$amount','$duration','$percent','$structure','$reason','$repay_amount','$find',now(),$ref)";
mysqli_query($con,$query)or die(mysqli_error($con));
$id=mysqli_insert_id($con);
if(isset($_POST['bvn']) ){

	$query="update bank_info set bvn='$bvn' where account_no='$account'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}


if(isset($_POST['id'])){
$id =escape($con,$_POST['id']);
$id_no =escape($con,$_POST['id_no']);
$issue_date =escape($con,$_POST['issue_date']);
$exdate =escape($con,$_POST['exdate']);

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["ufile"])) {
$fileName = $_FILES["ufile"]["name"];
 $fileTmpLoc = $_FILES["ufile"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["ufile"]["name"]);
$extension = end($temp);
if ((($_FILES["ufile"]["type"] == "image/gif")
|| ($_FILES["ufile"]["type"] == "image/jpeg")
|| ($_FILES["ufile"]["type"] == "image/jpg")
|| ($_FILES["ufile"]["type"] == "image/pjpeg")
|| ($_FILES["ufile"]["type"] == "image/x-png")
|| ($_FILES["ufile"]["type"] == "image/png"))
&& ($_FILES["ufile"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["ufile"]["error"] > 0) {
        echo "Return Code: " . $_FILES["ufile"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	
	$db_file_names="../userphoto/$db_file_name";
	$db_file_name="userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
			$query="update registeruser set id_image='$db_file_name' where account_number='$account'";
	mysqli_query($con,$query)or die(mysqli_error($con));
		$query="insert into uploads(purpose,image,regdate,account_no) values('ID image','$db_file_name',now(),'$accout')";
	mysqli_query($con,$query) or die(mysqli_error($con));
			
        }
    }
 else {
     //"Invalid file";
}
}
$query="update registeruser set id='$id',id_no='$id_no',issue_date='$issue_date',exp_date='$exdate' where account_number='$account'";
mysqli_query($con,$query)or die(mysqli_error($con));
}





		$query="select account_no from paystackloan where account_no='$account' and confirmed='1' and remove='0'";
	$ee=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($ee)<1){
	    $_SESSION['accounts']=$account;
		
		
		$amount =50;


$ref =rand(10000000000,99999999999);


		$totals=$amount;
	if(preg_match("/\.+/",$totals)){
	$totals=str_replace(".","",$totals);
					$totals=$totals;
	}else{
		$totals=$totals."00";
	}		
	$query="insert into paystackcard (account_no,ref_no,amount)values('$accounts','$ref','$amount')";
	mysqli_query($con,$query)or die(mysqli_error($con));
	$id=mysqli_insert_id($con);
	  $query="select firstname,lastname,email_address,phone from registeruser where account_number='$accounts'";
	  $d=mysqli_query($con,$query)or die(mysqli_error($con));
	  $row=mysqli_fetch_array($d);
	?>
	<center><h4 class="h3-w3l">Thank You</h4>
<p>You need to make a deposit of N50 with your card before you can continue  with your loan Application</p>	
				<p><b>Reference NO:  <?php echo $ref ?></b><br>
				Amount:  N<?php echo $amount ?> <br>
			
				</p></center><br>
				
				<form >
  <script src="https://js.paystack.co/v1/inline.js"></script>
 <div id='success'> <button  class='btn'type="button" onclick="payWithPaystack()"> Pay </button> </div>
</form>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $row['email_address'] ?>',
      amount: '<?php echo $totals ?>',
      channels:['card'],
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $row['firstname'] ?>',
      lastname: '<?php echo $row['lastname'] ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $row['phone'] ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updateloanpay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
		//window.location="payments.php";
			
		document.getElementById("success").innerHTML = "<h3 style='color:red'>Loan Application was Successful</h3><p>Await Approval.</p>";	 
			
			
		}
	}
	ajax.send("ref="+response+"&id=<?php echo $id ?>");
 
 
  }
</script>
  
		
		
		
		
		
		
		
		
		<?php
		
	}
			






echo "<h3>Loan Application was Successful</h3>";
?>
<center><h4 class="h3-w3l">Thanks for your Interest </h4> <p>Your Wallet will be credited when your Loan is approved</p></center>
				
<?php
				} else{
				?>
	<form action="" method="POST" enctype="multipart/form-data">
		<div class="row">
		

 <div class="col-lg-12 ">			
				<div class="col-md-3">
			<p>ID image</p>
			
				<img src="../images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile" id="ufile5" accept="image/*" onchange="loadFile(event)"  /><br>
				
				
			
			
			</div>
			<div class="col-md-5">
			
			<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Account Number</span>
								<input class="form-control" id='account_no' name="account_no" onblur="updateloan()"placeholder='Enter Account Number' type="text" required="">
								<span class='error' id='acc_err'></span>
							</div>
			
				
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br><br>
		<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Employment Status</span>
			<select name="emp_status" class="form-control" id='emp_status'  required="">
						<option value="">---EMPLOYMENT STATUS---</option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						
						
</select>	</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Employment Sector</span>
						<input type="text" name="emp_sector" id='emp_sector' value=""class="form-control" placeholder="EMPLOYMENT SECTOR" ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Name</span>
						<input type="text" id='buz_name'name="buz_name"value="" class="form-control" placeholder="BUSINESS NAME" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Busiess Address</span>
						<input type="text" name="buz_address" id='buz_address'value=""class="form-control" placeholder="BUSINESS ADDRESS" required=""><br>
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Status</span>
						<select name="buz_status" id='buz_status'class="form-control"  required="">
						<option value="">----Business Registration Status---</option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select><br>

				</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">RC Number</span>			
						
						<input type="text" name="rc_no" value=""class="form-control" id='rc_no' placeholder="RC NO" required=""><br>
							</div>
							<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Means of Identification</span>
				<select name="id" class="form-control" id='id' required="">
						<option value="">----Select Identification ---</option>
						<option value="National ID">National Id-card </option>
						<option value="Driver License">Driver License</option>
						<option value="Voters Card">Voters Card</option>
						<option value="International Passport">International Passport</option>
						</select>
						
			
						
						</div>
						<div class='form-group'>
						
<span class="badge" style="background-color:#3385FF;">ID Number</span>

						<input type="text" name="id_no" id='id_no'value="" class="form-control" title="ID NUMBER" >	
					
						</div>
						
							<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Issue Date *</span><br><br>
						 <input type='date' name="issue_date"  id='isdate' class="form-control" value="" >
 
</div><div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate" id='exdate'  class="form-control" value=''>
 
</div>
							
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Daily Turnover</span>
						<input type="text" name="net_profit" id='net_profit'value="" class="form-control" placeholder="DAILY TURNOVER" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Monthly Turnover</span>
						<input type="text" name="mon_turnover" id='mon_turnover'value=""class="form-control" placeholder="NET MONTHLY MONTHLY" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Start date</span>
						<input type="date" name="start_date" id='start_date'value="" class="form-control"  ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Email</span>
						<input type="email" name="buz_email" id='buz_email'value="" class="form-control" placeholder="BUSINESS EMAIL" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Phone</span>
						<input type="text" name="buz_phone" id='buz_phone' value=""class="form-control" placeholder="BUSINESS PHONE" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Tax Number</span>
						<input type="text" name="tax_no" id='tax_no'value="" class="form-control" placeholder="TAX NO" ><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Pension Number</span>
						<input type="text" name="pension_no" id='pension_no'value="" class="form-control" placeholder="PENSON NO"><br>
						
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Occupation</span>
						<select name="occupation" id='occupation' class="form-control"  required="">
						<option value=""> ----Occupation---</option>
						<option value="Student">Student</option>
						<option value="Trader">Trader</option>
						<option value="Technician">Technician</option>
						<option value="Accountants">Accountants</option>
							<option value="Accounting">Accounting</option>
							<option value=" Administrator"> Administrator</option>
							<option value="Administrative Assistants">Administrative Assistants</option>
							<option value="Advertiser">Advertiser</option>
							<option value="Agents">Agents</option>
							<option value="Air Conditioning Installers">Air Conditioning Installers</option>
							<option value="Analysts">Analysts</option>
							<option value="Architech">Architech</option>
							<option value="Artists">Artists</option>
							<option value="Asphalt Paving Machine Operators">Asphalt Paving Machine Operators</option>
                            <option value="Assistants">Assistants</option>
							<option value="Athletes">Athletes</option>
							<option value="Automobile Body Repair">Automobile Body Repair</option>
							<option value="Bank">Bank</option>
							<option value="Bookkeeping">Bookkeeping</option>
							<option value="Cafeteria">Cafeteria</option>
							<option value="Carpenter">Carpenter</option>
							<option value="Certified Nurse Midwives">Certified Nurse Midwives</option>
							<option value="Cleaner">Cleaner</option>
							<option value="Contractor">Contractor</option>
								<option value="Cooks">Cooks</option>
																<option value="Counselor">Counselor</option>
                                <option value="Doctor">Doctor</option>
								<option value="Comedian">Comedian</option>
                            <option value="Drivers">Drivers</option>
							<option value="Economics">Economics</option>
                                <option value=" Electricians"> Electricians</option>
								<option value="Engineer">Engineer</option>
								<option value="Equipment Installers">Equipment Installers</option>
								<option value="Equipment Operators">Equipment Operators</option>
								<option value="Feed Manager">Feed Manager</option>
								<option value="Graphic Designer">Graphic Designer</option>
								<option value="House helper">House helper</option>
                                <option value="librarian">Libralian</option>
                            
                                <option value="Lawyer">Lawyer</option>
                            
                                <option value="Security">Security</option>
                            
                                
                            
                                
                            
                                <option value="Photographer">Photographer</option>
                            
                                <option value="Web Designer">Web Designer</option>
								<option value="Phone Engineer">Phone Engineer</option>
								
								
								<option value="Sales girl">Sales girl</option>
								<option value="Sales boy">Sales boy</option>
								<option value="Radiographers">Radiographers</option>
								
								
								<option value="Spiritualist">Spiritualist</option>
								
								
								<option value="Teachers">Teachers</option>
								
								<option value="Mathematicians">Mathematicians</option>
								
								<option value="Managerial services">Managerial services</option>
								
								<option value="Photographer">Photographer</option>
								<option value="Rental">Rental</option>
								
								
								<option value="Nanny">Nanny</option>
								
								<option value="Mechanics">Mechanics</option>
							
								<option value="Medical Technician">Medical Technician</option>
								
								
								<option value="News Broadcaster">News Broadcaster</option>
								<option value="Painters">Painters</option>
								<option value="Sculptors Arts Producer">Sculptors Arts Producer</option>
								
								
								<option value="Medical laboratory Scientist">Medical laboratory Scientist</option>
								<option value="Nursing, Attendants">Nursing, Attendants</option>
								
								<option value="Social Workers">Social Workers</option>
								
								<option value="Laborer">Laborer</option>
								
								<option value="Marriage Counselor">Marriage Counselor</option>
								<option value="Doctors of Optometry">Doctors of Optometry</option>
								<option value="Public Health">Public Health</option>
								<option value="Elevator Installers">Elevator Installers</option>
								<option value="Repairers">Repairers</option>
								<option value="Epidemiologists">Epidemiologists</option>
								<option value="Physician Assistant">Physician Assistant</option>
								<option value="Firefighters">Firefighters</option>
								<option value="Drying Machine Operators">Drying Machine Operators</option>
								<option value="Health Diagnosing Practitioners">Health Diagnosing Practitioners</option>
								<option value="Tenders">Tenders</option>
								<option value="Helpers">Helpers</option>
								<option value="Plumber">Plumber</option>
								<option value="Pipefitters">Pipefitters</option>
								<option value="Home Appliance Repairers">Home Appliance Repairers</option>
								<option value="Hospital Registerers">Hospital Registerers</option>
								<option value=" Labor Economics Property Manager"> Labor Economics Property Manager</option>
								<option value="Librarians">Librarians</option>
								<option value="Clinical Mental Health Counselor">Clinical Mental Health Counselor</option>
								<option value="Logistics Planner">Logistics Planner</option>
								<option value="Mortician">Mortician</option>
								<option value="Movie Projectionists">Movie Projectionists</option>
								<option value="Nutritionists">Nutritionists</option>
								<option value="Public Health Specialist">Public Health Specialist</option>
								<option value="Pay loader Operator">Pay loader Operator</option>
								<option value="Painter">Painter</option>
								<option value="Makeup Artist">Makeup Artist</option>
								<option value="Pharmacist Technicians">Pharmacist Technicians</option>
								<option value="Pharmacists">Pharmacists</option>
								<option value="Wedding Planner">Wedding Planner</option>
								<option value="Equipment Repairers">Equipment Repairers</option>
								<option value="Physician">Physician</option>
								<option value="Surgeon">Surgeon</option>
								<option value="Marketing">Marketing</option>
								<option value="Weaving">Weaving</option>
								<option value="Fashion/dressmaking">Fashion/dressmaking</option>
								<option value="Property Managers">Property Managers</option>
								<option value="Real Estate developers">Real Estate developers</option>
								<option value="Car Repairers">Car Repairers</option>
								<option value="Real Estate Brokers">Real Estate Brokers</option>
								<option value="Rehabilitation Repairers">Rehabilitation Repairers</option>
								<option value="Sales Agents">Sales Agents</option>
								<option value="Shipping Agents">Shipping Agents</option>
								<option value="Healthcare">Healthcare</option>
								<option value="Software Developers">Software Developers</option>
								<option value="Solar Panel Installation Supervisor">Solar Panel Installation Supervisor</option>
								<option value="Supervisors">Supervisors</option>
								<option value="Gaming Supervisors">Gaming Supervisors</option>
								<option value="Urban Planner">Urban Planner</option>
								<option value="Waiter">Waiter</option>
								<option value="Waitresses">Waitresses</option>
								<option value="Gate man">Gate man</option>
																<option value="Programmer">Programmer</option>
								<option value="Seller">Seller</option>
						
</select>
						</div>
						<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
						
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Amount</span>
						<input type="text" id='amount'name="amount"onkeyup="this.value = numFormat(this.value)" value="<?php if(isset($_POST["amount"])){echo $_POST["amount"];}  ?>" class="form-control" placeholder="ENTER AMOUNT" required=""><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Duration</span>
								<select name='duration' class="form-control" id='duration'required="">
								<option   value="">Select LOAN Duration </option>
								<option   value="1 Month">1 Month</option>
								<option   value="2 Months">2 Months</option>
								<option   value="3 Months">3 Months</option>
								<option   value="4 Months">4 Months</option>
								<option   value="6 Months">6 Months</option>
								<option   value="12 Months">12 Months</option>
								
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Loan Percentage</span>
								
								<select name="percent" class="form-control" id='percent' required="" onchange="calculate()">
						<option value="">----Monthly Investment Interest Rate</option>
						
						
						<option value="30">30%</option>
						<option value="20">20%</option>
						<option value="10">10%</option>
						
						
</select><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Payback Amount</span>
								<input class="form-control" id='total' name="total" value=""placeholder='Payback Amount' readonly type="text">
							</div>
							 <div style='color:red;font-size:16px'id='resultss'></div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Repayment Plan Amount</span>
								<input class="form-control" id='repay'required=""  name="repay_amount" value=""placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Payment Structure</span>
								<select name='structure'  class="form-control"required="" >
								<option   value="">Select Repayment Structure </option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Reason for Loan</span>
						<textarea  name="reason"value="" id='reason'class="form-control" placeholder="Reason for loan" required=""></textarea><br>
						</div>
					
				
					

			
			
		
	
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Account Name </span>
	<input type="text" name="account_name" value=""class="form-control" id='ac_name'readonly><br>
		</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Account Number</span>
						<input type="text" name="account_number" class="form-control" id='ac_number'value="" readonly><br>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Bank Name</span>
						<input type="text" name="bank" class="form-control" id='bank'value="" readonly><br>
		</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">BVN</span>
					<input type="text" name="bvn" class="form-control" id='bvn'placeholder="BVN NO" required=""><br>
						<textarea  name="find" class="form-control" placeholder="How did you find us" required=""></textarea><br>
				<button class="btn btn-info" id='submit' name="change" type="submit">SUBMIT</button>
				
				</div>
				</form>
                    <?php
				} 
?>				
                    </div>
					</div>
					</div>
				   <br>
                    <br>
                    <p>Tab 3 Container</p>
                </div>
				<!-- end of loan form  -->
						
					<!--confirm deposit -->
					<div >
						<h4 class="page-header">Confirm  Deposit</h4>
						
						<div class="panel-body">
	    <div id='loaders'></div>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Amount</th><th>Amount in Word</th><th>Ref NO</th><th>Method</th><th>Date</th><th>Evidence of Payment</th><th>Confirmed</th><th>Action</th><th></th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from deposit where confirm='0' and category='Wallet' and method !='Instant' and rejected='0' and confirmed='1'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td> <?php echo $ree['account_no'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td> <?php echo $ree['amount_word'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['method'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['admin']!=""){ echo "Deposited by ".$ree['admin'];}else{if($ree['confirmed']=="0"){ echo "Not Confirmed" ;}else{ ?><a href="deposit_evidence.php?id=<?php echo $ree["deposit_id"] ?>" >View Payment</a><?php }} ?></td><td><?php if($ree['confirm'] =="1"){echo "Yes";}else{echo "No";} ?></td><td id="confirm_deposit<?php echo $ree['deposit_id'] ?>"><button  onclick='confirm_deposit("<?php echo $ree['deposit_id'] ?>","<?php echo $ree['ref_no'] ?>")'>Confirm</button></td><td id="reject_deposit<?php echo $ree['deposit_id'] ?>"><button  onclick='reject_deposit("<?php echo $ree['deposit_id'] ?>")'>Reject</button></td>
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
						
					</div>	
							<!-- end of confirm deposit -->
							
							<!--authorize deposit -->
					<div >
						<h4 class="page-header">Authorize Deposit</h4>
						
						<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Amount</th><th>Amount in Word</th><th>Ref NO</th><th>Method</th><th>Date</th><th>Evidence of Payment</th><th>Authorized</th><th>Action</th><th></th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from deposit where confirm='1' and authorize='0' and rejected='0' and category='Wallet'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td> <?php echo $ree['account_no'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td> <?php echo $ree['amount_word'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['method'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php if($ree['admin']!=""){ echo "Deposited by ".$ree['admin'];}else{if($ree['confirmed']=="0"){ echo "Not Confirmed" ;}else{ ?><a href="deposit_evidence.php?id=<?php echo $ree["deposit_id"] ?>" >View Payment</a><?php }} ?></td><td><?php if($ree['authorize'] =="1"){echo "Yes";}else{echo "No";} ?></td><td id="authorize_confirm<?php echo $ree['deposit_id'] ?>"><button onclick='authorize_deposit("<?php echo $ree['deposit_id'] ?>","<?php echo $ree['account_no'] ?>","<?php echo $ree['amount'] ?>","<?php echo $ree['ref_no'] ?>","<?php echo $ree['method'] ?>")'>Authorize Deposit</button></td><td id="authorize_reject<?php echo $ree['deposit_id'] ?>"><button onclick='authorize_reject("<?php echo $ree['deposit_id'] ?>")'>Reject Deposit</button></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
					</div>	
							<!-- end of authorize deposit -->
							
            </div><!-- end of resp-tabs-container -->
        </div><!-- end of parentVerticalTab -->
        <div id="nested-tabInfo2">
            Selected tab: <span class="tabName"></span>
        </div>

       

       
    </div><!-- end of container -->
	
	<!--Plug-in Initialisation-->
	<script type="text/javascript">
    $(document).ready(function() {
        //Horizontal Tab
        $('#parentHorizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

        // Child Tab
        $('#ChildVerticalTab_1').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true,
            tabidentify: 'ver_1', // The tab groups identifier
            activetab_bg: '#fff', // background color for active tabs in this group
            inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
            active_border_color: '#c1c1c1', // border color for active tabs heads in this group
            active_content_border_color: '#5AB1D0' // border color for active tabs contect in this group so that it matches the tab head border
        });

        //Vertical Tab
        $('#parentVerticalTab').easyResponsiveTabs({
            type: 'vertical', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo2');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
    });
</script>
<script>

		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function updateloan(){
	
	var types=document.getElementById("account_no").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "check.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:18:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Invalid"){
				document.getElementById("acc_err").innerHTML = ajax.responseText;
			}
			else{
								
				var data=ajax.responseText.split("|");
				var id_image=data[0];
				var id=data[1];
					var id_no=data[2];
				var name=data[19];
				var number=data[20];
				var bank=data[21];
				var bvn=data[22];
				var ow=data[3];
				var emp_status=data[4];
				var emp_sector =data[5];
				var buz_name=data[6];
				var buz_address=data[7];
				var buz_status=data[8];
				var rc_no=data[9];
				var mon_turnover=data[10];
				var net_profit=data[11];
				var start_date=data[12];
				var buz_email=data[13];
				var buz_phone=data[14];
				var tax_no=data[15];
				var pension_no=data[16];
				var occupation=data[17];
				var reason=data[18];
				if( emp_status!=""){
					document.getElementById("emp_status").value=emp_status;
				}
				if( emp_sector!=""){
					document.getElementById("emp_sector").value=emp_sector;
				}
				if( buz_email!=""){
					document.getElementById("buz_name").value=buz_name;
				}
				if( buz_address!=""){
					document.getElementById("buz_address").value=buz_address;
				}
				if( buz_status!=""){
					document.getElementById("buz_status").value=buz_status;
				}
				if( rc_no!=""){
					document.getElementById("rc_no").value=rc_no;
				}
				if( mon_turnover!=""){
					document.getElementById("mon_turnover").value=mon_turnover;
				}
				if( net_profit!=""){
					document.getElementById("net_profit").value=net_profit;
				}
				if( start_date!=""){
					document.getElementById("start_date").value=start_date;
				}
				if( buz_email!=""){
					document.getElementById("buz_email").value=buz_email;
				}
				if( buz_phone!=""){
					document.getElementById("buz_phone").value=buz_phone;
				}
				if( tax_no!=""){
					document.getElementById("tax_no").value=tax_no;
				}
				if( pension_no!=""){
					document.getElementById("pension_no").value=pension_no;
				}
				if( occupation!=""){
					document.getElementById("occupation").value=occupation;
				}
				if( reason!=""){
					document.getElementById("reason").value=reason;
				}
				document.getElementById("outputpix").src="../"+id_image;
				document.getElementById("ac_name").value=name;
				document.getElementById("ac_number").value=number;
				document.getElementById("bank").value=bank;
				document.getElementById("bvn").value=bvn;
				document.getElementById("id_no").value=id_no;
				document.getElementById("id").value=id;
				if(ow=="0"){
				document.getElementById("submit").style.display="block";
				document.getElementById("acc_err").innerHTML ="";				
				}else{
					document.getElementById("acc_err").innerHTML ="<p>Please You need to Complete Your ₦ "+ow+" Loan Repayment before applying for another one.</p>";
					document.getElementById("submit").style.display="none";
				}
				
			}
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 function calculate(){
	
	//alert("nofate");
	var amoun=document.getElementById("amount").value;
	var reg=/,/;
	var amount=amoun.replace(reg,""); 
	var duration=document.getElementById("duration").value;
	var account=document.getElementById("account_no").value;
	var percent=document.getElementById("percent").value;
	ajax.open("POST", "calculate.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:59:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			//document.getElementById("total").value=ajax.responseText;
				var data=ajax.responseText.split("|");
				var total=data[0];
				var id=data[1];
			document.getElementById("total").value=total;
			if(id=="expire"){
			document.getElementById("resultss").innerHTML="Card will expire before loan repayment";
			document.getElementById("submit").style.display="none";
			}else if(id=="no"){
			    	document.getElementById("resultss").innerHTML="No card Found";
			    	document.getElementById("submit").style.display="none";
			}else{
			    document.getElementById("submit").style.display="block";
			}
		
				
		}
	}
	ajax.send("amount="+amount+"&duration="+duration+"&percent="+percent+"&account="+account);
	 
 
 }
 function reject(id,account){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reject.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:17:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			 
			window.location="index.php";
			
		}
		}
	}
	ajax.send("id="+id+"&account="+account);
 
 }
 
 function confirm_update(id){
	
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 20 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("confirm"+id).innerHTML ="Done";
document.getElementById("reject"+id).innerHTML ="";

if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function confirm_reject(id){
	
	if(confirm("Are you Sure you want to reject the Loan")){
	
	var b=document.getElementById("loaders").style.display="block";//document.getElementById("reject"+id).innerHTML = 'please wait ...';
	
	 ajax.open("POST", "reject_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:10:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("reject"+id).innerHTML ="Done";
				document.getElementById("confirm"+id).innerHTML ="";
				if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}


		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 }
 
 
 function authorize_update(id){
	
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "authorize_confirm_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:11 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("confirm2"+id).innerHTML ="Done";
document.getElementById("reject2"+id).innerHTML ="";
if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function authorize_reject(id){
	
	if(confirm("Are you Sure you want to reject the Loan")){
	
	var b=document.getElementById("loaders").style.display="block";//document.getElementById("reject"+id).innerHTML = 'please wait ...';
	
	 ajax.open("POST", "authorize_reject_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:14:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("reject2"+id).innerHTML ="Done";
				document.getElementById("confirm2"+id).innerHTML ="";

if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 }
 
 function update_statement(){
	var id=document.getElementById("statement").value;
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "loan_statements.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("statement_result").innerHTML =ajax.responseText;
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	
	function update_status(){
	var id=document.getElementById("status").value;
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "account_statu.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("account_result").innerHTML =ajax.responseText;
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	
	
	
	function reset_status(){
	var id=document.getElementById("reset").value;
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reset_form.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("reset_result").innerHTML =ajax.responseText;
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	
	function change_pass(){
	var id=document.getElementById("reset").value;
	var pass=document.getElementById("pass1").value;
	var email=document.getElementById("reset_email").value;
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reset_pass.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			alert("Password changed Successfully");
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
			
				//document.getElementById("reset_result").innerHTML =ajax.responseText;
		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&pass="+pass+"&email="+email);
	}
	
	function checkpass (){
var pass1=document.getElementById('pass1').value;
var pass2=document.getElementById('pass2').value;
var reg=document.getElementById('submitpass');

if(pass1 !== pass2){
document.getElementById('res').innerHTML = "Password do not match";

reg.style.display="none";


}
else{
	reg.style.disabled=false;
	document.getElementById('res').innerHTML = "matched";
	reg.style.display="block";
}
}

 function update_profile(){
	var id=document.getElementById("profile").value;
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "loan_profile.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("profile_result").innerHTML =ajax.responseText;
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 function update_profiles(){
	var id=document.getElementById("profile2").value;
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "loan_profile2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("profile_result2").innerHTML =ajax.responseText;
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 
 function update_profile2(){
	var id=document.getElementById("suspend").value;
	
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "suspend_account.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1978 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText=="Incorrect"){
				document.getElementById("acc_err3").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
		
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
			 document.getElementById("suspend_result").innerHTML ="<button onclick='suspend()'>Suspend Account</button><button onclick='rejectit()'>Cancel</button>";
			document.getElementById("acc_err3").innerHTML="";
			}
			
				
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	
	function update_profile3(){
	var id=document.getElementById("phonec").value;
	var b=document.getElementById("loaders").style.display="block";
//alert("nofate");
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "phone_update.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1978 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
		    var b=document.getElementById("loaders").style.display="none";
alert(ajax.responseText);
			if(ajax.responseText=="Incorrect"){
				document.getElementById("acc_err3").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var code=data[5];
			var phone=data[3];
		var used=data[4];
		if(used=='1'){
		var us="Yes"
		}else{
		    var us="No";
		}
		
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
			 document.getElementById("phone_result").innerHTML ="<table class='table'><tr><th>Phone</th><th>Code</th><th>Used</th</tr><tr><td>"+phone+"</td><td>"+code+"<td>"+us+"</td></tr></table>";
			document.getElementById("acc_err4").innerHTML="";
			}
			
				
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function rejectit(){
		document.getElementById("suspend_result").innerHTML="";
		document.getElementById("suspend").innerHTML="";
	}
 
 
 function suspend(){
if(confirm("Are you Sure you want to suspend Account")){	 
	document.getElementById("loaders").style.display="block";
	var account=document.getElementById("suspend").value;
	var message=document.getElementById("smessage").value;
	var category=document.getElementById("category").value;
	
	 ajax.open("POST", "suspend.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 31 Oct 1978 14:20:41 ");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				
			 
			alert("Account Suspended Successfully");
			document.getElementById("suspend_result").style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		
		}
	}
	ajax.send("account="+account+"&message="+message+"&category="+category);
}
 }	
 
 function remove_suspend(id){
if(confirm("Are you Sure you want to Re-activate Account")){	 
	document.getElementById("loaders").style.display="block";
	var account=document.getElementById("suspend").value;
	
	 ajax.open("POST", "remove_suspend.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				if(ajax.responseText=="done"){
			 
			alert("Account Re-activated Successfully");
			document.getElementById(id).style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		}
		}
	}
	ajax.send("account="+account);
}
 }	
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}

var acc = document.getElementsByClassName("accordions");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
} 
function opennew(id,but){
	var id=document.getElementById(id);
	var but=document.getElementById(but);
	
	if(id.className=="hide"){
		id.className="show";
		
		but.innerText="Close";
	}else{
		id.className="hide";
		but.innerText="Add New";
	}

	//var acc = document.getElementsByClassName("accordions");
}
function opennewaccount(id,but){
	var id=document.getElementById(id);
	var but=document.getElementById(but);
	
	if(id.className=="hide"){
		id.className="show";
		
		but.innerText="Close";
	}else{
		id.className="hide";
		but.innerText="Add New";
	}

	//var acc = document.getElementsByClassName("accordions");
}

function opennewticket(id,but,post,title){
	var id=document.getElementById(id);
	var but=document.getElementById(but);
	document.getElementById("id").value=post;
	document.getElementById("titles").value=title;
	
	if(id.className=="hide"){
		id.className="show";
		
		but.innerText="Close";
	}else{
		id.className="hide";
		but.innerText="Reply";
	}

	//var acc = document.getElementsByClassName("accordions");
}
function save_email(){	
	document.getElementById("loaders").style.display="block";
	var e_subbject=document.getElementById("e_subbject").value;
	var e_email=document.getElementById("e_email").value;
	//var e_message=document.getElementById("e_message").value;
	var e_account_no=document.getElementById("e_account_no").value;
	var post=document.getElementById("post3").value;
	var data=document.getElementById("data").innerText;
	 ajax.open("POST", "loan_email.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1997 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
		    alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				if(ajax.responseText=="done"){
			 
			alert("Email sent Successfully");
			document.getElementById("email_result").style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		}
		}
	}
	ajax.send("subject="+e_subbject+"&message="+data+"&account="+e_account_no+"&email="+e_email+"&image="+post);
 
 }	
 
 function save_call(){	
	document.getElementById("loaders").style.display="block";
	var c_phone=document.getElementById("c_phone").value;
	var c_message=document.getElementById("c_message").value;
	var c_account_no=document.getElementById("c_account_no").value;
	var c_title=document.getElementById("c_title").value;
	 ajax.open("POST", "loan_call.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				if(ajax.responseText=="done"){
			 
			alert("Call added Successfully");
			document.getElementById("call_result").style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		}
		}
	}
	ajax.send("phone="+c_phone+"&message="+c_message+"&account="+c_account_no+"&title="+c_title);
 
 }	
 
 function save_message(){	
	document.getElementById("loaders").style.display="block";
	var m_title=document.getElementById("m_title").value;
	var m_message=document.getElementById("m_message").value;
	var m_account_no=document.getElementById("m_account_no").value;
	var m_phone=document.getElementById("m_phone").value;
	 ajax.open("POST", "loan_message.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				if(ajax.responseText=="done"){
			 
			alert("Message sent Successfully");
			document.getElementById("message_result").style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		}
		}
	}
	ajax.send("title="+m_title+"&message="+m_message+"&account="+m_account_no+"&phone="+m_phone);
 
 }
	function save_reminder(){	
	document.getElementById("loaders").style.display="block";
	var r_title=document.getElementById("r_title").value;
	var r_message=document.getElementById("r_message").value;
	var r_date=document.getElementById("r_date").value;
	 ajax.open("POST", "loan_reminder.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				if(ajax.responseText=="done"){
			 
			alert("Reminder added Successfully");
			document.getElementById("reminder_result").style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		}
		}
	}
	ajax.send("title="+r_title+"&message="+r_message+"&date="+r_date);
 
 }
  function remove_reminder(id){
	
		document.getElementById("loaders").style.display="block";
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "remove_reminder.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				document.getElementById("loaders").style.display="none";
			
				if(ajax.responseText=="done"){
			 alert("Reminder Removed Successfully");
		//	document.getElementById("reminder_result").style.display="none";
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		
			
		}
		}
	}
	ajax.send("id="+id);
 
 }
 
 function check_email(email,but,inco,account){	
	document.getElementById("loaders").style.display="block";
	var emailid=document.getElementById(email);
	var but=document.getElementById(but).value;
	var inco=document.getElementById(inco);
	
	 ajax.open("POST", "check_email.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Incorrect"){
				inco.innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var email=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			emailid.value=email;
			
			 inco.innerHTML = '';
			
			}
				
				
		}
	}
	ajax.send("type="+account);
 
 }
	
 function check_phone(email,but,inco,account){	
	document.getElementById("loaders").style.display="block";
	var emailid=document.getElementById(email);
	var but=document.getElementById(but).value;
	var inco=document.getElementById(inco);
	
	 ajax.open("POST", "check_phone.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1999 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Incorrect"){
				inco.innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var email=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			emailid.value=email;
			
			 inco.innerHTML = '';
			
			}
				
				
		}
	}
	ajax.send("type="+account);
 
 }	
 
 function confirm_deposit(id,ref){
	
	
	

	var b=document.getElementById("loaders").style.display="block";
	document.getElementById("reject_deposit"+id).innerHTML ="";
	 ajax.open("POST", "confirm_deposit.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 
	  ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			var b=document.getElementById("loaders").style.display="none";	
			
				document.getElementById("confirm_deposit"+id).innerHTML ="Deposit Confirmed";
document.getElementById("reject_deposit"+id).innerHTML ="";
if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}


		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&ref="+ref);
	}
	
	function reject_deposit(id){
	
	//if(confirm("Are you Sure you want to reject the deposit")){
		var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	document.getElementById("confirm_deposit"+id).innerHTML ="";
	 ajax.open("POST", "reject_deposit.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 20 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("reject_deposit"+id).innerHTML ="Deposit Rejected";
document.getElementById("confirm_deposit"+id).innerHTML ="";
if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	//}
 }
 function authorize_deposit(id,account,amount,ref,method){
	
	
	
	var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "authorize_deposit.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="done"){
				document.getElementById("authorize_confirm"+id).innerHTML ="Done";
document.getElementById("authorize_reject"+id).innerHTML ="";
}
if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}

		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&account="+account+"&amount="+amount+"&ref="+ref+"&method="+method);
	}
	
function reply(){	
	document.getElementById("loaders").style.display="block";
	var id=document.getElementById("id").value;
	var post=document.getElementById("post").value;
	var message=document.getElementById("descriptions").value;
	var data=document.getElementById("data2").innerText;

	 ajax.open("POST", "reply_ticket.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			document.getElementById("loaders").style.display="none";
				if(ajax.responseText=="done"){
			 document.getElementById("ticket_result").style.display="none";
			alert("Reply was Successfully");
			if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}
		}
		}
	}
	ajax.send("id="+id+"&post="+post+"&message="+data);
 
 }	
 function refresh(){
 if (document.referrer !== document.location.href) {
   
        document.location.reload();
}
 }
 </script>
 <script type="text/javascript" src="cs/bootstrap.js"></script>
        <script type="text/javascript" src="cs/bootstrap3-typeahead.js"></script>
       <script type="text/javascript" src="cs/app.js"></script>
        
    <script src="cs/summernote.js"></script>
  
   <script type="text/javascript">
        function scroll_to_class(element_class, removed_height) {
            var scroll_to = $(element_class).offset().top - removed_height;
            if($(window).scrollTop() != scroll_to) {
                $('html, body').stop().animate({scrollTop: scroll_to}, 0);
            }
        }

        function bar_progress(progress_line_object, direction) {
            var number_of_steps = progress_line_object.data('number-of-steps');
            var now_value = progress_line_object.data('now-value');
            var new_value = 0;
            if(direction == 'right') {
                new_value = now_value + ( 100 / number_of_steps );
            }
            else if(direction == 'left') {
                new_value = now_value - ( 100 / number_of_steps );
            }
            progress_line_object.attr('style', 'width: ' + new_value + '%;').data('now-value', new_value);
        }

        $(document).ready(function() {

            insertAxises();

            
                $('.f1 fieldset:first').fadeIn('slow');
            


            $('.f1 input[type="text"], .f1 input[type="password"], .f1 select').on('focus', function() {
                $(this).removeClass('input-error');
            });

            // next step
            $('.f1 .btn-next').on('click', function() {
                var parent_fieldset = $(this).parents('fieldset');
                var next_step = true;
                // navigation steps / progress steps
                var current_active_step = $(this).parents('.f1').find('.f1-step.active');
                var progress_line = $(this).parents('.f1').find('.f1-progress-line');

                // fields validation
                parent_fieldset.find('input[type="text"], input[type="password"], input[type="hidden"], select').each(function() {
                    if( $(this).val() == "" && $(this).attr("required") == "required") {
                        $(this).addClass('input-error');
                        next_step = false;
                    } else {
                        $(this).removeClass('input-error');
                    }
                    var value = $(this).val().split(",").join("");
                    if($(this).attr("id") == "price" && isNaN(value)) {
                        $(this).addClass('input-error');
                        next_step = false;
                        alert("Price must be a number e.g 300000 (comma is added for you)")
                    }
                });
                // fields validation

                if( next_step ) {
                    parent_fieldset.fadeOut(400, function() {
                        // change icons
                        current_active_step.removeClass('active').addClass('activated').next().addClass('active');
                        // progress bar
                        bar_progress(progress_line, 'right');
                        // show next step
                        $(this).next().fadeIn();
                        // scroll window to beginning of the form
                        scroll_to_class( $('.f1'), 100 );
                    });
                }
            });

            // previous step
            $('.f1 .btn-previous').on('click', function() {
                // navigation steps / progress steps
                var current_active_step = $(this).parents('.f1').find('.f1-step.active');
                var progress_line = $(this).parents('.f1').find('.f1-progress-line');

                $(this).parents('fieldset').fadeOut(400, function() {
                    // change icons
                    current_active_step.removeClass('active').prev().removeClass('activated').addClass('active');
                    // progress bar
                    bar_progress(progress_line, 'left');
                    // show previous step
                    $(this).prev().fadeIn();this
                    // scroll window to beginning of the form
                    scroll_to_class( $('.f1'), 100 );
                });
            });

            // submit
            $('.f1').on('submit', function(e) {
                // fields validation
                $(this).find('input[type="text"], input[type="password"], select').each(function() {
                    if( $(this).val() == "" && $(this).attr("required") == "required") {
                        e.preventDefault();
                        $(this).addClass('input-error');
                    }
                    else {
                        $(this).removeClass('input-error');
						alert("nofate")
                    }
                });
                // fields validation
            });

            $('#description').summernote();


        });

    </script>


         <script type="text/javascript">

            function hideAlert(){
                $.ajax({
                    type: "POST",
                    url : '/hideAlertModal',
                    complete : function(){
                    }
                });
            }

            $(document).ready(function() {
                //increase the size of post property request panel close button
                $("#alert-panel button.close").css("font-size","35px");
                $("#alert-panel2 button.close").css("font-size","35px");

                

                $('body').on('click', '.radioBtn button', function() {
                    var sel = $(this).data('title');
                    var tog = $(this).data('toggle');
                    $(this).parent().next('.' + tog).prop('value', sel);
                    $(this).parent().find('button[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
                    $(this).parent().find('button[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
                });

                $('.confirm').click(function(e){
                    if(confirm("Are You sure?")){
                        $("#ajaxWait").show();
                        $.ajax({
                            type: "POST",
                            url : $(this).attr("href"),
                            complete : function(){
                                window.location.reload();
                            }
                        });
                    }
                    e.preventDefault();
                });

                $('.confirm2').click(function(e){
                    if(confirm("Are You sure?")){
                        $("#ajaxWait").show();
                        $.ajax({
                            type: "POST",
                            url : $(this).attr("data-href"),
                            success: function(data) {
                                if(data!=="success") {
                                    alert(data);
                                }
                            },
                            complete : function(){
                                window.location.reload();
                            }
                        });
                    }
                    e.preventDefault();
                });

                $("#subscribe-btn").click(function(){
                    $('#info-box').html("");
                    $('#ajaxWait').show();
                    $.ajax({
                        type: 'POST',
                        url: $("#newsletterForm").attr("action"),
                        data: $("#newsletterForm").serialize(),
                        success: function(data) {
                            if(data==="success") {
                                $("#info-box").html("You have successfully subscribed to our home recommendation mailing list");
                            } else {
                                $("#info-box").html(data);
                            }
                            $("#ajaxWait").hide();
                            $('#info-modal').modal('show');
                        }
                    });
                    return false;
                });

                $("a[href='#top']").click(function() {
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                    return false;
                });

                $(window).scroll(function(e) {
                    checkScrollLocation();
                });

                $(window).load(function(e) {
                    checkScrollLocation();
                });

                $(".alert2-btn").click(function(){
                    var valid = true;
                    var form = $(this).parents("form");
                    form.find("input").each(function(){
                        if($(this).val().length === 0 && $(this).attr("required") === "required") {
                            $(this).addClass('error');
                            valid = false;
                        } else {
                            $(this).removeClass('error');
                        }
                    });
                    if(!valid) {
                        alert("Please enter your name and email address");
                        return;
                    }
                    $("#ajaxWait").show();
                    $.ajax({
                        type: 'POST',
                        url: form.attr("action"),
                        data: form.serialize(),
                        success: function(data) {
                            if(data==="success") {
                                alert("You have successfully subscribed");
                            } else if(data==="already") {
                                alert("You have already subscribed to this search");
                            } else {
                                alert(data);
                            }
                            $("#ajaxWait").hide();
                            $('#alert-panel').slideUp();
                        }
                    });
                    return false;
                });

                $('.close-alert-panel').click(function(e){
                    hideAlert();
                    $('#alert-panel').slideUp();
                });

                $('.hide-alert-panel').click(function(e){
                    hideAlert();
                    $('#alert-panel').slideUp();
                });

                $.get('/areas.json', function(data){
                    $(".searchInput").typeahead({ source:data });
                },'json');

                $("#nav-expo img").click(function(e) {
                    window.open('/expo', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
                });

                $("#nav-expo .expo-img span").click(function(e) {
                    $.get( "/hideExpoStrip", function(data) {
                    });
                    $("#nav-expo").slideUp('slow');
                });

                $("#jumiatolet .clicktoread").click(function(e) {
                    window.open('/blog/nigeria-uga-com-ng-acquires-jumia-house-nigeria/', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
                });

                
                    $(".push-header").css("height", "86px");
                

                $("#jumiatolet span").click(function(e) {
                    $.get( "/hideJumiaStrip", function(data) {
                    });
                    $("#jumiatolet").slideUp('slow');
                    $(".push-header").css("height", "50px");
                });


            });

            function checkScrollLocation(){
                scrollTop=$(window).scrollTop();
                intro=$('#brand').height()-70;
                if($("#header-navigation").hasClass('home')){
                    if(scrollTop > intro){
                        $('#header-navigation').fadeIn(500);
                    }
                    else{
                        $('#header-navigation').fadeOut(500);
                    }
                }
            }

            /*******************coverage collapse*******************/
            $('.collapse').on('show.bs.collapse', function (src) {
                $('#search-filter-btn').text('Close Filter');
            });


            $('.collapse').on('hidden.bs.collapse', function (src) {
                $('#search-filter-btn').text('Refine Search');
            });

        </script>
        
   

<script>
		function update(){
				var target=document.getElementById("target").value;
				if(target=="Individual"){
					document.getElementById("results").innerHTML='<input class="form-control" placeholder="Email Address" name="email" type="text" required>';
				}else{
					document.getElementById("results").innerHTML="";
				}
				
			}
			
			function submitForm() {
            //console.log("submit event");
            	var b=document.getElementById("loaders").style.display="block";
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploadd.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                	var b=document.getElementById("loaders").style.display="none";
                $('#result').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#result img').attr('src','../'+data);
				$('#post').val(data);
				
				//alert(data);
				
				
            });
            return false;
        }
		
		function submitForm() {
            //console.log("submit event");
            	var b=document.getElementById("loaders").style.display="block";
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploadd.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                	var b=document.getElementById("loaders").style.display="none";
                $('#result').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#result img').attr('src','../'+data);
				$('#post').val(data);
				
				//alert(data);
				
				
            });
            return false;
        }
		
		$('document').ready(function(){$('#statu_img_but').click(function(){$('#imageresult').load('status_image.php');});}); 
		
			function submitForm2() {
            //console.log("submit event");
            	var b=document.getElementById("loaders").style.display="block";
            var fd = new FormData(document.getElementById("fileinfo2"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploadd.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                	var b=document.getElementById("loaders").style.display="none";
                $('#result2').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#result2 img').attr('src','../'+data);
				var x=$('#post3').val(data);
				
			
				
				
            });
            return false;
        }
		
		$('document').ready(function(){$('#statu_img_but2').click(function(){$('#imageresult2').load('status_image2.php');});}); 
		</script>
</body>
</html>
