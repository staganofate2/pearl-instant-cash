<?php
include"connect.php";
$loan_repay_id=$_POST['loan_repay_id'];
$loan_id=$_POST['loan_id'];
$amount=$_POST['amount'];
$account=$_POST['account'];
$charge=$amount*0.1;


$query="insert into late_repay (loan_id,loan_repay_id,amount,account_no,regdate) values('$loan_id','$loan_repay_id','$charge','$account',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select charges from loan where loan_id='$loan_id'";
$d=mysqli_query($con,$query) or die(mysqli_error($con));
$s=mysqli_fetch_array($d);
$cha=$s['charges'];
$total=$cha+$charge;
$query="update loan set charges='$total' ,charge_status='1' where loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select charged from loan_repay where loan_repay_id ='$loan_repay_id' and charged='1'";
$x=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($x)<1){
	$query="update loan_repay set charged='1' where loan_repay_id='$loan_repay_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
echo "done";
exit();

								?>