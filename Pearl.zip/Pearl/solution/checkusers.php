<?php
include"connect.php";
 $id=$_POST['id'];
$action=$_POST['action'];
if(isset($_POST['action']) && $_POST['action']=="email"){
$query="select phone from registeruser where email_address='$id'";
$result=mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_num_rows($result)>0){
	echo "exists";
	exit();
}else{
    exit();
}

}
if(isset($_POST['action']) && $_POST['action']=="phone"){
$query="select phone from registeruser where phone='$id'";
$result=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($result)>0){
	echo "exists";
	exit();
}else{
exit();
}
}

?>