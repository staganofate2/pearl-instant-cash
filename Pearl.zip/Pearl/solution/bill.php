<?php
include"header.php";
$bar="withdraw";
?>



		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">bill</li>
				
			</ol>
		</div><!--/.row-->
		
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Bill Payment</h2>
					<table><tr><td><img src='' id='picture' width='150px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table>  
				<div id='balance'></div>
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-2 ">
 </div>
  <div class="col-lg-8 ">
                        
	
								
								
			
	<h4 class="page-header">Bill Payment Form</h4>
	<form action="bill_confirm.php" method="POST" enctype="multipart/form-data">

				<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update()"placeholder='Enter Account Number' type="text">
								<span class='danger' id='incorrect'></span>
							</div>
							<div class="form-group">
							<select name="type" class="form-control"  id='type' required="" onchange='updates()'>
						<option value="">----Select Bill Type---</option>
						<option value="gotv">GOTV</option>
						<option value="dstv">DSTV</option>
						<option value="startimes">Startimes</option>
						
						
						</select>
						</div>
						<div id='loaders'></div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Variation Code</span>
						
						<select  name="variation" id='variation' class="form-control" required onchange='update2()' >
						<option value="">Select Variation Code</option>
						</select>
						
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Cable Number</span>
						<input type="text" name="number" class="form-control" placeholder="Cable Number" required=""><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Payment Pin</span>
								<input class="form-control" value="" id='pin' name="pin" type="password"  onblur="checkpin()" required>
								<span class='danger' id='results'></span>
							</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' name="amount" type="text" placeholder='Amount in Digits' onblur="check()" required>
								<span class='danger' id='result'></span>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Convenience fee</span>
								<input class="form-control" value="100" id='commi' name="commi" type="text"  readonly >
								
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Amount</span>
								<input class="form-control" value="" id='total' name="total" type="text"  readonly >
								
							</div>
						<input type="submit" class="btn btn-info " id='submit'value="Pay Now" name="login"> <br>
						
						<div class="clearfix"></div>
					
				
				</form>

	
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<?php include"footer.php" ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function updates(){
	 var type=document.getElementById("type").value;
	 if(type=="gotv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>GOtv Lite N400</option><option value='02'>GOtv value N1250</option><option value='03'>GOtv plus N1900</option><option value='04'>GOtv Max N3200</option>"; 
	 }
	 if(type=="startimes"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>Nova - 900 Naira</option><option value='02'>Basic - 1,300 Naira</option><option value='03'>Smart - 1,900 Naira</option><option value='04'>Classic - 2,600 Naira </option><option value='05'>Unique - 3,800 Naira</option><option value='06'>Super - 3,800 Naira</option>"; 
	 }
	  if(type=="dstv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>DStv Access N2000</option><option value='02'>DStv Family N4000</option><option value='03'>DStv Compact N6,800</option><option value='04'>DStv Compact Plus N10,650</option><option value='05'>DStv Premium N15,800</option><option value='06'>DStv  Premium + HD/Exra View - N18,000</option>"; 
	 }
 }
 function update2(){
	  var type=document.getElementById("type").value;
		 var types=document.getElementById("variation").value;
	 if(type=="gotv" && types=="01"){
	document.getElementById("amount").value="400.00"; 
	document.getElementById("total").value="500.00";
	 }	 if(type=="gotv" && types=="02"){
	document.getElementById("amount").value="1250.00";
document.getElementById("total").value="1350.00";	
	 }	 if(type=="gotv" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="gotv" && types=="04"){
	document.getElementById("amount").value="3200.00"; 
	document.getElementById("total").value="3300.00";
	 }	
	 if(type=="startimes" && types=="01"){
	document.getElementById("amount").value="900.00";
document.getElementById("total").value="1000.00";	
	 }	 if(type=="startimes" && types=="02"){
	document.getElementById("amount").value="1300.00"; 
	document.getElementById("total").value="1400.00";
	 }	 if(type=="startimes" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="startimes" && types=="04"){
	document.getElementById("amount").value="2600.00";
document.getElementById("total").value="2700.00";	
	 }	
	  if(type=="startimes" && types=="05"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	
	 if(type=="startimes" && types=="06"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	


	 if(type=="dstv" && types=="01"){
	document.getElementById("amount").value="2000.00"; 
	document.getElementById("total").value="2100.00";
	 }if(type=="dstv" && types=="02"){
	document.getElementById("amount").value="4000.00";
document.getElementById("total").value="4100.00";	
	 }	 if(type=="dstv" && types=="03"){
	document.getElementById("amount").value="6800.00"; 
	document.getElementById("total").value="6900.00";
	 }	
	  if(type=="dstv" && types=="04"){
	document.getElementById("amount").value="10650.00"; 
	document.getElementById("total").value="10750.00";
	 }	
	 if(type=="dstv" && types=="05"){
	document.getElementById("amount").value="15800.00"; 
	document.getElementById("total").value="15900.00";
	 }	
	 if(type=="dstv" && types=="06"){
	document.getElementById("amount").value="18000.00"; 
	document.getElementById("total").value="18100.00";
	 }	
			 
 }
 function update(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "update4.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
				document.getElementById("balance").innerHTML ="Balance ₦ "+balance;
				document.getElementById("incorrect").innerHTML = '';
			 
			}
		
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	var amounts=amount.replace(reg,""); 
	var account=document.getElementById("account_no").value;
		var b=document.getElementById("loaders").style.display="block";
		//document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
				 var amountt=Number(amounts);
				 var total=amountt+100;
				 alert(total);
				 document.getElementById("total").value =total;
			}
			else{
				document.getElementById("total").value ="";
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts+"&account="+account);
 
 }
 function checkpin(){
	
	var pin=document.getElementById("pin").value;
	
	var account=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("results").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_pin.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
		var b=document.getElementById("loaders").style.display="none";		
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				document.getElementById("results").innerHTML="";
			}
			else{
				
			 
			 document.getElementById("results").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("pin="+pin+"&account="+account);
 
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
		
