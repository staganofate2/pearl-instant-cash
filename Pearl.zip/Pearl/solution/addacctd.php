<?php
session_start();

include"connect.php";


if (!isset($_SESSION['passi'])){
	header("location:index.php");
	exit();
} 

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PEARL ADMIN Dashboard</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	
</head>


<!------------------------top nav------------------------------------------------>

	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>PEARL</span> Admin</a>
				<ul class="nav navbar-top-links navbar-right">
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-envelope"></em><span class="label label-danger">0</span>
					</a>
						
					</li>
					<li class="dropdown"><a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
						<em class="fa fa-bell"></em><span class="label label-info">0</span>
					</a>
						
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
		</nav>
		
		
		<!-------------------------------------the side nav bar here-------------------------------------->
		
		<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li ><a href="dashboard.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<li><a href="addtotal.php"><em class="fa fa-calendar">&nbsp;</em> Add Total Amount</a></li>
			<li ><a href="transd.php"><em class="fa fa-bar-chart">&nbsp;</em> Transaction Details</a></li>
			<li class="active"><a href="addacctd.php"><em class="fa fa-toggle-off">&nbsp;</em> Add Acct Statement</a></li>
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
			
			
		</ul>
	</div><!--/.sidebar-->
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Add account summary/statement</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Add account summary/statement</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-sm-4 ">
                        
				<form role="form" action="" method="POST">
				
<code>
USE THIS FORMAT FOR DESCRIPTION:				
<p>
&ltcenter&gtFund Transfer of $2000 to account 1123657879&ltbr&gt <br> Reference# PEARL/TRNS123564&lt/center&gt

</p>		<br>
</code>		
			<div class="form-group">
								<input class="form-control" placeholder="TRANSACTION DATE (dd-mm-yy)" name="transdate" type="text" autofocus="" required>
							</div>	
							
							<div class="form-group">
								<input class="form-control" placeholder="" name="ref" value="<?php 

$gbotrn="PEARL/TRNS";
$generate=rand(0,5000000);
$transferid=$gbotrn.$generate;
echo $transferid;

								?>" type="text" readonly required>
							</div>	
							
            
							<div class="form-group">
								<textarea class="form-control" rows="5" name="desc" placeholder="Description"></textarea>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="DEBIT" name="debit" type="text" required>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="CREDIT" name="credit" type="text" required>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="ACCOUNT NUMBER" name="acct" type="text" required>
							</div>
							<button class="btn btn-info" type="submit" name="submit">Submit</button>
							
						
				</form>		
						
                      

					  <?php
			 
				 if (isset($_POST['submit'])){

$transdate=$_POST['transdate'];
$refno=$_POST['ref'];
$description=$_POST['desc'];
$deb=$_POST['debit'];
$cre=$_POST['credit'];
$acctnum=$_POST['acct'];


	
		
		$senddata2 = mysqli_query($con,"insert into transact (transaction_date,refno,description,debit,credit,account_number) values
	('".mysqli_real_escape_string($con,$transdate)."','".mysqli_real_escape_string($con,$refno)."','".mysqli_real_escape_string($con,$description)."',
	'".mysqli_real_escape_string($con,$deb)."','".mysqli_real_escape_string($con,$cre)."','".mysqli_real_escape_string($con,$acctnum)."'
	)")or die(mysqli_error()); 
	
				 

	
	if(@$senddata2){
		
	echo"<script>alert('you added an account statement')</script>";
}

else{
echo"<script>alert('An error occured,please try again..')</script>";	
}
	
}
	?>
					  
					  
					  

					  
                    </div>





		
			
			
			
		</div><!--/.row--><br><br>
		
		<div class="col-sm-12">
				<p class="">© 2017 E-Banking. Designed by <a href="../index.php">PEARL</a></p>
			</div>
		
		
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 
		
		
</body>
</html>