<?php include"header.php";
$bar="introducer";
 ?>
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Introducer Link</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href="paid_introducer.php">View Paid Introducer</a></h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">Introducer Details</h4>
	
				   
				
								<div class="col-md-8">
				
				
<?php
$account=$_GET['account'];

	 $query="select* from refer_user where refer_id='$account' and paid='0' and transact='1' order by refer_user_id limit 10";
					$fe=mysqli_query($con,$query) or die(mysqli_error($con));
					
					if(mysqli_num_rows($fe)<1){
						echo "<h3>User  don't have any unpaid Referrer Yet </h3>";
					}else{
						?>
								<div class="col-md-10">
				<h4 class="center">Referal Summary  <?php $query="select count(*) from refer_user where refer_id='$account' and transact='1' and paid='0'";
				$fes=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($fes)>=0){echo "<a href='pay.php?id=$account'>Pay Referral</a>";} ?></h4>
				<table class="table">
				
				<tr>
				<th>Name</th><th>Visit</th><th>Signup</th><th>Transact</th><th>Paid</th><th>Action</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($fe)){
					$query="select firstname,lastname from registeruser where account_number='".$ree['account_no']."'";
					$de=mysqli_query($con,$query) or die(mysqli_error($con));
					$te=mysqli_fetch_array($de);
					?>
				<tr>
				<td><?php echo $te['firstname']." ".$te['lastname'] ?></td><td>Yes</td><td> <?php if($ree['signup']=="1"){echo "Yes";}else{echo "No";} ?></td><td><?php if($ree['transact']=="1"){echo "Yes";}else{echo "No";} ?></td><td><?php if($ree['paid']=="1"){echo "Yes";}else{echo "No";} ?></td><td id="pay_<?php echo  $ree['refer_user_id'] ?>"><div id='loaders'></div><?php if($ree['transact']=="1"){?><button onclick="pay('<?php echo $ree['refer_user_id'] ?>')" >Treat as Paid</button>  <?php
				}
				?></td>
				
				
				</tr>
				<?php
				}
				?>
				
				
				</table>
				
				
				</div>
				<?php
					}
					
				
				?>
				
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>
		
		
	
		
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
		 <!-- DATA TABLE SCRIPTS -->
    <script src="dataTables/jquery.dataTables.js"></script>
    <script src="dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
			 
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			
	
	
	function pay(pid){
	
		var b=document.getElementById("loaders").style.display="block";
	
	//alert(pid);
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_pay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
	
			
				if(ajax.responseText=="done"){
			
			document.getElementById("pay_"+pid).innerHTML="success";
		}
			
		}
		}
	
	ajax.send("id="+pid);
 
 }

    </script>
		
		
</body>
</html>