<?php
session_start();

 $receiver=$_POST['receiver'];
$username=$_POST['sender'];
$message=$_POST['mes'];
include('connect.php');
$q="insert into conversation values(\"\",\"$username\",\"$receiver\",\"chat\")";
$s=mysqli_query($con,$q)or die(mysqli_error($con));
$id=mysqli_insert_id($con);

$query="insert into message values (\"\",\"$username\",\"$id\",\"\",\"$message\",NOW(),\"0\") ";
$result=mysqli_query($con,$query) or die(mysqli_error($con));
if($result>0){
echo"message_sent";
exit();
}
else{
echo "message not sent";
}

?>
