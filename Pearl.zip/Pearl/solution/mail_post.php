<?php
include"connect.php";
$x=$_POST;
//print_r($x);
if(isset($_FILES["file"]["name"])){
$fileName = $_FILES["file"]["name"];
 if($fileName==""){
	// echo "<b style='color:red'>please select a file</b>";
	// exit();
 }else{
 $fileTmpLoc = $_FILES["file"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		$db_file_names="images/$db_file_name";	
	$db_file_name="../images/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_name );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	
		
		
		//	echo $db_file_names;
        }
    }
 else {
    echo "Invalid file";
}
}
}
$message=$_POST['message'];
$image=isset($db_file_names) ? $db_file_names:"";
$subject=mysqli_real_escape_string($con,$_POST['subject']);
$loan_id=$_POST['id'];
//print_r($loan_id);
$query="insert into site_emails (subject,email,message,image,account_no,sent_date) values('$subject','','$message','$image','',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
for($s=0;$s<count($loan_id);$s++){

$query="select account_number, firstname,email_address,lastname from registeruser where registeruser_id='".$loan_id[$s]."'";
	$xx=mysqli_query($con,$query) or die(mysqli_error($con));

		$c=mysqli_fetch_array($xx);
			$firstname=$c['firstname'];
			$lastname=$c['lastname'];
			$email=$c['email_address'];
			$account=$c['account_number'];
			
			//$messages=$message;
			$messagess=htmlentities($message);
			$messagess=nl2br($message);
			
		$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td><h2>From: Pearl Instant Cash</h2></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
//$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/ThuOct17946092019124600048875.jpeg" alt="" width="100%" height="50%"></td></tr>';
if($image!=""){
    $messages.="<img  width='100%' height='200px'src='https://www.pearlinstantcash.com/$image' alt=''>";
			
}
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $messagess</p></td></tr><tr><td><p style='padding-left:10%;border:solid 1px'><a href='https://www.pearlinstantcash.com'> visit our website</a> | <a href='https://www.pearlinstantcash.com/login.php'>log in to your account </a>|<a href='https://www.pearlinstantcash.com/support.php'> get support</a><br>
Copyright &copy; Pearl Instant Cash, All rights reserved. </p></td>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";


$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
			

	
}
echo "done";	
	
exit();
//print_r($x);
?>