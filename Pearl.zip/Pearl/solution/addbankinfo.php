<?php
include"header.php";
$bar="addbankinfo";
$banks=array("044"=>"Access Bank","023"=>"Citibank Nigeria","063"=> "Diamond Bank","050"=>"Ecobank Nigeria","084"=>"Enterprise Bank","070"=>"Fidelity Bank","011"=>"First Bank of Nigeria","214"=>"First City Monument Bank","058"=>"Guaranty Trust Bank","030"=>"Heritage Bank","082"=>"Keystone Bank","014"=>"MainStreet Bank","076"=>"Skye Bank","221"=>"Stanbic IBTC Bank","068"=>"Standard Chartered Bank","232"=>"Sterling Bank","032"=>"Union Bank of Nigeria","033"=>"United Bank For Africa","215"=>"Unity Bank","035"=>"Wema Bank","057"=>"Zenith Bank","other"=>"Others");
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Transaction Details</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Add user bank Account Information</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header">Bank Account Information</h4>
	<?php
				if(isset($_POST['submit'])){
				$account=mysqli_real_escape_string($con,$_POST['acct']);
				
					$account_name = mysqli_real_escape_string($con,$_POST['account_name']);
								$account_number = mysqli_real_escape_string($con,$_POST['account_number']);
								
								
								$bank = mysqli_real_escape_string($con,$_POST['bank']);
								
								
								if($bank=="other"){
								    $code="";
								    $banks="Other";
									$bank=mysqli_real_escape_string($con,$_POST['other']);
									$query = "select* from bank_info where  account_no='$account'";
								$result = mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($result)>0){
									$rows=mysqli_fetch_array($result);
									if($rows['account_number']==$account_number){
								echo $email_err="<h3>Account number already exists</h3>";
								echo"<p><a href='addbankinfo.php'>TRY AGAIN</a></p>";
								}
								elseif($rows['account_name']==$account_name){
								
							
									
								$query="insert into bank_info (account_name,account_number,code,bank_name,account_no) values('$account_name','$account_number','$code',$banks','$account')";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
								
										
										echo "<h3>Bank Account Info added Successfully</h3>";
									}else{
										echo "<h3>different account name is not allowed</h3>";
									}
									}else{
									$query="insert into bank_info (account_name,account_number,code,bank_name,account_no) values('$account_name','$account_number','$code',$banks','$account')";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							
										
										echo "<h3>Bank Account Info added Successfully</h3>";
										
									}
									
								}else{
								    $banks=[$bank];
								    $code="";
								$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/bank/resolve?account_number=$account_number&bank_code=$bank",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4",
    "cache-control: no-cache",
	"Postman-Token: d01ebe5e-e12e-5d34-84f5-1cd54c8e9eb9"
  ),
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  if($x['status']=="true" && $x['message']=="Account number resolved"){
	$account_names=  $x['data']['account_name'];
	$account_numbers=$x['data']['account_number'];
	
	
	?>
	<h4>Account Details</h4>
	<div id='loaders'></div>
	<table class='table'>
	<tr><td>Account Name</td><td><?php echo $account_names ?></td></tr>
	<tr><td>Account Number</td><td><?php echo $account_numbers ?></td></tr>
	<?php /*<tr><td>Bank Name</td><td><?php echo $banks[$bank]; ?></td></tr>*/ ?>
	<tr><td><a href='index.php'>Back</a></td><td id='ress'><button  onclick='updates("<?php echo $account ?>","<?php echo $account_names ?>","<?php echo $account_numbers ?>","<?php echo $bank ?>")'>Proceed</button></td></tr>
	</table>
	<p id='have' style='color:red'></p>
	<?php
	
	
	
  }else{
	 echo "<p>". print_r($x)."</p>";
  }
  
}
								}								
								
								
								
									
	}else{
								
?>
	<form role="form" action="" method="POST">
				

						
						<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Bank Account Name</span>
						<input type="text" name="account_name" class="form-control" placeholder="Account Name" required="">
						</div>
						<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Bank Account Number</span>
						<input type="text" name="account_number" class="form-control" placeholder="Account Number" required="">
						</div>
						<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Bank Name</span>
						<select  name="bank" class="form-control" required="" id='bank'onchange="update()"><option value="">Select Bank</option>
						<?php
						foreach($banks as $key=>$value){
							echo "<option value='$key'>$value</option>";
						}?>
						</select>
						<div id='result'>
						</div>
						</div>
						<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;"> Account Number</span>
						<input type="text" name="acct" class="form-control" placeholder="Account Number" required="">
						</div>
							<button class="btn btn-info" type="submit" name="submit">ADD</button>
							
						
				</form>		
						
				<?php
				}
				?>
			
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
			 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 	
	
			function updates(account,account_name,account_number,bank_name){
	

	
		var b=document.getElementById("loaders").style.display="block";
		//document.getElementById("ress").innerHTML = 'please wait ...';
	 ajax.open("POST", "update_bankinfo.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="done"){
			
				document.getElementById("ress").innerHTML ="Account Added Successfully";
				document.getElementById("have").innerHTML ="Bank Account Info added Successfully";
			}else{
				document.getElementById("have").innerHTML =ajax.responseText;
			}
		 
	  }
	
			
		}
	
	ajax.send("account="+account+"&account_name="+account_name+"&account_number="+account_number+"&bank_name="+bank_name);
	}		
				
				function update(){
				var bank=document.getElementById("bank").value;
if(bank=="other"){
	document.getElementById("result").innerHTML='<br><input type="text" name="other" class="form-control" placeholder="Enter Bank Name" required="">';
}	else{
	document.getElementById("result").innerHTML="";
}			
				}
				</script>
		
		<?php include"footer.php" ?>