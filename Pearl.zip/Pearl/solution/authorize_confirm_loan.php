<?php
session_start();
include_once"connect.php";
$id=$_POST['id'];

$query="select* from loan where authorize='1' and loan_id='$id'";
$k=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($k)<1){
	$query="select* from loan where  loan_id='$id'";
$kk=mysqli_query($con,$query) or die(mysqli_error($con));
	$b=mysqli_fetch_array($kk);
	$duration=$b['loan_duration'];
$total=$b['total'];
$category=$b['category'];
$account=$b['account_no'];
$structure=$b['repayment_plan'];
$interest=$b['interest'];
$interest=str_replace("%","",$interest);
$amount=$b['amount'];
    	$interest=($amount*$interest)/100;
    if($duration=="1 Month"){
$interests=$interest;
		$query="update loan set interest='$interests' where loan_id='$id'";
	if($structure=="Monthly"){
		$amounts=$total;
		for($i=0;$i<1;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x months"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
	}else{
		$amounts=ceil($total/4);
		for($i=0;$i<4;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x weeks"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
		
	}
	
}elseif($duration=="2 Months"){
    $interests=$interest*2;
		$query="update loan set interest='$interests' where loan_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	if($structure=="Monthly"){
		$amounts=ceil($total/2);
		for($i=0;$i<2;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x months"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
	}else{
		$amounts=ceil($total/8);
		for($i=0;$i<8;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x weeks"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
		
	}
	
}elseif($duration=="3 Months"){
	$interests=$interest*3;
		$query="update loan set interest='$interests' where loan_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	if($structure=="Monthly"){
		$amounts=ceil($total/3);
		for($i=0;$i<3;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x months"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
	}else{
		$amounts=ceil($total/12);
		for($i=0;$i<12;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x weeks"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
		
	}
	
}elseif($duration=="4 Months"){
	$interests=$interest*4;
		$query="update loan set interest='$interests' where loan_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	if($structure=="Monthly"){
		$amounts=ceil($total/4);
		for($i=0;$i<4;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x months"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
	}else{
		$amounts=ceil($total/16);
		for($i=0;$i<16;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x weeks"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
		
	}
	
}elseif($duration=="6 Months"){
	$interests=$interest*6;
		$query="update loan set interest='$interests' where loan_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	if($structure=="Monthly"){
		ceil($amounts=$total/6);
		for($i=0;$i<6;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x months"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
	}else{
		$amounts=ceil($total/24);
		for($i=0;$i<24;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x weeks"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
		
	}
	
}elseif($duration=="12 Months"){
	$interests=$interest*12;
		$query="update loan set interest='$interests' where loan_id='$id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	if($structure=="Monthly"){
		$amounts=ceil($total/12);
		for($i=0;$i<12;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x months"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
	}else{
		$amounts=ceil($total/48);
		for($i=0;$i<48;$i++){
			$x=$i+1;
			$date = date("Y-m-d", strtotime(" +$x weeks"));
			$query="insert into loan_repay(loan_id,account_no,pay_date,amount)values('$id','$account','$date','$amounts')";
			mysqli_query($con,$query)or die(mysqli_error($con));
		
		}
		
	}
	
}                    
   
if($duration=="1 Month"){
	  $date = date("Y-m-d", strtotime(" +1 months"));
}elseif($duration=="2 Months"){
	$date = date("Y-m-d", strtotime(" +2 months"));
}elseif($duration=="3 Months"){
	$date = date("Y-m-d", strtotime(" +3 months"));
}elseif($duration=="4 Months"){
	$date = date("Y-m-d", strtotime(" +4 months"));
}elseif($duration=="6 Months"){
	$date = date("Y-m-d", strtotime(" +6 months"));
}elseif($duration=="12 Months"){
	$date = date("Y-m-d", strtotime(" +12 months"));
}


$query="update loan set repay_date='$date',start_date=date(now()),authorize='1' ,collected='1',authorize_user='admin',authorize_date=now(),approved='1' where loan_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select total from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']+$amount;
}
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$ref =rand(100000000,999999999);
$description="$amount was credited into your Loan Account";
$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','$account','$amount','','0','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description=" $amount was credited into your Wallet for Loan Application";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Loan','$account','$amount','','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="insert into statements (packages,packages_id,account_no,credit,debit,balance,refno,description,transaction_date) values('Loan','$id','$account','$amount','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select id from paystackcard where account_no='$account' and paid='1' and remove='0' and authorization_code !='' and active='1'"; 
					$x=mysqli_query($con,$query) or  die(mysqli_error($con));
					if(mysqli_num_rows($x)<1){
					    
					    $query="update paystackcard set active='1' where   account_no='$account' and authorization_code !=''order by id desc limit 1";
					    mysqli_query($con,$query) or die(mysqli_error($con));
					}
				    




$query="select phone,firstname,lastname,email_address  from registeruser where account_number='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$roo=mysqli_fetch_array($de);
$message="Your loan N $amount has been approved and paid into your wallet, check your repayment plan on dates and amount of weekly repayment. ".date('d-m-Y');
$firstname=$roo['firstname'];
$lastname=$roo['lastname'];
$email=$roo['email_address'];
$emessage="<table><tr><td>Date</td><td>".date('d-m-Y')."</td></tr>
<tr><td>Description</td><td> $description</td></tr>
<tr><td>Reference No </td><td>$ref</td></tr>
<tr><td>Wallet Id </td><td>$account</td></tr>
<tr><td>Amount Recieved</td><td>$amount</td></tr>
<tr><td>Balance</td><td>$amounts</td></tr></table>";
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td><h2>From: Pearl Instant Cash</h2></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/ThuOct17946092019124600048875.jpeg" alt="" width="100%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname  $lastname </td></tr>";
$messages .= "<tr><td><p> $emessage</p></td></tr><tr><td><p style='padding-left:10%;border:solid 1px'><a href='https://www.pearlinstantcash.com'> visit our website</a> | <a href='https://www.pearlinstantcash.com/login.php'>log in to your account </a>|<a href='https://www.pearlinstantcash.com/support.php'> get support</a><br>
Copyright &copy; Pearl Instant Cash, All rights reserved. </p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Loan Payment Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


//$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
/*
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
*/
echo "Loan Confirmed Successfully";
}else{
echo "failed";	
}
?>
	