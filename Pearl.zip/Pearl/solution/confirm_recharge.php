<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$query="update recharge set status='1' ,sender='{$_SESSION['confirm']}',sent_date=now() where recharge_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
?>