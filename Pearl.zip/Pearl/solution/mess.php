<?php 
session_start() ;
include"connect.php";
$receiver=$_POST['receiver'];

 
  
  $query2="select con.conversation_id,con.contype,con.userone,con.usertwo,m.image,m.message_id,m.message,m.mdate,m.sender from message m inner join conversation con using(conversation_id)where con.userone='$receiver' and con.usertwo='admin' or con.userone='admin' and con.usertwo='$receiver'" ;
 $result5=mysqli_query($con,$query2)or die(mysqli_error($con));
 if(mysqli_num_rows($result5)==0){
 echo "There is no conversation yet Between you and ".$receiver;
 }
 echo "<table class='table'>";
while($row= mysqli_fetch_array($result5)){
if($row['sender']==$receiver){
	$query="select firstname,lastname from registeruser where account_number='".$row['sender']."'";
	$aq=mysqli_query($con,$query)or die(mysqli_error($con));
	$x=mysqli_fetch_array($aq);
echo "<tr><td id='lt'><b style='color:green'>".$x['firstname']." ".$x['lastname']." </b><span class='date'> ".$row['mdate']."</span><br><span style='color:orange;margin-left:30px'><p>"; if($row['image']!=""){?><a href='moreimg.php?id=".$row['message_id']."'><img src='../".$row['image']."' alt='' width='120px' height='100px'></a><?php 
} echo "</p>".$row['message']."</span></td></tr>";
}
else {
echo "<tr><td id='rt' align='right'><b style='margin:25px'>".$row['sender']."</b><br><span style='color:orange'>".$row['message']."</span></td></tr>";
}
 $query="update message set red='1' where message_id='".$row['message_id']."' and sender !='admin'";
 mysqli_query($con,$query)or die(mysqli_error($con));
}
echo "</table>";
?>
