<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$types=$_POST['types'];
$types_id=$_POST['types_id'];
if($types=="Recharge"){
	
	$query="select* from recharge  where  recharge_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$amount=$e['amount'];

	$network=$e['code'];
	$query="update control set sent='1' , sent_date=now() where  control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

$http="https://mobileairtimeng.com/httpapi/?userid=08107302391&pass=912363232d306466ae2a1&network=$network&phone=$phone&amt=$amount&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
  //print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
							$query="update recharge set status='1', sent_date=now() where   recharge_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
										//echo "done";
										echo "<script>window.location='transaction.php'</script>";
exit();
									
} else{
	
											echo "Failed";
												exit();
										
}									
}

}
	
	
	
}elseif($types=="Bill"){
	$query="select* from bill where  bill_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$amount=$e['variation'];
	$name=$e['name'];
	$type=$e['types'];
	$cnumber=$e['cnumber'];
	$invoice=$e['invoice'];

	$number=$e['numbers'];
	$query="update control set sent='1' where   control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

if($type=="startimes"){

$http="https://mobileairtimeng.com/httpapi/startimes?userid=08107302391&pass=2513935&phone=$phone&amt=$amount&smartno=$number&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){
	$query="update bill set sent='1' , sent_date=now() where  bill_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
							
									
									//	echo "done";
										echo "<script>window.location='transaction.php'</script>";
exit();
										
	}else{
											echo "Failed !!!";
												exit();
										}
}
			}else{


$http="https://mobileairtimeng.com/httpapi/multichoice?userid=08107302391&pass=2513935&phone=$phone&amt=$amount&smartno=$number&customer=$name&invoice=$invoice&billtype=$type&customernumber=$cnumber&jsn=json";


// Get cURL resource
 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);


if($x['code']=="100"){				
							
									$query="update bill set sent='1' , sent_date=now() where    bill_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
									//	echo "done";
										echo "<script>window.location='transaction.php'</script>";
exit();
										
	}else{
											echo "failed";
												exit();
										}
}



			}
}
	
	
	
}elseif($types=="Data"){
	

$query="select* from datas  where  datas_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$variation=$e['amount'];

	$network=$e['code'];
	$query="update control set sent='1' where   control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

$http="https://mobileairtimeng.com/httpapi/datatopup.php?userid=08107302391&pass=912363232d306466ae2a1&network=$network&phone=$phone&amt=$variation&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 // print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
						
	
									//	echo "done";
										echo "<script>window.location='transaction.php'</script>";
exit();
} else{
	
											echo "Failed";
												exit();
										
}									
}
}
	
}elseif($types=="SMS"){
	
	$query="select* from sms  where  sms_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$phone=$e['phone'];
	$message=$e['message'];
	$sender=$e['sender'];
	$query="update control set sent='1' where  control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));

$message=urlencode($message);				


 $http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);


if(strstr( $resp,"OK" )!=""){
	$query="update sms set sent='1' , sent_date=now() where     sms_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
							
										//echo "done";
										echo "<script>window.location='transaction.php'</script>";
exit();
}else{
	
											echo "failed";
												exit();
										
}									
									
	}
	
}
elseif($types=="Withdraw"){
	

$query="select* from withdraw  where  withdraw_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$amount=$e['amount'];
	$amounts=$e['balance'];
	$account=$e['account_no'];
	$amt=$amount;
	$ref=$e['ref_no'];
	$query="select balance from control  where  control_id='$id'";
$dee=mysqli_query($con,$query) or die(mysqli_error($con));
$c=mysqli_fetch_array($dee);
$amounts=$c['balance'];

				$query="select* from bank_info where account_no='$account'";
$s=mysqli_query($con,$query) or die(mysqli_error($con));
$d=mysqli_fetch_array($s);

$account_number=$d['account_number'];
$code=$d['code'];
 $amountt=$amount."00";
$query="select firstname from registeruser where account_number='$account'";
$se=mysqli_query($con,$query) or die(mysqli_error($con));
$de=mysqli_fetch_array($se);

$name=$de['firstname'];
//Set other parameters as keys in the $postdata array
$postdata =  array('type' => 'nuban', 'name' => "$name","description" =>"Account Transfer","account_number" => "$account_number","bank_code"=> "$code","currency"=> "NGN");
   
$url = "https://api.paystack.co/transferrecipient";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  //print_r($x);
//Use the $result array to get redirect URL




$recipient=$x['data']['recipient_code'];//$re['recipient'];
}
//$amount=$re['amount'];
//Set other parameters as keys in the $postdata array
$postdata =  array("source"=>"balance", "reason"=>"transfer", "amount"=>"$amountt", "recipient" =>"$recipient");
   
$url = "https://api.paystack.co/transfer";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  //print_r($x);
  
// echo "<h3>".$x['message']."</h3>";
//Use the $result array to get redirect URL
if($x['status']=="1"){
    $query="update control set sent='1' where  control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
$query="update withdraw set paid='1' ,paid_date=now() where   account_no='$account' and withdraw_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$amount was Debited from your  Account";
	$message="Your $amount  Account Withdrawal has been Confirmed";
	
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Withdrawal','$account')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="select phone,firstname,lastname,email_address from registeruser where account_number='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$roo=mysqli_fetch_array($de);
$emessage="<table><tr><td>Date</td><td>".date('d-m-Y')."</td></tr>
<tr><td>Description</td><td> $description</td></tr>
<tr><td>Reference No </td><td>$ref</td></tr>
<tr><td>Wallet Id </td><td>$account</td></tr>
<tr><td>Amount</td><td>N$amount</td></tr>
<tr><td>Balance</td><td>N$amounts</td></tr></table>";
$fisrtname=$roo['firstname'];
$lastname=$roo['lastname'];
$email=$roo['email_address'];
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td><h2>From: Pearl Instant Cash</h2></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/ThuOct17946092019124600048875.jpeg" alt="" width="100%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong> $firstname $lastname</td></tr>";
$messages .= "<tr><td><p> $emessage</p></td></tr><tr><td><p style='padding-left:10%;border:solid 1px'><a href='https://www.pearlinstantcash.com'> visit our website</a> | <a href='https://www.pearlinstantcash.com/login.php'>log in to your account </a>|<a href='https://www.pearlinstantcash.com/support.php'> get support</a><br>
Copyright &copy; Pearl Instant Cash, All rights reserved. </p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


/*$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);*/
echo "<script>window.location='transaction.php'</script>";
exit();
}


}
			


										
}
}

elseif($types=="Transfer"){
	

$query="select* from transfer  where  transfer_id='$types_id'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$e=mysqli_fetch_array($de);
	$account=$e['account_no'];
	$amount=$e['amount'];
	$amounts=$e['balance'];
	$amt=$amount;
	$ref=$e['ref_no'];
$amount=$amount."00";
$query="select balance from control  where  control_id='$id'";
$dee=mysqli_query($con,$query) or die(mysqli_error($con));
$c=mysqli_fetch_array($dee);
$amounts=$c['balance'];

$query="select firstname from registeruser where account_number='$account'";
$se=mysqli_query($con,$query) or die(mysqli_error($con));
$de=mysqli_fetch_array($se);

$name=$de['firstname'];
//Set other parameters as keys in the $postdata array
$postdata =  array('type' => 'nuban', 'name' => "$name","description" =>"Account Transfer","account_number" => "$account_number","bank_code"=> "$code","currency"=> "NGN");
   
$url = "https://api.paystack.co/transferrecipient";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
 // print_r($x);
//Use the $result array to get redirect URL




$recipient=$x['data']['recipient_code'];//$re['recipient'];
//$amount=$re['amount'];
//Set other parameters as keys in the $postdata array
}
$postdata =  array("source"=>"balance", "reason"=>"transfer", "amount"=>"$amount", "recipient" =>"$recipient");
   
$url = "https://api.paystack.co/transfer";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
  
// echo "<h3>".$x['message']."</h3>";
//Use the $result array to get redirect URL

if($x['status']=="1"){


	$query="update control set sent='1' where  control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));


$description="$amount was Debited from your  Account";
$query="select phone,firstname,lastname,email_address from registeruser where account_number='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$roo=mysqli_fetch_array($de);
$emessage="<table><tr><td>Date</td><td>".date('d-m-Y')."</td></tr>
<tr><td>Description</td><td> $description</td></tr>
<tr><td>Reference No </td><td>$ref</td></tr>
<tr><td>Wallet Id </td><td>$account</td></tr>
<tr><td>Amount</td><td>N$amount</td></tr>
<tr><td>Balance</td><td>N$amounts</td></tr></table>";
$fisrtname=$roo['firstname'];
$lastname=$roo['lastname'];
$email=$roo['email_address'];
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/bankl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong> $firstname $lastname</td></tr>";
$messages .= "<tr><td><p> $emessage</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Transfer Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


/*$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);*/

	$query="update control set sent='1' where  control_id='$id' and packages_id='$types_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo "<script>window.location='transaction.php'</script>";
exit();
	
}

}
	
}
}
?>