<?php
include"header.php";
$bar="food";
?>
		
<style>
.img-responsive {
	width:100px;
	height:100px;
}
</style>		
		<?php include "sidebar.php"; ?>
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Food Account Form</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
		<div class="col-lg-2">
		
 <table><tr><td><img src='' id='picture' width='155px' alt=''></td></tr><tr><td><b id='first'></b></td></tr><tr><td><b id='last'></b></td> </tr> </table>   	

		</div>
			<div class="col-lg-8">
			<h3><span id='balance'></span></h3>
			<?php
				if(isset($_POST['change'])){
					
					$structure=$_POST['structure'];
					$account=$_POST['account_no'];
					$type=$_POST['type'];
					$amount=$_POST['amount'];
					$duration=$_POST['duration'];
					$mdate=$_POST['mdate'];
					$due=$_POST['due'];
					$items=$_POST['items'];
					$query="select active from food where package_name='$type' and active='0' and account_no='$account'";
					$qwe=mysqli_query($con,$query) or die(mysqli_error($con));
					if(mysqli_num_rows($qwe)>0){
						echo "<h3> Please you have an Active $type Account.<br>Choose a Different Account </h3>";
					}else{
					$query="insert into food (package_name,payment_structure,duration,maturity_date,due_amount,total,items,account_no,start_date,regdate) values('$type','$structure','$duration','$mdate','$due','$amount','$items','$account',date(now()),now())";
					
					mysqli_query($con,$query)or die(mysqli_error($con));
					$id=mysqli_insert_id($con);
					
echo "<h3>Your Food Account has been created Successfully</h3>";
echo "<h4>Date of Contributions </h4>";
	echo "<table class='table'>";
	echo "<tr><th>Dates</th><th>Amount</th></tr>";
if($type=="Legend"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<6;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','2000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 2000</td></tr>";
		}
	}else{
		for($i=0;$i<24;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','500')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 500</td></tr>";
		}
		
	}
	
}    
   elseif($type=="Prince"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<4;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','4000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 4000</td></tr>";
		}
	}else{
		for($i=0;$i<16;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','1000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 1000</td></tr>";
		}
		
	}
	
}    
elseif($type=="Emirate"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','6000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 6000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','1500')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 1500</td></tr>";
		}
		
	}
	
}
elseif($type=="Standard"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','10000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 10000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','2500')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 2500</td></tr>";
		}
		
	}
	
}  
elseif($type=="Concorde"){
	
	if($structure=="Monthly"){
		
			for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','12000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 12000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','3000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 3000</td></tr>";
		}
		
	}
	
}
elseif($type=="Global"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<2;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','20000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 20000</td></tr>";
		}
	}else{
		for($i=0;$i<8;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','5000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 5000</td></tr>";
		}
		
	}
	
}
elseif($type=="Rock"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','12000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 12000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','3000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 3000</td></tr>";
		}
		
	}
	
} 
elseif($type=="Golden"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','10000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 10000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','2500')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 2500</td></tr>";
		}
		
	}
	
}  
elseif($type=="Silver"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','8000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 8000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','2000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 2000</td></tr>";
		}
		
	}
	
}
elseif($type=="King"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','6000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 6000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','1500')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 1500</td></tr>";
		}
		
	}
	
}
elseif($type=="Genesis"){
	
	if($structure=="Monthly"){
		
		for($i=0;$i<3;$i++){
			$date = date("Y-m-d", strtotime(" +$i months"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','4000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 4000</td></tr>";
		}
	}else{
		for($i=0;$i<12;$i++){
			$date = date("Y-m-d", strtotime(" +$i weeks"));
			$query="insert into food_pay(food_id,account_no,pay_date,amount)values('$id','$account','$date','1000')";
			mysqli_query($con,$query)or die(mysqli_error($con));
			echo "<tr><td>$date</td><td>₦ 1000</td></tr>";
		}
		
	}
	
}
echo '</table>';                                        
				}
				}else{
				?>
			   
				<h4 class="page-header">Food Account Registration Form</h4>
				<form action="" method="POST" enctype="multipart/form-data">
	<div class="form-group">
								<input class="form-control" id='account_no' name="account_no" onblur="update2()"placeholder='Enter Account Number' type="text">
							<span id='incorrect'></span>
							</div>
				<div class="form-group">
								<select name='structure' id='structure' class="form-control">
								<option   value="">Select Payment Structure</option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
								<div id='loaders'></div>
							
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update()">
								<option   value="">Select Package Plan</option>
								<option   value="Genesis">Genesis</option>
								<option   value="Legend">Legend</option>
								<option   value="Prince">Prince</option>
								<option   value="Emirate">Emirate</option>
								<option   value="King">King</option>
								<option   value="Silver">Silver</option>
								<option   value="Golden">Golden</option>
								<option   value="Standard">Standard</option>
								<option   value="Concorde">Concorde</option>
								<option   value="Rock">Rock</option>
								<option   value="Global">Global</option>
								</select>
								<span id='result'></span>
							</div>
							
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Monthly Duration</span>
								<input class="form-control" id='duration' name="duration" placeholder='Duration' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Due Amount</span>
								<input class="form-control" id='due' name="due" placeholder='Total Due Amount' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Amount</span>
								<input class="form-control" id='amount' name="amount" placeholder='Total Contribution Amount' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Maturity Date</span>
								<input class="form-control" value="" id='mdate' name="mdate" type="text" placeholder='Maturity Date' readonly>
							
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">List of Items</span>
								<div id='list'></div>
							
							</div>
							<input type='hidden' name='items' id='items'>
							
							<button class="btn btn-info" name="change" type="submit">SUBMIT</button>
				
				</form>
				
			
				<?php
				}
				?>
				
				</div>
				
				
				
	 
	<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
 
 
 
 		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("actype").value;
	var structure=document.getElementById("structure").value;
	if(types=="Rock"){
		var type="3";
	}
	else if(types=="Golden"){
		var type="3";
	}
	else if(types=="Silver"){
		var type="3";
	}
	else if(types=="King"){
		var type="3";
	}
	else if(types=="Genesis"){
		var type="3";
	}
	else if(types=="Legend"){
		var type="6";
	}
	else if(types=="Prince"){
		var type="4";
	}
	else if(types=="Emirate"){
		var type="3";
	}
	else if(types=="Standard"){
		var type="3";
	}
	else if(types=="Concorde"){
		var type="3";
	}
	else if(types=="Global"){
		var type="2 ";
	}
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "date.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			var b=document.getElementById("loaders").style.display="none";
				document.getElementById("mdate").value = ajax.responseText;
			 var data=ajax.responseText.split("/");
			 
			if(types=="Legend"){
				if(structure=="Monthly"){
					document.getElementById("due").value="2000";
								}
								else{
									document.getElementById("due").value="500";
								}
		  document.getElementById("duration").value="6 Months";
		  
		  
		  document.getElementById("amount").value="12000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 quarter bag of rice</li><li>1 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 pack of Idomitable</li><li>1 carton of Amstel</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li></ul>";
		  document.getElementById("items").value="<ul><li>1 quarter bag of rice</li><li>1 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 pack of Idomitable</li><li>1 carton of Amstel</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li></ul>";
		  
	  }
	  else if(types=="Emirate"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 carton of Idomitable</li><li>1 c. constade</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 carton of Idomitable</li><li>1 c. constade</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  
	  }
	    else if(types=="Prince"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="4000";
								}
								else{
									document.getElementById("due").value="1000";
								}
		  document.getElementById("duration").value="4 Months";
		  
		  
		  document.getElementById("amount").value="16000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  
	  }
	   else if(types=="Emirate"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li></ul>"
		  
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li></ul>"
		  
	  }
	   else if(types=="Standard"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="10000";
								}
								else{
									document.getElementById("due").value="2500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="30000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of Tomatoes small</li><li>1 omo big sachet</li><li>1 pack of Coke</li></ul>"
		 document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of Tomatoes small</li><li>1 omo big sachet</li><li>1 pack of Coke</li></ul>"
		  
	  }
	   else if(types=="Concorde"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="12000";
								}
								else{
									document.getElementById("due").value="3000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="36000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 full bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 omo big sachet</li></ul>"
		  document.getElementById("items").value="<ul><li>1 full bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 omo big sachet</li></ul>"
		  
	  }
	  
	  
	   else if(types=="Global"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="20000";
								}
								else{
									document.getElementById("due").value="5000";
								}
		  document.getElementById("duration").value="2 Months";
		  
		  
		  document.getElementById("amount").value="40000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 full bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of small tin Tomatoes</li><li>1 omo big sachet</li><li>1 super pack of Noodles</li><li>2 rolls of tissue</li></ul>"
		 document.getElementById("items").value="<ul><li>1 full bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of small tin Tomatoes</li><li>1 omo big sachet</li><li>1 super pack of Noodles</li><li>2 rolls of tissue</li></ul>"
		   
	  }
	  
	   else if(types=="Rock"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="12000";
								}
								else{
									document.getElementById("due").value="3000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="36000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		   
	  }
	   else if(types=="Golden"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="10000";
								}
								else{
									document.getElementById("due").value="2500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="30000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, Tummy Tummy</li></ul>"
		document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, Tummy Tummy</li></ul>"
		    
	  }
	   else if(types=="Silver"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="24000";
								}
								else{
									document.getElementById("due").value="2000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="24000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 2 litre of  groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, 1/12 carton malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 2 litre of  groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, 1/12 carton malt</li></ul>"
		  
	  }
	  
	   else if(types=="King"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 quarter bag of rice</li><li>1 small  groundnut oil </li><li>Idomitable </li><li>1 small powdered milk</li><li>1 small powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1 quarter bag of rice</li><li>1 small  groundnut oil </li><li>Idomitable </li><li>1 small powdered milk</li><li>1 small powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, malt</li></ul>"
		  
	  }
	   else if(types=="Genesis"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="4000";
								}
								else{
									document.getElementById("due").value="1000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="12000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		  document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		  
	  }
	  
	  	document.getElementById("result").innerHTML = '';
			
		}
	}
	ajax.send("month="+type);
 
 }
 function update2(){
	
	var types=document.getElementById("account_no").value;
	var b=document.getElementById("loaders").style.display="block";
	//document.getElementById("incorrect").innerHTML = 'please wait ...';
	 ajax.open("POST", "updatee.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="Incorrect"){
				document.getElementById("incorrect").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
				
			var data=ajax.responseText.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			var balance=data[3];
	
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			document.getElementById("balance").innerHTML="Balance ₦ "+balance;
			
		document.getElementById("incorrect").innerHTML = '';
			}
			
				
		}
	}
	ajax.send("type="+types);
 
 }
  
  </script>	

	<?php include "footer.php"; ?>