<?php include"header.php";
$bar="view_loan"; ?>
		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Transaction Details</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Charged Loan</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
	<h4 class="page-header">All  Charged Loans</h4>
	<div class="panel-body">
	 <div id='loaders'></div>
                           <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Date</th><th>Late Charges</th><th>Duration</th><th>Interest</th><th>Amount</th><th>Total Amount</th><th>Amount Paid</th><th>Ref NO</th><th>Payment Date</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from loan where paid='0' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						 $query="select* from loan_repay where loan_id='".$ree['loan_id']."' and  datediff('".date("Y-m-d")."',pay_date)>'3' and paid='0' and charged='1'";
						$result=mysqli_query($con,$query);
						if(mysqli_num_rows($result)<1){
							continue;
						}
						$query="select sum(amount) as a from loan_repay where loan_id='".$ree['loan_id']."' and paid='0'";
						$xx=mysqli_query($con,$query) or die(mysqli_error($con));
						$e=mysqli_fetch_array($xx); 
					?>
				<tr>
				<td><?php echo $ree['account_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td>₦<?php echo $ree['charges']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td>₦<?php echo $ree['total'] ?></td><td>₦<?php echo $ree['deposit'] ?></td><td><?php echo $ree['ref_no'] ?></td><td>
				<table class='table'><?php while($dee=mysqli_fetch_array($result)){echo "<tr><td>".$dee['pay_date']."</td><td> ".$dee['amount']."</td>"; ?><td id='charge<?php echo $dee['loan_repay_id']?>'> <?php if ($dee['charged']=="1" && $dee['removed']=='0'){ ?>
				<button onclick='charge("<?php echo $ree['loan_id']?>","<?php echo $dee['loan_repay_id']?>","<?php echo $ree['account_no']?>","<?php echo $dee['amount']?>","<?php echo $dee['loan_repay_id']?>")'>Remove Charge</button>
				<?php
				}
				?>
				</td></tr> <?php } ?></table></td>
				
				
				</tr>
				<?php
					}  
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>





		
			
			
			
		</div><!--/.row-->
		
		<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
		 function charge(loan_id,loan_repay_id,account,amount,id){
	
	
	
	var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "remove_charge.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="done"){
				document.getElementById("charge"+id).innerHTML ="Charge was Successful";

}
if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}

		 
	  }
	
			
		}
	
	ajax.send("loan_id="+loan_id+"&loan_repay_id="+loan_repay_id+"&amount="+amount+"&account="+account);
	}
	 function charge_monthly(loan_id,account,amount,id){
	
	
	
	var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "charge_monthly.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-store");
	 ajax.setRequestHeader("Expires","Fri, 30 Oct 1998 14:19:41 GMT");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="done"){
				document.getElementById("charge_monthly"+id).innerHTML ="Charge was Successful";

}
if (document.referrer !== document.location.href) {
    setTimeout(function() {
        document.location.reload()
  }, 2000);
}

		 
	  }
	
			
		}
	
	ajax.send("loan_id="+loan_id+"&account="+account);
	}
		</script>
		
		<?php include"footer.php" ?>