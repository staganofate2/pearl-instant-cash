<?php
session_start();
include"connect.php";
$id=$_POST['id'];
$ref=$_POST['ref'];
$account=$_POST['account'];
$query="select amount,deposit_id from paystackthree where id='$id' and account_no='$account' and confirmed='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$rea=mysqli_fetch_array($de);
$amount=$rea['amount'];
$depositid=$rea['deposit_id'];
$query="select total,category from wallet where account_no='$account'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);

	$amounts=($rows['total']+$amount);

	
$query="update wallet set total='$amounts' where account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="update paystackthree set confirmed='1'  , sent_date=now() where id='$id' and account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update deposit set confirmed='1',total='$amount',confirm='1', confirm_user='admin', authorize_user='admin',authorize='1' where deposit_id='$depositid' and account_no='$account'";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was Credited to your Wallet Account ";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','$account','$amount','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select phone,firstname,lastname,email_address from registeruser where account_number='$account'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$roo=mysqli_fetch_array($de);
$message="Your Deposit of  N $amount has been confirmed and your money has been paid into your Wallet. Balance : N $amounts ".date('d-m-Y');
$firstname=$roo['firstname'];
$lastname=$roo['lastname'];
$email=$roo['email_address'];
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/bankl.png" alt="" width="50%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}

$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendfastmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
   $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);





echo "done";
}
}else{
	echo "Incorrect";
}
?>