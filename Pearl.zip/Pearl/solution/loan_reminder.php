<?php
include"connect.php";
$title=$_POST['title'];
$date=$_POST['date'];
$message=$_POST['message'];
$query="insert into loan_reminder (title,message,remind_date,postdate) values('$title','$message','$date',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";
exit();
?>