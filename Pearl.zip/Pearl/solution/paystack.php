<?php
include"header.php";
$bar="view_deposit";
?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Paystack one</li>
				
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header"><a href="paystack_confirmed.php">View Completed Payment</a></h2>
				
				</div>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Payment Details</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-12 ">
                        
						
	<h4 class="page-header">All Payment</h4>
	<div id='loaders'></div>
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Account No</th><th>Amount</th><th>Ref NO</th><th>Reg Date</th><th> Sent Date</th><th>Action</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from paystack where confirmed='0'  and rejected='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td> <?php echo $ree['account_no'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td><?php echo $ree['ref_no'] ?></td><td><?php echo $ree['regdate'] ?></td><td><?php echo $ree['sent_date'] ?></td><td id="confirm<?php echo $ree['id'] ?>"><button  onclick='update("<?php echo $ree['id'] ?>","<?php echo $ree['account_no'] ?>","<?php echo $ree['ref_no'] ?>")'>Update</button></td><td id="reject<?php echo $ree['id'] ?>"><button  onclick='reject("<?php echo $ree['id'] ?>")'>Reject</button></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		</div><!--/.row-->
		<script>
            
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function update(id,account,ref){
	
	
	
var b=document.getElementById("loaders").style.display="block";//	document.getElementById("confirm"+id).innerHTML = 'please wait ...';
	 ajax.open("POST", "confirm_paystack.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			var b=document.getElementById("loaders").style.display="none";
				document.getElementById("confirm"+id).innerHTML ="Payment Confirmed";


		 
	  }
	
			
		}
	
	ajax.send("id="+id+"&account="+account+"&ref="+ref);
	}
	
		function reject(id){
	
	if(confirm("Are you Sure you want to reject the Payment")){
		var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	document.getElementById("confirm"+id).innerHTML ="";
	 ajax.open("POST", "reject_paystack.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("reject"+id).innerHTML ="Payment Rejected";
document.getElementById("confirm"+id).innerHTML ="";

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
 }

    </script>
		<?php include"footer.php" ?>