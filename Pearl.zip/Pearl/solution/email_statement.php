<?php
include"header.php";
$bar="dashboard";
 
						$account=$_GET['account'];
						$limit=$_GET['limit'];
						$querys="select (@row_number :=@row_number +1) as num,transaction_date,refno,description,debit,credit,balance,remark,packages from statements,(select @row_number:=0) as t where account_no='$account' $limit";
						$q="select email_address from registeruser where account_number='$account'";
						$w=mysqli_query($con,$q)or die(mysqli_error($con));
						$c=mysqli_fetch_array($w);
					
						
?>

        
 <?php include"sidebar.php" ?>       
<!--
        <link rel="icon" type="image/ico" href="assets/image/logo2.png">

        <link rel="stylesheet" href="cs/bootstrap.css" type="text/css">
        <link rel="stylesheet" href="cs/font-awesome.css" type="text/css">
        <link rel="stylesheet" href="cs/style.css" type="text/css">

        <link href="css/cs.css" rel="stylesheet" type="text/css">

        
    <link href="css/summernote.css" rel="stylesheet">-->
    


       
        

  
       
        

    
        
     <!--   <div class="container">
            <div class="row">
            
    <div class="col-md-10 col-md-offset-1">-->
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active"> Email Statement</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Email Statement</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		

 <div class="col-lg-8 ">
 <h4 class="page-header">Email Statement Send Form</h4>
 <?php
				if(isset($_POST['submit'])){
				$subject=mysqli_real_escape_string($con,$_POST['subject']);
				$email=mysqli_real_escape_string($con,$_POST['email']);
				
				
				
			
		
				$messages="<h3>";
				$query="select firstname,lastname,middlename  from registeruser  where account_number='$account'";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$w=mysqli_fetch_array($res4); $messages.=$w['firstname']." ".$w['lastname']." ".$w['middlename']."<span style=\'margin-left:5%\'>Wallet ID : $account</span>";}
				$messages.="</h3>
						<table class=\"table\">
				
				
				<tr>
				<td>Total Deposit</td><td>₦ "; $query="select sum(total) as total from deposit where account_no='$account' and authorize='1'";
				$res=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){$we=mysqli_fetch_array($res);$messages.= $we['total'];}else{ $messages.= "0";} 
				$messages.="</td>
				
				
			
				
				<td>Total Bonus</td><td>₦ "; $query="select sum(bonus) as total from deposit where account_no='$account'";
				$res=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){$we=mysqli_fetch_array($res); $messages.= $we['total'];}else{$messages.= "0";} 
				$messages.="</td>
				
				</tr>
				<tr>
				
				<td>Total Withdraw</td><td>₦ "; $query="select sum(total) as total from withdraw where account_no='$account' ";
				$res2=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res2)>0){$we2=mysqli_fetch_array($res2); $messages.= $we2['total'];}else{$messages.= "0";}
				$messages.="</td><td>Total Bill Payment</td><td>₦ "; $query="select sum(total) as total from bill where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); $messages.=$we4['total'];}else{$messages.="0";}
				$messages.="</td>				
				</tr>
				<tr>
				<td>Total Bank Transfer</td><td>₦ "; $query="select sum(total) as total from transfer where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); $messages.= $we4['total'];}else{$messages.="0";}$messages.="</td>
				
				
				
				<td>Total Recharge Card</td><td>₦ "; $query="select sum(total) as total from recharge where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); $messages.= $we4['total'];}else{ $messages.= "0";}
				$messages.="</td></tr>
				<tr>				
				<td>Total Data Recharge </td><td>₦ "; $query="select sum(total) as total from datas where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); $messages.= $we4['total'];}else{$messages.= "0";}
				$messages.="</td>				
				<td>Total SMS</td><td>₦ "; $query="select sum(total) as total from sms where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); $messages.= $we4['total'];}else{$messages.="0";}
				$messages.="</td>		
				</tr>
			
				<tr>
				<td>Total Sent Wallet Transfer </td><td>₦"; $query="select sum(debit) as total from wallet_transact where account_no='$account' and packages='Wallet_transfer' and types='sent'";
				$res5=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res5)>0){$we5=mysqli_fetch_array($res5); $messages.= $we5['total'];}else{$messages.= "0";}
				$messages.="</td>
				
				
				
				<td>Total Recieved Wallet Transfer </td><td>₦ "; $query="select sum(credit) as total from wallet_transact where account_no='$account' and packages='Wallet_transfer' and types='recieved'";
				$res5=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res5)>0){$we5=mysqli_fetch_array($res5); $messages.= $we5['total'];}else{$messages.= "0";}
				$messages.="</td>
				</tr>
				<tr>
				<td>Total Loan </td><td>₦ "; $query="select sum(deposit) as total from loan where account_no='$account'";
				$res5=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res5)>0){$we5=mysqli_fetch_array($res5); $messages.= $we5['total'];}else{$messages.= "0";}
				$messages.="</td>				
				<td>Balance</td><td>₦ "; $query="select  total from wallet where account_no='$account'";
				$res6=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res6)>0){$we6=mysqli_fetch_array($res6); $messages.=$we6['total'];}
				$messages.="</td>
				
				
				</tr>
				
				</table>";
				
				
				
				
				
				
				$messages.='<table><thead>
                                        <tr>
										<th>SN</th>
										<th>Date</th>
										<th>Packages</th>
                                            <th>Ref No</th>
                                            <th>Description</th>
											<th>Debit</th>
											<th>Credit</th>
											<th>Balance</th>
											<th>Remark</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>';
									
	@$myquery1=mysqli_query($con,$querys) or die(mysqli_error($con));
		while(@$row2 = mysqli_fetch_object($myquery1)){
			
                                       $messages.=" <tr><td>". @$row2->num ."</td><td>". @$row2->transaction_date ."</td>                                    <td>". @$row2->packages ."</td>
											 <td>". @$row2->refno ."</td>
                                            <td>". @$row2->description ."</td>
                                            <td>". @$row2->debit ."</td>
											<td>". @$row2->credit ."</td>
											<td>". @$row2->balance ."</td>
											 <td>". @$row2->remark ."</td>
                                            
		</tr> ";
		  }  
                                        
                                $messages.="</tbody></table>";
				
				
				
				$query="insert into statement_email (account_no,subject,message,date_sent) values('$account','$subject','$messages',now())";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
			   
			   
			   $message = '<html><body>';

$message .= '<table  border="0" cellpadding="10">';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%">';

$message.='</td></tr>';
$message .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $email</td></tr>";
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%">';

$message.='</td></tr>';
$message .= "<tr><td><p>$messages</p></td></tr>";



$message .= "</table>";
$message .= "</body></html>";

$to = "$email";


$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $message, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
			   
			   
			   
			   
			   
			  
			   
			   echo "<h3 style='color:red'>Email Sent</h3>";
				}else{
			   ?>
			   
        <form  action="" method="post" enctype="multipart/form-data" class="f12">
            
                	
            
            <div class="f1-steps">
               
            </div>

            

            <field/set style="display: block;">
               
                
							<div class="form-group">
								<input class="form-control" placeholder="SUBJECT" value="ACCOUNT STATEMENT"name="subject" type="text" readonly>
							</div>
							
							<div class="form-group">
								<input class="form-control" placeholder="EMAIL " name="email" type="text" value='<?php echo $c['email_address']; ?>'required>
							</div>
							<div class="form-group">
						

                <div class="form-group ">
                    <label class="control-label">Message</label>
                    <?php if($_GET['account']){
						$account=$_GET['account'];
						$limit=$_GET['limit'];
						$querys="select (@row_number :=@row_number +1) as num,transaction_date,refno,description,debit,credit,balance,remark,packages from statements,(select @row_number:=0) as t where account_no='$account' $limit";
					
						
							echo"<h3>";
				$query="select firstname,lastname,middlename  from registeruser  where account_number='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$w=mysqli_fetch_array($res4); echo $w['firstname']." ".$w['lastname']." ".$w['middlename']."<span style='margin-left:5%'>Wallet ID : $account</span>";}?></h3>
						<table class="table">
				
				
				<tr>
				<td>Total Deposit</td><td>₦ <?php $query="select sum(total) as total from deposit where account_no='$account' and authorize='1'";
				$res=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){$we=mysqli_fetch_array($res); echo $we['total'];}else{echo "0";} ?></td>
				
				
			
				
				<td>Total Bonus</td><td>₦ <?php $query="select sum(bonus) as total from deposit where account_no='$account'";
				$res=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){$we=mysqli_fetch_array($res); echo $we['total'];}else{echo "0";} ?></td>
				
				
				
				<td>Total Withdraw</td><td>₦ <?php $query="select sum(total) as total from withdraw where account_no='$account' ";
				$res2=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res2)>0){$we2=mysqli_fetch_array($res2); echo $we2['total'];}else{echo "0";}?></td>
				
				
			
			
				<td>Total Bill Payment</td><td>₦ <?php $query="select sum(total) as total from bill where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); echo $we4['total'];}else{echo "0";}?></td>
				
				
				</tr>
				<tr>
				<td>Total Bank Transfer</td><td>₦ <?php $query="select sum(total) as total from transfer where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); echo $we4['total'];}else{echo "0";}?></td>
				
				
				
				<td>Total Recharge Card</td><td>₦ <?php $query="select sum(total) as total from recharge where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); echo $we4['total'];}else{echo "0";}?></td>
				
				
				
				<td>Total Data Recharge </td><td>₦ <?php $query="select sum(total) as total from datas where account_no='$accountt' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); echo $we4['total'];}else{echo "0";}?></td>
				
				
				
				<td>Total SMS</td><td>₦ <?php $query="select sum(total) as total from sms where account_no='$account' ";
				$res4=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res4)>0){$we4=mysqli_fetch_array($res4); echo $we4['total'];}else{echo "0";}?></td>
				
				
				</tr>
			
				<tr>
				<td>Total Sent Wallet Transfer </td><td>₦ <?php $query="select sum(debit) as total from wallet_transact where account_no='$account' and packages='Wallet_transfer' and types='sent'";
				$res5=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res5)>0){$we5=mysqli_fetch_array($res5); echo $we5['total'];}else{echo "0";}?></td>
				
				
				
				<td>Total Recieved Wallet Transfer </td><td>₦ <?php $query="select sum(credit) as total from wallet_transact where account_no='$account' and packages='Wallet_transfer' and types='recieved'";
				$res5=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res5)>0){$we5=mysqli_fetch_array($res5); echo $we5['total'];}else{echo "0";}?></td>
				
				<td>Total Loan </td><td>₦ <?php $query="select sum(deposit) as total from loan where account_no='$account'";
				$res5=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res5)>0){$we5=mysqli_fetch_array($res5); echo $we5['total'];}else{echo "0";}?></td>
				
				<td>Balance</td><td>₦ <?php $query="select  total from wallet where account_no='$account'";
				$res6=mysqli_query($con,$query)or die(mysqli_error($con));
				if(mysqli_num_rows($res6)>0){$we6=mysqli_fetch_array($res6); echo $we6['total'];}?></td>
				
				
				</tr>
				
				</table>
				
						 <table class="table table-striped table-bordered table-hover" >
                                    <thead>
                                        <tr>
										<th>SN</th>
										<th>Date</th>
										<th>Packages</th>
                                            <th>Ref No</th>
                                            <th>Description</th>
											<th>Debit</th>
											<th>Credit</th>
											<th>Balance</th>
											<th>Remark</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php
									
										
	
	@$myquery1=mysqli_query($con,$querys) or die(mysqli_error($con));
		while(@$row2 = mysqli_fetch_object($myquery1)){

?>				
									
                                        <tr class="info">
										 <td><?php echo @$row2->num;   ?></td>
										 <td><?php echo @$row2->transaction_date;   ?></td>
                                            <td><?php echo @$row2->packages;   ?></td>
											 <td><?php echo @$row2->refno;   ?></td>
                                            <td><?php echo @$row2->description;   ?></td>
                                            <td><?php echo @$row2->debit;   ?></td>
											<td><?php echo @$row2->credit;   ?></td>
											<td><?php echo @$row2->balance;   ?></td>
											 <td><?php echo @$row2->remark;   ?></td>
                                            
		</tr> <?php  }  ?>
                                        
                                    </tbody>
                                </table>
						
						<?php
					}
						?>
					
					
                </div>

               
            
                

                <br class="clear clearfix"><br>

                <div class="f1-buttons">
                    
                    
                    <input type="submit" name="submit"  class="btn btn-lg btn-info btn-uga btn-submit" value="Send">
                </div>
				
            
        </form>
   <?php
				}
				?>
				<br>
				<br>
    
   </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>

       

</body></html>