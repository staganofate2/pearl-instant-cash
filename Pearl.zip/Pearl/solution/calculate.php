<?php
$duration=$_POST['duration'];
$amount=$_POST['amount'];
 $amount=str_replace(",","",$amount);
$percent=$_POST['percent'];
if($duration=="1 Month"){
	$total=($amount*$percent)/100;
	
	}else if($duration=="2 Months"){
	$total=($amount*$percent*2)/100;
		
	}else if($duration=="3 Months"){
		$total=($amount*$percent*3)/100;
		
	}else if($duration=="4 Months"){
		$total=($amount*$percent*4)/100;
		
	}else if($duration=="6 Months"){
		$total=($amount*$percent*6)/100;
		
	}else if($duration=="12 Months"){
		$total=($amount*$percent*12)/100;
		
	}
	 echo$total+$amount;
	 exit();
?>