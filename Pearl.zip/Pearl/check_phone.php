<?php
include "connect.php";
$id=$_POST["id"];

$query="SELECT* FROM registeruser WHERE phone='$id'";
  $result = mysqli_query($con,$query)or die(mysqli_error($con));
  if(mysqli_num_rows($result)>0){
	  echo "exist";
  }
?>