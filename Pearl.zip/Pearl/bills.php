<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Pay Bills<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				<center><h4 class="h3-w3l"> Pay Bills Instantly</h4> 
				<img src='images/tv.jpg' width="60%" height="100px" alt='tv subscription image'>
				<p>Just a few steps ahead, your bills are instantly settled </p></center><br>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE Bill Payment</h3>

<form class="" action="bill_confirms.php" method="post" > 
			
			
			
			
			
			
			
			
			
						
						
						<div class="form-group">
							<select name="type" class="form-control"  id='type'required="" onchange='update()'>
						<option value="">----Select Bill Type---</option>
						<option value="gotv">GOTV</option>
						<option value="dstv">DSTV</option>
						<option value="startimes">Startimes</option>
						
					
						</select>
						<span id='one'></span>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Variation Code</span>
						
						<select  name="variation" id='variation' class="form-control" required onchange='update2()' >
						<option value="">Select Variation Code</option>
						</select>
						
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Cable Number</span>
						<input type="text" name="number" class="form-control" placeholder="Cable Number" required=""><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div>
						
						
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div>
						
					<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount'readonly name="amount" type="text" placeholder='Amount in Digits' onblur="check()" required>
								<span class='danger' id='result'></span>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Convenience fee</span>
								<input class="form-control" value="100" id='commi' name="commi" type="text"  readonly >
								
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Amount</span>
								<input class="form-control" value="" id='total' name="total" type="text"  readonly >
								
							</div>
						<input type="submit" class="btn btn-info " id='submit'value="Pay Now" name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			
			
			
			</form>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	 var type=document.getElementById("type").value;
	 if(type=="gotv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>GOtv Lite N400</option><option value='02'>GOtv value N1250</option><option value='03'>GOtv plus N1900</option><option value='04'>GOtv Max N3200</option>"; 
	 }
	 if(type=="startimes"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>Nova - 900 Naira</option><option value='02'>Basic - 1,300 Naira</option><option value='03'>Smart - 1,900 Naira</option><option value='04'>Classic - 2,600 Naira </option><option value='05'>Unique - 3,800 Naira</option><option value='06'>Super - 3,800 Naira</option>"; 
	 }
	  if(type=="dstv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>DStv Access N2000</option><option value='02'>DStv Family N4000</option><option value='03'>DStv Compact N6,800</option><option value='04'>DStv Compact Plus N10,650</option><option value='05'>DStv Premium N15,800</option><option value='06'>DStv  Premium + HD/Exra View - N18,000</option>"; 
	 }
 }
 function update2(){
	  var type=document.getElementById("type").value;
		 var types=document.getElementById("variation").value;
	 if(type=="gotv" && types=="01"){
	document.getElementById("amount").value="400.00"; 
	document.getElementById("total").value="500.00";
	 }	 if(type=="gotv" && types=="02"){
	document.getElementById("amount").value="1250.00";
document.getElementById("total").value="1350.00";	
	 }	 if(type=="gotv" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="gotv" && types=="04"){
	document.getElementById("amount").value="3200.00"; 
	document.getElementById("total").value="3300.00";
	 }	
	 if(type=="startimes" && types=="01"){
	document.getElementById("amount").value="900.00";
document.getElementById("total").value="1000.00";	
	 }	 if(type=="startimes" && types=="02"){
	document.getElementById("amount").value="1300.00"; 
	document.getElementById("total").value="1400.00";
	 }	 if(type=="startimes" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="startimes" && types=="04"){
	document.getElementById("amount").value="2600.00";
document.getElementById("total").value="2700.00";	
	 }	
	  if(type=="startimes" && types=="05"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	
	 if(type=="startimes" && types=="06"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	


	 if(type=="dstv" && types=="01"){
	document.getElementById("amount").value="2000.00"; 
	document.getElementById("total").value="2100.00";
	 }if(type=="dstv" && types=="02"){
	document.getElementById("amount").value="4000.00";
document.getElementById("total").value="4100.00";	
	 }	 if(type=="dstv" && types=="03"){
	document.getElementById("amount").value="6800.00"; 
	document.getElementById("total").value="6900.00";
	 }	
	  if(type=="dstv" && types=="04"){
	document.getElementById("amount").value="10650.00"; 
	document.getElementById("total").value="10750.00";
	 }	
	 if(type=="dstv" && types=="05"){
	document.getElementById("amount").value="15800.00"; 
	document.getElementById("total").value="15900.00";
	 }	
	 if(type=="dstv" && types=="06"){
	document.getElementById("amount").value="18000.00"; 
	document.getElementById("total").value="18100.00";
	 }	
			 
 }
 function check(){
	
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	alert(amount);
	var amounts=amount.replace(reg,""); 
	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
				 var amountt=Number(amounts);
				 var total=amountt+100;
				 alert(total);
				 document.getElementById("total").value =total;
			}
			else{
				document.getElementById("total").value ="";
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {

	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
<?php
include"footer.php";
?>