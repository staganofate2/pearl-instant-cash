<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Send Sms<b><img src='images/sms.jpg' width="20%" height="100px" alt='sms image'></h3>
			
			
			<!-- about bottom-->
			
				<center><h4 class="h3-w3l"> Send SMS Instantly</h4> 
				
				<p>Just a few steps ahead, to send SMS </p></center>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-10 "> 
			<h3>ONLINE SMS Sending</h3>

								<form class="" action="sms_payments.php" method="post" > 
			
			
			
			
			
			
						<p class='text-danger'>Note: Text message should not be more than 160 characters or you will charged for more than one unit</p>	
					<table class='table'>
						<tr><td>	<div class="form-group">
													<span class="badge" style="background-color:#3385FF;">Receiver Phone Number</span>
								<textarea class="form-control" placeholder="separate multiple numbers with comma" name="phone" required></textarea>
							</div></td><td>
							<div class="form-group">
						
													<span class="badge" style="background-color:#3385FF;">Message</span>
												
													<span id='screen' style='color:green'></span><span id='unit' style='margin-left:20px;color:purple'></span>
								<textarea class="form-control" placeholder="ENTER YOUR MESSAGE" name="message" id='message'required onkeydown="WordCount(this.value)" onblur="removeit()"></textarea>
							</div></td></tr>
						<tr><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Sender Id</span>
								<input class="form-control" placeholder="Sender Id" name="sender" type="text" value=""required>
							</div>
						</td><td>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div></td></tr>
						<tr><td>
						<div class="form-group">
						
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div></td><td>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div></td></tr>
							<tr><td>
						<div class="form-group">
												<span class="badge" style="background-color:#3385FF;">Charge for 1 Unit</span>
								<input class="form-control"   type="text"  value="3.50" >
							</div></td><td><br>
							
						<input type="submit" class="btn btn-info " id='submit'value="Send" name="login"> <a href='index.php' class='btn btn-info' style='background:red'>Cancel</a><br>
						
						<div class="clearfix"></div>
					
			
			
			
			</td></tr></table>
			
			
			
			 
			</form>
		
					
				</div> 
				<div class="clearfix"> </div>
				
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function countmess(val){
	var num=val.length;
	document.getElementById("screen").innerHTML = num+" characters";
}
function WordCount(str) { 
  var num=str.length;
 num+=1;
  document.getElementById("screen").innerHTML = num+" characters";
  var x=Math.ceil((num/160));
  document.getElementById("unit").innerHTML = x+" Unit(s)";
}
function removeit(){
	var nums=document.getElementById("message").value;
	var numss=nums.length
	
	if(numss=="0"){
		document.getElementById("screen").innerHTML ="0 characters";
		document.getElementById("unit").innerHTML ="0 Unit(s)";
	}
}
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {

	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
<?php
include"footer.php";
?>