<?php
$bar='signup';
include'header.php';


?>
<script>
function Resend(){
		Location.reload();
	}
</script>


	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l">Sign Up new Account</h4> 
				<p>Enter your information to proceed</p></center><br>
			</div> 
			
			<div class="row">
			
			<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
			
			<?php
      if (isset($_POST['login'])){
								
		include 'connect.php';
					if(isset($_SESSION['account'])){
	unset($_SESSION['account']);
	
}
if(isset($_SESSION['confirm'])){
	unset($_SESSION['confirm']);
}
if(isset($_SESSION['email'])){
	unset($_SESSION['email']);
}	
								$email = escape($con,$_POST['email']);
								$email=sanitize($email);
								$phone = escape($con,$_POST['phone']);
								$phone=sanitize($phone);
								
								$password = escape($con,$_POST['pass']);
								
								$query = "select email_address from registeruser where  email_address='$email'";
								$result = mysqli_query($con,$query)or die(mysqli_error($con));
								if(mysqli_num_rows($result)>0){
								$email_err="Email already taken";
								echo "<h3>$email_err</h3>";
								}else{
								$query = "select phone from registeruser where  phone='$phone'";
								$results = mysqli_query($con,$query)or die(mysqli_error($con));
								if(mysqli_num_rows($results)>0){
								$phone_err="Phone number already in use";
									echo "<h3>$phone_err</h3>";
								}else{
								
									$account=rand(1000000000,9999999999);
									$query="select account_number from registeruser where account_number='$account'";
								$resu =mysqli_query($con,$query)or die(mysqli_error($con));
									if(mysqli_num_rows($resu)>0){
										echo "<a href='signup.php' >Try Again</a>";
									}
									else{
									$query="insert into registeruser (account_number,email_address,phone,password,regdate) values('$account','$email','$phone','".sha1(md5($password))."',now())";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
                                if(isset($_COOKIE['refered'])){
                                   
	$ip = $_COOKIE['refered'];
	$query="update refer_user set account_no='$account' where ip='$ip'  and account_no=''";
	mysqli_query($con,$query)or die(mysqli_error($con));
	@setcookie("refered", $ip, strtotime( '-30 days' ), "/", "", "", TRUE);
	}
							$_SESSION['account']=$account;
							$_SESSION['email']=$email;
										$db_file_name =rand(10000,99999);	
										$query="insert into em_confirm (code,email,account_no,regdate) values('$db_file_name','$email','$account',now())";
										mysqli_query($con,$query) or die(mysqli_error($con));
										$query="insert into wallet(account_no,total) values('{$_SESSION['account']}','0')";
	mysqli_query($con,$query) or die(mysqli_error($con));
	@setcookie("confirm", $email, strtotime( '-5 days' ), "/", "", "", TRUE);
	$message="Hello $phone,thank you for choosing pearl. $db_file_name is your Account confirmation code";
	$message=urlencode($message);

$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource


$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
   $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
	
	
	$message = '<html><body>';

$message .= '<table  border="0" cellpadding="10">';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="logo" width="72px" height="26px"></td></tr>';
$message .= "<tr style='background: #eee;'><td><strong>Dear  </strong> " . strip_tags($email) . "</td></tr>";
$message .= "<tr><td><strong>This is your Account verification code: </strong>  $db_file_name </td></tr>";
$message .= "<tr><td><strong>Click on the Link below to verify your account</strong> </td></tr>";
$message .= "<tr><td><a href='https://www.pearlinstantcash.com/confirm.php?re0O0O=$db_file_name&ano=$account'>Confirm Account Now</a> </td></tr>";


$message .= "</table>";
$message .= "</body></html>";

$to = "$email";

$subject = 'Account Verification';

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $message, $headers)){
				echo"<h3>there was problem sending you  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
		
			}
										
@setcookie("email", $email, strtotime( '+30 days' ), "/", "", "", TRUE);
										echo "<br><br><h3>Thank You for Your Interest</h3>";
										echo "<p>A confirmation Code has been sent to your email and your phone number. <br>You can continue by clicking Continue Registration from Your email  or enter the code from your email or phone when requested </p>";
										echo '<h3> <a href="confirm.php">Confirm your Account </a> </h3>';
									}
								}
								}
								}else{
								
?>
			
			
			
						<form class="" action="" method="post" enctype="multipart/form-data"> 
						<p class='text-warning'>Note: Fields mark with * are required</p>
						
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email *</span>
						<input type="text" name="email" class="form-control" autocomplete='off' placeholder="Your Email" id='email' onblur="checkemail()"required="">
						<span class='error'id='email_result'></span>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone *</span>
						<input type="text" name="phone" class="form-control" autocomplete='off'placeholder="Your Phone" required="" id='phone'onblur="checkphone()">
						<span class='error'id='phone_result'></span>
						</div>
						<div id='loaders'></div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Password *</span>
						<input type="password" name="pass" class="form-control"id='pass' placeholder="PASSWORD" required="" onblur='checkPassword()'><br>
						<span class='error' id='passe'></span>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Confirm Password *</span>
						<input type="password" name="cpass" class="form-control"id="cpass" placeholder="CONFIRM PASSWORD" onblur="checkpass()" required=""><br>
						<span class='error'id='result'></span>
						</div>
						 <p>By clicking on Sign Up, You have agreed to our <a href="terms.php">Terms and Conditions</a> </p>
						<input type="submit" class="btn btn-info btn-block" id='submit' value="SIGN UP" name="login"> <br>
						<p>If you have already signup , please  click <a href="confirm.php">Continue </a> Now to Proceed</p>
						<div class="clearfix"></div>
					
			
			
			
			</form>
			
			
			<?php
			
			
								}
?>								</div> 
			
			
			</div>
			
			
			
			
			</div></div>
	<!-- //contact --> 
	
	
	
	
	
	
	<!--footer-->




<?php include"footer.php";
?>

</script>
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
		

  function checkForm(form)
  {
    if(form.username.value == "") {
      alert("Error: Username cannot be blank!");
      form.username.focus();
      return false;
    }
    re = /^\w+$/;
    if(!re.test(form.username.value)) {
      alert("Error: Username must contain only letters, numbers and underscores!");
      form.username.focus();
      return false;
    }

    if(form.pwd1.value != "" && form.pwd1.value == form.pwd2.value) {
      if(form.pwd1.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        form.pwd1.focus();
        return false;
      }
      if(form.pwd1.value == form.username.value) {
        alert("Error: Password must be different from Username!");
        form.pwd1.focus();
        return false;
      }
      re = /[0-9]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        form.pwd1.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.pwd1.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.pwd1.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      form.pwd1.focus();
      return false;
    }

    alert("You entered a valid password: " + form.pwd1.value);
    return true;
  }

 function checkPassword()
  {
	  var str=document.getElementById('pass').value;
    // at least one number, one lowercase and one uppercase letter
    // at least six characters
    var re = /(?=.*\d)(?=.*[a-zA-Z]).{6,}/;
    if(!re.test(str)){
		document.getElementById('submit').style.display="none";
		document.getElementById('passe').innerHTML="Password not strong<br> at least six characters, numbers,  letters ";
	}else{
	document.getElementById('submit').style.display="block";
document.getElementById('passe').innerHTML="";	
	}
	
  }
		function checkpass(){
			var pass=document.getElementById('pass').value;
			
			var cpass=document.getElementById("cpass").value;
			
			if(pass===cpass){
				document.getElementById('result').innerHTML="";
				document.getElementById('submit').style.display="inline";
				
				
			}else{
				document.getElementById('submit').style.display="none";
				document.getElementById('result').innerHTML="Password Mismatch";
			}
		}
			var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function checkemail(){
	id=document.getElementById("email").value;
		var b=document.getElementById("loaders").style.display="block";
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "check_email.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
	var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="exist"){
			
				document.getElementById("email_result").innerHTML ="Email Exists";
				document.getElementById('submit').style.display="none";
			}else{
				document.getElementById('submit').style.display="block";
				document.getElementById("email_result").innerHTML ="";
			}
		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	function checkphone(){
	
	
	
	id=document.getElementById("phone").value;
	
	 ajax.open("POST", "check_phone.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			if(ajax.responseText=="exist"){
			
				document.getElementById("phone_result").innerHTML ="Phone Number Exists";
				document.getElementById('submit').style.display="none";
			}else{
				document.getElementById('submit').style.display="block";
				document.getElementById("phone_result").innerHTML ="";
			}

		 
	  }
	
			
		}
	
	ajax.send("id="+id);
	}
	
	</script>
	<!-- //smooth-scrolling-of-move-up -->  

	