<?php
include "connect.php";



if(!empty($_POST["pin"])) {
  $result = mysqli_query($con,"SELECT count(*) FROM registeruser WHERE accountpin='" . $_POST["pin"] . "'");
  $row = mysqli_fetch_row($result);
  $user_count = $row[0];
  if($user_count>0) {
      echo "<span class='pin-not-available' style='color:red;'>Error!</span>";
  }else{
      echo "<span class='pin-available' style='color:green;'></span>";
  }
}
?>