<?php
$bar='signup';
include'header.php';
if(isset($_GET['acx'])){
	$account=$_GET['acx'];
	
?>





	
	
	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l">WALLET FUNDING</h4> 
				
				<p> </p></center><br>
			</div> 
			
			<div class="row">
			
			<div class="col-md-3">
			
			
			</div>
			<div class="col-md-8">
<?php
			
			$query="select*  from registeruser where account_number='$account'";
				$ert= mysqli_query($con,$query) or die(mysqli_error($con));
				
				$wee=mysqli_fetch_array($ert);
				$firstname=$wee['firstname'];
				$email=$wee['email_address'];
				$lastname=$wee['lastname'];
				$phone=$wee['phone'];
				
?>
			
			
		
			
				<form action="account_payment.php" method="POST" enctype="multipart/form-data">
<input type='hidden' name="track" value="true">
			<center><h4 class="h3-w3l">Early wallet funding for Loan repayment on the due date </h4> 
				<p>Enter Amount  to Proceed</p>
				<p class='text-warning'></p></center><br>
				
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value="<?php echo $firstname ?>"class="form-control" placeholder="FIRST NAME"  readonly="" required="" ><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="<?php echo $lastname ?>" class="form-control"  placeholder="LAST NAME" required=""readonly="" ><br>
							</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="email" name="email" value="<?php echo $email ?>" class="form-control"  placeholder="Email" required=""readonly="" ><br>
							</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone</span>
						<input type="text" name="phone" value="<?php echo $phone ?>" class="form-control"  placeholder="Phone" required=""readonly="" ><br>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Amount</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' name="amount" type="text" placeholder='Amount in Digits'onblur="check()" required>
								<span id='result'></span>
							</div>
							<input type='hidden' name='account' value="<?php echo $account ?>">
							<button class="btn btn-info" name="change" id='submit'type="submit">PAY NOW</button>
				
				</form>

			
	
			
			</div> 
			
			
			</div>
			
			
			
			
			</div></div>
	
			<?php
				}
				
				?>
	
 <script>
		function check(){
		var amount=document.getElementById('amount').value;
		var reg=/,/;
	//alert(amount);
	var amounts=amount.replace(reg,"");
		if(isNaN(amounts)){
		document.getElementById('submit').style.display="none";
		document.getElementById('result').innerHTML="Please Enter number in Digits";
	}else{
    document.getElementById('submit').style.display="block";
	document.getElementById('result').innerHTML="";
	}
	 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>



<?php include"footer.php";
?>