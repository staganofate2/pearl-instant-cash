<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Buy Data<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				<center><h4 class="h3-w3l"> Top Up Your data Instantly</h4> 
				<img src='images/network.jpg' width="60%" height="100px" alt='network image'>
				<p>Just a few steps ahead, to buy your desired Data Bundle </p></center><br>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE Data Top Up</h3>

	
								<form class="" action="data_payments.php" method="post" > 
			<div class="col-md-8">
			
			
			
			
			
						
						
						<div class="form-group">
							<select name="network" class="form-control"  id='type'required="" onchange='update()'>
						<option value="">----Select Network---</option>
						<option value="15">MTN</option>
						<option value="1">Airtel</option>
						<option value="6">GLO</option>
						<option value="2">9Mobile</option>
						
					
						</select>
						<span id='one'></span>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Data Amount</span>
						
						<select  name="variation" id='variation' class="form-control" required  >
						<option value="">Select Data</option>
						</select>
						
						</div>
												<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div>
						
					<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div>
							
						<input type="submit" class="btn btn-info " id='submit'value="Buy Now" name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			
			
			
			
			
			
			</div> 
			</form>
			
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	 var type=document.getElementById("type").value;
	 if(type=="15"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='100'>50MB-1day = 100</option><option value='500'>750MB-14days = 500</option><option value='1000'>1GB-30days = 1000</option><option value='1200'>1.5GB-30days = 1200</option><option value='2000'>2.5GB-30days = 2000</option><option value='3500'>5GB-30days = 3500</option><option value='5000'>10GB-30days = 5000</option><option value='10000'>22GB-30days = 10000</option>"; 
	 }
	if(type=="2"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='200'>150MB-7days = 200</option><option value='1000'>1GB-30days = 1000</option><option value='1000'>1.5GB-30days = 1200</option><option value='1200'>1.5GB-30days = 1200</option><option value='2000'>2.5GB-30days = 2000</option><option value='2500'>3.5GB-30days = 2500</option>"; 
	 }
	 if(type=="6"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='100'>80MB-24hrs = 100</option><option value='200'>210MB-5days = 200</option><option value='500'>800MB-14days = 500</option><option value='1000'>1.6GB-30days = 1000</option><option value='2000'>3.65GB-30days = 2000</option><option value='2500'>5.75GB-30days = 2500</option><option value='3000'>7GB-30days = 3000</option><option value='4000'>10GB-30days = 4000</option><option value='5000'>12.5GB-30days = 5000</option><option value='8000'>20GB-30days = 8000</option>"; 
	 }
	  if(type=="1"){
	document.getElementById("variation").innerHTML="<option value=''>Select Data Amount</option><option value='100'>50MB-1day = 100</option><option value='200'>100MB-3days = 200</option><option value='500'>750MB-14days = 500</option><option value='1000'>1.5GB-30days = 1000</option><option value='1500'>2.5GB-30days = 1500</option><option value='2000'>3.5GB-30days = 2000</option><option value='2500'>5.5GB-30days = 2500</option><option value='4000'>9.5GB-30days = 4000</option><option value='5000'>12GB-30days = 5000</option>"; 
	 }
 }
 function update2(){
	  var type=document.getElementById("type").value;
		 var types=document.getElementById("variation").value;
	 if(type=="gotv" && types=="01"){
	document.getElementById("amount").value="400.00"; 
	document.getElementById("total").value="500.00";
	 }	 if(type=="gotv" && types=="02"){
	document.getElementById("amount").value="1250.00";
document.getElementById("total").value="1350.00";	
	 }	 if(type=="gotv" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="gotv" && types=="04"){
	document.getElementById("amount").value="3200.00"; 
	document.getElementById("total").value="3300.00";
	 }	
	 if(type=="startimes" && types=="01"){
	document.getElementById("amount").value="900.00";
document.getElementById("total").value="1000.00";	
	 }	 if(type=="startimes" && types=="02"){
	document.getElementById("amount").value="1300.00"; 
	document.getElementById("total").value="1400.00";
	 }	 if(type=="startimes" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="startimes" && types=="04"){
	document.getElementById("amount").value="2600.00";
document.getElementById("total").value="2700.00";	
	 }	
	  if(type=="startimes" && types=="05"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	
	 if(type=="startimes" && types=="06"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	


	 if(type=="dstv" && types=="01"){
	document.getElementById("amount").value="2000.00"; 
	document.getElementById("total").value="2100.00";
	 }if(type=="dstv" && types=="02"){
	document.getElementById("amount").value="4000.00";
document.getElementById("total").value="4100.00";	
	 }	 if(type=="dstv" && types=="03"){
	document.getElementById("amount").value="6800.00"; 
	document.getElementById("total").value="6900.00";
	 }	
	  if(type=="dstv" && types=="04"){
	document.getElementById("amount").value="10650.00"; 
	document.getElementById("total").value="10750.00";
	 }	
	 if(type=="dstv" && types=="05"){
	document.getElementById("amount").value="15800.00"; 
	document.getElementById("total").value="15900.00";
	 }	
	 if(type=="dstv" && types=="06"){
	document.getElementById("amount").value="18000.00"; 
	document.getElementById("total").value="18100.00";
	 }	
			 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {

	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
<?php
include"footer.php";
?>