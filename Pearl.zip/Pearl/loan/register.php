<?php
include"header.php";
include"modal_box.php"; 
include '../function.php';

?>

<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  </script>
  <style>
  .img-responsive{
	  width:120px;
	  height:120px;
  }
  </style>
	
		<!-------------------------------------the side nav bar here-------------------------------------->
		
		<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			
				<img src="../<?php echo $row['picture'];  ?>" class="img-responsive" style="height:180px; width:90%;" alt="PEARL user picture"><!--------------------user picture here----------------->
			
			
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li class="active"><a href="loan.php"><em class="fa fa-dashboard">&nbsp;</em>Loan Application</a></li>
			<li><a href="approved.php"><em class="fa fa-calendar">&nbsp;</em>Approved Loan</a></li>
			<li><a href="repay.php"><em class="fa fa-bar-chart">&nbsp;</em> Repayment Plan</a></li>
			<li><a href="statement.php"><em class="fa fa-toggle-off">&nbsp;</em>Statement</a></li>
			
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout <?php echo $row['lastname'];  ?></a></li>
		</ul>
	</div><!--/.sidebar-->
	
	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Loan Application Form</h4>
<?php
if ( isset( $_POST["step"] ) and $_POST["step"] >= 1 and $_POST["step"]<= 3 ) {
call_user_func( "processStep" . (int)$_POST["step"]);
} else {
displayStep1();
}
function setValue( $fieldName ) {
if ( isset( $_POST[$fieldName] ) ) {
echo $_POST[$fieldName];
}
}
function setChecked( $fieldName, $fieldValue ) {
if ( isset( $_POST[$fieldName] ) and $_POST[$fieldName] == $fieldValue ) {
echo ' checked="checked"';
}
}
function setSelected( $fieldName, $fieldValue ) {
if ( isset( $_POST[$fieldName] ) and $_POST[$fieldName] == $fieldValue ) {
echo ' selected="selected"';
}
}
function processStep1() {
if(isset($_POST['subone']) ){
	include'connect.php';

$emp_status =escape($con,$_POST['emp_status']);
$emp_sector =escape($con,$_POST['emp_sector']);
$buz_name =escape($con,$_POST['buz_name']);
$buz_address =escape($con,$_POST['buz_address']);
$buz_status =escape($con,$_POST['buz_status']);
$rc_no =escape($con,$_POST['rc_no']);
$net_profit =escape($con,$_POST['net_profit']);
$mon_turnover =escape($con,$_POST['mon_turnover']);
$start_date =escape($con,$_POST['start_date']);
$buz_email =escape($con,$_POST['buz_email']);
$buz_phone =escape($con,$_POST['buz_phone']);
$tax_no =escape($con,$_POST['tax_no']);
$pension_no =escape($con,$_POST['tax_no']);
$student =escape($con,$_POST['student']);
$query="insert into loan  (emp_status,emp_sector,business_name,business_address,biz_status,rc_no,dialy_turnover,monthly_profit,biz_start,biz_email,biz_phone,tax_no,pension,student,account_no) values(
'$emp_status','$emp_sector','$buz_name','$buz_address','$buz_status','$rc_no','$net_profit','$mon_turnover','$start_date','$buz_email','$buz_phone','$tax_no','$pension_no','$student','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
 
displayStep2();
}
}

function processStep2() {
	
if (isset($_POST["submit2"] ) && $_POST["submit2"] =="< Back" ) {
displayStep1(); 
} 

elseif(isset($_POST['subtwo']) ){
	include'connect.php';
$amount =escape($con,$_POST['amount']);

$duration =escape($con,$_POST['duration']);
$percent =escape($con,$_POST['percent']);
$structure =escape($con,$_POST['structure']);
$reason =escape($con,$_POST['reason']);
$repay_amount =escape($con,$_POST['repay_amount']);

$query="update loan set amount='$amount',loan_duration='$duration',interest_rate='$percent',repayment_plan='$structure',reason_for_loan='$reason',repayment_plan_amount='$repay_amount' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));

 
 

displayStep3();
}
}
function processStep3() {
	
if ( isset( $_POST["subm3"] ) ) {
displayStep2();
} 
elseif(isset($_POST['subthree']) ){
	include'connect.php';
	if(isset($_POST['account_no'])){
		$account_no =escape($con,$_POST['account_no']);
	}
	if(isset($_POST['account_name'])){
		$account_name =escape($con,$_POST['account_name']);
	}
	if(isset($_POST['bank'])){
		$bank =escape($con,$_POST['bank']);
	}



$bvn=escape($con,$_POST['bvn']);
$find =escape($con,$_POST['find']);
$query="update loan set find='$find' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));
if(isset($_POST['account_no']) || isset($_POST['account_name']) || isset($_POST['bank'])){
	$query="insert into bank_info(bank_name,account_name,account_number,bvn,account_no)values('$bank','$account_name','$account_number','$bvn','{$_SESSION['account_no']}')";
	mysqli_query($con,$query)or die(mysqli_error($con));
}
else{
	$query="update bank_info set bvn='$bvn' where account_no='{$_SESSION['account_no']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}

displayThanks();
}
}

function displayStep1() {
$mon=array("01"=>"JANUARY","02"=>"FEBRUARY","03"=>"MARCH","04"=>"APRIL","05"=>"MAY","06"=>"JUNE","07"=>"JULY","08"=>"AUGUST","09"=>"SEPTEMBER","10"=>"OCTOBER","11"=>"NOVEMBER","12"=>"DECEMBER");
include"connect.php";
$query="select* from registeruser where email_address='{$_SESSION['email']}'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
$rows=mysqli_fetch_array($dee);
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">STEP 1 : BUSINESS INFORMATION</h4> 
				<p>Please fill your Business Information  Below</p></center><br>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="1" />

			<div class="col-md-3">
			<p>ID image</p>
			<img src="../<?php echo $rows['id_image']?> " alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
			
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br><br>
		
			<select name="emp_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];}  ?>"><?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];} else{ ?>----EMPLOYMENT STATUS---<?php } ?></option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						
						
</select><br>
						<input type="text" name="emp_sector" value="<?php if(isset($_POST["emp_sector"])){echo $_POST["emp_sector"];}  ?>"class="form-control" placeholder="EMPLOYMENT SECTOR" ><br>
						
						<input type="text" name="buz_name"value="<?php if(isset($_POST["buz_name"])){echo $_POST["buz_name"];}  ?>" class="form-control" placeholder="BUSINESS NAME" required=""><br>
						<input type="text" name="buz_address" value="<?php if(isset($_POST["buz_address"])){echo $_POST["buz_address"];}  ?>"class="form-control" placeholder="BUSINESS ADDRESS" required=""><br>
					
						<select name="buz_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}  ?>"><?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}else{  ?>----Business Registration Status---<?php } ?></option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select><br>

						
						
						<input type="text" name="rc_no" value="<?php if(isset($_POST["rc_no"])){echo $_POST["rc_no"];}  ?>"class="form-control" placeholder="RC NO" required=""><br>
						<input type="text" name="id_no"value="<?php echo $rows['id'] ?>" class="form-control"  readonly title="Mean of Identification"><br>
						<input type="text" name="id_no"value="<?php echo $rows['id_no'] ?>" class="form-control" title="ID NUMBER" readonly><br>
						<input type="text" name="net_profit"value="<?php if(isset($_POST["net_profit"])){echo $_POST["net_profit"];}  ?>" class="form-control" placeholder="DAILY TURNOVER" required=""><br>
						<input type="text" name="mon_turnover" value="<?php if(isset($_POST["mon_turnover"])){echo $_POST["mon_turnover"];}  ?>"class="form-control" placeholder="NET MONTHLY MONTHLY" required=""><br>
						<input type="date" name="start_date"value="<?php if(isset($_POST["start_date"])){echo $_POST["start_date"];}  ?>" class="form-control"  ><br>
						
						<input type="email" name="buz_email"value="<?php if(isset($_POST["buz_email"])){echo $_POST["buz_email"];}  ?>" class="form-control" placeholder="BUSINESS EMAIL" required=""><br>
						<input type="text" name="buz_phone" value="<?php if(isset($_POST["buz_phone"])){echo $_POST["buz_phone"];}  ?>"class="form-control" placeholder="BUSINESS PHONE" required=""><br>
						<input type="text" name="tax_no"value="<?php if(isset($_POST["tax_no"])){echo $_POST["tax_no"];}  ?>" class="form-control" placeholder="TAX NO" ><br>
						<input type="text" name="pension_no"value="<?php if(isset($_POST["pension_no"])){echo $_POST["pension_no"];}  ?>" class="form-control" placeholder="PENSON NO"><br>
						
						<div class="form-group">
						<span>ARE YOU A STUDENT ? </span><input type="CHECKBOX" name="student" value="Student" class="form-control">
						</div>
	

<input type="submit" name="subone" id="nextButton" value="SAVE AND CONTINUE &gt;" /><br/>




	</div> 
	</form>
			
			</div>
			
			
			
			
			</div></div>

<?php
}
function displayStep2() {
	$mon=array("01"=>"JANUARY","02"=>"FEBRUARY","03"=>"MARCH","04"=>"APRIL","05"=>"MAY","06"=>"JUNE","07"=>"JULY","08"=>"AUGUST","09"=>"SEPTEMBER","10"=>"OCTOBER","11"=>"NOVEMBER","12"=>"DECEMBER");
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">STEP 2 : LOAN ACCOUNT DETAILS</h4> 
				<p>Please fill the loan Details  Below</p></center><br>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="2" />

			<div class="col-md-3">
			
			
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
						<input type="text" name="amount"value="<?php if(isset($_POST["amount"])){echo $_POST["amount"];}  ?>" class="form-control" placeholder="ENTER AMOUNT" onblur="update()"><br>
						<div class="form-group">
								<select name='duration' class="form-control">
								<option   value="<?php if(isset($_POST["duration"])){echo $_POST["duration"];}  ?>"><?php if(isset($_POST["duration"])){echo $_POST["duration"];}else{  ?>Select LOAN Duration <?php } ?></option>
								<option   value="6 Months">6 Months</option>
								<option   value="12 Months">12 Months</option>
								<option   value="2 Years">2 Years</option>
								<option   value="3 Years">3 Years</option>
								<option   value="4 Years">4 Years</option>
								<option   value="5 Years">5 Years</option>
								
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" id='percent' value="<?php if(isset($_POST["percent"])){echo $_POST["percent"];}  ?>" name="percent" placeholder='Monthly Investment Interest Rate' type="text" readonly>
							</div>
							<div class="form-group">
								<input class="form-control" id='repay' name="repay_amount" value="<?php if(isset($_POST["repay_amount"])){echo $_POST["repay_amount"];}  ?>"placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
							<div class="form-group">
								<select name='structure' class="form-control">
								<option   value="<?php if(isset($_POST["structure"])){echo $_POST["structure"];}  ?>"><?php if(isset($_POST["structure"])){echo $_POST["structure"];} else{ ?>Select Repayment Structure <?php } ?></option>
								<option   value="Weekly">Weekly</option>
								<option   value="Monthly">Monthly</option>
								</select>
							</div>
						<textarea  name="reason"value="<?php if(isset($_POST["reason"])){echo $_POST["reason"];}  ?>" class="form-control" placeholder="Reason for loan" required=""></textarea><br>
<input type="submit" name="subtwo" id="nextButton" value="SAVE AND CONTINUE &gt;" /><br/>
<input type="submit" name="submit2" id="nextButton"value="&lt; Back" style="margin-right: 20px;" /><br/>


</form>
</div> 
			
			</div>
			
			
			
			
			</div></div>
<?php
}
function displayStep3() {
	include"connect.php";
$query="select* from registeruser where email_address='{$_SESSION['email']}'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
$rows=mysqli_fetch_array($dee);

?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">STEP 3 : BANK ACCOUNT DETAILS</h4> 
				<p>Please fill your Bank Details  Below</p></center><br>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="3" />

			<div class="col-md-3">
			<div class="form-group">
				<p> Passport</p>
			<img src="../<?php echo $rows['passport'] ?>" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                
				</div>
				<div class="form-group">
							<p> Signature</p>
			<img src="../<?php echo $rows['signature'] ?>" alt="" class="img-responsive"  align="absmiddle" id="outputpix2"/><br />
               
				</div>
			
			</div>
			<div class="col-md-5">
			
			<?php
		
$query="select* from bank_info where account_no='{$_SESSION['account']}'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($dee)>0){
$rows=mysqli_fetch_array($dee);
			?>
			<input type="text"  value="<?php echo $rows['account_name'] ?>"class="form-control"  readonly><br>
						<input type="text"  class="form-control" value="<?php echo $rows['account_number'] ?>" readonly><br>
						<input type="text"  class="form-control" value="<?php echo $rows['bank_name'] ?>" readonly ><br>
						
						<?php
}
else{
	?>
	<input type="text" name="account_name" value=""class="form-control" placeholder="Bank Account Name" required=""><br>
						<input type="text" name="account_no" class="form-control" value="" placeholder="Bank Account Number"required=""><br>
						<input type="text" name="bank" class="form-control" value="" required="" placeholder="Bank Name"><br>
	<?php
}
			?>			<input type="text" name="bvn" class="form-control" placeholder="BVN NO" required=""><br>
						<textarea  name="find" class="form-control" placeholder="How did you find us" required=""></textarea><br>

<input type="submit" name="subthree" id="nextButton" value="FINISH &gt;" /><br/>

<input type="submit" name="subm3" id="nextButton"value="&lt;Back" style="margin-right: 20px;" /><br/>


</form>
</div> 
			
			</div>
			
			
			
			
			</div></div>
<?php
}
function displayThanks(){
	?>
	
	<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">Thanks for your Interest </h4> 
				<p>Your Application is been processed.<br>We will get back to you when everything we are done.</p>
				<p>Please Note that we not give you that exact amount you requested for in your form</p></center><br>
			</div> 
			
			

			
			
			
			
			</div></div>
	
	<?php
}
?>









<div class="w3_agile-copyright text-center">
		<p>© 2018 E-Banking. All rights reserved | Design by PEARL</p>
	</div>
<!--//footer-->	


</script>
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
		
		
	
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  function update(){
	  var amount=document.getElementById("amount").value;
	  var intreset=(amount*30)/100;
	  document.getElementById("percent").value=intreset;
  }
	</script>
	<!-- //smooth-scrolling-of-move-up -->  

	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
	/
	</body>
</html>
