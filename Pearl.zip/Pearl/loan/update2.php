<?php
session_start();
include"connect.php";

$type=$_POST['type'];
$id=$_POST['id'];
$x="";
       $query="select repayment_plan  from loan where account_no='{$_SESSION['account']}'  and active='0' and approved='1' and loan_id='$id'";
								$re=mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($re)>0){
									$ros=mysqli_fetch_array($re);
									
								echo$x.=$ros['repayment_plan'];
								
								}
								
								
								
							                          
?>