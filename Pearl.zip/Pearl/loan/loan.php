<?php
include"header.php";
include"modal_box.php"; 
$bar="loan";

?>
		
	<?php include"sidebar.php" ?>
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				
				<?php
include '../function.php';

?>

<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  </script>
  <style>
  .img-responsive{
	  width:120px;
	  height:120px;
  }
  </style>
	
		
	
	
	
	
	
	
	
	
	
 
		
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Loan Application Form</h4>
<?php

if ( isset( $_POST["step"] ) and $_POST["step"] >= 1 and $_POST["step"]<= 3 ) {
call_user_func( "processStep" . (int)$_POST["step"]);
} else {
displayStep1();
}
function setValue( $fieldName ) {
if ( isset( $_POST[$fieldName] ) ) {
echo $_POST[$fieldName];
}
}
function setChecked( $fieldName, $fieldValue ) {
if ( isset( $_POST[$fieldName] ) and $_POST[$fieldName] == $fieldValue ) {
echo ' checked="checked"';
}
}
function setSelected( $fieldName, $fieldValue ) {
if ( isset( $_POST[$fieldName] ) and $_POST[$fieldName] == $fieldValue ) {
echo ' selected="selected"';
}
}
function processStep1() {
if(isset($_POST['subone']) ){
	include'connect.php';

$emp_status =escape($con,$_POST['emp_status']);
$emp_sector =escape($con,$_POST['emp_sector']);
$buz_name =escape($con,$_POST['buz_name']);
$buz_address =escape($con,$_POST['buz_address']);
$buz_status =escape($con,$_POST['buz_status']);
$rc_no =escape($con,$_POST['rc_no']);
$net_profit =escape($con,$_POST['net_profit']);
$mon_turnover =escape($con,$_POST['mon_turnover']);
$start_date =escape($con,$_POST['start_date']);
$buz_email =escape($con,$_POST['buz_email']);
$buz_phone =escape($con,$_POST['buz_phone']);
$tax_no =escape($con,$_POST['tax_no']);
$pension_no =escape($con,$_POST['tax_no']);
$occupation =escape($con,$_POST['occupation']);
$query="insert into loan  (emp_status,emp_sector,business_name,business_address,biz_status,rc_no,dialy_turnover,monthly_profit,biz_start,biz_email,biz_phone,tax_no,pension,occupation,account_no,regdate) values(
'$emp_status','$emp_sector','$buz_name','$buz_address','$buz_status','$rc_no','$net_profit','$mon_turnover','$start_date','$buz_email','$buz_phone','$tax_no','$pension_no','$occupation','{$_SESSION['account']}',now())";
mysqli_query($con,$query)or die(mysqli_error($con));
$_SESSION['id']=mysqli_insert_id($con);
if(isset($_POST['id'])){
$id =escape($con,$_POST['id']);
$id_no =escape($con,$_POST['id_no']);
$issue_date =escape($con,$_POST['issue_date']);
$exdate =escape($con,$_POST['exdate']);

if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["ufile"])) {
$fileName = $_FILES["ufile"]["name"];
 $fileTmpLoc = $_FILES["ufile"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["ufile"]["name"]);
$extension = end($temp);
if ((($_FILES["ufile"]["type"] == "image/gif")
|| ($_FILES["ufile"]["type"] == "image/jpeg")
|| ($_FILES["ufile"]["type"] == "image/jpg")
|| ($_FILES["ufile"]["type"] == "image/pjpeg")
|| ($_FILES["ufile"]["type"] == "image/x-png")
|| ($_FILES["ufile"]["type"] == "image/png"))
&& ($_FILES["ufile"]["size"] < 4000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["ufile"]["error"] > 0) {
        echo "Return Code: " . $_FILES["ufile"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	
	$db_file_names="../userphoto/$db_file_name";
	$db_file_name="userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_names );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
			$query="update registeruser set id_image='$db_file_name' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query)or die(mysqli_error($con));
		$query="insert into uploads(purpose,image,regdate,account_no) values('ID image','$db_file_name',now(),'{$_SESSION['account']}')";
	mysqli_query($con,$query) or die(mysqli_error($con));
			
        }
    }
 else {
    echo "Invalid file";
}
}
$query="update registeruser set id='$id',id_no='$id_no',issue_date='$issue_date',exp_date='$exdate' where account_number='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));
}
 
displayStep2();
}
}

function processStep2() {
	
if (isset($_POST["submit2"] ) && $_POST["submit2"] =="< Back" ) {
displayStep1(); 
} 

elseif(isset($_POST['subtwo']) ){
	include'connect.php';
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$duration =escape($con,$_POST['duration']);
$percent =escape($con,$_POST['percent']);
$structure =escape($con,$_POST['structure']);
$reason =escape($con,$_POST['reason']);
$repay_amount =escape($con,$_POST['repay_amount']);
$ref =rand(100000,999999);
$query="update loan set req_amount='$amount',ref_no='$ref',loan_duration='$duration',interest_rate='30%',interest='$percent',repayment_plan='$structure',reason_for_loan='$reason',repayment_plan_amount='$repay_amount' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));

 
 

displayStep3();
}
}
function processStep3() {
	
if ( isset( $_POST["subm3"] ) ) {
displayStep2();
} 
elseif(isset($_POST['subthree']) ){
	include'connect.php';
	if(isset($_POST['account_no'])){
		$account_no =escape($con,$_POST['account_no']);
	}
	if(isset($_POST['account_name'])){
		$account_name =escape($con,$_POST['account_name']);
	}
	if(isset($_POST['bank'])){
		$bank =escape($con,$_POST['bank']);
	}




$find =escape($con,$_POST['find']);
$query="update loan set find='$find' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query)or die(mysqli_error($con));

if(isset($_POST['bvn'])){
		@$bvn=escape($con,$_POST['bvn']);
	
	$query="select bvn from bank_info where bvn='$bvn'";
	$d=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($d)>0){
		echo "<h3>Bvn Number Exists</h3>";
	}else{
	$query="update bank_info set bvn='$bvn' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
}

displayThanks();
}
}

function displayStep1() {
$mon=array("01"=>"JANUARY","02"=>"FEBRUARY","03"=>"MARCH","04"=>"APRIL","05"=>"MAY","06"=>"JUNE","07"=>"JULY","08"=>"AUGUST","09"=>"SEPTEMBER","10"=>"OCTOBER","11"=>"NOVEMBER","12"=>"DECEMBER");
include"connect.php";
$query="select* from registeruser where account_number='{$_SESSION['account']}'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
$rows=mysqli_fetch_array($dee);
$query="select total  from loan where collected='1' and approved='1' and paid='0' and account_no='{$_SESSION['account']}' order by loan_id desc";
$we=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($we)>0){
	$fe=mysqli_fetch_array($we);
	?>
	<center><h4 class="h3-w3l">Thanks for your Interest </h4> 
	<p>Please You need to Complete Your ₦<?php echo $fe['total'] ?> Loan Repayment before applying for another one.</p>
	</center>
	<?php
}else{
$query="select total  from loan where  paid='0' and account_no='{$_SESSION['account']}' and amount !='0'and rejected='0' order by loan_id desc";
$wee=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($wee)>0){
	$fee=mysqli_fetch_array($wee);
	?>
	<center><h4 class="h3-w3l">Thanks for your Interest </h4> 
	<p>Please Your ₦<?php echo $fee['total'] ?> have not been  approved, please wait for approval before applying for another one.</p>
	</center>
	<?php
}else{	
	
	$query="select* from bank_info where account_no='{$_SESSION['account']}'";
$de=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($de)<1){
    	?>
	<center><h4 class="h3-w3l">Thanks for your Interest </h4> 
	<p>Please You  need to Provide your Bank Account Details.<br><a href='../personal/addbankinfo.php'>Add Bank Info</a></p>
	</center>
	<?php
}else{
	$query="select*  from loan where  account_no='{$_SESSION['account']}'";
$wee=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($wee)>0){
	$th=mysqli_fetch_array($wee);
}
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">STEP 1 : BUSINESS INFORMATION</h4> 
				<p>Please fill your Business Information  Below</p>
				</center><br>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="1" />

			<div class="col-md-3">
			<p>ID image</p>
			<?php
			if($rows['image']==""){
				?>
				<img src="../images/faceless.png" alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="4000000">
                <input type="file"  name="ufile" id="ufile5" accept="image/*" onchange="loadFile(event)" required="" /><br>
				
				<?php
			}else{
				?>
			<img src="../<?php echo $rows['id_image']?> " alt="" class="img-responsive"  align="absmiddle" id="outputpix"/><br />
			<?php
			}
			?>
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;">Business Information......</span><br>
		<div class='form-group'>
		<span class="badge" style="background-color:#3385FF;">Employment Status</span>
			<select name="emp_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];}else{echo @$th['emp_status'];}  ?>"><?php if(isset($_POST["emp_status"])){echo $_POST["emp_status"];} else{ if(isset($th['emp_status'])){echo @$th['emp_status'];}else{?>----EMPLOYMENT STATUS---<?php }} ?></option>
						<option value="Employed">Employed</option>
						<option value="Unemployed">Unemployed</option>
						<option value="Self Employed">Self Employed</option>
						<option value="Student">Student</option>
						
						
</select></div>
<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Employment Sector </span>
						<input type="text" name="emp_sector" value="<?php if(isset($_POST["emp_sector"])){echo $_POST["emp_sector"];}else{echo @$th['emp_sector'];}   ?>"class="form-control" placeholder="EMPLOYMENT SECTOR" >
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Name</span>
						<input type="text" name="buz_name"value="<?php if(isset($_POST["buz_name"])){echo $_POST["buz_name"];}else{echo @$th['business_name'];}   ?>" class="form-control" placeholder="BUSINESS NAME" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Address</span>
						<input type="text" name="buz_address" value="<?php if(isset($_POST["buz_address"])){echo $_POST["buz_address"];}else{echo @$th['business_address'];}  ?>"class="form-control" placeholder="BUSINESS ADDRESS" required="">
						</div>
						
					<div class='form-group'>
					<span class="badge" style="background-color:#3385FF;">Business Registration Status</span>
						<select name="buz_status" class="form-control"  required="">
						<option value="<?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}else{echo @$th['biz_status'];}  ?>"><?php if(isset($_POST["buz_status"])){echo $_POST["buz_status"];}else{if(isset($th['biz_status'])){echo @$th['biz_status'];}else{  ?>----Business Registration Status---<?php }} ?></option>
						<option value="Registered">Registered</option>
						<option value="Unregistered">Unregistered</option>
						
						
</select>

			</div>			
					<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">RC Number</span>	
						<input type="text" name="rc_no" value="<?php if(isset($_POST["rc_no"])){echo $_POST["rc_no"];}else{echo @$th['rc_no'];}  ?>"class="form-control" placeholder="RC NO" >
						</div>
						<span class="badge" style="background-color:#3385FF;">Means of Identification</span>
						
<?php
			if($rows['id']==""){
				?>
				<div class='form-group'>
				<select name="id" class="form-control"  required="">
						<option value="">----Select Identification ---</option>
						<option value="National ID">National Id-card </option>
						<option value="Driver License">Driver License</option>
						<option value="Voters Card">Voters Card</option>
						<option value="International Passport">International Passport</option>
						</select>
						</div>
						<?php
			}else{
				?>
				<div class='form-group'>
						<input type="text" name="id_no"value="<?php echo $rows['id'] ?>" class="form-control"  readonly title="Means of Identification">
						</div>
						<?php
			} 
			?>
						
						<div class='form-group'>
						
<span class="badge" style="background-color:#3385FF;">ID Number</span>
<?php
						if($rows['id_no']==""){
				?>
						<input type="text" name="id_no"value="" class="form-control" title="ID NUMBER" >
						<?php
						}else{
							?>
						<input type="text" name="id_no"value="<?php echo $rows['id_no'] ?>" class="form-control" title="ID NUMBER" readonly>	
						<?php
						}
						?>
						</div>
						<?php
						if($rows['id_no']==""){
							?>
							<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Issue Date *</span><br><br>
						 <input type='date' name="isdate"   class="form-control" value="<?php echo $rows ?>" >
 
</div><div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate"   class="form-control">
 
</div>
							
							<?php
							
							
						}else{
						?>
							<div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Issue Date *</span><br><br>
						 <input type='date' name="isdate" value="<?php echo $rows['issue_date'] ?>"  class="form-control" readonly>
 
</div><div class='form-group'>
 <span class="badge" style="background-color:#3385FF;">Expire Date *</span><br><br>
						 <input type='date' name="exdate"   value="<?php echo $rows['exp_date'] ?>" class="form-control" readonly>
 
</div>
						<?php	
						}
				?>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Daily Turnover</span>
						<input type="text" name="net_profit"value="<?php if(isset($_POST["net_profit"])){echo $_POST["net_profit"];}else{echo @$th['dialy_turnover'];}  ?>" class="form-control" placeholder="DAILY TURNOVER" required="">
						</div>
					
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Monthly Turnover</span>
						<input type="text" name="mon_turnover" value="<?php if(isset($_POST["mon_turnover"])){echo $_POST["mon_turnover"];}else{echo @$th['monthly_profit'];}  ?>"class="form-control" placeholder="NET MONTHLY MONTHLY" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Start Date</span>
						<input type="date" name="start_date"value="<?php if(isset($_POST["start_date"])){echo $_POST["start_date"];}else{echo @$th['biz_start'];}  ?>" class="form-control"  >
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Email</span>
						<input type="email" name="buz_email"value="<?php if(isset($_POST["buz_email"])){echo $_POST["buz_email"];}else{echo @$th['biz_email'];}  ?>" class="form-control" placeholder="BUSINESS EMAIL" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Business Phone number</span>
						<input type="text" name="buz_phone" value="<?php if(isset($_POST["buz_phone"])){echo $_POST["buz_phone"];}else{echo @$th['biz_phone'];}  ?>"class="form-control" placeholder="BUSINESS PHONE" required="">
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Tax Number</span>
						
						<input type="text" name="tax_no"value="<?php if(isset($_POST["tax_no"])){echo $_POST["tax_no"];}else{echo @$th['tax_no'];}  ?>" class="form-control" placeholder="TAX NO" >
						</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Pension Number</span>
						
						<input type="text" name="pension_no"value="<?php if(isset($_POST["pension_no"])){echo $_POST["pension_no"];}else{echo @$th['pension'];}  ?>" class="form-control" placeholder="PENSON NO">
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Occupation</span>
						<select name="occupation" class="form-control"  required="">
						<option value="<?php if(isset($_POST["occupation"])){echo $_POST["occupation"];}else{echo @$th['occupation'];}  ?>"><?php if(isset($_POST["occupation"])){echo $_POST["occupation"];} else{if(isset($th['occupation'])){echo @$th['occupation'];}else{ ?>----Occupation---<?php }} ?></option>
						<option value="Student">Student</option>
						<option value="Trader">Trader</option>
						<option value="Technician">Technician</option>
						<option value="Accountants">Accountants</option>
							<option value="Accounting">Accounting</option>
							<option value=" Administrator"> Administrator</option>
							<option value="Administrative Assistants">Administrative Assistants</option>
							<option value="Advertiser">Advertiser</option>
							<option value="Agents">Agents</option>
							<option value="Air Conditioning Installers">Air Conditioning Installers</option>
							<option value="Analysts">Analysts</option>
							<option value="Architech">Architech</option>
							<option value="Artists">Artists</option>
							<option value="Asphalt Paving Machine Operators">Asphalt Paving Machine Operators</option>
                            <option value="Assistants">Assistants</option>
							<option value="Athletes">Athletes</option>
							<option value="Automobile Body Repair">Automobile Body Repair</option>
							<option value="Bank">Bank</option>
							<option value="Bookkeeping">Bookkeeping</option>
							<option value="Cafeteria">Cafeteria</option>
							<option value="Carpenter">Carpenter</option>
							<option value="Certified Nurse Midwives">Certified Nurse Midwives</option>
							<option value="Cleaner">Cleaner</option>
							<option value="Contractor">Contractor</option>
								<option value="Cooks">Cooks</option>
																<option value="Counselor">Counselor</option>
                                <option value="Doctor">Doctor</option>
								<option value="Comedian">Comedian</option>
                            <option value="Drivers">Drivers</option>
							<option value="Economics">Economics</option>
                                <option value=" Electricians"> Electricians</option>
								<option value="Engineer">Engineer</option>
								<option value="Equipment Installers">Equipment Installers</option>
								<option value="Equipment Operators">Equipment Operators</option>
								<option value="Feed Manager">Feed Manager</option>
								<option value="Graphic Designer">Graphic Designer</option>
								<option value="House helper">House helper</option>
                                <option value="librarian">Libralian</option>
                            
                                <option value="Lawyer">Lawyer</option>
                            
                                <option value="Security">Security</option>
                            
                                
                            
                                
                            
                                <option value="Photographer">Photographer</option>
                            
                                <option value="Web Designer">Web Designer</option>
								<option value="Phone Engineer">Phone Engineer</option>
								
								
								<option value="Sales girl">Sales girl</option>
								<option value="Sales boy">Sales boy</option>
								<option value="Radiographers">Radiographers</option>
								
								
								<option value="Spiritualist">Spiritualist</option>
								
								
								<option value="Teachers">Teachers</option>
								
								<option value="Mathematicians">Mathematicians</option>
								
								<option value="Managerial services">Managerial services</option>
								
								<option value="Photographer">Photographer</option>
								<option value="Rental">Rental</option>
								
								
								<option value="Nanny">Nanny</option>
								
								<option value="Mechanics">Mechanics</option>
								
								<option value="Medical Technician">Medical Technician</option>
								
								
								<option value="News Broadcaster">News Broadcaster</option>
								<option value="Painters">Painters</option>
								<option value="Sculptors Arts Producer">Sculptors Arts Producer</option>
								
								
								<option value="Medical laboratory Scientist">Medical laboratory Scientist</option>
								<option value="Nursing, Attendants">Nursing, Attendants</option>
								
								<option value="Social Workers">Social Workers</option>
								
								<option value="Laborer">Laborer</option>
								
								<option value="Marriage Counselor">Marriage Counselor</option>
								<option value="Doctors of Optometry">Doctors of Optometry</option>
								<option value="Public Health">Public Health</option>
								<option value="Elevator Installers">Elevator Installers</option>
								<option value="Repairers">Repairers</option>
								<option value="Epidemiologists">Epidemiologists</option>
								<option value="Physician Assistant">Physician Assistant</option>
								<option value="Firefighters">Firefighters</option>
								<option value="Drying Machine Operators">Drying Machine Operators</option>
								<option value="Health Diagnosing Practitioners">Health Diagnosing Practitioners</option>
								<option value="Tenders">Tenders</option>
								<option value="Helpers">Helpers</option>
								<option value="Plumber">Plumber</option>
								<option value="Pipefitters">Pipefitters</option>
								<option value="Home Appliance Repairers">Home Appliance Repairers</option>
								<option value="Hospital Registerers">Hospital Registerers</option>
								<option value=" Labor Economics Property Manager"> Labor Economics Property Manager</option>
								<option value="Librarians">Librarians</option>
								<option value="Clinical Mental Health Counselor">Clinical Mental Health Counselor</option>
								<option value="Logistics Planner">Logistics Planner</option>
								<option value="Mortician">Mortician</option>
								<option value="Movie Projectionists">Movie Projectionists</option>
								<option value="Nutritionists">Nutritionists</option>
								<option value="Public Health Specialist">Public Health Specialist</option>
								<option value="Pay loader Operator">Pay loader Operator</option>
								<option value="Painter">Painter</option>
								<option value="Makeup Artist">Makeup Artist</option>
								<option value="Pharmacist Technicians">Pharmacist Technicians</option>
								<option value="Pharmacists">Pharmacists</option>
								<option value="Wedding Planner">Wedding Planner</option>
								<option value="Equipment Repairers">Equipment Repairers</option>
								<option value="Physician">Physician</option>
								<option value="Surgeon">Surgeon</option>
								<option value="Marketing">Marketing</option>
								<option value="Weaving">Weaving</option>
								<option value="Fashion/dressmaking">Fashion/dressmaking</option>
								<option value="Property Managers">Property Managers</option>
								<option value="Real Estate developers">Real Estate developers</option>
								<option value="Car Repairers">Car Repairers</option>
								<option value="Real Estate Brokers">Real Estate Brokers</option>
								<option value="Rehabilitation Repairers">Rehabilitation Repairers</option>
								<option value="Sales Agents">Sales Agents</option>
								<option value="Shipping Agents">Shipping Agents</option>
								<option value="Healthcare">Healthcare</option>
								<option value="Software Developers">Software Developers</option>
								<option value="Solar Panel Installation Supervisor">Solar Panel Installation Supervisor</option>
								<option value="Supervisors">Supervisors</option>
								<option value="Gaming Supervisors">Gaming Supervisors</option>
								<option value="Urban Planner">Urban Planner</option>
								<option value="Waiter">Waiter</option>
								<option value="Waitresses">Waitresses</option>
								<option value="Gate man">Gate man</option>
																<option value="Programmer">Programmer</option>
								<option value="Seller">Seller</option>
						
						
</select>
						</div>
	

<input type="submit" name="subone"class="btn btn-info" id="nextButton" value="SAVE AND CONTINUE &gt;" /><br/>




	</div> 
	</form>
			
			</div>
			
			
			
			
			</div></div>

<?php
}
}
}
}
function displayStep2() {
	$mon=array("01"=>"JANUARY","02"=>"FEBRUARY","03"=>"MARCH","04"=>"APRIL","05"=>"MAY","06"=>"JUNE","07"=>"JULY","08"=>"AUGUST","09"=>"SEPTEMBER","10"=>"OCTOBER","11"=>"NOVEMBER","12"=>"DECEMBER");
include"connect.php";
	$query="select*  from loan where  account_no='{$_SESSION['account']}'";
$wee=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($wee)>0){
	$th=mysqli_fetch_array($wee);
}?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">STEP 2 : LOAN ACCOUNT DETAILS</h4> 
				<p>Please fill the loan Details  Below</p></center><br>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="2" />

			<div class="col-md-3">
			
			
			</div>
			<div class="col-md-5">
			
			
			
			
			<span class="badge" style="background-color:#3385FF;">Loan Account Details ......</span><br><br>
			
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Loan Amount</span>
						<input type="text"onkeyup="this.value = numFormat(this.value)" name="amount"value="<?php if(isset($_POST["amount"])){echo $_POST["amount"];}else{echo @$th['amount'];}  ?>" id='amount' class="form-control" placeholder="ENTER AMOUNT" onblur="update()">
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Loan Duration</span>
								<select name='duration' class="form-control">
								<option   value="<?php if(isset($_POST["duration"])){echo $_POST["duration"];}else{echo @$th['loan_duration'];}  ?>"><?php if(isset($_POST["duration"])){echo $_POST["duration"];}else{ if(isset($th['loan_duration'])){echo @$th['loan_duration'];}else{ ?>Select LOAN Duration <?php } }?></option>
								<option   value="1 Month">1 Month</option>
								
								
								</select>
							</div>
						<div class='form-group'>
<span class="badge" style="background-color:#3385FF;">Loan Percentage Interest</span>
						
								<input class="form-control" id='percent' value="<?php if(isset($_POST["percent"])){echo $_POST["percent"];}else{echo @$th['interest_rate'];} ?>" name="percent" placeholder='30%' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Repayment Amount</span>
								<input class="form-control" id='repay' name="repay_amount" value="<?php if(isset($_POST["repay_amount"])){echo $_POST["repay_amount"];}else{echo @$th['repayment_plan_amount'];}  ?>"placeholder='REPAYMENT PLAN AMOUNT' type="text">
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Payment Structure</span>
								<select name='structure' class="form-control">
								<option   value="<?php if(isset($_POST["structure"])){echo $_POST["structure"];}else{echo @$th['repayment_plan'];}  ?>"><?php if(isset($_POST["structure"])){echo $_POST["structure"];} else{if(isset($th['repayment_plan'])){echo @$th['repayment_plan'];}else{ ?>Select Repayment Structure <?php }} ?></option>
								<option   value="Weekly">Weekly</option>
								
								</select>
							</div>
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">Reason for Loan</span>
						<textarea  name="reason"value="<?php if(isset($_POST["reason"])){echo $_POST["reason"];}else{echo @$th['reason_for_loan'];}  ?>" class="form-control" placeholder="Reason for loan" required=""></textarea>
</div>
						<input type="submit" name="submit2" class="btn btn-info"id="nextButton"value="&lt; Back" style="margin-right: 20px;" />
						<input class="btn btn-info" type="submit" name="subtwo" id="nextButton" value="SAVE AND CONTINUE &gt;" />



</form>
</div> 
			
			</div>
			
			
			
			
			</div></div>
<?php
}
function displayStep3() {
	include"connect.php";
$query="select* from registeruser where account_number='{$_SESSION['account']}'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
$rows=mysqli_fetch_array($dee);
$query="select*  from loan where  account_no='{$_SESSION['account']}'";
$wee=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($wee)>0){
	$th=mysqli_fetch_array($wee);
}
?>
<div class="w3ls-section contact">
		<div class="container"> 
					<div class="w3ls-title">
				<center><h4 class="h3-w3l">STEP 3 : BANK ACCOUNT DETAILS</h4> 
				<p>Please fill your Bank Details  Below</p></center><br>
			</div> 
			
			<div class="row">
			<form action="" method="POST" enctype="multipart/form-data"> 
			<input type="hidden" name="step" value="3" />

			<div class="col-md-3">
		
			
			</div>
			<div class="col-md-5">
			
			<?php
		
$query="select* from bank_info where account_no='{$_SESSION['account']}'";
$dee=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($dee)>0){
$rows=mysqli_fetch_array($dee);
			?>
			
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">Bank Account Name</span>
			<input type="text"  value="<?php echo $rows['account_name'] ?>"class="form-control"  readonly>
			</div>
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">Bank Account Number</span>
						<input type="text"  class="form-control" value="<?php echo $rows['account_number'] ?>" readonly>
						
						</div>
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">Bank Name</span>
							<input type="text"  class="form-control" value="<?php echo $rows['bank_name'] ?>" readonly >
						
						</div>
						<?php  if($rows['bvn']==""){
							echo" <div class='form-group'>
							<span class='badge' style='background-color:#3385FF;'>BVN</span>
							<input type='text' name='bvn' class='form-control' placeholder='BVN NO' id='bvn'value=''onblur='checkbvn()' required>
							<span id='result'>
							</div>";
						}
						else{
							?><div class='form-group'>
							<span class="badge" style="background-color:#3385FF;"></span>BVN<input type="text"  class="form-control" value="<?php echo $rows['bvn'] ?>" readonly >
						</div>
						
						<?php
						}
}
?>	

							
							<div class='form-group'>
							<span class="badge" style="background-color:#3385FF;">How did you find us</span>
						<textarea  name="find" class="form-control" placeholder="How did you find us" value='<?php echo @$th['find'];?>'></textarea>
</div>


<input type="submit" name="subm3" id="nextButton"value="&lt;Back" style="margin-right: 20px;"class="btn btn-info" />
<input type="submit" name="subthree" id="submit" value="FINISH &gt;" class="btn btn-info"/>


</form>
</div> 
			
			</div>
			
			
			
			
			</div></div>
<?php
}
function displayThanks(){
	include"connect.php";
	?>
	
	<div class="w3ls-section contact">
		<div class="container"> 
		<?php
		$query="select account_no from paystackloan where account_no='{$_SESSION['account']}' and confirmed='1' and remove='0'";
	$ee=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($ee)<1){
		?>
		<script>window.location="loan_payment.php"</script>
		<?php
		exit();
	}
			?>		
			<script>window.location="payments.php"</script>
			

			
			
			
			
			</div></div>
	
	<?php
}

?>











</script>
	<script src="js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
		
		
	
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  function update(){
	  
	  var amount=document.getElementById("amount").value;
	   var reg=/,/;
	var amounts=amount.replace(reg,""); 
	  var interest=(amounts*30)/100;
	  document.getElementById("percent").value=interest;
	  
  }
  function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
	var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
			function checkbvn(){
	bvn=document.getElementById("bvn").value;
	if(bvn.length !="11"){
		document.getElementById("result").innerHTML ="Bvn must be 11 numbers only";
		document.getElementById('submit').style.display="none";
		return false;
	}else{
	
	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_bvn.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText=="exists"){
			
				document.getElementById("result").innerHTML ="Bvn Exists";
				document.getElementById('submit').style.display="none";
			}else{
				document.getElementById('submit').style.display="block";
				document.getElementById("result").innerHTML ="";
			}
		 
	  }
	
			
		}
	
	ajax.send("bvn="+bvn);
	}
function accept(amount,stage,id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			 
			document.getElementById("results").innerHTML="<p>Your Application is being processed.<br>We will  credit your Bank Account when as soon as your Loan is approved.</p>";
			
		}
		}
	}
	ajax.send("amount="+amount+"&stage="+stage+"&id="+id);
 
 }
			}
 function reject(id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reject.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			 
			window.location="index.php";
			
		}
		}
	}
	ajax.send("id="+id);
 
 }

	</script>
	<!-- //smooth-scrolling-of-move-up -->  

	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
	
				
				
				
				
				<?php include "footer.php"; ?>