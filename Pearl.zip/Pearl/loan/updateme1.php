<?php
session_start();
include"connect.php";
$action=$_POST['action'];
if($action=='one'){
$account=$_POST['account'];
$x="";
$query="select*  from registeruser where account_number='$account'";
$er=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($er)>0){
	$we=mysqli_fetch_array($er);
	$x.=$we['picture']."|";
	$x.=$we['firstname']."|";
	$x.=$we['lastname']."|";
	
								$query="select total from wallet where account_no='$account'";
								$fe=mysqli_query($con,$query) or die(mysqli_error($con));
								if(mysqli_num_rows($fe)>0){
									$row=mysqli_fetch_array($fe);
									$x.=$row['total'];	
									
								}	
								
								
								
								echo $x;
								exit();
}else{
	echo "Incorrect";
	exit();
}
}elseif($action=='amount1'){
	$amount=$_POST['amount'];
$amount=str_replace(",","",$amount);
$account=$_POST['account'];
$que="select* from wallet where  account_no='$account'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$row=mysqli_fetch_array($res);
if($row['total']<$amount){
	echo "The amount you Entered is bigger than Your Wallet Amount";
	exit();
}elseif($row['suspended']=='1'){
    echo "Your Account is Suspended";
    exit();
    
}else{

echo 'ok';
exit();
}
	
}elseif($action=='two'){
}elseif($action=='three'){
}elseif($action=='four'){
	
	
}elseif($action=="transfer"){
	$ref=rand(100000,9999999);
	$que="select* from wallet where  account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$row=mysqli_fetch_array($res);
$amount=($row['total']+$row['cashback']);
$que="update wallet  set total='$amount', cashback='0' where  account_no='{$_SESSION['account']}'";
mysqli_query($con,$que)or die(mysqli_error($con));

$description=$row['cashback']." was Credited into your Wallet for cashback";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Cashback','{$_SESSION['account']}','".$row['cashback']."','','$amount','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Cashback','','{$_SESSION['account']}','".$row['cashback']."','','$amount','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
echo"done";
	exit();
}
	
	?>