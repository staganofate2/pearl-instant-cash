<?php
session_start();
include_once"connect.php";
$phone=mysqli_real_escape_string($con,$_POST['phone']);


	$query="update registeruser set  phone='$phone' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo "done";
	exit();
}
?>
	