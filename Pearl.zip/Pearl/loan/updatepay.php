<?php
session_start();
include"connect.php";
$ref=$_POST['ref'];
$id=$_POST['id'];


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/transaction/verify/$ref",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "Authorization:Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4",
   
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  //print_r($x['data']['authorization']);
   
   $authorization_code=$x['data']['authorization']["authorization_code"];
     $bin=$x['data']['authorization']["bin"];
       $last4=$x['data']['authorization']["last4"];
       $exp_month=$x['data']['authorization']["exp_month"];
      $exp_year=$x['data']['authorization']["exp_year"];
      $channel=$x['data']['authorization']["channel"];
      $card_type=$x['data']['authorization']["card_type"];
      $bank=$x['data']['authorization']["bank"];
	  $query="update paystackloan set authorization_code='$authorization_code',bin='$bin',last4='$last4',exp_month='$exp_month',exp_year='$exp_year',channel='$channel',card_type='$card_type',bank='$bank',confirmed='1' ,paid='1' where ref_no='$ref' and account_no='{$_SESSION['account']}' and id='$id'";
	  mysqli_query($con,$query) or die(mysqli_error($con));
     
   
   
   
  

$query="select total from wallet where account_no='{$_SESSION['account']}'";
  $s=mysqli_query($con,$query) or die(mysqli_error($con));
  $w=mysqli_fetch_array($s);
  $wallet=$w['total'];
  
	$amounts=$wallet+50;
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="insert into deposit  (ref_no,amount,total,method,confirm,authorize,regdate,account_no,category,confirmed) values('$ref','50','50','Instant','1','1',now(),'{$_SESSION['account']}','Wallet','1')";
mysqli_query($con,$query)or die(mysqli_error($con));


$description="50 was Credited to your Wallet Account ";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','{$_SESSION['account']}','50','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));


$message="Your Deposit of  N 50 has been confirmed and your money has been paid into your Wallet. Balance : N $amounts ".date('d-m-Y');

$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/bankl.png" alt="" width="50%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}

$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendfastmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
   $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);



}

/*
$query="select amount from paystackloan where ref_no='$ref' and account_no='{$_SESSION['account']}' and confirmed='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	 $query="update paystackloan set paid='1' where ref_no='$ref' and account_no='{$_SESSION['account']}'";
	  mysqli_query($con,$query) or die(mysqli_error($con));

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/transaction/$ref",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "Authorization:Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4",
   
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  //print_r($x);
   
  $authorization_code=$x['data']['authorization']["authorization_code"];
     $bin=$x['data']['authorization']["bin"];
       $last4=$x['data']['authorization']["last4"];
       $exp_month=$x['data']['authorization']["exp_month"];
      $exp_year=$x['data']['authorization']["exp_year"];
      $channel=$x['data']['authorization']["channel"];
      $card_type=$x['data']['authorization']["card_type"];
      $bank=$x['data']['authorization']["bank"];
	  $query="update paystackloan set authorization_code='$authorization_code',bin='$bin',last4='$last4',exp_month='$exp_month',exp_year='$exp_year',channel='$channel',card_type='$card_type',bank='$bank',confirmed='1' where ref_no='$ref' and account_no='{$_SESSION['account']}'";
	  mysqli_query($con,$query) or die(mysqli_error($con));
     
   
   
   
  }

$query="select total  from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']+50;
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));


$query="insert into deposit  (ref_no,amount,total,method,confirm,authorize,regdate,account_no,category) values('$ref','$amount','50','50','Instant','1','1',now(),'{$_SESSION['account']}','Wallet')";
mysqli_query($con,$query)or die(mysqli_error($con));
$description="50 was Credited to your Wallet Account ";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Deposit','{$_SESSION['account']}','$amount','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select phone,firstname,lastname,email_address from registeruser where account_number='{$_SESSION['account']}'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
$roo=mysqli_fetch_array($de);
$message="Your Deposit of  N 50 has been confirmed and your money has been paid into your Wallet. Balance : N $amounts ".date('d-m-Y');
$firstname=$roo['firstname'];
$lastname=$roo['lastname'];
$email=$roo['email_address'];
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/bankl.png" alt="" width="50%" height="50%"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}

$message=urlencode($message);
$phone=$roo['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendfastmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";

// Get cURL resource
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
   $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);





echo "done";
}
}else{
	 
	echo "Incorrect";
}
*/
?>