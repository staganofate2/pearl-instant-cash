<?php
include"header.php";
include"modal_box.php"; 
$bar="approved";
?>
		
		
		<?php include"sidebar.php"
?>	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Approved Loan</h4>
				
				<?php $query="select* from loan where account_no='{$_SESSION['account']}' and collected='1' and authorize='1'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				
			
				
								<div class="col-md-12">
				
				<table class="table">
				
				<tr>
				<th>Date</th><th>Repayment Plan</th><th>Duration</th><th>Interest</th><th>Amount Received</th><th>Repayment Amount </th><th>Total Deposit</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($res)){
					
					?>
				<tr>
				<td><?php echo $ree['regdate'] ?></td><td><?php echo $ree['repayment_plan']?></td><td><?php echo $ree['loan_duration'] ?></td><td>₦ <?php echo $ree['interest'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td>₦ <?php echo $ree['total'] ?></td><td>₦<?php echo $ree['deposit'] ?></td>
				
				
				</tr>
				<?php
				}
				?>
				
				
				</table>
				
				
				</div>
				<?php
				}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any  Approved Loan</h4> 
				<p><a href="loan.php">Apply Now </a> </p></center><br>
					<?php
				}
				?>
				
			<?php
			
			include"footer.php";
			?>