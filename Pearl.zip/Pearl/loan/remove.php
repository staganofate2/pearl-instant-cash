<?php
session_start();
include"connect.php";
$id=$_POST['id'];

$query="update paystackloan set remove='1' where id='$id' and account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";

?>