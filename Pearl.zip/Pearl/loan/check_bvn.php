<?php
session_start();
include_once('connect.php');
$bvn=$_POST['bvn'];


$query="select bvn from bank_info where bvn='$bvn'";
	$d=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($d)>0){
		echo "exists";
	}
	

exit();



?>