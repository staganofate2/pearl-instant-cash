<?php
session_start();
include_once"connect.php";
$ref=mysqli_real_escape_string($con,$_POST['ref']);
$id=mysqli_real_escape_string($con,$_POST['id']);
$card=mysqli_real_escape_string($con,$_POST['card']);
$query="select select card_number from paystackloan where ref_no='$ref' and id='$id'";
$d=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($d)>0){
	echo "exists";
	exit();
}else{
	$query="update paystackloan set card_number='$card' where id='$id' and ref_no='$ref'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo "done";
	exit();
}
?>
	