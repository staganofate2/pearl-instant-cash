<?php
include"header.php";
$bar="dashboard";
?>

        
 <?php include"sidebar.php" ?>       
<!--
        <link rel="icon" type="image/ico" href="assets/image/logo2.png">

        <link rel="stylesheet" href="cs/bootstrap.css" type="text/css">
        <link rel="stylesheet" href="cs/font-awesome.css" type="text/css">
        <link rel="stylesheet" href="cs/style.css" type="text/css">

        <link href="css/cs.css" rel="stylesheet" type="text/css">

        
    
	-->
    


       
        

  
       
        

    <style>
	.hides{
		display:none;
	}
	</style>
        
     <!--   <div class="container">
            <div class="row">
            
    <div class="col-md-10 col-md-offset-1">-->
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">ticket</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Add Surety</h2>
			
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
 <h4 class="page-header">Add  Surety</h4>
<?php
      if (isset($_POST['login'])){
								
								
								$number1 = mysqli_real_escape_string($con,$_POST['number1']);
								$number2 = mysqli_real_escape_string($con,$_POST['number2']);
								
								
								$amount = mysqli_real_escape_string($con,$_POST['amount']);
								$amount=str_replace(",","",$amount);
								
								$ref =rand(100000,999999);
								
								$pin = mysqli_real_escape_string($con,$_POST['pin']);

$query="select account_number,phone,firstname,lastname,email_address from registeruser where account_number='$number2'";
$er=mysqli_query($con,$query)or die(mysqli_error($con));
if(mysqli_num_rows($er)>0){
	$xe=mysqli_fetch_array($er);
	if($xe['account_number']==$number1){
		echo "<h3>From Account and To Account is the same</h3>";
	}else{								
								$que="select pin,phone,firstname,lastname,email_address  from registeruser  where  account_number='$number1' and pin='".sha1(md5($pin))."'";
$ret=mysqli_query($con,$que)or die(mysqli_error($con));
if(mysqli_num_rows($ret)<1){
	echo "Incorrect Account Pin";
}else{
$rooww=mysqli_fetch_array($ret);
$query="select total from wallet where account_no='$number1'";
$roww=mysqli_query($con,$query) or die(mysqli_error($con));
								
if(mysqli_num_rows($roww)>0){
	$rowss=mysqli_fetch_array($roww);
	if($rowss['total']<$amount){
		echo "<h3>The amount you want to pay greater than your wallet balance</h3>";
	}else{	
									$amt=$rowss['total']-$amount;
									$query="update wallet set total='$amt' where account_no='$number1'";
mysqli_query($con,$query) or die(mysqli_error($con));
									
									$query="select total from wallet where account_no='$number2'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	$amounts=($rows['total']+$amount);
$query="update wallet set total='$amounts' where account_no='$number2'";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$amount was Debited from your Wallet via Wallet Transfer to account number: $number2, name: ".$xe['firstname']." ".$xe['lastname'];
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id,types) values('Wallet_transfer','$number1','','$amount','$amt','$ref','$description',now(),'','sent')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Wallet_transfer','','','$number1','','$amount','$amt','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was credited into your Wallet by ".$rooww['firstname']." ".$rooww['lastname']." via Wallet Transfer";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id,types) values('Wallet_transfer','$number2','$amount','','$amounts','$ref','$description',now(),'','recieved')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="insert into statements (packages,packages_id,method,account_no,credit,debit,balance,refno,description,transaction_date) values('Wallet_transfer','$id','','$number2','$amount','','$amounts','$ref','$description',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
}
$message="$amount was Debited from your Wallet via Wallet Transfer to account number: $number2, name: ".$xe['firstname']." ".$xe['lastname']." Balance: N $amt ".date('d-m-Y');

$fisrtname=$rooww['firstname'];
$lastname=$rooww['lastname'];
$email=$rooww['email_address'];
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Debit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


$message=urlencode($message);

$phone=$rooww['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";


echo "done";
// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
}


$message="$amount was credited into your Wallet by ".$rooww['firstname']." ".$rooww['lastname']." via Wallet Transfer . Balance :N $amounts ".date('d-m-Y');
$fisrtname=$xe['firstname'];
$lastname=$xe['lastname'];
$email=$xe['email_address'];
$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="http://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}


$message=urlencode($message);

$phone=$xe['phone'];
$sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";


// Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);										echo "<h3>Wallet transfer was successful </h3><p class='error'>Please don't Resend  Again</p>";	
										
										
	echo "<h3>Transfer was Successfull</h3>";								
	
	  }}
}}else{
		  echo "<h3>Account not found</h3>";
	  }}else{
	$bank=array('Access Bank Plc','AG Mortgage Bank Plc','Aso Savings','Access Mobile','Boctrust Micro-finance bank Limited','Chikum Micro-finance bank','Citi bank Nigeria Ltd','Cellulant','Ecobank Nig Plc','Ecobank Express account','Ekondo Micro-finance bank','Empire Mfb','')							
?>
			
			<form class="" action="" method="post" > 
			<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
			
			<div class="form-group">
			<span class="badge" style="background-color:#3385FF;">Number Surety</span>
			<select name='surety'id='surety' class='form-control' required onchange='showit()'>
			<option value="">Select</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			</select>
			</div>
			
			
			<div id='one' class='hides'>
						<div class="form-group">
						<table class='table' ><tr><td><img src='' id='picture' width='100px' alt=''></td><td><b id='first'></b></td><td><b id='last'></b></td> </tr> </table> 
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">1st Surety</span>
						<input type="text" name="surety1" class="form-control" placeholder="Account Number" id='surety1'required="" onblur='update1()'><br>
						<span id='incorrect1'></span>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount to surety</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount1' name="amount" type="text" placeholder='Amount in Digits' onblur="check1()" required>
								<span class='danger' id='result1'></span>
							</div>
						</div>
						<div id='two' class='hides'>
							<div class="form-group">
						<table class='table'><tr><td><img src='' id='picture2' width='150px' alt=''></td><td><b id='first2'></b></td><td><b id='last2'></b></td> </tr> </table> 
						</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">2nd Surety</span>
						<input type="text" name="surety2" class="form-control" placeholder="Account Number" id='surety2'required="" onblur='update2()'><br>
						<span id='incorrect2'></span>
						</div>
							
						

						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount to surety</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount2' name="amount2" type="text" placeholder='Amount in Digits' onblur="check2()" required>
								<span class='danger' id='result2'></span>
							</div>
							</div>
							<div id='three' class='hides'>
							<div class="form-group">
						<table class='table'><tr><td><img src='' id='picture3' width='150px' alt=''></td><td><b id='first3'></b></td><td><b id='last3'></b></td> </tr> </table> 
						</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">3rd Surety</span>
						<input type="text" name="surety3" class="form-control" placeholder="Account Number" id='surety3'required="" onblur='update3()'><br>
						<span id='incorrect3'></span>
						</div>
							
						

						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount to surety</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount3' name="amount3" type="text" placeholder='Amount in Digits' onblur="check3()" required>
								<span class='danger' id='result3'></span>
							</div>
							</div>
							<div id='four' class='hides'>
							<div class="form-group">
						<table class='table'><tr><td><img src='' id='picture3' width='150px' alt=''></td><td><b id='first3'></b></td><td><b id='last3'></b></td> </tr> </table> 
						</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">4th Surety</span>
						<input type="text" name="surety4" class="form-control" placeholder="Account Number" id='surety4'required="" onblur='update4()'><br>
						<span id='incorrect4'></span>
						</div>
							
						

						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount to surety</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount4' name="amount4" type="text" placeholder='Amount in Digits' onblur="check4()" required>
								<span class='danger' id='result4'></span>
							</div>
							</div>
						<input type="submit" class="btn btn-info " id='submit'value="Submit" name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			
			
			
			
			
			
			</div> 
			</form>
			<?php
								}
								?>
				<br>
				<br>
    
   <?php
   include"footer.php"; ?>
  
   <script type="text/javascript">
   function showit(){
	   var x=document.getElementById("surety").value;
	   //alert(x);
	   if(x=='1'){
		   var c=document.getElementById("one");
		   c.style.display="block";
		   document.getElementById("four").style.display="none";
		    document.getElementById("three").style.display="none";
			 document.getElementById("two").style.display="none";
	   }
	   else if(x==2){
		   document.getElementById("one").style.display="block";
		    document.getElementById("two").style.display="block";
			 document.getElementById("four").style.display="none";
			  document.getElementById("three").style.display="none";
	   }else if(x==3){
		   document.getElementById("one").style.display="block";
		   document.getElementById("two").style.display="block";
		   document.getElementById("three").style.display="block";
		    document.getElementById("four").style.display="none";
	   }
	    else if(x==4){
		   document.getElementById("one").style.display="block";
		   document.getElementById("two").style.display="block";
		   document.getElementById("three").style.display="block";
		   document.getElementById("four").style.display="block";
	   }else{
		    document.getElementById("one").style.display="none";
		   document.getElementById("two").style.display="none";
		   document.getElementById("three").style.display="none";
		   document.getElementById("four").style.display="none";
	   }
   }
        
		function update1(){
	
	var types=document.getElementById("surety1").value;
//var b=document.getElementById("loaders").style.display="block";
//alert(types);

var request = $.ajax({
  url: "updateme1.php",
  method: "POST",
  data: { account:types,action:'one'},
  dataType: "html",
  cache:false,
});
 
request.done(function( msg ) {
  alert(msg);
  if(msg=="Incorrect"){
				document.getElementById("incorrect1").innerHTML="Incorrect Account Number";
				document.getElementById("picture").src="";
			document.getElementById("first").innerHTML="";
			document.getElementById("last").innerHTML="";
			
				document.getElementById("balance").innerHTML ="";
			}else{
			var data=msg.split("|");
			var image=data[0];
			var first=data[1];
			var last=data[2];
			
			
			document.getElementById("picture").src="../"+image;
			document.getElementById("first").innerHTML=first;
			document.getElementById("last").innerHTML=last;
			
			document.getElementById("incorrect1").innerHTML = '';
			}
  
});
 
request.fail(function( jqXHR, textStatus ) {
  alert( "Request failed: " + textStatus );
});
			
	 
	}
	

 function check1(){
	 var account=document.getElementById("surety1").value;
	if(document.getElementById("incorrect1").innerHTML=="" && account !=""){
	
	var amount=document.getElementById("amount1").value;
	//var b=document.getElementById("loaders").style.display="block";
	var reg=/,/;
	alert(amount);
	var amounts=amount.replace(reg,""); 
	if(isNaN(amounts)){
		document.getElementById('submit').style.display="none";
		document.getElementById('result1').innerHTML="Please Enter number in Digits";
		//var b=document.getElementById("loaders").style.display="none";
	}else{
    document.getElementById('submit').style.display="block";
	document.getElementById('result1').innerHTML="";
	//var total=new Number(amounts);
	
var request = $.ajax({
  url: "updateme1.php",
  method: "POST",
  data: { action:'amount1',amount:amounts,account:account},
  dataType: "html",
  cache:false,
});
 
request.done(function( msg ) {
  alert(msg);
			//var b=document.getElementById("loaders").style.display="none";
			if(msg=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result1").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result1").innerHTML = msg;
			 document.getElementById("submit").style.display="none";
			}
			
			
	});
 
request.fail(function( jqXHR, textStatus ) {
  alert( "Request failed: " + textStatus );
});
	}
 }
 }
    </script>


         







