<?php
include"header.php";
include"../function.php";
$bar="deposit";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Deposit Slip</h4>
				<div class="col-md-8">
<?php	
		

$amount_w =escape($con,$_POST['amount_w']);
$amount =50;

$ref =rand(10000000000,99999999999);
$fee=($amount*1.5)/100;

		$totals=$amount;
	if(preg_match("/\.+/",$totals)){
	$totals=str_replace(".","",$totals);
					$totals=$totals;
	}else{
		$totals=$totals."00";
	}		
	$query="insert into paystackloan(account_no,ref_no,amount,regdate)values('{$_SESSION['account']}','$ref','$amount',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
	$id=mysqli_insert_id($con);
	  $totals;
	?>
	<center><h4 class="h3-w3l">Thank You</h4>
<p>You need to make a deposit of N50 with your card before you can continue  with your loan Application</p>	
				<p><b>Reference NO:  <?php echo $ref ?></b><br>
				Amount:  N<?php echo $amount ?> <br>
			
				</p></center><br>
				
				<form >
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <button type="button" onclick="payWithPaystack()"> Pay </button> 
</form>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $row['email_address'] ?>',
      amount: '<?php echo $totals ?>',
      channels:['card'],
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $row['firstname'] ?>',
      lastname: '<?php echo $row['lastname'] ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $row['phone'] ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatepay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
		window.location="payments.php";
			
			 
			
			
		}
	}
	ajax.send("ref="+response+"&id=<?php echo $id ?>");
 
 
  }
</script>
  
	<?php



?>

				
				
				</div>
				
					
					
				
				<?php
				include"footer.php" ?>