<?php
include"header.php";
include"modal_box.php"; 
if(!isset($_SESSION['id'])){
	?>
	<script>window.location="index.php";</script>
	<?php
	exit();
}
include"../function.php";
$bar="deposit";
?>
		
	<?php include"sidebar.php" ?>
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
<?php

$id=$_POST['id'];

$query="update loan set rejected='1' where loan_id='$id' and account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "<h3>Loan Application rejected</h3>";

?>
</div>
				<script>
				var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
function accept(amount,stage,id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
			var data=ajax.responseText.split("|");
			var date=data[0];
			var total=data[1];
			
			 
			document.getElementById("results").innerHTML="<p>Your request have been Recieved. We will credit Your Wallet When your Loan is approved.</p>";
			document.getElementById("button").style.display="none";
			
		
		}
	}
	ajax.send("amount="+amount+"&stage="+stage+"&id="+id);
 
 }
 function reject(id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reject.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			
			window.location="index.php";
			
		}
		}
	}
	ajax.send("id="+id);
 
 }

				</script>
					
					
			<?php include "footer.php"; ?>