<?php
include"header.php";
include"modal_box.php"; 
include"../function.php";
$bar="deposit";
?>
		
	<?php include"sidebar.php" ?>
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Deposit Slip</h4>
				<div class="col-md-8">
<?php	
if(isset($_POST['change'])){			
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$loan_id=$_POST['loan_id'];
$loan_repay_id=$_POST['loan_repay_id'];
$query="select total from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	if($rows['total']<$amount){
		echo "<h3 style='color:red'>The amount you want to pay is greater than your wallet balance</h3>";
	}else{
	$amounts=$rows['total']-$amount;
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));

if($loan_repay_id!=""){
$query="select deposit,total  from loan where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['deposit']=="0"){
	$query="update loan set start_date=date(now()) where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['deposit']+$amount;
$total=$ers['total'];
$balance=$am-$total;
$query="update loan set deposit='$am' where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update loan_repay set paid='1' ,paid_date=now() where account_no='{$_SESSION['account']}' and loan_repay_id='$loan_repay_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
}else{
	$query="select deposit,total  from loan where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['deposit']=="0"){
	$query="update loan set start_date=date(now()) where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['deposit']+$amount;
$total=$ers['total'];
$balance=$am-$total;
$query="update loan set deposit='$am' where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select loan_id  from loan where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
$rowse=mysqli_query($con,$query) or die(mysqli_error($con));
while($erc=mysqli_fetch_array($rowse)){
	$query="update loan_repay set paid='1',paid_date=now() where account_no='{$_SESSION['account']}' and loan_id='".$erc['loan_id']."' and paid='0'";
mysqli_query($con,$query) or die(mysqli_error($con));

}
}
$query="select loan_id,total,deposit  from loan where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
$rowsee=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($rowsee)>0){
	$z=mysqli_fetch_array($rowsee);
	if($z['total']<=$z['deposit']){
	$query="update loan set paid='1' where account_no='{$_SESSION['account']}' and loan_id='$loan_id'";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select phone, firstname, lastname from registeruser where account_number='{$_SESSION['account']}'";
$d=mysqli_query($con,$query) or die(mysqli_error($con));
$rowx=mysqli_fetch_array($d);
$phone=$rowx['phone'];
 
  $name=$rowx['firstname']." ".$rowx['lastname'];
 

 
 $message=" Congratulations $name !. Your ".$z['total']." Loan has been completed. You are free to apply for another loan.";
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

	}
}


$ref =rand(100000000,999999999);
$description="Your $amount Loan have been Paid ";
$query="insert into loan_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,loan_id) values('Loan','{$_SESSION['account']}','','$amount','$balance','$ref','$description',now(),'$loan_id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $amount Loan Repayment";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Loan','{$_SESSION['account']}','','$amount','$amounts','$ref','$description',now(),'$loan_id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select refer_id from refer_user  where account_no='{$_SESSION['account']}' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
echo"<h3>Loan Payment was Successful</h3><p class='error'>Please don't Resend  Again</p>";
}
}
}
?>

				
				
				</div>
				
					
					
			<?php include "footer.php"; ?>