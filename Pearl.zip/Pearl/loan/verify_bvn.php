<?php
include"header.php";
$bar="addbankinfo";

?>



		
		
	<?php include"sidebar.php" ?>
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">verify account BVN</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Verify BVN</h2>
				
				</div>
		</div><!--/.row--><hr>
		
		<div class="row">
		
<div class="col-lg-2 ">
</div>
 <div class="col-lg-8 ">
                        
						
	<h4 class="page-header">Verify Bank Account Information</h4>
	<?php

	
				if(isset($_POST['submit'])){
				   
				
$bvn = mysqli_real_escape_string($con,$_POST['bvn']);

							
$query="select*  from bvn where bvn='$bvn'";
$de=mysqli_query($con,$query)or die(mysqli_error($con));
echo mysqli_num_rows($de);
if(mysqli_num_rows($de)>0){
	$s=mysqli_fetch_array($de);
	echo $s['account_no'];
	if($s['account_no']==$_SESSION['account']){
	$first_name=$s['first_name'];
	$last_name=$s['last_name'];
	$dob=$s['dob'];
	$phone=$s['phone'];
	$query="select firstname,lastname,dob,phone from registeruser where account_number='{$_SESSION['account']}'";
	$s=mysqli_query($con,$query)or die(mysqli_error($con));
	$d=mysqli_fetch_array($s);
	$firstname=$d['firstname'];
	$lastname=$d['lastname'];
	$do=$d['dob'];
	$mobile=$d['phone'];
	
	if($dob !=$do){
		
		echo "<h3>Your date of birth does not match the one on your bvn</h3>";
		echo "<div class='form-group'><input type='date' name='don' id='dob'  class='form-control' value='' required><button id='but_dob'  class='btn' onclick='updatedob()'>Update </button></div>";
		
	}
		
	/*
	elseif($mobile !=$phone){
		
		echo "<h3>The phone number you provide  does not match the one on your bvn</h3>";
		echo "<div class='form-group'><input type='text' name='phone' id='phone' class='form-control' value='' required><button id='but_phone'  class='btn' onclick='updatphone()'>Update </button></div>";
		
	}*/
	elseif((strtolower($last_name)==strtolower($lastname) || strtolower($last_name)==strtolower($firstname)) && (strtolower($first_name)==strtolower($firstname) || strtolower($first_name)==strtolower($lastname)) ){
      
      echo "<h3>BVN verification was successful</h3>";
	  echo"<form method='post' action='payments.php'>";
	echo "<table class='table' ><tr><td>First Name</td><td>$first_name</td><td>Last Name</td><td>$last_name</td><td>Date of Birth</td><td>$dob</td><td>Phone Number</td><td>$mobile</td></tr></table>";
	 //echo "<p>". print_r($x)."</p>";
  $query="update bank_info set bvn='$bvn' where account_no='{$_SESSION['account']}'";
  mysqli_query($con,$query)or die(mysqli_error($con));
  echo "<input type='submit' name='go' value='Continue' class='btn btn-info'></form>";
      
		
		
	}else{
	    echo "<h3>The Name you registered with does not match the one on your bvn</h3>";
		echo "<div class='form-group'><input type='text' name='first' id='first'  class='form-control' value='$first_name'placeholder='First Name' required></div><div class='form-group'>
		<input type='text' name='last' id='last'  class='form-control' value='$last_name' placeholder='First Name'required></div><button id='but_name'  class='btn btn-info' onclick='updatedname()'>Update Name</button>";
	  

	}		
		
	}else{
	echo "<h3 style='color:red'>BVN Exists</h3>";
	}
}else{
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/bank/resolve_bvn/$bvn",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4",
    "cache-control: no-cache"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  if($x['status']=="true" && $x['message']=="BVN resolved"){
	$first_name=  $x['data']['first_name'];
	$last_name=$x['data']['last_name'];
	$dob=$x['data']['formatted_dob'];
	$mobile=$x['data']['mobile'];
	$query="select firstname,lastname,dob,phone from registeruser where account_number='{$_SESSION['account']}'";
	$s=mysqli_query($con,$query)or die(mysqli_error($con));
	$d=mysqli_fetch_array($s);
	$firstname=$d['firstname'];
	$lastname=$d['lastname'];
	$do=$d['dob'];
	$phone=$d['phone'];
	$query="insert into bvn (account_no,bvn,first_name,last_name,dob,phone,postdate) values('{$_SESSION['account']}','$bvn','$first_name','$last_name','$dob','$mobile',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
	
	if($dob !=$do){
		
		echo "<h3>Your date of birth does not match the one on your bvn</h3>";
		echo "<div class='form-group'><input type='date' name='don' id='dob'  class='form-control' value='' required><button id='but_dob'  class='btn' onclick='updatedob()'>Update </button></div>";
		
	}
		
	/*
	elseif($mobile !=$phone){
		
		echo "<h3>The phone number you provide  does not match the one on your bvn</h3>";
		echo "<div class='form-group'><input type='text' name='phone' id='phone' class='form-control' value='' required><button id='but_phone'  class='btn' onclick='updatphone()'>Update </button></div>";
		
	}*/
	elseif($first_name !=$$firstname || $last_name != $lastname or $last_name!=$firstname || $first_name!=$lastname){
		echo "<h3>The Name you registered with does not match the one on your bvn</h3>";
		echo "<div class='form-group'><input type='text' name='first' id='first'  class='form-control' value='$first_name' required>
		<input type='text' name='last' id='last'  class='form-control' value='$last_name' required><button id='but_name'  class='btn' onclick='updatedname()'>Update Name</button></div>";
		
	}else{
	  echo "<h3>BVN verification was successful</h3>";
	  echo"<form method='post' action='payments.php'>";
	echo "<table class='table' ><tr><td>First Name</td><td>$first_name</td><td>Last Name</td><td>$last_name</td><td>Date of Birth</td><td>$dob</td><td>Phone Number</td><td>$mobile</td></tr></table>";
	 //echo "<p>". print_r($x)."</p>";
   $query="update bank_info set bvn='$bvn' where account_no='{$_SESSION['account']}'";
  mysqli_query($con,$query)or die(mysqli_error($con));
  echo "<input type='submit' name='go' value='Continue' class='btn btn-info'></form>";

	}							
	}
	}
	}
	}else{
		
		
								
?>
	<form role="form" action="" method="post">
				

						
							<div class='form-group'>
						<input type="text" name="bvn" class="form-control" placeholder="BVN" id='bvn'required="" onblur='checkbvn()'><br>
						
						
						<span id='result'>
						</div>
						
							<button class="btn btn-info" id='submit' type="submit" name="submit">VERIFY</button>
							
						
				</form>		
				<?php
				}
				?>
			
						
						
						
                       
                    </div>





		
			
			
			
		</div><!--/.row-->
		
		<script>
				var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
function updatename(){
	$first=document.getElementById("first").value;
	$last=document.getElementById("last").value;
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_name.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
			alert("Name updated successful");
			document.getElementById("but_name").style.display="none";
			
		
		}
	}
	ajax.send("first="+first+"&last="+last);
 
 }
 
 function updatephone(){
	$phone=document.getElementById("phone").value;
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_phone.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
			alert("Phone updated successful");
			document.getElementById("but_phone").style.display="none";
			
		
		}
	}
	ajax.send("phone="+phone);
 
 }


function updatedob(){
	dob=document.getElementById("dob").value;
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_dob.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
			alert("Date of birth updated successful");
			document.getElementById("but_dob").style.display="none";
			
		
		}
	}
	ajax.send("dob="+dob);
 
 }
 	function checkbvn(){
	bvn=document.getElementById("bvn").value;
var bvn=bvn.replace(/\D\s*/g, "");
		document.getElementById("bvn").value=bvn;
		bvn=document.getElementById("bvn").value;
	if(bvn.length !="11"){
		document.getElementById("result").innerHTML ="Bvn must be 11 numbers only";
		document.getElementById('submit').style.display="none";
		return false;
	}else{
	
	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_bvn.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText=="exists"){
			
				document.getElementById("result").innerHTML ="Bvn Exists";
				document.getElementById('submit').style.display="none";
			}else{
				document.getElementById('submit').style.display="block";
				document.getElementById("result").innerHTML ="";
			}
		 
	  }
	
			
		}
	
	ajax.send("bvn="+bvn);
	}}
				</script>
		
		<?php include"footer.php" ?>