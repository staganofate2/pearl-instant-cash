<?php
include"header.php";
include"modal_box.php"; 
$bar="manage";
?>
		
		
		<?php include"sidebar.php"
?>	
	
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Card Information</h4>
				
				<?php $query="select* from paystackloan where account_no='{$_SESSION['account']}' and confirmed='1' and remove='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				
			
				
						
				
				<table class="table">
				<?php while($d=mysqli_fetch_array($res)){
					?>
				<tr>
				<th>Card Information</th>
				
				</tr>
				<tr>
				<td>Card Type</td>
				<td><?php echo @$d['card_type']; ?></td>
				
				</tr>
				<tr>
				<td>Last Four Digit</td>
				<td><?php echo @$d['last4']; ?></td>
				
				</tr>
				
				<tr>
				<td>Expiring Month</td>
				<td><?php echo @$d['exp_month']; ?></td>
				
				</tr>
				<tr>
				<td>Expiring Year</td>
				<td><?php echo @$d['exp_year']; ?></td>
				
				</tr>
				<tr>
				<td>Bank</td>
				<td><?php echo @$d['bank']; ?></td>
				
				</tr>
					<?php
				$query="select account_no from loan where paid='0' and  account_no='{$_SESSION['account']}' and collected='1'";
				$resx=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($resx)<1){
				    ?>
				    <tr>
				<td></td>
				    
				<td id='remove<?php echo $d['id'] ?>'><button onclick="reject('remove<?php echo $d['id'] ?>','<?php echo $d['id'] ?> ]')" >Remove Card</button></td>
				</tr>
				<?php
				}
				
				}
				?>
				
				</table>
				
				
				
				<?php
				}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Active Card</h4> 
				</center><br>
					<?php
				}
				?>
				
				
		
		
	<?php include "footer.php"; ?>
		<script>
		function reject(but,id){
	
	
	
	document.getElementById(but).innerHTML = 'please wait ...';
	 ajax.open("POST", "remove.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			 
			document.getElementById(but).innerHTML = 'Removed Successfully';
			
		}
		}
	}
	ajax.send("id="+id);
 
 }

	</script>
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	 
		
