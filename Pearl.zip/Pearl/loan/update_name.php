<?php
session_start();
include_once"connect.php";
$first=mysqli_real_escape_string($con,$_POST['first']);
$last=mysqli_real_escape_string($con,$_POST['last']);
$query="update registeruser set  firstname='$first',lastname='$last' where account_number='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));

	echo "done";
	exit();

?>
	