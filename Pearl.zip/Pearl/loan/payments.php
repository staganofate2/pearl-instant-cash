<?php
include"header.php";
include"modal_box.php"; 
if(!isset($_SESSION['id'])){
	?>
	<script>window.location="index.php";</script>
	<?php
	exit();
}
include"../function.php";
$bar="deposit";
?>
		
	<?php include"sidebar.php" ?>
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Loan Form</h4>
				<div class="col-md-8">

				<div class="w3ls-title">
				<center><h4 class="h3-w3l">Thanks for your Interest </h4> 
				<?php $query="select* from loan where stage > '0' and collected='1' and   paid='1' and account_no='{$_SESSION['account']}' order by loan_id desc ";
				$querys=mysqli_query($con,$query) or die(mysqli_error($con));
				 mysqli_num_rows($querys);
				if(mysqli_num_rows($querys)<1){
					
					?><h3>Please we Can only Give you ₦ 2000 for now</h3>
					<table class='table'>
					<tr><td>Loan Duration</td><td>1 Month</td></tr>
					<tr><td>Loan Interest</td><td><?php $interest=(30*2000)/100;echo $interest ?></td></tr>
					<tr><td>Repayment Structure</td><td>Weekly</td></tr>
					<tr><td>Repayment Weekly Amount</td><td>₦  <?php $amount=($interest+2000)/4; echo $amount ?></td></tr>
					<tr><td>Total Amount</td><td>₦ <?php $total=($interest+2000); echo $total ?></td></tr>
					</table>
					<p>check your repayment plan for more detail</p>
				<p id='results'></p>
				<div id='button'><table>
			<tr><td>	<form method='post' action='update_loan.php' class='form'><input type='submit' style='color:green;marging-right:20px'name='submit'button class='btn info' value='Accept'> <input type='hidden' name='amount' value="2000"><input type='hidden' name='stage' value="1"><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form></td><td><form method='post' action='reject.php' class='form'><input type='submit' class='btn info'  name='submit' style='color:red;marging-right:20px'value='Reject'><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form></td></tr></table>
				</div>
				<?php
				$query="select refer_id from refer_user  where account_no='{$_SESSION['account']}' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
				}else{
					$des=mysqli_fetch_array($querys);
					if($des['stage']=="1" ){
					 
					
					?>
					<h3>Please we Can only Give you ₦ 4000 for now</h3>
					<table class='table'>
					<tr><td>Loan Duration</td><td>1 Month</td></tr>
					<tr><td>Loan Interest</td><td><?php $interest=(30*4000)/100;echo $interest ?></td></tr>
					<tr><td>Repayment Structure</td><td>Weekly</td></tr>
					<tr><td>Repayment Weekly Amount</td><td>₦  <?php $amount=($interest+4000)/4; echo $amount ?></td></tr>
					<tr><td>Total Amount</td><td>₦ <?php $total=($interest+4000); echo $total ?></td></tr>
					</table>
					<p>check your repayment plan for more detail</p>
				<p id='results'></p>
				<div id='button'>
				<form method='post' action='update_loan.php'><input type='submit' name='submit'button class='btn' value='Accept'> <input type='hidden' name='amount' value="4000"><input type='hidden' name='stage' value="2"><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form><form method='post' action='reject.php'><input type='submit' class='btn'  name='submit' value='Reject'><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form>
					</div>
					<?php
					}
					elseif($des['stage']=="2"){
					
					?>
					<h3>Please we Can only Give you ₦ 6000 for now</h3>
					<table class='table'>
					<tr><td>Loan Duration</td><td>1 Month</td></tr>
					<tr><td>Loan Interest</td><td><?php $interest=(30*6000)/100;echo $interest ?></td></tr>
					<tr><td>Repayment Structure</td><td>Weekly</td></tr>
					<tr><td>Repayment Weekly Amount</td><td>₦  <?php $amount=($interest+6000)/4; echo $amount ?></td></tr>
					<tr><td>Total Amount</td><td>₦ <?php $total=($interest+6000); echo $total ?></td></tr>
					</table>
					<p>check your repayment plan for more detail</p>
				<p id='results'></p>
				<div id='button'>
				<form method='post' action='update_loan.php'><input type='submit' name='submit'button class='btn' value='Accept'> <input type='hidden' name='amount' value="6000"><input type='hidden' name='stage' value="3"><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form><form method='post' action='reject.php'><input type='submit' class='btn'  name='submit' value='Reject'><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form>
					</div>
					<?php
					}
					elseif($des['stage']=="3"){
					
					?>
					<h3>Please we Can only Give you 8000 for now</h3>
					<table class='table'>
					<tr><td>Loan Duration</td><td>1 Month</td></tr>
					<tr><td>Loan Interest</td><td><?php $interest=(30*8000)/100;echo $interest ?></td></tr>
					<tr><td>Repayment Structure</td><td>Weekly</td></tr>
					<tr><td>Repayment Weekly Amount</td><td>₦  <?php $amount=($interest+8000)/4; echo $amount ?></td></tr>
					<tr><td>Total Amount</td><td>₦ <?php $total=($Interest+8000); echo $total ?></td></tr>
					</table>
					<p>check your repayment plan for more detail</p>
				<p id='results'></p>
				<div id='button'>
					<form method='post' action='update_loan.php'><input type='submit' name='submit'button class='btn' value='Accept'> <input type='hidden' name='amount' value="8000"><input type='hidden' name='stage' value="4"><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form><form method='post' action='reject.php'><input type='submit' class='btn'  name='submit' value='Reject'><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form>
					</div>
					<?php
					}
					elseif($des['stage']=="4"){
					
					?>
					<h3>Please we Can only Give you ₦ 10000 for now</h3>
					<table class='table'>
					<tr><td>Loan Duration</td><td>1 Month</td></tr>
					<tr><td>Loan Interest</td><td><?php $interest=(30*10000)/100;echo $interest; ?></td></tr>
					<tr><td>Repayment Structure</td><td>Weekly</td></tr>
					<tr><td>Repayment Weekly Amount</td><td>₦  <?php $amount=($interest+10000)/4; echo $amount ?></td></tr>
					<tr><td>Total Amount</td><td>₦ <?php $total=($interest+10000); echo $total ?></td></tr>
					</table>
					<p>check your repayment plan for more detail</p>
				<p id='results'></p>
				<div id='button'>
					<form method='post' action='update_loan.php'><input type='submit' name='submit'button class='btn' value='Accept'> <input type='hidden' name='amount' value="10000"><input type='hidden' name='stage' value="5"><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form><form method='post' action='reject.php'><input type='submit' class='btn'  name='submit' value='Reject'><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form>
					</div><?php
					}
					elseif($des['stage']>="5"){
						$stage=$des['stage']+1;
					
					?>
					<h3>Please we Can only Give you ₦ 10000 for now</h3>
					<table class='table'>
					<tr><td>Loan Duration</td><td>1 Month</td></tr>
					<tr><td>Loan Interest</td><td><?php $interest=(30*10000)/100;echo $interest ?></td></tr>
					<tr><td>Repayment Structure</td><td>Weekly</td></tr>
					<tr><td>Repayment Weekly Amount</td><td>₦  <?php $amount=($interest+10000)/4; echo $amount ?></td></tr>
					<tr><td>Total Amount</td><td>₦ <?php $total=($interest+10000); echo $total ?></td></tr>
					</table>
					<p>check your repayment plan for more detail</p>
				<p id='results'></p>
				<div id='button'>
				    
				    	<form method='post' action='update_loan.php'><input type='submit' name='submit'button class='btn' value='Accept'> <input type='hidden' name='amount' value="10000"><input type='hidden' name='stage' value="<?php echo $stage ?>"><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form><form method='post' action='reject.php'><input type='submit' class='btn'  name='submit' value='Reject'><input type='hidden' name='id' value="<?php echo $_SESSION['id'] ?>"></form>
				
					</div><?php
					}
				}
				?></center><br>
			</div> 
			
				
				</div>
				<script>
				var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
function accept(amount,stage,id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update_loan.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
			var data=ajax.responseText.split("|");
			var date=data[0];
			var total=data[1];
			
			 
			document.getElementById("results").innerHTML="<p>Your request have been Recieved. We will credit Your Wallet When your Loan is approved.</p>";
			document.getElementById("button").style.display="none";
			
		
		}
	}
	ajax.send("amount="+amount+"&stage="+stage+"&id="+id);
 
 }
 function reject(id){
	
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "reject.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				if(ajax.responseText=="done"){
			
			window.location="index.php";
			
		}
		}
	}
	ajax.send("id="+id);
 
 }

				</script>
					
					
			<?php include "footer.php"; ?>