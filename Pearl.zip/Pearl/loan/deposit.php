<?php
include"header.php";
include"modal_box.php"; 
$bar="deposit";
?>
		
		<?php include"sidebar.php" ?>
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Loan</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Loan Deposit</h4>
				
				
			<?php $query="select total from wallet where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				$ve=mysqli_fetch_array($res);
				
					?>
				<h5 class="page-header">Wallet Balance  ₦ <?php echo $ve['total'] ?></h5>
				<div class="col-md-8">
			

				<form action="payment.php" method="POST" enctype="multipart/form-data">
<?php
if(isset($_GET['action'])){
					?><form action="payment.php" method="POST" enctype="multipart/form-data">
						
			<div class="form-group">
			<span class="badge" style="background-color:#3385FF;">Loan Amount</span>
								<select name='type' class="form-control" id='actype' onchange="update()">
								
								<?php
						
							$query="select total  from loan where account_no='{$_SESSION['account']}' and active='0' and loan_id='".$_GET['loan_id']."'";
														$re=mysqli_query($con,$query) or die(mysqli_error($con));
								while($ros=mysqli_fetch_array($re)){
									?>
								<option   value="<?php echo $ros['total']?>"><?php echo $ros['total']?></option>
								<?php
								}
								?>
								</select>
							</div>
							<?php
				}else{
				?>
			
							<?php
				}
				?>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Amount</span>
							<?php
							if(isset($_GET['action']) && $_GET['action']=="single"){
								$id=$_GET['id'];
								$amount=$_GET['amount'];
								$loan_id=$_GET['loan_id'];
								?>
								
								<input  value="<?php echo $loan_id ?>"  name="loan_id" type="hidden" >
								<input  value="<?php echo $id ?>"  name="loan_repay_id" type="hidden" >
								<input class="form-control" value="<?php echo $amount ?>" name="amount" type="text" readonly>
								<?php
							}
							elseif(isset($_GET['action']) && $_GET['action']=="All"){
								$id=$_GET['id'];
								$amount=$_GET['amount'];
								$loan_id=$_GET['loan_id'];
								?>
								
								<input  value="<?php echo $loan_id ?>"  name="loan_id" type="hidden" >
								<input  value="<?php echo $id ?>"  name="loan_repay_id" type="hidden" >
								<?php $query="select sum(p.amount) as total from loan_repay p inner join loan f using(loan_id) where f.loan_id='$loan_id' and p.paid='0'";
								$rec=mysqli_query($con,$query) or die(mysqli_error($con));
								$es=mysqli_fetch_array($rec);
								?>
								<input class="form-control" value="<?php echo $es['total'] ?>" name="amount" type="text" readonly>
								<?php
							}
							
							?>
								
							</div>
							
							<button class="btn btn-info" name="change" type="submit">Continue</button>
				
				</form>

				<br>
				<button class="btn btn-info" onclick="goback()">Cancel</button>

				
				</div>
				
				
				
				
				
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function goback(){
			window.location="repay.php";
		}
 function update(){
	
	var types=document.getElementById("actype").value;
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "update2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
				document.getElementById("payment").value = ajax.responseText;
			 
			
			
		}
	}
	ajax.send("type="+types+"&id=<?php echo $rows['loan_id'] ?>");
 
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
<?php include "footer.php"; ?>