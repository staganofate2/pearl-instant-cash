<?php
session_start();
include_once"connect.php";
$dob=mysqli_real_escape_string($con,$_POST['dob']);


	$query="update registeruser set  dob='$dob' where account_number='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));
	echo "done";
	exit();

?>
	