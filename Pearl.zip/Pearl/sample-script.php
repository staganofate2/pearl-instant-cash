<?php 


/***********************************************************
	Payflexi methods handles serives that don't have
	billersCode such as mtn,airtel,glo,etisalat Service
	e.g http://sandbox.vtpass.com/api/services?identifier=airtime,
	typres can be gotten from the Get service Endpoint
*************************************************************/ 
/*
  	$ref="901059298989";
$username = " sandox@vtpass.com"; //email address(sandbox@vtpass.com)
$password = "sandbox"; //password (sandbox)
$host = 'http://sandbox.vtpass.com/api/payflexi';
$data = array(
 'serviceID'=> 'mtn',//$_POST['serviceID'], //integer e.g mtn,airtel
  	'amount' => '500.00', //$_POST['amount'], // integer
  	'phone' => '08123456789',//$_POST['recepient'], //integer
  	'request_id' => '970859298989' // unique for every transaction from your platform
);

$curl       = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => $host,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_USERPWD => $username.":" .$password,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => $data,
));
echo curl_exec($curl);



/********************************************************************************
	Payfix methods handles serives that have
	billersCode such as gotv,dstv,eko-electric,abuja-electric Service 
	typres can be gotten from the services endpoint 
	e.g http://sandbox.vtpass.com/api/services?identifier=bills,
	also the variation code can be gotten from the service-variations 
	endpoint e.g http://sandbox.vtpass.com/api/service-variations?serviceID=dstv
**********************************************************************************/ 
//echo $ref =rand(100000000000,999999999999);

/*$username = "sandbox@vtpass.com"; //email address(sandbox@vtpass.com)
$password = "sandbox"; //password (sandbox)
$host = 'http://sandbox.vtpass.com/api/payflexi';
$data = array(
  	"serviceID"=> "mtn",//$_POST['serviceID'], //integer e.g gotv,dstv,eko-electric,abuja-electric
  	//"billersCode"=> "1111111111",//$_POST['billersCode'], // e.g smartcardNumber, meterNumber,
  	//"variation_code"=> "dstv1",//$_POST['variation_code'], // e.g dstv1, dstv2,prepaid,(optional for somes services)
  	"amount" =>  "2000.00",//$_POST['amount'], // integer (optional for somes services)
  	"phone" =>"08123456789",// $_POST['recepient'], //integer
  	"request_id" => "$ref" // unique for every transaction from your platform
);
$curl       = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => $host,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_USERPWD => $username.":" .$password,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => $data,
));
$x= curl_exec($curl);
$y=json_decode($x,true);
print_r($y);
echo $y['requestId'];

*/

  	$ref="901059298989";
$username = " sandox@vtpass.com"; //email address(sandbox@vtpass.com)
$password = "sandbox"; //password (sandbox)
$host = 'https://vtpass.com/api/merchant-verify';
$data = array(
 'serviceID'=> 'gotv',//$_POST['serviceID'], //integer e.g mtn,airtel
  'billersCode'=> '4622316403'
  	
);

$curl       = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => $host,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_USERPWD => $username.":" .$password,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => $data,
));
//echo curl_exec($curl);
$x= curl_exec($curl);
$y=json_decode($x,true);
print_r($y);

  
  
?>