<?php
session_start();
include_once('connect.php');

$type=$_POST['type'];

$que="select* from investment where duration='$type' and account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$row=mysqli_fetch_array($res);
$gtotal=$row['amount']+$row['interest'];
echo $row['maturity_date']."|".$row['start_date']."|".$row['amount']."|".$row['interest']."|".$gtotal."|".$row['interest']."|".$row['investment_id']."|".$row['active'];
exit();



?>