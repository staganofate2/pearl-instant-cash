<?php
include"header.php";
include"modal_box.php";
$bar="index";
?>


<style>
  /* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add an active class to highlight the current page */
.active {
    background-color: #4CAF50;
    color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
    display: none;
} 
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}
@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive a.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
 </style>
 <script>

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
} 
</script>
<?php
include"sidebar.php";
?>
		
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Invest Overview</h2>
				
			</div>
		</div><!--/.row--><hr>
		
		<div class="row">
			<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-8">
		<ul class='home'>
		<li><a href='index.php'>PEARL INVEST </a>:Our members who has funded their wallet may decide to create pearl investment account and invest huge sum because of its huge return  on investment for a certain period depending on choice. The member equally has the right to withdraw monthly interest yielding  and leave the capital till maturity .The menu are for your usage example <a href='summary.php'>INVESTMENT SUMMARY</a> , <a href='investform.php'>INVESTMENT FORM</a> , <a href='interest.php'>ADDED INTEREST</a> , <a href='withdrawal.php'>PAYOUT </a> to your wallet and <a href='statement.php'>STATEMENT</a>.</li></ul> 
		</div>
		</div><!--/.row-->
		
		<?php
		include"footer.php";
		?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		