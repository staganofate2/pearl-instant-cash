<?php
include"header.php";
include"modal_box.php"; 
include"../function.php";
$bar="withdrawal"
?>
		
	<?php include "sidebar.php"; ?>
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Invest</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Investment Form</h4>
				<div class="col-md-8">
<?php	
if(isset($_POST['change'])){			
$duration=mysqli_real_escape_string($con,$_POST['duration']);
					$name=mysqli_real_escape_string($con,$_POST['name']);
					$amount=mysqli_real_escape_string($con,$_POST['amount']);
					$amount=str_replace(",","",$amount);
					$imonth=mysqli_real_escape_string($con,$_POST['imonth']);
					$mdate2=mysqli_real_escape_string($con,$_POST['mdate']);
					$total=mysqli_real_escape_string($con,$_POST['total']);
					$percent=mysqli_real_escape_string($con,$_POST['percent']);
					
					$querys="select amount,deposit_id from deposit where  paid='0' and account_no='{$_SESSION['account']}' and authorize='1' ";
$p=mysqli_query($con,$querys)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
          $ref =rand(100000000,999999999);
         $query="select firstname,lastname,email_address,phone  from registeruser  where  account_number='{$_SESSION['account']}'";
$re=mysqli_query($con,$query)or die(mysqli_error($con));
$rs=mysqli_fetch_array($re);
$firstname=$rs['firstname'];
$lastname=$rs['lastname'];
$email=$rs['email_address'];
$phone=$rs['phone'];
        $quee="select* from wallet where  account_no='{$_SESSION['account']}'";
$resx=mysqli_query($con,$quee)or die(mysqli_error($con));
$rowsa=mysqli_fetch_array($resx);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rowsa['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rowsa['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rowsa['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
		}
	}elseif($rowsa['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}elseif($rowsa['category']=="Zenith"){
		if($amountt>=100000){
			$bonus=($amountt*5)/100;
		 	$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date) values('Bonus','{$_SESSION['account']}','$bonus','','$amounts','$ref','$message',now())";
mysqli_query($con,$query) or die(mysqli_error($con));
	$messages = '<html><body>';

$messages .= '<table  border="0" cellpadding="10">';
$messages.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="73px" height="26px"></td></tr>';
$messages .= "<tr style='background: #eee;'><td><strong>Dear  </strong>  $firstname $lastname </td></tr>";
$messages .= "<tr><td><p> $message</p></td></tr>";



$messages .= "</table>";
$messages .= "</body></html>";

$to = "$email";

$subject = "Credit Alert";

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $messages, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
				}
 $message=urlencode($message);
 $sender="pearl";
$http="http://www.smslive247.com/http/index.aspx?cmd=sendquickmsg&owneremail=pearlsolutionprojectmanager@gmail.com&subacct=instantcredit&subacctpwd=pearlsolution&message=$message&sender=$sender&sendto=$phone&msgtype=0";
	 // Get cURL resource
 
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
 echo $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);
			
		}
	}
        
        
    }
}

					if($amount>=5000){
					
					$query="select duration from investment where duration='$duration' and active='0' and account_no='{$_SESSION['account']}'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	echo "<h3>You already have similar Investment </h3><p>Please Choose Different Investment. <br><a href='investform.php'>Back</a></p>";
}else{
						$query="select total from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	if($rows['total']<$amount){
		echo "<h3>The amount you want to pay greater than your wallet balance</h3>";
	}else{
		$amounts=$rows['total']-$amount;
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));


					$query="insert into investment (invest_name,duration,amount,interest_rate,maturity_date,mont_interest_witdra,total_duration_interest,account_no,regdate,invest_date,start_date) values('$name','$duration','$amount','$percent','$mdate2','0','0','{$_SESSION['account']}',now(),now(),now())";
					mysqli_query($con,$query)or die(mysqli_error($con));
					$id=mysqli_insert_id($con);
					$ref =rand(100000,999999);
$description="$amount was credited into your $duration Investment";
$query="insert into investment_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,investment_id) values('Investment','{$_SESSION['account']}','$amount','','$amount','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$amount was debited  from your Wallet for $duration Investment Deposit";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Investment','{$_SESSION['account']}','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select refer_id from refer_user  where account_no='{$_SESSION['account']}' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
					echo "<h3>Your Investment has been Created Successfully</h3><p class='error'>Please don't Resend  Again</p>";
}
}
}
}else{
	echo"<h3>Invest Amount should not be less than 5000</h3>";
}
}
?>

				
				
				</div>
				
					
					
				
				<?php include "footer.php"; ?>