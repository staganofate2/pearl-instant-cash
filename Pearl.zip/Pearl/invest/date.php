<?php
$mont=$_POST['month'];
$amount=$_POST['amount'];
$amount=str_replace(",","",$amount);
$interest=$amount*0.1;
$total=$mont*$amount*0.1;
    $date = date("Y-m-d", strtotime(" +$mont months"));
	
    echo $date."|".$interest."|".$total;
?>
	