<?php
include"header.php";
include"modal_box.php"; 
include"../function.php";
$bar="deposit";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Investment</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Deposit Slip</h4>
				<div class="col-md-8">
<?php	
if(isset($_POST['change'])){			
$actype =escape($con,$_POST['type']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$id=$_POST['id'];
$querys="select amount,deposit_id from deposit where  paid='0' and account_no='{$_SESSION['account']}' and authorize='1' ";
$p=mysqli_query($con,$querys)or die(mysqli_error($con));
if(mysqli_num_rows($p)>0){
    while($c=mysqli_fetch_array($p)){
        $quee="select* from wallet where  account_no='{$_SESSION['account']}'";
$resx=mysqli_query($con,$quee)or die(mysqli_error($con));
$rowsa=mysqli_fetch_array($resx);
        $amountt=$c['amount'];
        $did=$c['deposit_id'];
        if($rowsa['category']=="Bronze"){
		if($amountt>=20000){
			$bonus=($amountt*1)/100;
			$amounts=($rowsa['total']+$bonus);
			$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysql_error($con));
			
			$message="Your  N$bonus Bronze bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
			
		}
	}elseif($rowsa['category']=="Silver"){
		if($amountt>=40000){
			$bonus=($amountt*2)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Silver bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		}
	}elseif($rowsa['category']=="Diamond"){
		if($amountt>=60000){
			$bonus=($amountt*3)/100;
			$amounts=($rowsa['total']+$bonus);
			
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Diamond bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
		}
	}elseif($rowsa['category']=="Gold"){
		if($amountt>=80000){
			$bonus=($amountt*4)/100;
			$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Gold bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		}
	}elseif($rowsa['category']=="Zenith"){
		if($amountt>=100000){
			$bonus=($amountt*5)/100;
		 	$amounts=($rowsa['total']+$bonus);
				$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
			mysqli_query($con,$query)or die(mysqli_error($con));
				$query="update deposit set bonus='$bonus',paid='1'  where account_no='{$_SESSION['account']}' and deposit_id='$did'";
			mysqli_query($con,$query)or die(mysqli_error($con));
			
			$message="Your  N$bonus Zenith bonus for N$amountt  Deposit has been Paid into your Wallet";
$query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Deposit','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
			
		}
	}
        
        
    }
}


$que="select* from wallet where  account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysql_error($con));
$roww=mysqli_fetch_array($res);
if($roww['total']>=$amount){
$query="select total from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	
	$amounts=$rows['total']-$amount;
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));

$query="select amount  from investment where account_no='{$_SESSION['account']}' and investment_id='$id' and duration='$actype'";
$rowss=mysqli_query($con,$query) or die(mysqli_error($con));
$ers=mysqli_fetch_array($rowss);
if($ers['amount']=="0"){
	$query="update investment set start_date=date(now()) where account_no='{$_SESSION['account']}' and investment_id = '$id' and duration='$actype'";
	mysqli_query($con,$query) or die(mysqli_error($con));
}
$am=$ers['amount']+$amount;
$query="update investment set amount='$am',wallet='$am' where account_no='{$_SESSION['account']}' and duration='$actype' and investment_id = '$id'";
mysqli_query($con,$query) or die(mysqli_error($con));

}
$ref =rand(100000000,999999999);
$description="$amount was credited into your $actype Investment";
$query="insert into investment_transact (packages,account_no,credit,debit,balance,ref_no,description,transaction_date,investment_id) values('Investment','{$_SESSION['account']}','$amount','','$am','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$description="$amount was debited  from your Wallet for $actype Investment Deposit";
$query="insert into transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,investment_id) values('Investment','{$_SESSION['account']}','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="select refer_id from refer_user  where account_no='{$_SESSION['account']}' and transact='0'";
$de=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($de)>0){
	$query="update refer_user set transact='1' where account_no='{$_SESSION['account']}'";
	mysqli_query($con,$query) or die(mysqli_error($con));

}
echo"<h3>Investment Deposit was Successful</h3><p class='error'>Please don't Resend  Again</p>";
}else{
	
	echo "<h3>The amount you Entered is bigger than Your Wallet Amount</h3>";
	echo"<a href='deposit.php'>Try Again</a>"
}
}

?>

				
				
				</div>
				
					
					
				
				<br><br><br><br>
				</div></div>
				
				<div class="col-sm-12">
				<p class="">© 2018 E-Banking. Designed by <a href="../index.php">PEARL</a></p>
			</div>
		
		
		
		</div>
		
		
		
		<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	
		
</body>
</html>