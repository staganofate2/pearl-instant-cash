<?php
include"header.php";
include"modal_box.php"; 
$bar="deposit"
?>
		
	<?php
	include"sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Investment</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Deposit Slip</h4>
				
				<?php $query="select* from investment where account_no='{$_SESSION['account']}' and active='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				
				<?php $query="select total from wallet where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				$ve=mysqli_fetch_array($res);
				
					?>
				<h5 class="page-header">Wallet Balance  ₦ <?php echo $ve['total'] ?></h5>
								<div class="col-md-8">
			

				<form action="payment.php" method="POST" enctype="multipart/form-data">

				<input type="hidden" name="id" id='id'value="" />
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update()">
								<option   value="">Select Account</option>
								<?php $query="select duration  from investment where account_no='{$_SESSION['account']}' and active='0' ";
								$re=mysqli_query($con,$query) or die(mysqli_error($con));
								while($ros=mysqli_fetch_array($re)){
									?>
								<option   value="<?php echo $ros['duration']?>"><?php echo $ros['duration']?></option>
								<?php
								}
								?>
								</select>
							</div>
							
							
							<div class="form-group">
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' onblur="check()" name="amount" type="text" placeholder='Amount in Digits' required>
								
							</div>
							<button class="btn btn-info" name="change" id='submit'type="submit">SUBMIT</button>
				
				</form>

				
				</div>
				<?php

}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Investment With Us. Click below to create one now</h4> 
				<p><a href="investform.php">Create New Investment </a> </p></center><br>
					<?php
				}
				?>
				
				
		
	
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("actype").value;
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "structure.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
			
			
			
				
				document.getElementById("id").value =ajax.responseText;
			 
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	alert(amount);
	var amounts=amount.replace(reg,""); 
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts);
 
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
		
<?php include"footer.php"; ?>