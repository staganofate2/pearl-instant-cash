<?php
include"header.php";
include"modal_box.php"; 
$bar="withdrawal";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Profile</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Withdrawal Slip</h4>
				
				<?php $query="select* from investment where account_no='{$_SESSION['account']}' ";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				
								<div class="col-md-8">
			

				<form action="payout.php" method="POST" enctype="multipart/form-data">

				<input type="hidden" name="id" id='id'value="" />
							<div class="form-group">
								<select name='type' class="form-control" id='actype' onchange="update()">
								<option   value="">Select Account</option>
								<?php $query="select duration  from investment where account_no='{$_SESSION['account']}' and paid='0'";
								$re=mysqli_query($con,$query) or die(mysqli_error($con));
								while($ros=mysqli_fetch_array($re)){
									?>
								<option   value="<?php echo $ros['duration']?>"><?php echo $ros['duration']?></option>
								<?php
								}
								?>
								</select>
								<span id='one'></span>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Maturity Date</span>
								<input class="form-control" id='maturity' name="maturity" placeholder='Maturity Date' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Start Account Contribution Date</span>
								<input class="form-control" id='contribute' name="contribute" placeholder='Start Account Contribution Date' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Deposit</span>
								<input class="form-control" id='deposit' name="deposit" placeholder='Total Deposit' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Added Interest</span>
								<input class="form-control" id='interest' name="interest" placeholder='Added Interest' type="text" readonly>
							</div>
							<div id='loaders'></div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Grand Total</span>
								<input class="form-control" id='total' name="total" placeholder='Grand Total' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Withdrawalable Amount</span>
								<input class="form-control" id='withdraw' name="withdraw" placeholder='Withdrawalable Amount' type="text" readonly>
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Amount</span>
								<div id='am'><input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' name="amount" type="text" placeholder='Amount in Digits' onblur="check()" required>
								</div>
								<span class='danger' id='result'></span>
							</div>
							
							<button class="btn btn-info" name="change" id='submit'type="submit">Transfer to Wallet</button>
				
				</form>

				
				</div>
				<?php

}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Investment With Us. Click below to create one now</h4> 
				<p><a href="investform.php">Invest Now </a> </p></center><br>
					<?php
				}
				?>
				
				
				
				
	 
	<script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
function update(){
	
	var types=document.getElementById("actype").value;
		var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "structure2.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	  ajax.setRequestHeader("Cache-Control","no-cache");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
			
				document.getElementById("one").innerHTML = '';
			 var data=ajax.responseText.split("|");
			 var mat_date=data[0];
			 var start_date=data[1];
			 var total=data[2];
			 var interest=data[3];
			 var gtotal=data[4];
			 var witamount=data[5];
			 var id=data[6];
		
			  var status=data[7];
			 document.getElementById("maturity").value = mat_date;
			 document.getElementById("contribute").value =start_date;
			 document.getElementById("deposit").value =total ;
			 document.getElementById("interest").value =interest ;
			 document.getElementById("total").value =gtotal ;
			 document.getElementById("id").value =id;
			 
			 if(status=="1"){
				 document.getElementById("am").innerHTML ="<select name='amount'><option value='All'>All</option></select>";
				 document.getElementById("withdraw").value =gtotal;
			 }else{
				document.getElementById("am").innerHTML ="<input class='form-control' value=''onkeyup='this.value = numFormat(this.value)' id='amount' name='amount' type='text' placeholder='Amount in Digits' onblur='check()' required>";
			document.getElementById("withdraw").value =witamount;
			}
			 
			
			
		}
	}
	ajax.send("type="+types);
 
 }
 function check(){
	
	var types=document.getElementById("actype").value;
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	var amounts=amount.replace(reg,""); 
	if(isNaN(amounts)){
		document.getElementById('submit').style.display="none";
		document.getElementById('result').innerHTML="Please Enter number in Digits";
	}else{
    document.getElementById('submit').style.display="block";
	document.getElementById('result').innerHTML="";
		var b=document.getElementById("loaders").style.display="block";
	 ajax.open("POST", "check_withdraw.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
				var b=document.getElementById("loaders").style.display="none";
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				document.getElementById("result").innerHTML ="";
			}
			else{
				
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("type="+types+"&amount="+amounts);
	}
 }
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>	
<?php include "footer.php"; ?>