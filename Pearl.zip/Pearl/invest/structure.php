<?php
session_start();
include_once('connect.php');

$type=$_POST['type'];

$que="select investment_id from investment where duration='$type' and account_no='{$_SESSION['account']}'";
$res=mysqli_query($con,$que)or die(mysqli_error($con));
$row=mysqli_fetch_array($res);
echo $row['investment_id'];
exit();



?>