<?php
include"header.php";
include"modal_box.php"; 
$bar="summary";
?>
		
		
	<?php include "sidebar.php"; ?>
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">invest</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Investment Summary</h4>
				<?php $query="select* from investment where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				<p>Hi, <?php echo$row['firstname']." .. This is Your Investment Summary";  ?>
				</p>
				
								<div class="col-md-12">
				
				<table class="table">
				
				<tr>
				<th>Name</th><th>Capital</th><th>Total Savings</th><th>Total Interest</th><th>Duration</th><th>Investment Date</th><th>Maturity Date</th><th>Invest Percentage</th><th>Status</th><th>Pay Out</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['invest_name'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td>₦ <?php echo ($ree['amount'] + $ree['interest']) ?></td><td>₦ <?php echo ($ree['interest'] + $ree['interests']) ?></td><td><?php echo $ree['duration'] ?></td><td><?php echo $ree['invest_date'] ?></td><td><?php echo $ree['maturity_date'] ?></td><td><?php echo $ree['interest_rate'] ?></td><td><?php if($ree['active']=="0" ){echo "active";}else{echo "matured";} ?></td><td><?php if($ree['paid']=="0" && $ree['active']=="1"){echo "<a href='withdraw.php'>Pay Out</a>";}elseif($ree['paid']=='1'){echo "Payed Out";}else{echo "Not Matured";} ?></td>
				
				
				</tr>
				<?php
				}
				?>
				
				
				</table>
				
				
				</div>
				<?php
				}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Investment With Us. Click below to Invest now</h4> 
				<p><a href="investform.php">Invest Now </a> </p></center><br>
					<?php
				}
				?>
				
			<?php include "footer.php"; ?>