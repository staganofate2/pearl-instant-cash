<?php

$_SESSION['pinn'];



                                       $first= $_SESSION['first'];
                                       $last= $_SESSION['last'];
									   $acct=$_SESSION['acctnumber'];
									   
                                        $mail=$_SESSION['mail'];
                                        $phone= $_SESSION['phone'];
                                        $_SESSION['dob'];
                                        $address= $_SESSION['addr'];	
                                        $city=$_SESSION['city'];
                                         $state=$_SESSION['state'];	
                                          $_SESSION['acctype'];
                                           $pic=$_SESSION['pics'];
										   
										  $zip= $_SESSION['zip'];	
$bal=$_SESSION['acctbal'];	
$pin=$_SESSION['acctpin'];	
										   








?>