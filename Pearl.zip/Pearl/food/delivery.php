<?php
include"header.php";
include"modal_box.php"; 
$bar="delivery";
?>
		
<style>
.img-responsive {
	width:100px;
	height:100px;
}
</style>		
		<?php include "sidebar.php"; ?>
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Food Delivery Form</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
		<div class="col-lg-2">
		</div>
			<div class="col-lg-8">
		
			
				<?php $query="select* from food where account_no='{$_SESSION['account']}' and delivery='0'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					
				if(isset($_POST['change'])){
					
					
					
					$type=$_POST['type'];
					$name=$_POST['name'];
					$address=$_POST['address'];
					$lga=$_POST['lga'];
					$state=$_POST['state'];
					$phone=$_POST['phone'];
					$query="select food_id  from delivery where food_id='$type'  and account_no='{$_SESSION['account']}'";
					$qwe=mysqli_query($con,$query) or die(mysqli_error($con));
					if(mysqli_num_rows($qwe)>0){
						echo "<h3> Please you have Delivery Information for the selected Food Account.<br>Choose a Different Account </h3>";
					}else{
					$query="insert into delivery (food_id,name,phone,address,lga,states,account_no) values('$type','$name','$phone','$address','$lga','$state','{$_SESSION['account']}')";
					
					mysqli_query($con,$query)or die(mysqli_error($con));
					
					$query="update food set delivery='1'  where food_id='$type'";
					mysqli_query($con,$query)or die(mysqli_error($con));
echo "<h3>Your Food Delivery has been created Successfully</h3>";
                                        
				}
				}else{
					
				?>
			   
				<h4 class="page-header">Food Delivery  Form</h4>
				
				<form action="" method="POST" enctype="multipart/form-data">

											<div class="form-group">
											<span class="badge" style="background-color:#3385FF;">Package Plan</span>
								<select name='type' class="form-control" id='actype' >
								<option   value="">Select Package Plan</option>
								<?php
								while($fe=mysqli_fetch_array($res)){
									?>
								<option   value="<?php echo $fe['food_id'] ?>"><?php echo $fe['package_name'] ?></option>
							<?php
								}
								?>
								</select>
							</div>
							
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Receiver Name</span>
								<input class="form-control" id='duration' name="name" placeholder='Full Name' type="text" >
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Receiver Address</span>
								<input class="form-control" id='due' name="address" placeholder='Address' type="text" >
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Receiver Phone</span>
								<input class="form-control" id='amount' name="phone" placeholder='Phone Number' type="text" >
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">L.G.A</span>
								<input class="form-control" value="" id='mdate' name="lga" type="text" placeholder='L.G.A'>
							
							</div>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">State</span>
								<input class="form-control" value="" id='mdate' name="state" type="text" placeholder='State'>
							
							</div>
							
							
							
							<button class="btn btn-info" name="change" type="submit">SUBMIT</button>
				
				</form>
				
			
				<?php
				}
				?>
				<?php

}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Food Account to add Delivery </h4> 
				</center><br>
					<?php
				}
				?>
				</div>
				
				
				
	 
	<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
 
 
 
 		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("actype").value;
	var structure=document.getElementById("structure").value;
	if(types=="Rock"){
		var type="3";
	}
	else if(types=="Golden"){
		var type="3";
	}
	else if(types=="Silver"){
		var type="3";
	}
	else if(types=="King"){
		var type="3";
	}
	else if(types=="Genesis"){
		var type="3";
	}
	else if(types=="Legend"){
		var type="6";
	}
	else if(types=="Prince"){
		var type="4";
	}
	else if(types=="Emirate"){
		var type="3";
	}
	else if(types=="Standard"){
		var type="3";
	}
	else if(types=="Concorde"){
		var type="3";
	}
	else if(types=="Global"){
		var type="2 ";
	}
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "date.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("mdate").value = ajax.responseText;
			 var data=ajax.responseText.split("/");
			 
			if(types=="Legend"){
				if(structure=="Monthly"){
					document.getElementById("due").value="2000";
								}
								else{
									document.getElementById("due").value="500";
								}
		  document.getElementById("duration").value="6 Months";
		  
		  
		  document.getElementById("amount").value="12000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 quarter bag of rice</li><li>1 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 pack of Idomitable</li><li>1 carton of Amstel</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li></ul>";
		  document.getElementById("items").value="<ul><li>1 quarter bag of rice</li><li>1 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 pack of Idomitable</li><li>1 carton of Amstel</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li></ul>";
		  
	  }
	  else if(types=="Emirate"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 carton of Idomitable</li><li>1 c. constade</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 carton of Idomitable</li><li>1 c. constade</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  
	  }
	    else if(types=="Prince"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="4000";
								}
								else{
									document.getElementById("due").value="1000";
								}
		  document.getElementById("duration").value="4 Months";
		  
		  
		  document.getElementById("amount").value="16000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  
	  }
	   else if(types=="Emirate"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li></ul>"
		  
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li></ul>"
		  
	  }
	   else if(types=="Standard"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="10000";
								}
								else{
									document.getElementById("due").value="2500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="30000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of Tomatoes small</li><li>1 omo big sachet</li><li>1 pack of Coke</li></ul>"
		 document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of Tomatoes small</li><li>1 omo big sachet</li><li>1 pack of Coke</li></ul>"
		  
	  }
	   else if(types=="Concorde"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="14000";
								}
								else{
									document.getElementById("due").value="3500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="35000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 full bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 omo big sachet</li></ul>"
		  document.getElementById("items").value="<ul><li>1 full bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 omo big sachet</li></ul>"
		  
	  }
	  
	  
	   else if(types=="Global"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="20000";
								}
								else{
									document.getElementById("due").value="5000";
								}
		  document.getElementById("duration").value="2 Months";
		  
		  
		  document.getElementById("amount").value="40000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 full bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of small tin Tomatoes</li><li>1 omo big sachet</li><li>1 super pack of Noodles</li><li>2 rolls of tissue</li></ul>"
		 document.getElementById("items").value="<ul><li>1 full bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of small tin Tomatoes</li><li>1 omo big sachet</li><li>1 super pack of Noodles</li><li>2 rolls of tissue</li></ul>"
		   
	  }
	  
	   else if(types=="Rock"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="12000";
								}
								else{
									document.getElementById("due").value="3000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="36000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		   
	  }
	   else if(types=="Golden"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="10000";
								}
								else{
									document.getElementById("due").value="2500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="30000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, Tummy Tummy</li></ul>"
		document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, Tummy Tummy</li></ul>"
		    
	  }
	   else if(types=="Silver"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="24000";
								}
								else{
									document.getElementById("due").value="2000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="24000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 2 litre of  groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, 1/12 carton malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 2 litre of  groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, 1/12 carton malt</li></ul>"
		  
	  }
	  
	   else if(types=="King"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 quarter bag of rice</li><li>1 small  groundnut oil </li><li>Idomitable </li><li>1 small powdered milk</li><li>1 small powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1 quarter bag of rice</li><li>1 small  groundnut oil </li><li>Idomitable </li><li>1 small powdered milk</li><li>1 small powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, malt</li></ul>"
		  
	  }
	   else if(types=="Genesis"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="4000";
								}
								else{
									document.getElementById("due").value="1000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="12000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		  document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		  
	  }
	  
	  
			
		}
	}
	ajax.send("month="+type);
 
 }
  
  </script>	

	<?php include "footer.php"; ?>