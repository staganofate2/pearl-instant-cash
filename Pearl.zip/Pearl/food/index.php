<?php
include"header.php";
include"modal_box.php";
$bar="index";
?>


<style>
  /* Add a black background color to the top navigation */
.topnav {
    background-color: #333;
    overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Add an active class to highlight the current page */
.active {
    background-color: #4CAF50;
    color: white;
}

/* Hide the link that should open and close the topnav on small screens */
.topnav .icon {
    display: none;
} 
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}
@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive a.icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
 </style>
 <script>

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
} 
</script>
<?php
include"sidebar.php";
?>
		
		
		
		
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h2 class="page-header">Food Overview</h2>
				
			</div>
		</div><!--/.row--><hr>
		
		<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-8">
		<ul class='home'>
			<li><a href='index.php'>PEARL FOOD STORE </a>: Members of our online cooperative program are eligible to register for food store program by clicking on <a href='newacc.php'>ADD NEW FOOD ACCOUNT</a> , and be able to choose the plan that suit their needs.</li> 
			<li><a href='procedure.php'>ORDER PROCEDURE</a> is a menu that is designed for payment of food store program monthly or weekly program deposit , provided your <a href='../wallet/'>WALLET</a> is funded click on <a href='../wallet/'>MY WALLET</a> go to <a href='../wallet/deposit.php'>WALLET DEPOSIT</a> to fund your wallet. Immediately your maturity date is due and your payment is completed , it is expected you <a href='delivery.php'>ADD DELIVERY INFO</a> to enable the institution identify where to deliver your food item because your delivery date will be placed immediately your payment is completed .<br> <strong class='text-danger'>Note: </strong> always view your delivery info to be notified your delivery date immediately your payment is completed.</li>
			</ul>	
			</div>
		</div><!--/.row-->
		</div>
		
		<?php include"footer.php" ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		