<?php
$mont=$_POST['month'];
    $date = date("Y-m-d", strtotime(" +$mont months"));
    echo $date;
    exit();
?>
	