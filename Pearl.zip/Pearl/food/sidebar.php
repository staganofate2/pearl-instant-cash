

<!-------------------------------------the side nav bar here-------------------------------------->
		
		<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar" style='background:black;color:white'>
		
		
		
		<ul class="nav menu">
		    <li><a class="" href="../personal/index.php">
						<span class="fa fa-user">&nbsp;</span>Dashboard
					</a></li>
		<li class="parent"  <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em>Personal Information<span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
				    
					<li><a class="" href="../personal/info.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Reg Info
					</a></li>
					
					<li><a class="" href="../personal/changepass.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Change Password
					</a></li>
					<li><a class="" href="../personal/changepics.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Update profile picture
					</a></li>
					<li><a class="" href="../personal/chat.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Chat Online
					</a></li>
					<li><a class="" href="../personal/addbankinfo.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Add Bank A/C Info
					</a></li>
					<li><a class="" href="../personal/bankinfo.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Bank A/C Info
					</a></li>
					<li><a class="" href="../personal/notification.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Notification
					</a></li>
					<li><a class="" href="../personal/order.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Standing Order
					</a></li>
					<li><a class="" href="../personal/link.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Introducer Link
					</a></li>
					<li><a class="" href="../personal/myuploads.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Uploads
					</a></li>
				</ul>
			</li>
			<li class="parent"  <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-2">
				<em class="fa fa-navicon">&nbsp;</em>Account<span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li><a class="" href="../account/summary.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Account Summary
					</a></li>
					
					<li><a class="" href="../account/newacc.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Add new Account
					</a></li>
					<li><a class="" href="../account/procedure.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Payment Schedule
					</a></li>
					<li><a class="" href="../account/withdraw.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Pay Out
					</a></li>
					<li><a class="" href="../account/interest.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Added Interest
					</a></li>
					<li><a class="" href="../account/statement.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Account Statement
					</a></li>
					
				</ul>
			</li>
			<li class="parent"  <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-3">
				<em class="fa fa-navicon">&nbsp;</em>Invest<span data-toggle="collapse" href="#sub-item-3" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li><a class="" href="../invest/summary.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Invest Summary
					</a></li>
					
					<li><a class="" href="../invest/investform.php">
						<span class="fa fa-arrow-right">&nbsp;</span>New Investment
					</a></li>
					<li><a class="" href="../invest/interest.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Added Interest
					</a></li>
					<li><a class="" href="../invest/withdrawal.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Pay Out
					</a></li>
					<li><a class="" href="../invest/statement.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Statement
					</a></li>
				</ul>
			</li>
			<li class="parent"  <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-4">
				<em class="fa fa-navicon">&nbsp;</em>Loan<span data-toggle="collapse" href="#sub-item-4" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-4">
					<li><a class="" href="../loan/loan.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Loan Application
					</a></li>
					
					<li><a class="" href="../loan/approved.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Approved Loan
					</a></li>
					<li><a class="" href="../loan/repay.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Repayment Plan
					</a></li>
					<li><a class="" href="../loan/manage.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Manage Card
					</a></li>
					<li><a class="" href="../loan/statement.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Statement
					</a></li>
				</ul>
			</li>
			<li class="parent" style='background:green' <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-5">
				<em class="fa fa-navicon">&nbsp;</em>Food<span data-toggle="collapse" href="#sub-item-5" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-5">
					<li><a class="" href="../food/newacc.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Add new Food Account
					</a></li>
					
					<li><a class="" href="../food/procedure.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Order Procedures
					</a></li>
					<li><a class="" href="../food/delivery.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Add Delivery Info
					</a></li>
					<li><a class="" href="../food/view_delivery.php">
						<span class="fa fa-arrow-right">&nbsp;</span>View Delivery Info
					</a></li>
					<li><a class="" href="../food/statement.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Transaction Statement
					</a></li>
				</ul>
			</li>
			
			<li class="parent"  <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-6">
				<em class="fa fa-navicon">&nbsp;</em>Wallet<span data-toggle="collapse" href="#sub-item-6" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-6">
					<li><a class="" href="../wallet/category.php">
						<span class="fa fa-arrow-right">&nbsp;</span>My Category
					</a></li>
					
					<li><a class="" href="../wallet/summary.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Wallet Summary
					</a></li>
					<li><a class="" href="../wallet/deposit.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Wallet Deposit
					</a></li>
					<li><a class="" href="../wallet/withdraw.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Wallet Withdrawal
					</a></li>
					<li><a class="" href="../wallet/statement.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Wallet Statement
					</a></li>
					<li><a class="" href="../wallet/bill.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Pay Bills
					</a></li>
					
					<li><a class="" href="../wallet/wallettransfer.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Wallet Transfer
					</a></li>
					<li><a class="" href="../wallet/tranfer.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Bank Transfer
					</a></li>
					<li><a class="" href="../wallet/recharge.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Buy Recharge Card
					</a></li>
					<li><a class="" href="../wallet/data.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Buy Data
					</a></li>
					
					<li><a class="" href="../wallet/sms.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Send SMS
					</a></li>
					<li class="parent"  <?php if($bar=="deposit"){echo 'class="active"' ; }?>><a data-toggle="collapse" href="#sub-item-7">
				<em class="fa fa-navicon">&nbsp;</em>My Order<span data-toggle="collapse" href="#sub-item-7" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-7">
					<li><a class="" href="../wallet/bill_order.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Bills
					</a></li>
					
					<li><a class="" href="../wallet/transfer_order.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Bank Transfer
					</a></li>
					<li><a class="" href="../wallet/recharge_order.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Recharge Card 
					</a></li>
					<li><a class="" href="../wallet/data_order.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Data 
					</a></li>
					<li><a class="" href="../wallet/sms_order.php">
						<span class="fa fa-arrow-right">&nbsp;</span>SMS
					</a></li>
				</ul>
			</li>
					<li><a class="" href="../wallet/changepass.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Change Payment Password
					</a></li>
					<li><a class="" href="../wallet/resetpass.php">
						<span class="fa fa-arrow-right">&nbsp;</span>Reset Payment Password
					</a></li>
					
				</ul>
			</li>
			
			
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout <?php echo $row['lastname'];  ?></a></li>
		</ul>
	</div><!--/.sidebar-->
	