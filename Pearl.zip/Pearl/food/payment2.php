<?php
include"header.php";
include"modal_box.php"; 
include"../function.php";
$bar="withdraw";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Withdrawal  Slip</h4>
				<div class="col-md-8">
<?php	
if(isset($_POST['change'])){			
$actype =escape($con,$_POST['type']);
$maturity =escape($con,$_POST['maturity']);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$contribute =escape($con,$_POST['contribute']);
$interest =escape($con,$_POST['interest']);
$deposit =escape($con,$_POST['deposit']);
$gtotal =escape($con,$_POST['total']);
$withdraw =escape($con,$_POST['withdraw']);
$ref =rand(100000,999999);
$message="pending Account Withdrawal Confirmation";
$query="insert into withdraw (account_type,ref_no,maturity_date,start_date,amount,total,grand_total,interest,withdrable_interest,regdate,account_no)
 values('$actype','$ref','$maturity','$contribute','$amount','$deposit','$gtotal','$interest','$withdraw',now(),'{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));
 $query="insert into notification (message,postdate,purpose,account_no)values('$message',now(),'Withdrawal','{$_SESSION['account']}')";
mysqli_query($con,$query)or die(mysqli_error($con));


	?>
	<center><h4 class="h3-w3l">Thank You</h4> 
				<p>Your bank Account will be credited when your Withdrawal is approved </p></center><br>
				<p class='error'>Please don't Resend  Again</p>
<?php	
}

?>

				
				
				</div>
				
					
					
			<?php include "footer.php"; ?>