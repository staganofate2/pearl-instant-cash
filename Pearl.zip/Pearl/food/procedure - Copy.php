<?php
include"header.php";
$bar="procedure";
?>
		
		
		<?php include "sidebar.php"; ?>
	
	
	
	
	
	
	
	
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Order Procedure</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
			
			   
				<h4 class="page-header">Order Procedure</h4>
				<?php $query="select* from food where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					?>
				<p>Hi, <?php echo$row['firstname']." .. This is Your Order Procedure";  ?>
				</p>
				
								<div class="col-md-12">
				 
				<table class="table">
				
				<tr>
				<th>Package Name</th><th>Items</th><th>Payment Plan</th><th>Payment Plan Amount with Dates</th><th>Payment Plan Amount</th><th>Contributed Amount</th><th>Targeted Amount</th><th>Distribute Date</th><th>Start  Date</th><th>Maturity Date</th><th>Status</th>
				
				</tr>
				<?php while($ree=mysqli_fetch_array($res)){
					?>
				<tr>
				<td><?php echo $ree['package_name'] ?></td><td><?php echo $ree['items'] ?></td><td><?php echo $ree['payment_structure'] ?></td><td><table class='table'><?php $query="select* from food_pay where food_id='".$ree['food_id']."' and account_no='{$_SESSION['account']}'";$result=mysqli_query($con,$query);while($dee=mysqli_fetch_array($result)){echo "<tr><td>".$dee['pay_date']."</td><td> ".$dee['amount']."</td><td> "; if($dee['paid']=="0"){echo " Unpaid <br><a href='deposit.php?action=single&food_id=".$ree['food_id']."&amount=".$dee['amount']."&id=".$dee['food_pay_id']."'>Pay Now</a>";}else{echo " Paid";} echo "</td></tr>";} ?></table></td><td>₦ <?php echo $ree['due_amount'] ?></td><td>₦ <?php echo $ree['amount'] ?></td><td>₦ <?php echo $ree['total'] ?></td><td><?php echo $ree['distribute_date'] ?></td><td><?php echo $ree['start_date'] ?></td><td><?php echo $ree['maturity_date'] ?></td><td><?php if($ree['active']=="0"){echo "Active";}else{echo "Completed";} ?></td>
				
				
				</tr>
				<?php if(($ree['total']-$ree['amount'])>0){
					?>
				<tr><td></td><td></td><td></td><td><a href='deposit.php?action=All&id=&amount=&food_id=<?php echo $ree['food_id']?>'>Pay All</a></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
				<?php
				}
				}
				?>
				
				
				</table>
				
				
				</div>
				<?php
				}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Account With Us. Click below to create one now</h4> 
				<p><a href="newacc.php">Create New Account </a> </p></center><br>
					<?php
				}
				?>
				
			<?php include "footer.php"; ?>