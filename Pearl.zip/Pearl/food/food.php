<?php
$query="select* from delivery where food_id=".$fe['food_id']." and account_no='{$_SESSION['account']}'";
					$de=mysqli_query($con,$query)or die(mysqli_error($con));
					if(mysqli_num_rows($de)>){
						echo "<h3>Delivery Information Already Set</h3>";
					}
					?>