<?php
include"header.php";
include"modal_box.php"; 
$bar="view_delivery";
?>
		
<style>
.img-responsive {
	width:100px;
	height:100px;
}
</style>		
		<?php include "sidebar.php"; ?>
	
	
			<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Food Delivery Form</li>
				
			</ol>
		</div><!--/.row-->
		
		<div class="row">
		<div class="col-lg-2">
		</div>
			<div class="col-md-12">
			
			
				<?php $query="select* from food where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					
				
					
				?>
			   
				<h4 class="page-header">Food Delivery  Info</h4>
				
				
                        
						
	<div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
<tr><th>Package Name</th><th>Items</th><th>Receiver Name</th><th>Receiver Address</th><th>Receiver Phone</th><th>L.G.A</th><th>State</th><th>Delivery Date</th><th>Status</th></tr>
                                    </thead>
                                    <tbody>
									
									
									
									<?php 
									$query="select* from delivery where account_no='{$_SESSION['account']}'";
				$res=mysqli_query($con,$query) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>0){
					while($ree=mysqli_fetch_array($res)){
						$query="select* from food where food_id='".$ree['food_id']."' and account_no='{$_SESSION['account']}'";
						$se=mysqli_query($con,$query) or die(mysqli_error($con));
						$as=mysqli_fetch_array($se);
					?>
					
				<tr>
				<td><?php echo $as['package_name'] ?></td><td><?php echo $as['items'] ?></td><td> <?php echo $ree['name'] ?></td><td> <?php echo $ree['address'] ?></td><td> <?php echo $ree['phone'] ?></td><td><?php echo $ree['lga'] ?></td><td><?php echo $ree['states'] ?></td><td><?php echo $as['distribute_date'] ?></td><td><?php if($ree['done']=="0"){echo "Not Delivered";}else{echo "Delivered";} ?></td>
				
				
				</tr>
				<?php
				}
				}
				?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>




		
			
			
			
		

				<?php

}else{
					?>
					<center><h4 class="h3-w3l">You Don't have any Food Account With Us. Click below to create one now</h4> 
				<p><a href="newacc.php">Create New Account </a> </p></center><br>
					<?php
				}
				?>
				</div>
				
				
				
	 
	<script>
  var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
  var loadFile2 = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
      var output = document.getElementById('outputpix2');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };
 
 
 
 		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	
	var types=document.getElementById("actype").value;
	var structure=document.getElementById("structure").value;
	if(types=="Rock"){
		var type="3";
	}
	else if(types=="Golden"){
		var type="3";
	}
	else if(types=="Silver"){
		var type="3";
	}
	else if(types=="King"){
		var type="3";
	}
	else if(types=="Genesis"){
		var type="3";
	}
	else if(types=="Legend"){
		var type="6";
	}
	else if(types=="Prince"){
		var type="4";
	}
	else if(types=="Emirate"){
		var type="3";
	}
	else if(types=="Standard"){
		var type="3";
	}
	else if(types=="Concorde"){
		var type="3";
	}
	else if(types=="Global"){
		var type="2 ";
	}
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "date.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			
				document.getElementById("mdate").value = ajax.responseText;
			 var data=ajax.responseText.split("/");
			 
			if(types=="Legend"){
				if(structure=="Monthly"){
					document.getElementById("due").value="2000";
								}
								else{
									document.getElementById("due").value="500";
								}
		  document.getElementById("duration").value="6 Months";
		  
		  
		  document.getElementById("amount").value="12000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 quarter bag of rice</li><li>1 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 pack of Idomitable</li><li>1 carton of Amstel</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li></ul>";
		  document.getElementById("items").value="<ul><li>1 quarter bag of rice</li><li>1 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 pack of Idomitable</li><li>1 carton of Amstel</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li></ul>";
		  
	  }
	  else if(types=="Emirate"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 carton of Idomitable</li><li>1 c. constade</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 small powdered milk</li><li>1 carton of Idomitable</li><li>1 c. constade</li><li>1 small powdered milo</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  
	  }
	    else if(types=="Prince"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="4000";
								}
								else{
									document.getElementById("due").value="1000";
								}
		  document.getElementById("duration").value="4 Months";
		  
		  
		  document.getElementById("amount").value="16000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li><li>1 pack of Conflakes</li><li>1 rolls of tissue</li></ul>"
		  
	  }
	   else if(types=="Emirate"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li></ul>"
		  
		  document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 carton of Idomitable</li><li>1 omo big sachet</li></ul>"
		  
	  }
	   else if(types=="Standard"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="10000";
								}
								else{
									document.getElementById("due").value="2500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="30000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of Tomatoes small</li><li>1 omo big sachet</li><li>1 pack of Coke</li></ul>"
		 document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of Tomatoes small</li><li>1 omo big sachet</li><li>1 pack of Coke</li></ul>"
		  
	  }
	   else if(types=="Concorde"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="14000";
								}
								else{
									document.getElementById("due").value="3500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="35000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 full bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 omo big sachet</li></ul>"
		  document.getElementById("items").value="<ul><li>1 full bag of rice</li><li>1 5 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 omo big sachet</li></ul>"
		  
	  }
	  
	  
	   else if(types=="Global"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="20000";
								}
								else{
									document.getElementById("due").value="5000";
								}
		  document.getElementById("duration").value="2 Months";
		  
		  
		  document.getElementById("amount").value="40000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 full bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of small tin Tomatoes</li><li>1 omo big sachet</li><li>1 super pack of Noodles</li><li>2 rolls of tissue</li></ul>"
		 document.getElementById("items").value="<ul><li>1 full bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 big tin powdered milk</li><li>1 big tin powdered milo</li><li>1 carton of small tin Tomatoes</li><li>1 omo big sachet</li><li>1 super pack of Noodles</li><li>2 rolls of tissue</li></ul>"
		   
	  }
	  
	   else if(types=="Rock"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="12000";
								}
								else{
									document.getElementById("due").value="3000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="36000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		   
	  }
	   else if(types=="Golden"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="10000";
								}
								else{
									document.getElementById("due").value="2500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="30000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, Tummy Tummy</li></ul>"
		document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 2 litre of groundnut oil </li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, Tummy Tummy</li></ul>"
		    
	  }
	   else if(types=="Silver"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="24000";
								}
								else{
									document.getElementById("due").value="2000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="24000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 half bag of rice</li><li>1 2 litre of  groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, 1/12 carton malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1 half bag of rice</li><li>1 2 litre of  groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, 1/12 carton malt</li></ul>"
		  
	  }
	  
	   else if(types=="King"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="6000";
								}
								else{
									document.getElementById("due").value="1500";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="18000";
		  
		document.getElementById("list").innerHTML="<ul><li>1 quarter bag of rice</li><li>1 small  groundnut oil </li><li>Idomitable </li><li>1 small powdered milk</li><li>1 small powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, malt</li></ul>"
		 document.getElementById("items").value="<ul><li>1 quarter bag of rice</li><li>1 small  groundnut oil </li><li>Idomitable </li><li>1 small powdered milk</li><li>1 small powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, spices,maggi, malt</li></ul>"
		  
	  }
	   else if(types=="Genesis"){
		
		if(structure=="Monthly"){
					document.getElementById("due").value="4000";
								}
								else{
									document.getElementById("due").value="1000";
								}
		  document.getElementById("duration").value="3 Months";
		  
		  
		  document.getElementById("amount").value="12000";
		  
		document.getElementById("list").innerHTML="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		  document.getElementById("items").value="<ul><li>1  bag of rice</li><li>1 3 litre of groundnut oil </li><li>1 carton of Tummy</li><li>1 medium powdered milk</li><li>1 medium powdered milo</li><li>1 paint of Crayfish stock fish</li><li>1 pack of Sugar, Maggi, spices, malt</li></ul>"
		  
	  }
	  
	  
			
		}
	}
	ajax.send("month="+type);
 
 }
  
  </script>	

	<?php include "footer.php"; ?>