<?php
$bar="product";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>ONLINE FOOD STORE<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-10"> 
<h3>PEARL ONLINE FOOD STORE</h3>
     <p>  The member saves for food stuff/ beverages depending on the category, at the due date, depend on choice, the institution gives the items. Be aware that during registration provisions are made to see the item and their payment schedule. The packages are as follows.
<table class='table'>
<tr><th>Names Of Packages</th><th>	Weekly Contribution</th><th>	Monthly Contribution</th><th>	Working Days Mon-Fri</th><th>	Contribution Duration In Months	</th><th>Total Contribution</th></tr>
<tr><td>Legend</td><td>	N 500.00</td><td>	N 2,000.00</td><td>	120	</td><td>6</td><td>	N 12,000.00</td></tr>
<tr><td>Prince</td><td>	N 1,000.00</td><td>	N 4,000.00</td><td>	80</td><td>	4</td><td>	N 16,000.00</td></tr>
<tr><td>Emirate</td><td>	N 1,500.00</td><td>	N 6,000.00</td><td>	60	</td><td>3	</td><td>N 18,000.00</td></tr>
<tr><td>Standard</td><td>	N 2,500.00</td><td>	N 10,000.00</td><td>	60</td><td>	3</td><td>	N 30,000.00</td></tr>
<tr><td>Concorde</td><td>	N 3,500.00</td><td>	N 14,000.00	</td><td>50	</td><td>3	</td><td>N 35,000.00</td></tr>
<tr><td>Global	</td><td>N 5,000.00	</td><td>N 20,000.00	</td><td>40	</td><td>2	</td><td>N 40,000.00</td></tr>
<tr><td>Genesis	</td><td>N 1,000.00	</td><td>N 4,000.00	</td><td>60	</td><td>3	</td><td>N 12,000.00</td></tr>
<tr><td>King	</td><td>N 1,500.00	</td><td>N 6,000.00</td><td>	60	</td><td>3	</td><td>N 18,000.00</td></tr>
<tr><td>Silver	</td><td>N 2,000.00	</td><td>N 8,000.00	</td><td>60</td><td>	3	</td><td>N 24,000.00</td></tr>
<tr><td>Gold	</td><td>N 2,500.00	</td><td>N 10,000.00	</td><td>60</td><td>	3	</td><td>N 30,000.00</td></tr>
<tr><td>Rock	</td><td>N 3,000.00	</td><td>N 12,000.00</td><td>	60	</td><td>3	</td><td>N 36,000.00</td></tr></table>
					




<ol class='food'><li>	LEGEND</li>
      Quarter bag of rice, A litre of groundnut oil, 1 small powdered milk, 1 small powdered milo, 1 pack           of cornflake, cartoon of indomitable, A create of amstel.       
<li>	PRINCE</li>
Half bag of rice, 2 litre of groundnut oil, 1 small powdered milk,1  small powdered milo, 1 pack of cornflake,  1 cornstade , 2 rolls of tissue. 1 cartoon of indomitable.
<li>	EMIRATE</li>
Half  bag of rice, 3 litre of groundnut oil, 1 medium powdered milk,1  medium  powdered milo,. 1 cartoon of indomitable. 1 omo big sachet.
<li>	STANDARD</li>
Half bag of rice, 5 litre of groundnut oil, 1 big powdered milk,1  big powdered milo, 1 tomatoes carton, 1 omo big sachet, 1 pack of coke.
<li>	CONCORDE</li>
Full bag of rice, 5 litre of groundnut oil, 1 big powdered milk,1  big powdered milo, 1 big omo sachet. 
<li>	GLOBAL</li>
Full bag of rice, 3 litre of groundnut oil, 1 big powdered milk,1  big powdered milo, 1 big omo sachet, 1 super pack, 1 carton of small tin tomatoes, 2 roll of tissue.
<li>	ROCK</li>
Full bag of rice, 3 litre of groundnut oil, 1 carton of noodles, 1 medium powdered milk,1  medium powdered milo, 1 paint of crayfish,  stock fish, 1 pack of sugar, packet of maggi, spices, 1 carton of amstel.
<li>	GOLDEN</li>
Full bag of rice, 2 litre of groundnut oil, 1 carton of noodles, 1 medium powdered milk,1  medium powdered milo, 1 paint of crayfish,  stock fish, 1 pack of sugar, packet of maggi, spices, 
<li>	SILVER</li>
Half  bag of rice, 2 litre of groundnut oil, 1 carton of noodles, 1 medium powdered milk,1  medium powdered milo, 1 paint of crayfish,  stock fish, 1 pack of sugar, packet of maggi, spices, Half carton of amstel.
<li>	KING</li>
Half  bag of rice, 1 litre of groundnut oil, 1 carton of noodles, 1 small powdered milk,1  small powdered milo, Half paint of crayfish,  stock fish, 1 pack of sugar, packet of maggi, spices, 
<li>	GENESIS </li>
Quarter  bag of rice, 1 litre of groundnut oil, 1 carton of noodles, 1 small powdered milk,1  small powdered milo, Half  paint of crayfish,  stock fish, 1 pack of sugar, packet of maggi, spices. </ol>



			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>