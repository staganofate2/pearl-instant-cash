<?php
include"connect.php";
$query="select* from wallet_transact where packages='Deposit'";
$x=mysqli_query($con,$query) or die(mysqli_error($con));
while($c=mysqli_fetch_array($x)){
	$query="insert into deposit (total,amount,account_no,authorize,confirmed,confirm,ref_no)values('".$c['credit']."','".$c['credit']."','".$c['account_no']."','1','1','1','".$c['ref_no']."')";
	mysqli_query($con,$query) or die(mysqli_error($con));
}

?>