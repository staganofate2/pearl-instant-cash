<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Pay Bills<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				<center><h4 class="h3-w3l"> Pay Bills Instantly</h4> 
				<img src='images/tv.jpg' width="60%" height="100px" alt='tv subscription image'>
				<p>Just a few steps ahead, your bills are instantly settled </p></center><br>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE Bill Payment</h3>
<h2 style='color:green' id='resul'></h2>
	<?php
      if (isset($_POST['login'])){
								
								
								$type = mysqli_real_escape_string($con,$_POST['type']);
								$invoice = mysqli_real_escape_string($con,$_POST['invoice']);
								$email = mysqli_real_escape_string($con,$_POST['email']);
									$firstname = mysqli_real_escape_string($con,$_POST['firstname']);
										$lastname = mysqli_real_escape_string($con,$_POST['lastname']);
								$name = mysqli_real_escape_string($con,$_POST['name']);
								$cnumber = mysqli_real_escape_string($con,$_POST['cnumber']);
								$number = mysqli_real_escape_string($con,$_POST['number']);
								$phone = mysqli_real_escape_string($con,$_POST['phone']);
								$variation = mysqli_real_escape_string($con,$_POST['variation']);
								$amount = mysqli_real_escape_string($con,$_POST['amount']);
								$amount=str_replace(",","",$amount);
								$total=$amount+100;
								$ref =rand(100000000,999999999);
								
	
									$query="insert into billtwo (ref_no,types,variation,phone,numbers,amount,commission,regdate) values('$ref','$type','$variation','$phone','$number','$amount','$commi',now())";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							$id=mysqli_insert_id($con);
							$amounts=$total."00";
							$query="insert into paystacktwo(types,types_id,firstname,lastname,email,phone,ref_no,amount,regdate)values('Bill','$id','$firstname','$lastname','$email','$phone','$ref','$amount',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
						
				?>
				<center><h4 class="h3-w3l">Thank You</h4> 
				<p><b>Reference NO:  <?php echo $ref ?></b><br>
				Amount : N<?php echo $total ?></p>
				<?php $amount=$amount."00"; ?>
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <button type="button" onclick="payWithPaystack()" class='btn btn-info'> Pay Now </button> 
  <span id='res'></span>
</center><br>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $email ?>',
      amount: '<?php echo $amounts ?>',
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $firstname ?>',
      lastname: '<?php echo $lastname ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $phone ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	document.getElementById("res").innerHTML = 'please wait ...';
	 ajax.open("POST", "updatebillpay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
		if(ajax.responseText="done"){
		document.getElementById("res").innerHTML = '';
		document.getElementById("resul").innerHTML = 'Your Bill Payment was Successful';
			 
			}else{
				alert(ajax.responseText);
				document.getElementById("res").innerHTML = '';
				document.getElementById("resul").innerHTML = '';
				
			}	
			 
			
			
		}
	}
	ajax.send("ref="+response);
 
 
  }
</script>
  

<?php				
										
										
										
	}

								
?>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>