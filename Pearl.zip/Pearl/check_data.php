<?php
session_start();
include_once('connect.php');
$amount=$_POST['amount'];
 $amount=str_replace(",","",$amount);

if($amount<50){
	echo "The amount Should not be less than N50 ";
		exit();
}
elseif($amount>50000){
	echo "The amount should not be greater than N 50,000 ";
		exit();
}else{
   echo"ok"; 

exit();
}
?>

