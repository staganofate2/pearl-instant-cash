<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Buy Recharge<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				<center><h4 class="h3-w3l"> Top Up Your Airtime Instantly</h4> 
				<img src='images/network.jpg' width="60%" height="100px" alt='network image'>
				<p>Just a few steps ahead, to buy your desired Recharge Card </p></center><br>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE Airtime Top Up</h3>

	<?php
			 if (isset($_POST['login'])){
								
								
								$network = mysqli_real_escape_string($con,$_POST['network']);
								$phone = mysqli_real_escape_string($con,$_POST['phone']);
								$variation = mysqli_real_escape_string($con,$_POST['variation']);
													
								$ref =rand(100000000000,999999999999);
														
								$net=array("15"=>"MTN","6"=>"GLO","2"=>"9Mobile","1"=>"Airtel");
								$networks=$net[$network];	
								$query="insert into datas (ref_no,network,phone,account_no,amount,regdate) values('$ref','$networks','$phone','{$_SESSION['account']}','$variation',now())";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							 $id=mysqli_insert_id($con);
							 //$amount=$amount.".00";
							
									
$http="https://mobileairtimeng.com/httpapi/datatopup.php?userid=08107302391&pass=912363232d306466ae2a1&network=$network&phone=$phone&amt=$variation&jsn=json";

	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $http,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => ""
  
));
$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
   $x=json_decode($response,true);
 
 // print_r($x);

//echo "<a href='$http'>COntinue</a>";


// Get cURL resource
 /*
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $http
	));
// Send the request & save response to $resp
  $resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//print_r($resp);

$y=json_decode($resp,true);
print_r($y);
*/


if($x['message']=="Recharge successful"){
							
										$query="select total from wallet where account_no='{$_SESSION['account']}'";
$row=mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_num_rows($row)>0){
	$rows=mysqli_fetch_array($row);
	$amounts=($rows['total']-$amount);
$query="update wallet set total='$amounts' where account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));

$description="$amount was Debited from your Wallet for Data Recharge of $phone";
$query="insert into wallet_transact (packages,account_no,credit,debit,balance,refno,description,transaction_date,packages_id) values('Data','{$_SESSION['account']}','','$amount','$amounts','$ref','$description',now(),'$id')";
mysqli_query($con,$query) or die(mysqli_error($con));
$query="update datas set status='1',sent_date=now(),total='$amount' where account_no='{$_SESSION['account']}' and ref_no='$ref'";
mysqli_query($con,$query) or die(mysqli_error($con));
}
										echo "<h3>Your Data Recharge was Successful</h3>";
}else{
	
											echo "<h3>Failed !!! Please <a href='recharge.php'>Try Again</a></h3>";
										
}									
								
	

	  }
			 }
	  
								
?>
								<form class="" action="recharge_payments.php" method="post" > 
			<div class="col-md-8">
			
			
			
			
			
						
						
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Mobile Network</span>
							<select name="network" class="form-control"  required="">
						<option value="">----Select Network---</option>
						<option value="15">MTN</option>
						<option value="1">Airtel</option>
						<option value="6">GLO</option>
						<option value="2">9Mobile</option>
						</select>
						</div>
						
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Recharging Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div>
						
						
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount' name="amount" type="text" placeholder='Amount in Digits' onblur="check()" required>
								<span class='danger' id='result'></span>
							</div>
							
						<input type="submit" class="btn btn-info " id='submit'value="BUY"name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			
			
			
			
			
			
			</div> 
			</form>
		
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 function update(){
	 var type=document.getElementById("type").value;
	 if(type=="gotv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>GOtv Lite N400</option><option value='02'>GOtv value N1250</option><option value='03'>GOtv plus N1900</option><option value='04'>GOtv Max N3200</option>"; 
	 }
	 if(type=="startimes"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>Nova - 900 Naira</option><option value='02'>Basic - 1,300 Naira</option><option value='03'>Smart - 1,900 Naira</option><option value='04'>Classic - 2,600 Naira </option><option value='05'>Unique - 3,800 Naira</option><option value='06'>Super - 3,800 Naira</option>"; 
	 }
	  if(type=="dstv"){
	document.getElementById("variation").innerHTML="<option value=''>Select Variation Code</option><option value='01'>DStv Access N2000</option><option value='02'>DStv Family N4000</option><option value='03'>DStv Compact N6,800</option><option value='04'>DStv Compact Plus N10,650</option><option value='05'>DStv Premium N15,800</option><option value='06'>DStv  Premium + HD/Exra View - N18,000</option>"; 
	 }
 }
 function update2(){
	  var type=document.getElementById("type").value;
		 var types=document.getElementById("variation").value;
	 if(type=="gotv" && types=="01"){
	document.getElementById("amount").value="400.00"; 
	document.getElementById("total").value="500.00";
	 }	 if(type=="gotv" && types=="02"){
	document.getElementById("amount").value="1250.00";
document.getElementById("total").value="1350.00";	
	 }	 if(type=="gotv" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="gotv" && types=="04"){
	document.getElementById("amount").value="3200.00"; 
	document.getElementById("total").value="3300.00";
	 }	
	 if(type=="startimes" && types=="01"){
	document.getElementById("amount").value="900.00";
document.getElementById("total").value="1000.00";	
	 }	 if(type=="startimes" && types=="02"){
	document.getElementById("amount").value="1300.00"; 
	document.getElementById("total").value="1400.00";
	 }	 if(type=="startimes" && types=="03"){
	document.getElementById("amount").value="1900.00"; 
	document.getElementById("total").value="2000.00";
	 }	  if(type=="startimes" && types=="04"){
	document.getElementById("amount").value="2600.00";
document.getElementById("total").value="2700.00";	
	 }	
	  if(type=="startimes" && types=="05"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	
	 if(type=="startimes" && types=="06"){
	document.getElementById("amount").value="3800.00"; 
	document.getElementById("total").value="3900.00";
	 }	


	 if(type=="dstv" && types=="01"){
	document.getElementById("amount").value="2000.00"; 
	document.getElementById("total").value="2100.00";
	 }if(type=="dstv" && types=="02"){
	document.getElementById("amount").value="4000.00";
document.getElementById("total").value="4100.00";	
	 }	 if(type=="dstv" && types=="03"){
	document.getElementById("amount").value="6800.00"; 
	document.getElementById("total").value="6900.00";
	 }	
	  if(type=="dstv" && types=="04"){
	document.getElementById("amount").value="10650.00"; 
	document.getElementById("total").value="10750.00";
	 }	
	 if(type=="dstv" && types=="05"){
	document.getElementById("amount").value="15800.00"; 
	document.getElementById("total").value="15900.00";
	 }	
	 if(type=="dstv" && types=="06"){
	document.getElementById("amount").value="18000.00"; 
	document.getElementById("total").value="18100.00";
	 }	
			 
 }
 function check(){
	
	
	var amount=document.getElementById("amount").value;
	var reg=/,/;
	alert(amount);
	var amounts=amount.replace(reg,""); 
	document.getElementById("result").innerHTML = 'please wait ...';
	 ajax.open("POST", "check_amount.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
alert(ajax.responseText);
			
			if(ajax.responseText=="ok"){
				document.getElementById("submit").style.display="block";
				 document.getElementById("result").innerHTML ="";
				 var amountt=Number(amounts);
				 var total=amountt+100;
				 alert(total);
				 document.getElementById("total").value =total;
			}
			else{
				document.getElementById("total").value ="";
			 
			 document.getElementById("result").innerHTML = ajax.responseText;
			 document.getElementById("submit").style.display="none";
			}
			
			
		}
	}
	ajax.send("amount="+amounts);
 
 }
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {

	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
<?php
include"footer.php";
?>