<?php
/*
$username   = "sandbox";
$apiKey     = "ccc95712457653bcaa1af9789bdf19689df453855bf8ed7cca32d2ab6bb9b0ec";

// Initialize the SDK
$AT         = new AfricasTalking($username, $apiKey);

// Get the SMS service
$sms        = $AT->sms();

// Set the numbers you want to send to in international format
$recipients = "+2348134748465";

// Set your message
$message    = "I'm a lumberjack and its ok, I sleep all night and I work all day";

// Set your shortCode or senderId
$from       = "AFRICASTKNG";

try {
    // Thats it, hit send and we'll take care of the rest
    $result = $sms->send([
        'to'      => $recipients,
        'message' => $message,
        'from'    => $from
    ]);

    print_r($result);
} catch (Exception $e) {
    echo "Error: ".$e->getMessage();
}

class AfricasTalking
{
	const BASE_DOMAIN        = "africastalking.com";
	const BASE_SANDBOX_DOMAIN = "sandbox." . self::BASE_DOMAIN;
	
	protected $username;
	protected $apiKey;

	protected $client;
	protected $paymentClient;
	protected $voiceClient;
	protected $tokenClient;

	public $baseUrl;
	protected $voiceUrl;
	protected $paymentUrl;

	protected $SMS;

	public function __construct($username, $apiKey)
	{
		if($username === 'sandbox') {
			$this->baseDomain = self::BASE_SANDBOX_DOMAIN;
		} else {
			$this->baseDomain = self::BASE_DOMAIN;
		}

		$this->baseUrl = "https://api." . $this->baseDomain . "/version1/";
		$this->voiceUrl = "https://voice." . $this->baseDomain . "/";
		$this->paymentsUrl = "https://payments." . $this->baseDomain . '/';
		$this->checkoutTokenUrl = "https://api." . $this->baseDomain . '/';

		$this->username = $username;
		$this->apiKey = $apiKey;

		$this->client = new Client([
			'base_uri' => $this->baseUrl,
			'headers' => [
				'apikey' => $this->apiKey,
				'Content-Type' => 'application/x-www-form-urlencoded',
				'Accept' => 'application/json'
			]
		]);

		$this->voiceClient = new Client([
			'base_uri' => $this->voiceUrl,
			'headers' => [
				'apikey' => $this->apiKey,
				'Content-Type' => 'application/x-www-form-urlencoded',
				'Accept' => 'application/json'
			]
		]);

		$this->paymentsClient = new Client([
			'base_uri' => $this->paymentsUrl,
			'headers' => [
				'apikey' => $this->apiKey,
				'Content-Type' => 'application/json',
				'Accept' => 'application/json'
			]
		]);

		$this->tokenClient = new Client([
			'base_uri' => $this->checkoutTokenUrl,
			'headers' => [
				'apikey' => $this->apiKey,
				'Content-Type' => 'application/json',
				'Accept' => 'application/json'
			]
		]);
	}

	public function sms()
	{
		$sms = new SMS($this->client, $this->username, $this->apiKey);
		return $sms;
	}

	public function airtime()
	{
		$airtime = new Airtime($this->client, $this->username, $this->apiKey);		
		return $airtime;
	}

	public function voice()
	{
		$voice = new Voice($this->voiceClient, $this->username, $this->apiKey);
		return $voice;
	}

	public function application()
	{
		$application = new Application($this->client, $this->username, $this->apiKey);		
		return $application;
	}

	public function payments()
	{
		$payments = new Payments($this->paymentsClient, $this->username, $this->apiKey);		
		return $payments;
	}

	public function token()
	{
		$token = new Token($this->tokenClient, $this->username, $this->apiKey);
		return $token;
	}
}



$postdata ="username=sandbox&from=&to=2348134748465&message=Testing";
$data=urlencode($postdata);
$url = "https://api.sandbox.africastalking.com/version1/messaging";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data)); //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$headers = [
'apikey: ccc95712457653bcaa1af9789bdf19689df453855bf8ed7cca32d2ab6bb9b0ec',
'Content-Type:application/x-www-form-urlencoded',
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
echo$response = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);
if ($err) {
echo "cURL Error #:" . $err;
} else {
$x=json_decode($response,true);

print_r($x);
}*/
$message=urlencode("Testing SMS with aSender ID");

$data="username=sandbox&from=AFRICASTKNG&to=+2348160523974&message=$message";
//$x=htmlspecialchars($data);
echo $data;
//$x=htmlentities($x);

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.sandbox.africastalking.com/version1/messaging",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => $data,
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/x-www-form-urlencoded",
    "apiKey: ccc95712457653bcaa1af9789bdf19689df453855bf8ed7cca32d2ab6bb9b0ec"
  ),
));
$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
?>