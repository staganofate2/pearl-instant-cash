<?php
session_start();
include"connect.php";
/*$id=$_POST['id'];
$query="select* from transfer where transfer_id='$id'";
$s=mysqli_query($con,$query) or die(mysqli_error($con));
$d=mysqli_fetch_array($s);
*/
$account_number="0020136975";//$d['account_number'];
$code="063";//$d['code'];
$amount="10000";//$d['amount']."00";
/*$query="select firstname from registeruser where account_number='".$d['account_no']."'";
$se=mysqli_query($con,$query) or die(mysqli_error($con));
$de=mysqli_fetch_array($se);
*/
$name="stan";//$de['firstname'];
//Set other parameters as keys in the $postdata array
$postdata =  array('type' => 'nuban', 'name' => "$name","description" =>"Account Transfer","account_number" => "$account_number","bank_code"=> "$code","currency"=> "NGN");
   
$url = "https://api.paystack.co/transferrecipient";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
//Use the $result array to get redirect URL

echo"<hr>";


$recipient=$x['data']['recipient_code'];//$re['recipient'];
//$amount=$re['amount'];
//Set other parameters as keys in the $postdata array
}
$postdata =  array("source"=>"balance", "reason"=>"transfer", "amount"=>"$amount", "recipient" =>"$recipient");
   
$url = "https://api.paystack.co/transfer";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
  
 echo "<h3>".$x['message']."</h3>";
//Use the $result array to get redirect URL
}


echo"<hr>";

$postdata =  array("transfer_code"=>"TRF_qwq5ekwzcp36a9a");
   
$url = "https://api.paystack.co/transfer/finalize_transfer";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
  'Authorization: Bearer sk_live_c08db5b6efd12dcf835dbad50d97203217ee53a4',
  'Content-Type: application/json',

];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);
$err = curl_error($ch);

curl_close($ch);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $x=json_decode($response,true);
  print_r($x);
  
// echo "<h3>".$x['message']."</h3>";
//Use the $result array to get redirect URL
}


/*
$query="update transfer set status='1' ,sender='{$_SESSION['authorize']}',sent_date=now() where transfer_id='$id'";
mysqli_query($con,$query) or die(mysqli_error($con));
echo "done";*/
?>