<?php
$bar="product";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>F.A.Q<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-10 "> 
				<h3>FREQUENT ASK QUESTIONS    FAQ</h3>
 <button class="accordion">HOW DO I OPEN A PEARL ONLINE ACCOUNT </button>
 <div class="panel">Intending member can create a pearl online account by visiting the site, clicking on sign-up or registration, Filling the required details, uploading the required field, verifying your account through the code sent to your email. Please ensure that all field are accurately filled before final submission.   </div> 
 <button class="accordion">HOW CAN I FUND MY PEARL WALLET </button>
 <div class="panel">A.	Pearl wallet can be funded instantly by our online payment platform or ATM<br>
B.	By depositing directly to our bank, then filling a deposit confirmation slip in your user platform, 3-15 minutes  your payment will be approved or equally use a transfer and upload an evidence of payment on your user platform, it will be approved .
 </div>
 <button class="accordion">CAN I HAVE MORE THAN ONE PEARL ACCOUNT </button>
 <div class="panel">yes , but it is encouraged to have one single account to enable you run effectively as any details used in creating account cannot be use again. </div>
 <button class="accordion">ARE THEIR ANY SUBSCRIPTION FEE FOR USING PEARL MEMBERSHIP ACCOUNT </button>
 <div class="panel">No, pearl membership account is created free of charge. </div>
 <button class="accordion">DOES PEARL KNOW MY PIN OR IS IT SECURED </button>
 <div class="panel">The institution do not have access to your password  or your transaction pin because they are encrypted. </div> 
 <button class="accordion">WHICH BANK IN NIGERIA CAN I SEND MONEY TO </button>
 <div class="panel">All registered bank in Nigeria can receive payment from pearl solutions. </div>
 <button class="accordion">WILL I RECEIVE ALERT AFTER A SUCCESSFUL TRANSACTION </button>
 <div class="panel">Yes, alert are received only in funding wallet and withdrawal from wallet but other transaction in the platform are visible because of that alert will not be sent. </div>
 <button class="accordion">WHAT CAN I DO WITH THE MONEY IN MY PEARL WALLET </button>
 <div class="panel">Any money found in your wallet can be used for the following 
<ol><li> Paying of bills </li><li> Recharge card </li><li> Bank transfer </li> <li>Payment of thrift </li><li> payment of food stuff</li> <li>Repayment of loan</li></ol> </div>
 <button class="accordion">CAN I WITHDRAW FROM MY WALLET BALANCE </button>
 <div class="panel">Yes, any money in your wallet balance can be withdrawn at any time, it takes 3-15 minutes to hit your bank account. </div>
 <button class="accordion">DO I RECEIVE ALERT FOR PERFORMING ORDER SERVICES IN MY PEARL SOLUTION ACCOUNT </button>
 <div class="panel">No, the only service you receive alert is funding wallet and withdrawal from wallet </div>	
 <button class="accordion">CAN ANY BODY REGISTER TO USE PEARL SOLUTION SERVICES </button>
 <div class="panel">Yes, but as soon as you registered as online user, you are seen as pearl online member. </div>
 <button class="accordion">WHAT IS TRANSACTION PIN </button>
 <div class="panel">Before any transaction can be effective, there is provision where you input transaction Pin that is different from Login Pin that you took while creating the membership account. </div>
 <button class="accordion">WHEN DO I NEED TRANSACTION PIN </button>
 <div class="panel">Transaction Pin is needed  when completing any transaction example
<ol> <li> bill payment </li><li> Recharge card </li><li> Sending SMS </li><li> Bank transfer</li><li> Wallet withdrawal etc.</li></ol> </div>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>