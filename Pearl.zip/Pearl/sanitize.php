<?php
function sanitize($data){
	trim($data);
	$result=htmlspecialchars($data);
	$result=strip_tags($data);
	$result=stripslashes($data);
	return $result;
}
function num($data){
		$result = preg_replace('#[^0-9]#', '',$data);
		return $result;
		
}
function char($data){
			$result = preg_replace('#[^a-zA-Z]#', '',$data);
		return $result;
}
function numchar($data){
			$result = preg_replace('#[^a-zA-Z0-9]#', '',$data);
		return $result;
}
?>