<?php
$bar='login';
include"header.php";
$x=0;

?>



	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l"> Log In to Access your Account</h4> 
				<p>Enter your account login details and proceed</p></center><br>
			</div> 
			
			<div class="row">
			<form class="" action="" method="post"> 
			<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
			
			
			
			
			
						
						
						<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" class="form-control" placeholder="ENTER EMAIL" required="">
						</div>
						<div class='form-group'>
						<span class="badge" style="background-color:#3385FF;">Password</span>
						<input type="password" name="password" class="form-control" placeholder="PASSWORD" required=""><br>
						</div>
						<input type="submit" class="btn btn-info btn-block" value="LOGIN" name="login"> <br>
							<?php
      if (isset($_POST['login'])){
								
								
								$email = mysqli_real_escape_string($con,$_POST['email']);
								$email=sanitize($email);
								
								$password = $_POST['password'];
								$query = "select * from registeruser where  password='".sha1(md5($password))."' AND email_address='$email' ";
								$result = mysqli_query($con,$query)or die(mysqli_error($con));
                                $row = mysqli_fetch_array($result);
								 
								$num_row = mysqli_num_rows($result);
									if($num_row>0){
									if( $row['activated'] =="1" ) {
										
										$_SESSION['email']=$row['email_address'];
$_SESSION['account']=$row['account_number'];											
										?>								
<script>window.location="personal/"</script>
										<?php
									exit();	
									}/*elseif($row['paid']=="1" && $row["activated"=="0"]){
									    	$_SESSION['confirm']=$row['account_number'];
										$_SESSION['account']=$row['account_number'];
										$_SESSION['email']=$row['email_address'];
										?>
										<script>window.location="register.php"</script>
										<?php
										exit();
									}*/
									else{
										$query="select* from em_confirm where email='$email'";
									$resy = mysqli_query($con,$query)or die(mysqli_error($con));
									
									$se=mysqli_fetch_array($resy);
									
									if($se['confirm']=="0"){
										?>
										<script>window.location="confirm.php"</script>
										<?php
										exit();
									}/*else{
										$_SESSION['confirm']=$row['account_number'];
										$_SESSION['account']=$row['account_number'];
										?>
										<script>window.location="start.php"</script>
										<?php
										exit();
									}*/
									}
									}else{
								echo "<h4>Invalid Email or Password! ')</h4>";
								$x+1;
						
								
								}
								}
								
?>
						<p> <a href="password.php">Forget Password</a></p>
						<div class="clearfix"></div>
					
			
			
			
		
			
			
			
			
			</div> 
			</form>
			
			</div>
			
			
			
			
			</div></div>
	<!-- //contact --> 
	
	
	
	
	
	
	<!--footer-->




<?php include"footer.php";
?>