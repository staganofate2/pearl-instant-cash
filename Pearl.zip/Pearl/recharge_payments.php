<?php
$bar="product";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Buy Recharge<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				<center><h4 class="h3-w3l"> Top Up Your Airtime Instantly</h4> 
				<img src='images/network.jpg' width="60%" height="100px" alt='network image'>
				<p>Just a few steps ahead, to buy your desired Recharge Card </p></center><br>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE Airtime Top Up</h3>
<h2 style='color:green' id='resul'></h2>
	<?php
      if (isset($_POST['login'])){
								
								
								$network = mysqli_real_escape_string($con,$_POST['network']);
								$phone = mysqli_real_escape_string($con,$_POST['phone']);
								$variation = mysqli_real_escape_string($con,$_POST['amount']);
								$variation=str_replace(",","",$variation);
								$firstname = mysqli_real_escape_string($con,$_POST['firstname']);
								$lastname = mysqli_real_escape_string($con,$_POST['lastname']);
								$email = mysqli_real_escape_string($con,$_POST['email']);
									
								$ref =rand(100000000000,999999999999);
														
								$net=array("15"=>"MTN","6"=>"GLO","2"=>"9Mobile","1"=>"Airtel");
								
								$query="insert into rechargetwo (ref_no,network,phone,amount,regdate) values('$ref','$network','$phone','$variation',now())";
                                $result =mysqli_query($con,$query)or die(mysqli_error($con));
							 $id=mysqli_insert_id($con);
						$amount=$variation."00";
							 
								$query="insert into paystacktwo(types,types_id,firstname,lastname,email,ref_no,amount,phone,regdate)values('Recharge','$id','$firstname','$lastname','$email','$ref','$variation','$phone',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
						
				?>
				<center><h4 class="h3-w3l">Thank You</h4> 
				<p><b>Reference NO:  <?php echo $ref ?></b><br>
				Amount : N<?php echo $variation ?></p>
				
				
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <button type="button" onclick="payWithPaystack()" class='btn btn-info'> Pay Now </button> 
  <span id='res'></span>
</center><br>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $email ?>',
      amount: '<?php echo $amount ?>',
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $firstname ?>',
      lastname: '<?php echo $lastname ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $phone ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	document.getElementById("res").innerHTML = 'please wait ...';
	 ajax.open("POST", "updaterechargepay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			if(ajax.responseText="done"){
		document.getElementById("res").innerHTML = '';
		document.getElementById("resul").innerHTML = 'Your Recharge was Successful';
			 
			}else{
				alert(ajax.responseText);
				document.getElementById("res").innerHTML = '';
				document.getElementById("resul").innerHTML = '';
				
			}	
			
		}
	}
	ajax.send("ref="+response);
 
 
  }
</script>
  

<?php				
										
										
										
	}

								
?>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 
<?php
include"footer.php";
?>