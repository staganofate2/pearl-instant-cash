<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>MTN Data<b><img src='images/mtn-data.jpg' width="20%" height="100px" alt='network image'></h3>
			
			
			<!-- about bottom-->
			
				<center><h4 class="h3-w3l"> Top Up Your data Instantly</h4> 
				
				<p>Just a few steps ahead, to buy your desired Data Bundle </p></center>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-10 "> 
			<h3>ONLINE Data Top Up</h3>

	
								<form class="" action="data_payments.php" method="post" > 
			
			
			
			
			
			
						
						
						<input type='hidden' name="network" value='15'>
						<table class='table'>
						<tr><td><div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Data Amount</span>
						
						<select  name="variation" id='variation' class="form-control" required  >

						<option value=''>Select Data Amount</option><option value='100'>50MB-1day = 100N</option><option value='500'>750MB-14days = 500N</option><option value='1000'>1GB-30days = 1000N</option><option value='1200'>1.5GB-30days = 1200N</option><option value='2000'>2.5GB-30days = 2000N</option><option value='3500'>5GB-30days = 3500N</option><option value='5000'>10GB-30days = 5000N</option><option value='10000'>22GB-30days = 10000N</option>
						</select>
						
						</div>
								</td><td>				<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Recharging Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div></td></tr>
						<tr><td>
					<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div></td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div></td></tr>
							<tr><td>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div>
							</td><td><br>
						<input type="submit" class="btn btn-info " id='submit'value="Buy Now" name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			
			</td></tr></table>
			
			
			
			
		
			</form>
			
				</div> 
				<div class="clearfix"> </div>
			</div>		
		
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>