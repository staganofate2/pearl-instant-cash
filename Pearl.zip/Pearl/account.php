<?php
$bar="product";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>ACCOUNT<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-10 "> 
				<h2>TARGETED SAVING ACCOUNT</h2>
<p>Pearl  Targeted  account are those account package that has duration ranging from 3, 4, 6, 8 an 12 months  respectively, the targeted account are interest yielding up to maximum of 5% depending on the total deposit on the account before the maturity date.
The member takes a decision of either online payment, transfer or bank deposit. Wallet are funded for easy payment at your confort. The member chooses monthly, weekly and  amount  of payment  depending on the income rate.   The types of account are as follows.</p>  
	
			<button class="accordion"> Prime account ( save for 3 months)</button>

<div class="panel">This is an account package that gives an individual opportunity to  save for 3 months before collection. The member agrees with the collection officer or online users when creating the account on the days of payment.

<h5>Features of prime account</h5>
<ol>
<li>	Deposit depending on agreement.</li>
<li>	1% interest is paid on the account on maturity.</li>
<li>	Instant withdrawal.</li>

<li>	Alert on deposit.</li>
<li>	Free financial advice.</li>
<li>	All listed conditions are applicable to online users.</li>
</ol></div>
          <button class="accordion"> vintage account ( save for 4 months)</button>
            <div class="panel">A well structured account that a member save for four months before collection .<br>
			2%     interest will be given to the member at the end of four months.      
<h5>Features of vintage account</h5>
<ol>
<li>	Account package that the member save for 4months before collection.</li>
<li>	Instant withdrawal.</li>
<li>	Access to loan facilities .</li>
<li>	Instant sms alert.</li>
<li>	2% of the members total money paid to the member during withdrawal.</li>

</ol></div>
<button class="accordion">Premium draws account ( 6 months account )</button>
  <div class="panel">This is a targeted account for investment in the future, maturity of this account package is six        months .<br>it gives the depositors the time and opportunity to plan before maturity.
        <h5> Features of premium draws</h5>
<ol>
<li>	The account matures after six months from the date of starting.</li>
<li>	The institution pays 3% interest on the total savings during withdrawal.</li>
	<li>Instant sms alert.</li>
<li>Free financial advice.</li>
<li>	Access to loan facilities.</li>

<li>	Instant withdrawal.</li></ol></div>


<button class="accordion"> Treasure account: ( 8 months account)</button>
<div class="panel">An account package that mature in eight months from the date of commencement till the day of collection.
<h5>Feature of treasure account</h5>
<ol>
<li>	8 months maturity from the date of commencement.</li>
<li>	Instant withdrawal.</li>
<li>	Instant sms alert.</li>
<li>	Access to loan facilities.</li>
<li>	The institution pays 4% interest on the total money deposited by our member.</li>
<li>Free financial advice.</li>
</ol></div>

<button class="accordion">	Partnership account (12 months account)</button>
           <div class="panel">An account package that matures in 12 months, starting from the date of commencement till the date of maturity. This account gives depositor the opportunity of becoming the companies dormant partner after running for 5 year . A partnership allocation will be paid to that account annually, till the holder stop running the account.
<h5>Feature of partnership account</h5>
<ol>
<li>	12 months before maturity</li>
<li>	Instant withdrawal.</li>
<li>	Instant sms alert.</li>
<li>	Free financial advice.</li>
<li>	5% interest payable on the total saving of our member.</li>
</ol>
		</div>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>