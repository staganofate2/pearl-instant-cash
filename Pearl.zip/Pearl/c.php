<?php
include "connect.php";
$query="select account_number from registeruser";
$xs=mysqli_query($con,$query) or  die(mysqli_error($con));
while($z=mysqli_fetch_array($xs)){
	$account=$z['account_number'];


$query="select id from paystackcard where account_no='$account' and paid='1' and remove='0' and authorization_code !='' and active='1'"; 
					$x=mysqli_query($con,$query) or  die(mysqli_error($con));
					echo mysqli_num_rows($x);
					if(mysqli_num_rows($x)<1){
					    
					    $query="update paystackcard set active='1' where   account_no='$account' and authorization_code !=''order by id desc limit 1";
					    mysqli_query($con,$query) or die(mysqli_error($con));
					}
}