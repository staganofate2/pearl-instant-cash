<?php
include"connect.php";
$query="select account_number,email_address from registeruser where registeruser_id>'1250' and registeruser_id<'1385'";
$e=mysqli_query($con,$query) or die(mysqli_error($con));
echo mysqli_num_rows($e);
while($x=mysqli_fetch_array($e)){
	$query="select email from em_confirm where account_no='".$x['account_number']."'";
	$d=mysqli_query($con,$query) or die(mysqli_error($con));
	 mysqli_num_rows($d);
	if(mysqli_num_rows($d)<1){
	$f=rand(100000,999999);
	 $query="insert into em_confirm(code,email,account_no,regdate)values('$f','".$x['email_address']."','".$x['account_number']."',now())";
	mysqli_query($con,$query) or die(mysqli_error($con));
	
	
	$email=$x['email_address'];
	$account=$x['account_number'];

	$message = '<html><body>';

$message .= '<table  border="0" cellpadding="10">';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="logo" width="72px" height="26px"></td></tr>';
$message .= "<tr style='background: #eee;'><td><strong>Dear  </strong> " . strip_tags($email) . "</td></tr>";
$message .= "<tr><td><strong>This is your Account verification code: </strong>  $code </td></tr>";
$message .= "<tr><td><strong>Click on the Link below to verify your account</strong> </td></tr>";
$message .= "<tr><td><a href='https://www.pearlinstantcash.com/personal/email_conf.php?re0O0O=$code&ano=$account'>Confirm Account Now</a> </td></tr>";


$message .= "</table>";
$message .= "</body></html>";

$to = "$email";

$subject = 'Email Verification';

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To:info@pearlinstantcash.com \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $message, $headers)){
				echo"<h3>there was problem sending you  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
		
			}
	}
}

?>