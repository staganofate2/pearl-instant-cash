<?php
$bar="index";
include'header.php';
?>
	<div class="container">
			<div class="banner-text agileits-w3layouts">
				<div  id="top" class="callbacks_container">
					<ul class="rslides" id="slider3">
						<li>
							<div class="banner-textagileinfo" id="one">
								<h3>100% secure, reliable and stable.</h3>	
										
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="two"> 
								
								<h3 style='color:blue'>Online treasure investment, loan made easy @ your door step.</h3>	
								
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="three">
								
<h3 style='color:blue'>Tested, trusted and still counting.</h3>

`	
							</div>	
						</li> 
						<li>
							<div class="banner-textagileinfo" id="four">
								<h3 style='color:blue'>Digital cooperative principles and practices.</h3>	
										
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="five"> 
								
								<h3>Reducing the level of poverty in the society.</h3>	
								
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="six">
								
<h3>Subsidizing food item in our society.</h3>

`	
							</div>	
						</li> 
						<li>
							<div class="banner-textagileinfo" id="seven">
								<h3>Online reliable payment option integrated to your wallet to easy your stress.</h3>	
										
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="eight"> 
								
								<h3 style='color:blue'>Register and join millions of professionals in making the right choice they can trust.</h3>	
								
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="nine"> 
								
								<h3 style='color:lime'>Pay your GOTV, DSTV and STARTIME BILLS right here.</h3>	
								
							</div>	
						</li>
						<li>
							<div class="banner-textagileinfo" id="ten"> 
								
								<h3 style='color:lime'>Buy Recharge cards, bungle data of any network instantly.</h3>	
								
							</div>	
						</li>
						 
					</ul>
				</div>
			</div>
		 </div>
	</div>
	
	
		<!-- about -->
	
	<div class="home-about w3ls-section">
		<div class="container">
			<!-- about top-->
			<h3>Recharge, Data, Tv Subscription and bulk SMS Services</h3>
			<div class='gallery'>
			<a href='mtn-recharge.php'><img src='images/mtn.jpg' alt='mtn recharge'></a><a href='glo-recharge.php'><img src='images/glo.jpg' alt=''></a><a href='airtel-recharge.php'><img src='images/airtel.jpg' alt=''></a><a href='9mobile-recharge.php'><img src='images/9mobile.jpg' alt='9mobile'></a>
			<a href='glo-data.php'><img src='images/glo-data.jpg' alt='glo data'></a><a href='mtn-data.php'><img src='images/mtn-data.jpg' alt='mtn data'></a><a href='9mobile-data.php'><img src='images/9mobile-data.jpg' alt='9mobile data'></a><!--<a href='airtel-data.php'><img src='images/airtel-data.jpg' alt='airtel data'></a>-->
			<a href='dstv.php'><img src='images/dstv.jpg' alt='dstv'></a><a href='gotv.php'><img src='images/gotv.jpg' alt='gotv'></a><a href='startimes.php'><img src='images/startimes.jpg' alt='startimes'></a><a href='sms.php'><img src='images/sms.jpg' alt='sms'></a>
			<div class='clear'></div>
			</div>
			<!-- //about top-->
			<!-- about bottom-->
			
		</div>	
			<!-- //about-bottom -->
			<!-- about-bottom-grid -->
			<div class="wthree-about-bot-grid-sec">
			
			
			</div>
			<!-- //about-bottom-grid-->
	</div>
	<!-- //about -->
	
	
	
	
	
	<div class="home-about w3ls-section" style='border:solid blue;'>
		<div class="container">
			<!-- about top-->
			<div class="w3ls-about agile-section">
					<div class="w3-agileits-about-grids">
						
						<div class="middle" id='benefit'>
			<h1>Benefit/ways of making money using pearlinstantcash.com</h2>
<ol><li>1.	Instant access to loan facilities</li>
<li>2.	Batch of 5 referral, attract bonus of # 1,000.00 paid into your wallet instantly.</li>
<li>3.	Account upgrade attract percentage payment bonus ranging from 1-5% in every deposit. </li>
<li>4.	Recharge card price reduction.</li>
<li>5.	Percentage payment ranging from 1-5% paid to weekly/monthly membership saving account.</li>
<li>6.	Monthly payment interest of 10% Paid into your wallet on pearl investment.</li>
<li>7.	Food stuff well billed to your door step. </li></ol>
			
			</div>
						
						<div class="clearfix"> </div>
				   </div>
			</div>
			<!-- //about top-->
			<!-- about bottom-->
			
		</div>	
			<!-- //about-bottom -->
			<!-- about-bottom-grid -->
			
				
			<!-- //about-bottom-grid-->
	</div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	<!--services-->
	<div class="w3ls-section services">
		<div class="container">
			<div class="services-left">
				<h4 class="title">PEARL SOLUTION CTCS LTD Online Platform</h4>
				<h5>any time,anywhere.</h5>
				<p class="data" style='color:white'>Transact Online with your online account anywhere, on the GO..</p>
				

				
			</div>
			<div class="services-right">
			<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Online Loan</h5>
						<p>Online Loan made easy within 24 hours</p>
					</div>	
					</div>
					<div class="clearfix"> </div>
					<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Transfer Fund</h5>
						<p>Instant Transfer of fund from wallet to wallet</p>
					</div>	
					<div class="clearfix"> </div>
				</div>
				
				
			
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-lock" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>safe & secure</h5>
						<p>With our Comodo Security verification, All info are safe and secured</p>
					</div>	
					<div class="clearfix"></div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-clock-o" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>save time</h5>
						<p>Save time going to banks and make transactions online</p>
					</div>	
					<div class="clearfix"></div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-gg" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>transfer money</h5>
						<p>speedy transfer of money with ease</p>
					</div>
					<div class="clearfix"></div>
				</div>	
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>pay bills</h5>
						<p>pay all type of Bills with PEARL online</p>
					</div>	
					<div class="clearfix"> </div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Buy Recharge Card</h5>
						<p>Get Recharge Card of all network instantly</p>
					</div>	
					<div class="clearfix"> </div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Send SMS</h5>
						<p>Send instant customized SMS to all network</p>
					</div>	
					<div class="clearfix"> </div>
					</div>
					<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Bank Transfer </h5>
						<p>Instant Transfer of fund from wallet to Bank</p>
					</div>	
					<div class="clearfix"> </div>
				</div>
				</div>
				<!--<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-shopping-cart" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>Shop Online</h5>
						<p>Connect your PEARL account to Amazon.com and other shopping websites to shop online</p>
					</div>	
					<div class="clearfix"> </div>
				</div>-->
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//services-->

<?php
include"footer.php";
?>