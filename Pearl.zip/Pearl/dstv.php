<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>DSTV Subscription<b><img src='images/dstv.jpg' width="20%" height="100px" alt='dstv subscription image'></h3>
			
			
			<!-- about bottom-->
			
				<center><h4 class="h3-w3l"> Renew your DSTV subscription</h4> 
				
				<p>Just a few steps ahead, your bills are instantly settled </p></center>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE DSTV Bill Payment</h3>

<form class="" action="bill_confirms.php" method="post" > 
			
			
			
			
			
			
			
			
			
						<input type='hidden' name="type" value='dstv'>
						
						
						<table class='table'>
						<tr><td><div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Bouquet</span>
						
						<select  name="variation" id='variation' class="form-control" required onchange='update2()' >
						<option value="">Select Bouquet</option><option value='01'>DStv Access N2000</option><option value='02'>DStv Family N4000</option><option value='03'>DStv Compact N6,800</option><option value='04'>DStv Compact Plus N10,650</option><option value='05'>DStv Premium N15,800</option><option value='06'>DStv  Premium + HD/Exra View - N18,000</option>
						</select>
						
						</div></td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">DStv Smartcard Number</span>
						<input type="text" name="number" class="form-control" placeholder="DStv Smartcard Number" required=""><br>
						</div></td></tr>
						<tr><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">First Name</span>
				<input type="text" name="firstname" value=""class="form-control" placeholder="FIRST NAME" required="" ><br>
						</div></td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Last Name</span>
						<input type="text" name="lastname" value="" class="form-control"  placeholder="LAST NAME" required="" ><br>
							</div></td></tr>
							<tr><td>
							<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Email</span>
						<input type="text" name="email" value="" class="form-control"  placeholder="EMAIL" required="" ><br>
							</div>
						
						</td><td>
						<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Phone Number</span>
						<input type="text" name="phone" class="form-control" placeholder="Phone Number" required=""><br>
						</div></td></tr>
						<tr><td>
					<div class="form-group">
						<span class="badge" style="background-color:#3385FF;">Amount</span>
								<input class="form-control" value=""onkeyup="this.value = numFormat(this.value)" id='amount'readonly name="amount" type="text" placeholder='Amount in Digits' onblur="check()" required>
								<span class='danger' id='result'></span>
							</div></td><td>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Convenience fee</span>
								<input class="form-control" value="100" id='commi' name="commi" type="text"  readonly >
								
							</div></td></tr>
							<tr><td>
							<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Total Amount</span>
								<input class="form-control" value="" id='total' name="total" type="text"  readonly >
								
							</div></td><td><br>
						<input type="submit" class="btn btn-info " id='submit'value="Pay Now" name="login"> <br>
						
						<div class="clearfix"></div>
					
			
			</td></tr></table>
			
			
			</form>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 <script>
		var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
 function update2(){
	 
		 var types=document.getElementById("variation").value;


	 if(types=="01"){
	document.getElementById("amount").value="2000.00"; 
	document.getElementById("total").value="2100.00";
	 }if( types=="02"){
	document.getElementById("amount").value="4000.00";
document.getElementById("total").value="4100.00";	
	 }	 if( types=="03"){
	document.getElementById("amount").value="6800.00"; 
	document.getElementById("total").value="6900.00";
	 }	
	  if( types=="04"){
	document.getElementById("amount").value="10650.00"; 
	document.getElementById("total").value="10750.00";
	 }	
	 if( types=="05"){
	document.getElementById("amount").value="15800.00"; 
	document.getElementById("total").value="15900.00";
	 }	
	 if( types=="06"){
	document.getElementById("amount").value="18000.00"; 
	document.getElementById("total").value="18100.00";
	 }	
			 
 }
 
 
 function intFormat(n) {
    var regex = /(\d)((\d{3},?)+)$/;
    n = n.split(',').join('');
    while(regex.test(n)) {
        n = n.replace(regex, '$1,$2');
    }
    return n;
}
function numFormat(n) {

	 document.getElementById("submit").style.display="none";
    var pointReg = /([\d,\.]*)\.(\d*)$/, f;
    if(pointReg.test(n)) {
        f = RegExp.$2;
        return intFormat(RegExp.$1) + '.' + f;
    }
    return intFormat(n);
}
 </script>
<?php
include"footer.php";
?>