<?php
$bar='login';
include'header.php';
?>



	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l">Account Recovery</h4> 
				<p>Enter your email or phone number you provided during registration</p></center><br>
			</div> 
			
			
			<?php
if(isset($_POST['check'])){
	$user=mysqli_real_escape_string($con,$_POST['email']);
	$user=sanitize($user);
	$query="select phone,firstname,lastname ,account_number,email_address from registeruser where  email_address='$user'";
	$result=mysqli_query($con,$query)or die(mysqli_error($con));
	if(mysqli_num_rows($result)>0){
	$row=mysqli_fetch_array($result);
	$_SESSION['user']=$row['firstname']." ".$row['lastname'];
	$_SESSION['emails']=$row['email_address'];
	$account=$row['account_number'];
	?>
	<div class='row'>
	<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
	<h2>Hi <?php echo $_SESSION['user']?> </h2>
	<h3>A link has been sent to your email</h3>
	<p> click on the link to reset your password</p>
	
<?php

$message = '<html><body>';
$message .= '<table  border="0" cellpadding="10">';
$message.='<tr><td bgcolor="#ffffff" style="padding:2% 2% 2% 10%"><img src="https://www.pearlinstantcash.com/images/pearl.png" alt="" width="72px" height="26px"></td></tr>';
$message .= "<tr style='background: #eee;'><td><strong>Dear </strong> </td><td>" . $_SESSION['user'] . "</td></tr>";
//$message .= "<tr><td><strong>This is your Email verification code</strong> </td><td> $code </td></tr>";
$message .= "<tr><td><strong>Click on the Link below to reset your password</strong> </td><td></td></tr>";
$message .= "<tr><td><a href='https://www.pearlinstantcash.com/resetpass.php?re=$account'>Reset Password Now</a> </td><td></td></tr>";


$message .= "</table>";
$message .= "</body></html>";

$to = $_SESSION['emails'];

$subject = 'Password Reset Request';

$headers = "From: info@pearlinstantcash.com\r\n";
$headers .= "Reply-To: ". $_SESSION['emails'] . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if(!mail($to, $subject, $message, $headers)){
				echo"<h3>there was problem sending your  email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
			echo "<h3 style='text-align:center;color:red;magin-top:50px'>Email Sent</h3>";
			}









/*
			if(!mail($email, "Password Recovery", "Dear ".$_SESSION['user']." Pleace click on the link below to change your password <br><a href='resetpass.php?re=$account'>Reset my Password</a>. thank you for choosing PEARL. ")){
				echo"<h3>there was problem sending your password to your email</h3>";
				echo "<b>please try again later</b>";
			}else{
				
			echo "<h3 style='text-align:center;color:red;magin-top:50px'>".$_SESSION['user']." please check your email   inbox for your Password recovery link</h3>";
			}
			*/
			?>
			<h4>Thanks</h4>
	</div>
	</div>
	<?php
	
	}
	else{
		echo "<center><h3>Data Not Found</h3>
		<a href='password.php'>Try Again</a></center>";
	
	}
}else{
		?>
			
			
			
			
			
			<div class="row">
			<form class="" action="" method="post" > 
			<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
			
			
			
			
			
						
						
						
						<input type="text" name="email" class="form-control" placeholder="Your Email" required=""><br>
						
						
						<input type="submit" class="btn btn-info btn-block" value="CHECK" name="check"> <br>
						
						<div class="clearfix"></div>
					
			
			
			
		
     
			
			
			
			</div> 
			</form>
			
			</div>
			
			<?php
}
?>
			
			</div></div>
	<!-- //contact --> 
	
	
	
	
	
	
	<!--footer-->




<?php include"footer.php";
?>