<?php
include"connect.php";
$bar='signup';
include'header.php';

if(isset($_SESSION['confirm']) && isset($_SESSION['account'])){
	echo "<script>window.location='register.php'</script>";
	exit();
}
if(isset($_GET['re0O0O']) && isset($_GET['ano'])){
	$code=$_GET['re0O0O'];
	$account=$_GET['ano'];
	$query="select* from em_confirm where account_no='$account' and code='$code'";
	$resu = mysqli_query($con,$query) or die(mysqli_error($con,$query));
		if(mysqli_num_rows($resu)>0){
			$ro=mysqli_fetch_array($resu);
			$query = "update em_confirm set confirm='1' where  account_no='$account'";
								$results = mysqli_query($con,$query)or die(mysqli_error($con));
								
	@setcookie("confirm", $ro['email'], strtotime( '+30 days' ), "/", "", "", TRUE);
	
$_SESSION['confirm']=$ro['account_no'];
$_SESSION['account']=$ro['account_no'];
								
									?>
									<script>window.location='register.php'</script>
									<?php
									exit();
		}
}
?>



	
	
	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l">Sign Up new Account</h4> 
				<p>Enter your information to proceed</p></center><br>
			</div> 
			
			<div class="row">
			<form class="" action="" method="post" > 
			<div class="col-md-4">
			
			
			</div>
			<div class="col-md-5">
			
			
			
			
			
						<div class='form-group'>
						
						<span class="badge" style="background-color:#3385FF;">Confirmation Code</span>
						<input type="text" name="email" class="form-control" placeholder="Enter Confirmation Code" required=""><br>
						</div>
						
						<input type="submit" class="btn btn-info btn-block" value="CONFIRM" name="confirm"> <br>
						<?php
      if (isset($_POST['confirm'])){
								
								
								$email = escape($con,$_POST['email']);
													
								
								$query = "select* from em_confirm where  code='$email'";
								$result = mysqli_query($con,$query) or die(mysqli_error($con,$query));
								if(mysqli_num_rows($result)>0){
								$row=mysqli_fetch_array($result);
								
								
								
								if($row['confirm']=="1"){
									/*$_SESSION['account']=$row['account_no'];
									$_SESSION['email']=$row['email'];
									$query = "update em_confirm set confirm='1' where  email='{$_SESSION['email']}'";
								$results = mysqli_query($con,$query)or die(mysqli_error($con));
								
	@setcookie("confirm", $row['email'], strtotime( '+30 days' ), "/", "", "", TRUE);
	
$_SESSION['confirm']=$row['account_no'];
$_SESSION['account']=$row['account_no'];
								
									?>
									<script>window.location='register.php'</script>
									<?php
									exit();*/
									echo "<h3>This code has been used</h3>";
									
								}elseif($row['confirm']=="0"){
								     $query="update em_confirm set confirm='1' where code='$email'";
								    mysqli_query($con,$query) or die(mysqli_error($con));
								    $_SESSION['confirm']=$row['account_no'];
$_SESSION['account']=$row['account_no'];
								    ?>
								    	<script>window.location='register.php'</script>
								    	
								    <?php
								    exit();
								    }else{
								        
								   
								    
													$query="select total from wallet where account_no='{$_SESSION['account']}'";
				$er= mysqli_query($con,$query) or die(mysqli_error($con));
				$we=mysqli_fetch_array($er);
				if($we['total']<1000){
				    /*
					$_SESSION['confirm']=$row['account_no'];
					?>
					<script>window.location='confirm.php'</script>
					<?php
					exit();
					*/
				}else{
									echo "<h4>This  Code has been used by another account </h4>";
				}
								}
								}
								else{
									echo "<h4>Invalid Confirmation Code</h4>";
									
								}
	  }
	  
								
?>
						<p>Please Enter The Confirmation Code that was sent to your email or phone number  above</p>
						<div class="clearfix"></div>
					
			
			
			
			
			
			
			
			
			</div> 
			</form>
			
			</div>
			
			
			
			
			</div></div>
	<!-- //contact --> 
	
	




<?php include"footer.php";
?>