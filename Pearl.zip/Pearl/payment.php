<?php
$bar='signup';
include'header.php';

?>

<style>

table.table  tr td{
	color:black;
	font-weight:bold;
	font-size:16px;
}
</style>	
	
	
	
	
	
	
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			
				<center><h4 class="h3-w3l">Sign Up new Account</h4> 
				
				<p>Update Wallet</p></center><br>
			</div> 
			
			<div class="row">
			
<?php

				$query="select total from wallet where account_no='{$_SESSION['account']}'";
				$er= mysqli_query($con,$query) or die(mysqli_error($con,$query));
				$we=mysqli_fetch_array($er);
				if($we['total']>=1000){
					?>
					<script>window.location='register.php'</script>
					<?php
					exit();
				}else{
					?>
			
			
			<div class="col-md-2">
			
			
			</div>
			<div class="col-md-10">
			
			<h3><b style='color:blue;font-size:25px;margin-left:10px'>Wallet Balance:</b>   <b style='color:lime'>₦  <?php 
				
				  echo $we['total'] ?></b></h3>
<?php	
if(isset($_POST['change'])){			

$amount_w =escape($con,$_POST['amount_w']);
$amount_w=sanitize($amount_w);
$firstname =escape($con,$_POST['firstname']);
$firstname=sanitize($firstname);
$lastname =escape($con,$_POST['lastname']);
$lastname=sanitize($lastname);
$amount =escape($con,$_POST['amount']);
$amount=str_replace(",","",$amount);
$amount=sanitize($amount);
 $amountt=$amount.".00";
$method =escape($con,$_POST['method']);
$method=sanitize($method);

$_SESSION['method']=$method;
$ref =rand(100000000,999999999);
$query="select* from registeruser where account_number='{$_SESSION['account']}'";
$te=mysqli_query($con,$query)or die(mysqli_error($con));
$row=mysqli_fetch_array($te);
$message="pending  Deposit Payment";
$query="insert into deposit  (ref_no,amount_word,amount,method,regdate,account_no,category) values('$ref','$amount_w','$amount','$method',now(),'{$_SESSION['account']}','Wallet')";
mysqli_query($con,$query)or die(mysqli_error($con));
$id=mysqli_insert_id($con);
if($method=="Instant"){
	$query="insert into paystack(account_no,ref_no,amount,deposit_id,regdate)values('{$_SESSION['account']}','$ref','$amount','$id',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
	$query="update deposit set confirmed='1' where deposit_id='$id' and account_no='{$_SESSION['account']}'";
mysqli_query($con,$query) or die(mysqli_error($con));
	$amount=$amount."00";
	?>
	<center><h4 class="h3-w3l">Thank You</h4> 
				<p><p>Reference NO:  <?php echo $ref ?></p><br>
				
				
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <button type="button" onclick="payWithPaystack()" class='btn btn-info'> Pay Now </button> 
</center><br>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $row['email_address'] ?>',
      amount: '<?php echo $amount ?>',
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $firstname ?>',
      lastname: '<?php echo $lastname ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $row['phone'] ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	//document.getElementById(elem).innerHTML = 'please wait ...';
	 ajax.open("POST", "updatepay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
		window.location='start.php';	
			 
			
			
		}
	}
	ajax.send("ref="+response);
 
 
  }
</script>
  
	<?php
}
elseif($method=="Deposit"){
?>
<center><h4 class="h3-w3l">Thank You</h4> 
				<p>Bank Payment Details  </p><p>Reference NO:   #<?php echo $ref ?></p></center><br>
				
			 
			 <table class='table'>
			 <tr><td>ACCOUNT NAME   <strong class='text-danger'> ==></strong></td><td>Pearl Solution Cooperative thrift and credit Society Ltd</td></tr>
			 <tr><td>F.C.M.B ACCOUNT NO   <strong class='text-danger'>==> </strong></td><td> 5734338013</td></tr>
			 <tr><td>DIAMOND ACCOUNT NO    <strong class='text-danger'>==></strong></td><td>0106261717</td></tr>
			 
			 </table>
			 <h3>OR</h3>
			  <table class="table">
			 <tr><td>ACCOUNT NAME  <strong class='text-danger'> ==></strong></td><td>The Pearl Solution Cooperative Society</td></tr>
			 <tr><td>ACCESS ACCOUNT NO  <strong class='text-danger'> ==> </strong></td><td> 0762768697</td></tr>
			 <tr><td>ZENITH ACCOUNT NO   <strong class='text-danger'>==> </strong></td><td> 1015400153</td></tr>
			
			 
			 </table>
			 <h5>After Your Bank Payment Click below to confirm your Payment.</h5>
			 <a  style='text-align:center;margin-left:20%'href='confirmation.php?confirm_id=<?php echo $id ?>&method=Deposit'>Confirm Deposit Now</a></h5>
			 
<?php	
}
elseif($method=="Transfer"){
	?>
	<center><h4 class="h3-w3l">Thank You</h4> 
				<p>Bank Transfer Payment Details  </p><p>Reference NO:   #<?php echo $ref ?></p></center><br>
				
			 
			 <table class='table'>
			 <tr><td>ACCOUNT NAME   <strong class='text-danger'> ==></strong></td><td>Pearl Solution Cooperative thrift and credit Society Ltd</td></tr>
			 <tr><td>F.C.M.B ACCOUNT NO   <strong class='text-danger'>==> </strong></td><td> 5734338013</td></tr>
			 <tr><td>DIAMOND ACCOUNT NO    <strong class='text-danger'>==></strong></td><td>0106261717</td></tr>
			 
			 </table>
			 <h3>OR</h3>
			  <table class="table">
			 <tr><td>ACCOUNT NAME  <strong class='text-danger'> ==></strong></td><td>The Pearl Solution Cooperative Society</td></tr>
			 <tr><td>ACCESS ACCOUNT NO  <strong class='text-danger'> ==> </strong></td><td> 0762768697</td></tr>
			 <tr><td>ZENITH ACCOUNT NO   <strong class='text-danger'>==> </strong></td><td> 1015400153</td></tr>
			
			 
			 </table>
			 <h5>After Your Bank Transfer Click below to confirm your Payment.</h5>
			 <a href='confirmation.php?confirm_id=<?php echo $id ?>&method=Transfer'>Confirm Your Transfer Deposit Now</a></h5>
			
	<?php
	
}
}
echo "</div>";
				}
?>

				
				
				
				
				</div>
				
				</div>	
					</div>
					
		
	<?php include"footer.php";
?>