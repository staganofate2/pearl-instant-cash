<?php
include "connect.php";



if(!empty($_POST["acctnum"])) {
  $result = mysqli_query($con,"SELECT count(*) FROM registeruser WHERE account_number='" . $_POST["acctnum"] . "'");
  $row = mysqli_fetch_row($result);
  $user_count = $row[0];
  if($user_count>0) {
      echo "<span class='status-not-available' style='color:red;'>Account Already Exist!</span>";
  }else{
      echo "<span class='status-available' style='color:green;'>Ride On!</span>";
  }
}
?>