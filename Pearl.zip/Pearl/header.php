<?php
session_start();
include 'connect.php';
include'function.php';
if(isset($_GET['ref'])){
	$refer=num($_GET['ref']);
	
	$query="select* from refer where account_no='$refer'";
	$result=mysqli_query($con,$query) or die(mysqli_error($con));
	if(mysqli_num_rows($result)>0){
	$row=mysqli_fetch_array($result);
	
	if(!isset($_COOKIE['refered'])){
	$ip = preg_replace('#[^0-9.]#', '', getenv('REMOTE_ADDR'));
	setcookie("refered", $ip, strtotime( '+30 days' ), "/", "", "", TRUE);
	}
	$query="insert into refer_user (refer_id,ip,visit,regdate) values('".$row['refer_id']."','$ip','1',now())";
	mysqli_query($con,$query) or die(mysqli_error($con));
	}

}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>PEARL</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- link to koltech themes-->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">
<link href="css/font-awesome.css" rel="stylesheet">  
<!-- //Link end -->  
<!-- js --> 
	<script src="js/jquery-2.2.3.min.js"></script>
<script type="text/javascript"> //<![CDATA[ 
var tlJsHost = ((window.location.protocol == "https:") ? "https://secure.comodo.com/" : "http://www.trustlogo.com/");
document.write(unescape("%3Cscript src='" + tlJsHost + "trustlogo/javascript/trustlogo.js' type='text/javascript'%3E%3C/script%3E"));
//]]>
</script>
</head>
<body> 
	<!-- header -->
	<div class="headerw3-agile"> 
		<div class="header-w3mdl"><!-- header-two --> 
			<div class="container"> 
				<div class="agileits-logo navbar-left">
					<h3><a href="index.php"><img src="images/pearl.png" alt="logo"/></a></h3> 
				</div> 
				<div class="agileits-hdright nav navbar-nav">
					<div class="header-w3top"><!-- header-top --> 
						<ul class="w3l-nav-top">
						
						<!-----------------------------------------put the bank number--------------------->
							<li><i class="fa fa-phone"></i><span> +234 816 629 1593  </span></li>
							
							
							<!-------------bank number ends here---------------------------------->
							
							<!-------------------------put bank email here------------------------>
							<li><a href="mailto:info@pearlinstantcash.com"><i class="fa fa-envelope-o"></i><span>info@pearlinstantcash.com</span></a></li>
							
							<!-------------bank email ends here---------------------------------->
						</ul>
						<div class="clearfix"> </div> 	 
					</div>
					<div class="agile_social_banner">
					    
						<ul class="agileits_social_list">
							<li><a href="#"  onclick="popitup('https://facebook.com/pearlsolutioncooperativesociety/')"class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" onclick="popitup('https://twitter.com/Pearlsolutionc1/')"class="agile_twitter" ><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" onclick="popitup('http://instagram.com/pearlsolutioncooperative/')"class="w3_agile_dribble"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							
							
						</ul>
						<ul>
					</div>  

				</div>
				<div class="clearfix"> </div> 
			</div>	
		</div>	
	</div>	
	
	
	
	
	
	<!-- //header -->  
	<!-- banner -->
	<div class="banner">
	    <marquee style='color:red'scrollamount='2'>Buy Data, &nbsp;Recharge Cards for all networks, &nbsp;Pay Tv Subscription Bills such as GOTV, DSTV, Startimes and send Bulk SMS Instantly. Click on services under menu to perform your desired transaction</marquee>
		<div class="header-nav"><!-- header-three --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				
				
				<!-- top navigation -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
					
						<li><a href="index.php"<?php if($bar=="index"){echo ' class="active"';} ?>>Home</a></li>
						<li class="dropdown">
  <a class="dropbtn  <?php if($bar=="product"){echo ' active';} ?>" href='#'>Products</a>
  <div class="dropdown-content">
    <a href="account.php">Account
    <a href="investment.php">Investment</a>
    <a href="loan.php">Loan</a>
	<a href="food.php">Food Store</a>
	<a href="wallet.php">Wallet</a>
  </div>
<li> 
						<li class="dropdown">
  <a class="dropbtn  <?php if($bar=="services"){echo ' active';} ?>" href='#'>Services</a>
  <ul class="dropdown-content">
    <li><a href="#"  class="drop">Pay Bills</a>
	 <ul>
              <li><a href="dstv.php">DSTV</a></li>
              <li><a href="gotv.php">GOTV</a></li>
              <li><a href="startimes.php">Startimes</a></li>
              
             
            </ul>
	</li>
    <li><a href="#"  class="drop">Buy Recharge Card</a>
	<ul>
              <li><a href="mtn-recharge.php">MTN</a></li>
              <li><a href="glo-recharge.php">GLO</a></li>
              <li><a href="airtel-recharge.php">Airtel</a></li>
              <li><a href="9mobile-recharge.php">9Mobile</a></li>
             
            </ul>
	</li>
    <li><a href="#"  class="drop">Buy Data</a>
	<ul>
              <li><a href="mtn-data.php">MTN</a></li>
              <li><a href="glo-data.php">GLO</a></li>
              <!--<li><a href="airtel-data.php">Airtel</a></li>-->
              <li><a href="9mobile-data.php">9Mobile</a></li>
             
            </ul>
	</li>
	<li><a href="sms.php">Send SMS</a></li>

  </ul>
<li> 	
						<li><a href="login.php" class="scroll <?php if($bar=="login"){echo ' active';} ?>">Login </a></li>  
						 
						<li><a href="signup.php" class="scroll <?php if($bar=="signup"){echo ' active';} ?>">Create  Account</a></li>
						<li><a href="support.php" class="scroll <?php if($bar=="support"){echo ' active';} ?>">Support</a></li> 
                      						
						<li><a href="about.php" class="scroll <?php if($bar=="about"){echo ' active';} ?>">About Us</a></li>  
<li><a href="blog/" class="scroll <?php if($bar=="blog"){echo ' active';} ?>">Blog</a></li>  						
						  
						
						<!--<li><a href="about.php" class="scroll">About Us</a></li>-->
					</ul>  
					<div class="clearfix"> </div>	
				</div>
			</nav>  
<!--------------------------nav bar ends here----------------------------->			
		</div>
		<!-- banner-text -->
		<!-- banner -->
		<style>
ul ul{z-index:9999; position:absolute; width:180px; text-transform:none;}
 ul ul ul{left:180px; top:0;}
 li li{width:100%; margin:0;}
  .drop{padding-left:10px;}
  .drop a{padding-left:10px;margin-left:10px}
 li li a,  li li .drop{display:block; margin:0; padding:10px 10px;}
 .drop::after, li li .drop::after{content:" \00BB";color:red}
 .drop::after{top:35px; left:5px;}
 li li .drop::after{top:15px; left:5px;}
 li{
	 list-style-type:none;
 }
		 ul ul{visibility:hidden; opacity:0;background:#E3CF57;}
 ul li:hover > ul{visibility:visible; opacity:1;}
 
 
  /* Dropdown Button */
.dropbtn {
   /* background-color: #4CAF50; */
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 100;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;} 
 </style>
 <script>
 function popitup(url) {
      
	   newwindow=window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=400,left=400,width=600,height=500"); 
       if (window.focus) {newwindow.focus()}
       return false;
     }
 </script>