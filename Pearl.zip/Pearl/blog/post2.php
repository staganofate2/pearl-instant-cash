<?php
$bar="blog";
include"header.php";


?>

        
  
<!--
        <link rel="icon" type="image/ico" href="assets/image/logo2.png">

        <link rel="stylesheet" href="cs/bootstrap.css" type="text/css">
        <link rel="stylesheet" href="cs/font-awesome.css" type="text/css">
        <link rel="stylesheet" href="cs/style.css" type="text/css">

        <link href="css/cs.css" rel="stylesheet" type="text/css">

        
    <link href="css/summernote.css" rel="stylesheet">-->
    


       
        

  
       
        

    
        
     <!--   <div class="container">
            <div class="row">
            
    <div class="col-md-10 col-md-offset-1">-->
	
?>
  <style>
	.reg{
		border:solid green;
		margin:50px auto;
		width:60%;
		padding:20px;
	}
	button,input[type=file]{
		margin:20px;
	}
	input{
		width:200px;
		margin:10px 20px 100px 2px;
	}
	</style>		
		
	
		
		
		
		<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Blog Post<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-8"> 
               <?php if(!isset($_SESSION['post'])){ 
		  ?>
		  <form method="post" action="">
		  <label>Enter Password</label><input type="password" name="pass"><br>
		  <input type="submit" name="login" value="Login">
		  </form>
		  
		  
		  <?php
		  
		  if(isset($_POST['login'])){
			  
			  $pass=$_POST['pass'];
			  if($pass=="information"){
				  $_SESSION['post']=true;
				  echo"<script>window.location='post.php'</script>";
				  exit();
			  }else{
				  echo "<h3>Incorrect Password</h3>";
			  }
		  }
		  }else{
?>			  
						
	<h4 class="page-header">Blog Form</h4>
	
			<div id="imageresult"></div>
	<button id="statu_img_but">Add images</button><button id="statu_hd_but">Add Heading</button>
	<span id="results"></span>
		   
 
			    
        <form  action="" method="post" enctype="multipart/form-data" class="f12">
            
                	<input type='hidden' name='image' id='post' value=''>
            
            <div class="f1-steps">
               
            </div>

            

            <field/set style="display: block;">
               
                
								<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Title</span>
                <input type="text" class="form-control" name="title"placeholder="title" required>
				</div>
				<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Description</span>
                <input type="text" class="form-control" name="descripton"placeholder="descripton" required>
				</div>

                <div class="form-group ">
                    <label class="control-label">Post</label>
                    <textarea style="display: none;" name="message" id="description" placeholder="Message" rows="5" class="form-control"></textarea><div class="note-editor"><div class="note-dropzone"><div class="note-dropzone-message"></div></div><div class="note-dialog"><div class="note-image-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" aria-hidden="true" tabindex="-1">脳</button><h4 class="modal-title">Insert Image</h4></div><form class="note-modal-form"><div class="modal-body"><div class="form-group row-fluid note-group-select-from-files"><label>Select from files</label><input class="note-image-input" name="files" accept="image/*" multiple="multiple" type="file"></div><div class="form-group row-fluid"><label>Image URL</label><input class="note-image-url form-control span12" type="text"></div></div><div class="modal-footer"><button href="#" class="btn btn-primary note-image-btn disabled" disabled="disabled">Insert Image</button></div></form></div></div></div><div class="note-link-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" aria-hidden="true" tabindex="-1">脳</button><h4 class="modal-title">Insert Link</h4></div><form class="note-modal-form"><div class="modal-body"><div class="form-group row-fluid"><label>Text to display</label><input class="note-link-text form-control span12" type="text"></div><div class="form-group row-fluid"><label>To what URL should this link go?</label><input class="note-link-url form-control span12" type="text"></div><div class="checkbox"><label><input checked="checked" type="checkbox"> Open in new window</label></div></div><div class="modal-footer"><button href="#" class="btn btn-primary note-link-btn disabled" disabled="disabled">Insert Link</button></div></form></div></div></div><div class="note-help-dialog modal" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><form class="note-modal-form"><div class="modal-body"><a class="modal-close pull-right" aria-hidden="true" tabindex="-1">Close</a><div class="title">Keyboard shortcuts</div><div class="note-shortcut-row row"><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Action</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Z</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Undo</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + Z</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Redo</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + ]</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Indent</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + [</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Outdent</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + ENTER</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Insert Horizontal Rule</div></div></div><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Text formatting</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + B</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Bold</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + I</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Italic</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + U</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Underline</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + \</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Remove Font Style</div></div></div></div><div class="note-shortcut-row row"><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Document Style</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM0</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Normal</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM1</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 1</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM2</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 2</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM3</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 3</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM4</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 4</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM5</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 5</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + NUM6</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Header 6</div></div></div><div class="note-shortcut note-shortcut-col col-sm-6 col-xs-12"><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-title col-xs-offset-6">Paragraph formatting</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + L</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align left</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + E</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align center</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + R</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Align right</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + J</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Justify full</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + NUM7</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Ordered list</div></div><div class="note-shortcut-row row"><div class="note-shortcut-col col-xs-6 note-shortcut-key">Ctrl + Shift + NUM8</div><div class="note-shortcut-col col-xs-6 note-shortcut-name">Unordered list</div></div></div></div><p class="text-center"><a href="https://summernote.org/" target="_blank">Summernote 0.6.1</a> 路 <a href="https://github.com/summernote/summernote" target="_blank">Project</a> 路 <a href="https://github.com/summernote/summernote/issues" target="_blank">Issues</a></p></div></form></div></div></div></div><div class="note-handle"><div class="note-control-selection"><div class="note-control-selection-bg"></div><div class="note-control-holder note-control-nw"></div><div class="note-control-holder note-control-ne"></div><div class="note-control-holder note-control-sw"></div><div class="note-control-sizing note-control-se"></div><div class="note-control-selection-info"></div></div></div><div class="note-popover"><div class="note-link-popover popover bottom in" style="display: none;"><div class="arrow"></div><div class="popover-content"><a href="http://www.google.com/" target="_blank">www.google.com</a>&nbsp;&nbsp;<div class="note-insert btn-group"><button data-original-title="Edit (CTRL+K)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showLinkDialog" data-hide="true" tabindex="-1"><i class="fa fa-edit"></i></button><button data-original-title="Unlink" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="unlink" tabindex="-1"><i class="fa fa-unlink"></i></button></div></div></div><div class="note-image-popover popover bottom in" style="display: none;"><div class="arrow"></div><div class="popover-content"><div class="btn-group"><button data-original-title="Resize Full" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="1" tabindex="-1"><span class="note-fontsize-10">100%</span></button><button data-original-title="Resize Half" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="0.5" tabindex="-1"><span class="note-fontsize-10">50%</span></button><button data-original-title="Resize Quarter" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="resize" data-value="0.25" tabindex="-1"><span class="note-fontsize-10">25%</span></button></div><div class="btn-group"><button data-original-title="Float Left" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="left" tabindex="-1"><i class="fa fa-align-left"></i></button><button data-original-title="Float Right" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="right" tabindex="-1"><i class="fa fa-align-right"></i></button><button data-original-title="Float None" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="floatMe" data-value="none" tabindex="-1"><i class="fa fa-align-justify"></i></button></div><div class="btn-group"><button data-original-title="Shape: Rounded" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-rounded" tabindex="-1"><i class="fa fa-square"></i></button><button data-original-title="Shape: Circle" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-circle" tabindex="-1"><i class="fa fa-circle-o"></i></button><button data-original-title="Shape: Thumbnail" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" data-value="img-thumbnail" tabindex="-1"><i class="fa fa-picture-o"></i></button><button data-original-title="Shape: None" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="imageShape" tabindex="-1"><i class="fa fa-times"></i></button></div><div class="btn-group"><button data-original-title="Remove Image" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="removeMedia" data-value="none" tabindex="-1"><i class="fa fa-trash-o"></i></button></div></div></div></div><div class="note-toolbar btn-toolbar"><div class="note-style btn-group"><button data-original-title="Style" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-magic"></i> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="formatBlock" href="#" data-value="p">Normal</a></li><li><a data-event="formatBlock" href="#" data-value="blockquote"><blockquote>Quote</blockquote></a></li><li><a data-event="formatBlock" href="#" data-value="pre">Code</a></li><li><a data-event="formatBlock" href="#" data-value="h1"><h1>Header 1</h1></a></li><li><a data-event="formatBlock" href="#" data-value="h2"><h2>Header 2</h2></a></li><li><a data-event="formatBlock" href="#" data-value="h3"><h3>Header 3</h3></a></li><li><a data-event="formatBlock" href="#" data-value="h4"><h4>Header 4</h4></a></li><li><a data-event="formatBlock" href="#" data-value="h5"><h5>Header 5</h5></a></li><li><a data-event="formatBlock" href="#" data-value="h6"><h6>Header 6</h6></a></li></ul></div><div class="note-font btn-group"><button data-original-title="Bold (CTRL+B)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="bold" tabindex="-1"><i class="fa fa-bold"></i></button><button data-original-title="Italic (CTRL+I)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="italic" tabindex="-1"><i class="fa fa-italic"></i></button><button data-original-title="Underline (CTRL+U)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="underline" tabindex="-1"><i class="fa fa-underline"></i></button><button data-original-title="Remove Font Style (CTRL+\)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="removeFormat" tabindex="-1"><i class="fa fa-eraser"></i></button></div><div class="note-fontname btn-group"><button data-original-title="Font Family" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><span class="note-current-fontname">Helvetica Neue</span> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="fontName" href="#" data-value="Arial" style="font-family:'Arial'"><i class="fa fa-check"></i> Arial</a></li><li><a data-event="fontName" href="#" data-value="Arial Black" style="font-family:'Arial Black'"><i class="fa fa-check"></i> Arial Black</a></li><li><a data-event="fontName" href="#" data-value="Comic Sans MS" style="font-family:'Comic Sans MS'"><i class="fa fa-check"></i> Comic Sans MS</a></li><li><a data-event="fontName" href="#" data-value="Courier New" style="font-family:'Courier New'"><i class="fa fa-check"></i> Courier New</a></li><li><a data-event="fontName" href="#" data-value="Impact" style="font-family:'Impact'"><i class="fa fa-check"></i> Impact</a></li><li><a data-event="fontName" href="#" data-value="Tahoma" style="font-family:'Tahoma'"><i class="fa fa-check"></i> Tahoma</a></li><li><a data-event="fontName" href="#" data-value="Times New Roman" style="font-family:'Times New Roman'"><i class="fa fa-check"></i> Times New Roman</a></li><li><a data-event="fontName" href="#" data-value="Verdana" style="font-family:'Verdana'"><i class="fa fa-check"></i> Verdana</a></li></ul></div><div class="note-color btn-group"><button data-original-title="Recent Color" type="button" class="btn btn-default btn-sm btn-small note-recent-color" title="" data-event="color" data-value="{&quot;backColor&quot;:&quot;yellow&quot;}" tabindex="-1"><i class="fa fa-font" style="color:black;background-color:yellow;"></i></button><button data-original-title="More Color" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"> <span class="caret"></span></button><ul class="dropdown-menu"><li><div class="btn-group"><div class="note-palette-title">Background Color</div><div class="note-color-reset" data-event="backColor" data-value="inherit" title="Transparent">Set transparent</div><div class="note-color-palette" data-target-event="backColor"><div class="note-color-row"><button data-original-title="#000000" type="button" class="note-color-btn" style="background-color:#000000;" data-event="backColor" data-value="#000000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#424242" type="button" class="note-color-btn" style="background-color:#424242;" data-event="backColor" data-value="#424242" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#636363" type="button" class="note-color-btn" style="background-color:#636363;" data-event="backColor" data-value="#636363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C9C94" type="button" class="note-color-btn" style="background-color:#9C9C94;" data-event="backColor" data-value="#9C9C94" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEC6CE" type="button" class="note-color-btn" style="background-color:#CEC6CE;" data-event="backColor" data-value="#CEC6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFEFEF" type="button" class="note-color-btn" style="background-color:#EFEFEF;" data-event="backColor" data-value="#EFEFEF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7F7F7" type="button" class="note-color-btn" style="background-color:#F7F7F7;" data-event="backColor" data-value="#F7F7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFFFF" type="button" class="note-color-btn" style="background-color:#FFFFFF;" data-event="backColor" data-value="#FFFFFF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#FF0000" type="button" class="note-color-btn" style="background-color:#FF0000;" data-event="backColor" data-value="#FF0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF9C00" type="button" class="note-color-btn" style="background-color:#FF9C00;" data-event="backColor" data-value="#FF9C00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFF00" type="button" class="note-color-btn" style="background-color:#FFFF00;" data-event="backColor" data-value="#FFFF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FF00" type="button" class="note-color-btn" style="background-color:#00FF00;" data-event="backColor" data-value="#00FF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FFFF" type="button" class="note-color-btn" style="background-color:#00FFFF;" data-event="backColor" data-value="#00FFFF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#0000FF" type="button" class="note-color-btn" style="background-color:#0000FF;" data-event="backColor" data-value="#0000FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C00FF" type="button" class="note-color-btn" style="background-color:#9C00FF;" data-event="backColor" data-value="#9C00FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF00FF" type="button" class="note-color-btn" style="background-color:#FF00FF;" data-event="backColor" data-value="#FF00FF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#F7C6CE" type="button" class="note-color-btn" style="background-color:#F7C6CE;" data-event="backColor" data-value="#F7C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE7CE" type="button" class="note-color-btn" style="background-color:#FFE7CE;" data-event="backColor" data-value="#FFE7CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFEFC6" type="button" class="note-color-btn" style="background-color:#FFEFC6;" data-event="backColor" data-value="#FFEFC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6EFD6" type="button" class="note-color-btn" style="background-color:#D6EFD6;" data-event="backColor" data-value="#D6EFD6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEDEE7" type="button" class="note-color-btn" style="background-color:#CEDEE7;" data-event="backColor" data-value="#CEDEE7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEE7F7" type="button" class="note-color-btn" style="background-color:#CEE7F7;" data-event="backColor" data-value="#CEE7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6D6E7" type="button" class="note-color-btn" style="background-color:#D6D6E7;" data-event="backColor" data-value="#D6D6E7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E7D6DE" type="button" class="note-color-btn" style="background-color:#E7D6DE;" data-event="backColor" data-value="#E7D6DE" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E79C9C" type="button" class="note-color-btn" style="background-color:#E79C9C;" data-event="backColor" data-value="#E79C9C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFC69C" type="button" class="note-color-btn" style="background-color:#FFC69C;" data-event="backColor" data-value="#FFC69C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE79C" type="button" class="note-color-btn" style="background-color:#FFE79C;" data-event="backColor" data-value="#FFE79C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5D6A5" type="button" class="note-color-btn" style="background-color:#B5D6A5;" data-event="backColor" data-value="#B5D6A5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A5C6CE" type="button" class="note-color-btn" style="background-color:#A5C6CE;" data-event="backColor" data-value="#A5C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9CC6EF" type="button" class="note-color-btn" style="background-color:#9CC6EF;" data-event="backColor" data-value="#9CC6EF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5A5D6" type="button" class="note-color-btn" style="background-color:#B5A5D6;" data-event="backColor" data-value="#B5A5D6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6A5BD" type="button" class="note-color-btn" style="background-color:#D6A5BD;" data-event="backColor" data-value="#D6A5BD" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E76363" type="button" class="note-color-btn" style="background-color:#E76363;" data-event="backColor" data-value="#E76363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7AD6B" type="button" class="note-color-btn" style="background-color:#F7AD6B;" data-event="backColor" data-value="#F7AD6B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFD663" type="button" class="note-color-btn" style="background-color:#FFD663;" data-event="backColor" data-value="#FFD663" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#94BD7B" type="button" class="note-color-btn" style="background-color:#94BD7B;" data-event="backColor" data-value="#94BD7B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#73A5AD" type="button" class="note-color-btn" style="background-color:#73A5AD;" data-event="backColor" data-value="#73A5AD" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BADDE" type="button" class="note-color-btn" style="background-color:#6BADDE;" data-event="backColor" data-value="#6BADDE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#8C7BC6" type="button" class="note-color-btn" style="background-color:#8C7BC6;" data-event="backColor" data-value="#8C7BC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#C67BA5" type="button" class="note-color-btn" style="background-color:#C67BA5;" data-event="backColor" data-value="#C67BA5" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#CE0000" type="button" class="note-color-btn" style="background-color:#CE0000;" data-event="backColor" data-value="#CE0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E79439" type="button" class="note-color-btn" style="background-color:#E79439;" data-event="backColor" data-value="#E79439" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFC631" type="button" class="note-color-btn" style="background-color:#EFC631;" data-event="backColor" data-value="#EFC631" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BA54A" type="button" class="note-color-btn" style="background-color:#6BA54A;" data-event="backColor" data-value="#6BA54A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A7B8C" type="button" class="note-color-btn" style="background-color:#4A7B8C;" data-event="backColor" data-value="#4A7B8C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#3984C6" type="button" class="note-color-btn" style="background-color:#3984C6;" data-event="backColor" data-value="#3984C6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#634AA5" type="button" class="note-color-btn" style="background-color:#634AA5;" data-event="backColor" data-value="#634AA5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A54A7B" type="button" class="note-color-btn" style="background-color:#A54A7B;" data-event="backColor" data-value="#A54A7B" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#9C0000" type="button" class="note-color-btn" style="background-color:#9C0000;" data-event="backColor" data-value="#9C0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B56308" type="button" class="note-color-btn" style="background-color:#B56308;" data-event="backColor" data-value="#B56308" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#BD9400" type="button" class="note-color-btn" style="background-color:#BD9400;" data-event="backColor" data-value="#BD9400" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#397B21" type="button" class="note-color-btn" style="background-color:#397B21;" data-event="backColor" data-value="#397B21" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#104A5A" type="button" class="note-color-btn" style="background-color:#104A5A;" data-event="backColor" data-value="#104A5A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#085294" type="button" class="note-color-btn" style="background-color:#085294;" data-event="backColor" data-value="#085294" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#311873" type="button" class="note-color-btn" style="background-color:#311873;" data-event="backColor" data-value="#311873" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#731842" type="button" class="note-color-btn" style="background-color:#731842;" data-event="backColor" data-value="#731842" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#630000" type="button" class="note-color-btn" style="background-color:#630000;" data-event="backColor" data-value="#630000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#7B3900" type="button" class="note-color-btn" style="background-color:#7B3900;" data-event="backColor" data-value="#7B3900" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#846300" type="button" class="note-color-btn" style="background-color:#846300;" data-event="backColor" data-value="#846300" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#295218" type="button" class="note-color-btn" style="background-color:#295218;" data-event="backColor" data-value="#295218" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#083139" type="button" class="note-color-btn" style="background-color:#083139;" data-event="backColor" data-value="#083139" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#003163" type="button" class="note-color-btn" style="background-color:#003163;" data-event="backColor" data-value="#003163" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#21104A" type="button" class="note-color-btn" style="background-color:#21104A;" data-event="backColor" data-value="#21104A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A1031" type="button" class="note-color-btn" style="background-color:#4A1031;" data-event="backColor" data-value="#4A1031" title="" data-toggle="button" tabindex="-1"></button></div></div></div><div class="btn-group"><div class="note-palette-title">Foreground Color</div><div class="note-color-reset" data-event="foreColor" data-value="inherit" title="Reset">Reset to default</div><div class="note-color-palette" data-target-event="foreColor"><div class="note-color-row"><button data-original-title="#000000" type="button" class="note-color-btn" style="background-color:#000000;" data-event="foreColor" data-value="#000000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#424242" type="button" class="note-color-btn" style="background-color:#424242;" data-event="foreColor" data-value="#424242" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#636363" type="button" class="note-color-btn" style="background-color:#636363;" data-event="foreColor" data-value="#636363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C9C94" type="button" class="note-color-btn" style="background-color:#9C9C94;" data-event="foreColor" data-value="#9C9C94" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEC6CE" type="button" class="note-color-btn" style="background-color:#CEC6CE;" data-event="foreColor" data-value="#CEC6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFEFEF" type="button" class="note-color-btn" style="background-color:#EFEFEF;" data-event="foreColor" data-value="#EFEFEF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7F7F7" type="button" class="note-color-btn" style="background-color:#F7F7F7;" data-event="foreColor" data-value="#F7F7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFFFF" type="button" class="note-color-btn" style="background-color:#FFFFFF;" data-event="foreColor" data-value="#FFFFFF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#FF0000" type="button" class="note-color-btn" style="background-color:#FF0000;" data-event="foreColor" data-value="#FF0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF9C00" type="button" class="note-color-btn" style="background-color:#FF9C00;" data-event="foreColor" data-value="#FF9C00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFFF00" type="button" class="note-color-btn" style="background-color:#FFFF00;" data-event="foreColor" data-value="#FFFF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FF00" type="button" class="note-color-btn" style="background-color:#00FF00;" data-event="foreColor" data-value="#00FF00" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#00FFFF" type="button" class="note-color-btn" style="background-color:#00FFFF;" data-event="foreColor" data-value="#00FFFF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#0000FF" type="button" class="note-color-btn" style="background-color:#0000FF;" data-event="foreColor" data-value="#0000FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9C00FF" type="button" class="note-color-btn" style="background-color:#9C00FF;" data-event="foreColor" data-value="#9C00FF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FF00FF" type="button" class="note-color-btn" style="background-color:#FF00FF;" data-event="foreColor" data-value="#FF00FF" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#F7C6CE" type="button" class="note-color-btn" style="background-color:#F7C6CE;" data-event="foreColor" data-value="#F7C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE7CE" type="button" class="note-color-btn" style="background-color:#FFE7CE;" data-event="foreColor" data-value="#FFE7CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFEFC6" type="button" class="note-color-btn" style="background-color:#FFEFC6;" data-event="foreColor" data-value="#FFEFC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6EFD6" type="button" class="note-color-btn" style="background-color:#D6EFD6;" data-event="foreColor" data-value="#D6EFD6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEDEE7" type="button" class="note-color-btn" style="background-color:#CEDEE7;" data-event="foreColor" data-value="#CEDEE7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#CEE7F7" type="button" class="note-color-btn" style="background-color:#CEE7F7;" data-event="foreColor" data-value="#CEE7F7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6D6E7" type="button" class="note-color-btn" style="background-color:#D6D6E7;" data-event="foreColor" data-value="#D6D6E7" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E7D6DE" type="button" class="note-color-btn" style="background-color:#E7D6DE;" data-event="foreColor" data-value="#E7D6DE" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E79C9C" type="button" class="note-color-btn" style="background-color:#E79C9C;" data-event="foreColor" data-value="#E79C9C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFC69C" type="button" class="note-color-btn" style="background-color:#FFC69C;" data-event="foreColor" data-value="#FFC69C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFE79C" type="button" class="note-color-btn" style="background-color:#FFE79C;" data-event="foreColor" data-value="#FFE79C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5D6A5" type="button" class="note-color-btn" style="background-color:#B5D6A5;" data-event="foreColor" data-value="#B5D6A5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A5C6CE" type="button" class="note-color-btn" style="background-color:#A5C6CE;" data-event="foreColor" data-value="#A5C6CE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#9CC6EF" type="button" class="note-color-btn" style="background-color:#9CC6EF;" data-event="foreColor" data-value="#9CC6EF" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B5A5D6" type="button" class="note-color-btn" style="background-color:#B5A5D6;" data-event="foreColor" data-value="#B5A5D6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#D6A5BD" type="button" class="note-color-btn" style="background-color:#D6A5BD;" data-event="foreColor" data-value="#D6A5BD" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#E76363" type="button" class="note-color-btn" style="background-color:#E76363;" data-event="foreColor" data-value="#E76363" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#F7AD6B" type="button" class="note-color-btn" style="background-color:#F7AD6B;" data-event="foreColor" data-value="#F7AD6B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#FFD663" type="button" class="note-color-btn" style="background-color:#FFD663;" data-event="foreColor" data-value="#FFD663" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#94BD7B" type="button" class="note-color-btn" style="background-color:#94BD7B;" data-event="foreColor" data-value="#94BD7B" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#73A5AD" type="button" class="note-color-btn" style="background-color:#73A5AD;" data-event="foreColor" data-value="#73A5AD" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BADDE" type="button" class="note-color-btn" style="background-color:#6BADDE;" data-event="foreColor" data-value="#6BADDE" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#8C7BC6" type="button" class="note-color-btn" style="background-color:#8C7BC6;" data-event="foreColor" data-value="#8C7BC6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#C67BA5" type="button" class="note-color-btn" style="background-color:#C67BA5;" data-event="foreColor" data-value="#C67BA5" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#CE0000" type="button" class="note-color-btn" style="background-color:#CE0000;" data-event="foreColor" data-value="#CE0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#E79439" type="button" class="note-color-btn" style="background-color:#E79439;" data-event="foreColor" data-value="#E79439" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#EFC631" type="button" class="note-color-btn" style="background-color:#EFC631;" data-event="foreColor" data-value="#EFC631" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#6BA54A" type="button" class="note-color-btn" style="background-color:#6BA54A;" data-event="foreColor" data-value="#6BA54A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A7B8C" type="button" class="note-color-btn" style="background-color:#4A7B8C;" data-event="foreColor" data-value="#4A7B8C" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#3984C6" type="button" class="note-color-btn" style="background-color:#3984C6;" data-event="foreColor" data-value="#3984C6" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#634AA5" type="button" class="note-color-btn" style="background-color:#634AA5;" data-event="foreColor" data-value="#634AA5" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#A54A7B" type="button" class="note-color-btn" style="background-color:#A54A7B;" data-event="foreColor" data-value="#A54A7B" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#9C0000" type="button" class="note-color-btn" style="background-color:#9C0000;" data-event="foreColor" data-value="#9C0000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#B56308" type="button" class="note-color-btn" style="background-color:#B56308;" data-event="foreColor" data-value="#B56308" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#BD9400" type="button" class="note-color-btn" style="background-color:#BD9400;" data-event="foreColor" data-value="#BD9400" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#397B21" type="button" class="note-color-btn" style="background-color:#397B21;" data-event="foreColor" data-value="#397B21" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#104A5A" type="button" class="note-color-btn" style="background-color:#104A5A;" data-event="foreColor" data-value="#104A5A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#085294" type="button" class="note-color-btn" style="background-color:#085294;" data-event="foreColor" data-value="#085294" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#311873" type="button" class="note-color-btn" style="background-color:#311873;" data-event="foreColor" data-value="#311873" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#731842" type="button" class="note-color-btn" style="background-color:#731842;" data-event="foreColor" data-value="#731842" title="" data-toggle="button" tabindex="-1"></button></div><div class="note-color-row"><button data-original-title="#630000" type="button" class="note-color-btn" style="background-color:#630000;" data-event="foreColor" data-value="#630000" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#7B3900" type="button" class="note-color-btn" style="background-color:#7B3900;" data-event="foreColor" data-value="#7B3900" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#846300" type="button" class="note-color-btn" style="background-color:#846300;" data-event="foreColor" data-value="#846300" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#295218" type="button" class="note-color-btn" style="background-color:#295218;" data-event="foreColor" data-value="#295218" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#083139" type="button" class="note-color-btn" style="background-color:#083139;" data-event="foreColor" data-value="#083139" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#003163" type="button" class="note-color-btn" style="background-color:#003163;" data-event="foreColor" data-value="#003163" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#21104A" type="button" class="note-color-btn" style="background-color:#21104A;" data-event="foreColor" data-value="#21104A" title="" data-toggle="button" tabindex="-1"></button><button data-original-title="#4A1031" type="button" class="note-color-btn" style="background-color:#4A1031;" data-event="foreColor" data-value="#4A1031" title="" data-toggle="button" tabindex="-1"></button></div></div></div></li></ul></div><div class="note-para btn-group"><button data-original-title="Unordered list (CTRL+SHIFT+NUM7)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertUnorderedList" tabindex="-1"><i class="fa fa-list-ul"></i></button><button data-original-title="Ordered list (CTRL+SHIFT+NUM8)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertOrderedList" tabindex="-1"><i class="fa fa-list-ol"></i></button><button data-original-title="Paragraph" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-align-left"></i> <span class="caret"></span></button><div class="dropdown-menu"><div class="note-align btn-group"><button data-original-title="Align left (CTRL+SHIFT+L)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyLeft" tabindex="-1"><i class="fa fa-align-left"></i></button><button data-original-title="Align center (CTRL+SHIFT+E)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyCenter" tabindex="-1"><i class="fa fa-align-center"></i></button><button data-original-title="Align right (CTRL+SHIFT+R)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyRight" tabindex="-1"><i class="fa fa-align-right"></i></button><button data-original-title="Justify full (CTRL+SHIFT+J)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="justifyFull" tabindex="-1"><i class="fa fa-align-justify"></i></button></div><div class="note-list btn-group"><button data-original-title="Indent (CTRL+])" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="indent" tabindex="-1"><i class="fa fa-indent"></i></button><button data-original-title="Outdent (CTRL+[)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="outdent" tabindex="-1"><i class="fa fa-outdent"></i></button></div></div></div><div class="note-height btn-group"><button data-original-title="Line Height" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-text-height"></i> <span class="caret"></span></button><ul class="dropdown-menu"><li><a data-event="lineHeight" href="#" data-value="1"><i class="fa fa-check"></i> 1.0</a></li><li><a data-event="lineHeight" href="#" data-value="1.2"><i class="fa fa-check"></i> 1.2</a></li><li><a data-event="lineHeight" href="#" data-value="1.4"><i class="fa fa-check"></i> 1.4</a></li><li><a data-event="lineHeight" href="#" data-value="1.5"><i class="fa fa-check"></i> 1.5</a></li><li><a data-event="lineHeight" href="#" data-value="1.6"><i class="fa fa-check"></i> 1.6</a></li><li><a data-event="lineHeight" href="#" data-value="1.8"><i class="fa fa-check"></i> 1.8</a></li><li><a data-event="lineHeight" href="#" data-value="2"><i class="fa fa-check"></i> 2.0</a></li><li><a data-event="lineHeight" href="#" data-value="3"><i class="fa fa-check"></i> 3.0</a></li></ul></div><div class="note-table btn-group"><button data-original-title="Table" type="button" class="btn btn-default btn-sm btn-small dropdown-toggle" data-toggle="dropdown" title="" tabindex="-1"><i class="fa fa-table"></i> <span class="caret"></span></button><ul class="note-table dropdown-menu"><div class="note-dimension-picker"><div style="width: 10em; height: 10em;" class="note-dimension-picker-mousecatcher" data-event="insertTable" data-value="1x1"></div><div class="note-dimension-picker-highlighted"></div><div class="note-dimension-picker-unhighlighted"></div></div><div class="note-dimension-display"> 1 x 1 </div></ul></div><div class="note-insert btn-group"><button data-original-title="Link (CTRL+K)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showLinkDialog" data-hide="true" tabindex="-1"><i class="fa fa-link"></i></button><!--<button data-original-title="Picture" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showImageDialog" data-hide="true" tabindex="-1"><i class="fa fa-picture-o"></i></button>--><button data-original-title="Insert Horizontal Rule (CTRL+ENTER)" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="insertHorizontalRule" tabindex="-1"><i class="fa fa-minus"></i></button></div><div class="note-view btn-group"><button data-original-title="Full Screen" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="fullscreen" tabindex="-1"><i class="fa fa-arrows-alt"></i></button><button data-original-title="Code View" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="codeview" tabindex="-1"><i class="fa fa-code"></i></button></div><div class="note-help btn-group"><button data-original-title="Help" type="button" class="btn btn-default btn-sm btn-small" title="" data-event="showHelpDialog" data-hide="true" tabindex="-1"><i class="fa fa-question"></i></button></div></div><textarea class="note-codable"></textarea><div data-placeholder="Description" class="note-editable" contenteditable="true"></div></div>
                    <span class="help-block desc-error"></span>
                </div>

               
            
                <p>Upload Primary Image</p>
			<img src="../images/faceless.png" alt=""  width='100px'class="img-responsive"  align="absmiddle" id="outputpix"/><br />
                <input type="hidden" name="MAX_FILE_SIZE" value="5000000">
                <input type="file"  name="file" id="ufile" accept="image/*" onchange="loadFile(event)" required  /><br>

                <br class="clear clearfix"><br>

                <div class="f1-buttons">
                    
                    
                    <input type="submit" name="submit"  class="btn btn-lg btn-info btn-uga btn-submit" value="Send">
                </div>
				
            
        <?php if(isset($_POST['Submit'])){
		  $title=mysqli_real_escape_string($con ,$_POST['title']);
		  $descripton=mysqli_real_escape_string($con ,$_POST['descripton']);
		  
		  $message=$_POST['message'];
		$messagedb=mysqli_real_escape_string($con ,$message);
		$idcard='';
	if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["file"])) {	
		 $fileName = $_FILES["file"]["name"];
 $fileTmpLoc = $_FILES["file"]["tmp_name"];
@list($width, $height) = getimagesize($fileTmpLoc);
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(10000000000,99999999999).".".$extension;
		
		
	$idcard="../blog/userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$idcard );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
		
		
			
        }
    }
 else {
    echo "Invalid file";
}

	}
$page=str_replace(" ","-",$title);
		  $query="insert into blog (title,page,description,post,image,postdate)values('$title','$page','$descripton','$messagedb','$idcard',now())";
		  $result=mysqli_query($con ,$query) or die(mysqli_error($con ));
		  
		  
$script='<?php $bar=\'blog\';include"../headers.php";';
$script.='$query="select* from ';
$script.="blog where page='";
$script.="$page'\";";
$script.='$result=mysqli_query($con ,$query) or die(mysqli_error($con ));$row=mysqli_fetch_array($result); ?>';
$script.="<div class=' w3ls-section' id='inner-about'>
		<div class='container'>
			<h3 class='h3-w3l'><b>Blog<b></h3>
			
			
			<!-- about bottom-->
			<div class='about-bottom'>
				
				<div class='col-md-10'> ";
$script.= <<<'DOCT'
 <!-- blog detail -->
  <h2><?php echo $row['title'] ?></h2>
  
  <img src="../<?php echo $row['image'] ?>" class="thumbnail img-responsive" style='width:60%;margin-left:10%;border:none' alt="">
  <div class="info">Posted on:<?php echo $row['postdate'] ?></div>
<p>
DOCT;
 $script.='<?php echo $row["post"] ?></p>';
 $script.=<<<'DOCT'
  <?php
$query="select* from blogcomment where blog_id='".$row['blog_id']."' and status='1'";
$re=mysqli_query($con ,$query) or die(mysqli_error($con ));
if(mysqli_num_rows($re)>0){
	echo "<h4>".mysqli_num_rows($re)." Comment(s) </h4>";
	while($se=mysqli_fetch_array($re)){
		?>
		<div class='commentss'>
		<b style='margin-right:20px;color:blue'><?php echo $se['name'] ?></b><strong style='color:gray'><?php echo $se['postdate'] ?></strong>
		<p><?php echo $se['post'] ?></p>
		<?php 
		$query="select* from reply where blogcomment='".$se['blogcomment_id']."'";
		$u=mysqli_query($con ,$query) or die(mysqli_error($con ));
		if(mysqli_num_rows($u)>0){
			echo "<h4>". mysqli_num_rows($u)." Reply(s) </h4>";
			while($fe=mysqli_fetch_array($u)){
				?>
		<div class='reply'>
		<b style='margin-right:20px;color:green'>Admin</b><strong style='color:gray'><?php echo $fe['postdate'] ?></strong>
		<p><?php echo $fe['post'] ?></p>
		</div>
		<?php
		}}
		?>
		</div>
		<?php
	}
}
?>
<div class='col-md-5'> 
<div class="form-group">
							<span class="badge" style="background-color:#3385FF;">Your Comment</span><br>
                <textarea type="text" name="mes" id="mes"></textarea><br>
				<input type='hidden' id='id' value="<?php echo $row['blog_id'] ?>">
				</div>
				<div class="form-group">
				<input type="text" class="form-control"id='name'  name="name"placeholder="Your Name" required>
				</div>
				<div class="form-group">
				<input type="text" class="form-control"id='email'  name="email"placeholder="Your Email" required>
				</div>
				<div class="form-group">
				<input type="text" class="form-control"id='phone'  name="phone"placeholder="Your Phone" required>
				</div>
				<input type="submit" id="meebutton" value="SEND" onclick="sendit()"><br><span id='result'></span>
      
	  </div>
	  </div>
 </div>

  <div class="col-lg-2 ">

              
                <h3>Recent Post</h3>
                
              
              <div class="tab-content">
                
                  <ul class="list-unstyled">
				 <?php  $query="select* from 
DOCT;
$script.="blog order by postdate desc limit 10 \";";
$script.=<<<'DOCT'
$re=mysqli_query($con ,$query) or die(mysqli_error($con ));
while($red=mysqli_fetch_array($re)){
	
	?>
                  <li>
                  <h5><a href="../<?php echo $red['page'] ?>/"><?php echo $red['title'] ?></a></h5>
                            <div class="info">Posted on: <?php echo $red['postdate'] ?></div>  
                            </li>
							<?php 
}
?>
                
DOCT;
$script.='
                            
              
            </div>
  <!-- tabs -->


  </div>
</div>
</div>
</div>

<?php include\'../footers.php\';?>';	
 $filenam = basename( $page );
$filenam = preg_replace( "/[^A-Za-z0-9_\- ]/", "", $filenam  );

 $mytable=$filenam;
if (!file_exists($mytable)) {
			mkdir($mytable, 0755);
		}

$file = "index.php";
$filepath = "$mytable/$file";
if ( file_exists( $filepath ) ) {

} else {
if ( file_put_contents( $filepath, $script ) === false ) die( "Couldn’t createfile" );
chmod( $filepath, 0644 );

}	  
		  
	echo "success";	  
	  }
	  
	  ?>
          
</form>

						
                       
						
						
						
                       
                   




<?php
		  }
		  ?>
    
   </div>





		
			
			
			
		</div><!--/.row-->
		
		<div class="col-sm-12">
				
			</div>
		
		
		</div>

       <script type="text/javascript" src="cs/jquery.js"></script>
		
        <script type="text/javascript" src="cs/bootstrap.js"></script>
        <script type="text/javascript" src="cs/bootstrap3-typeahead.js"></script>
       <script type="text/javascript" src="cs/app.js"></script>
        
    <script src="cs/summernote.js"></script>
  
   <script type="text/javascript">
        function scroll_to_class(element_class, removed_height) {
            var scroll_to = $(element_class).offset().top - removed_height;
            if($(window).scrollTop() != scroll_to) {
                $('html, body').stop().animate({scrollTop: scroll_to}, 0);
            }
        }

        function bar_progress(progress_line_object, direction) {
            var number_of_steps = progress_line_object.data('number-of-steps');
            var now_value = progress_line_object.data('now-value');
            var new_value = 0;
            if(direction == 'right') {
                new_value = now_value + ( 100 / number_of_steps );
            }
            else if(direction == 'left') {
                new_value = now_value - ( 100 / number_of_steps );
            }
            progress_line_object.attr('style', 'width: ' + new_value + '%;').data('now-value', new_value);
        }

        $(document).ready(function() {

            insertAxises();

            
                $('.f1 fieldset:first').fadeIn('slow');
            


            $('.f1 input[type="text"], .f1 input[type="password"], .f1 select').on('focus', function() {
                $(this).removeClass('input-error');
            });

            // next step
            $('.f1 .btn-next').on('click', function() {
                var parent_fieldset = $(this).parents('fieldset');
                var next_step = true;
                // navigation steps / progress steps
                var current_active_step = $(this).parents('.f1').find('.f1-step.active');
                var progress_line = $(this).parents('.f1').find('.f1-progress-line');

                // fields validation
                parent_fieldset.find('input[type="text"], input[type="password"], input[type="hidden"], select').each(function() {
                    if( $(this).val() == "" && $(this).attr("required") == "required") {
                        $(this).addClass('input-error');
                        next_step = false;
                    } else {
                        $(this).removeClass('input-error');
                    }
                    var value = $(this).val().split(",").join("");
                    if($(this).attr("id") == "price" && isNaN(value)) {
                        $(this).addClass('input-error');
                        next_step = false;
                        alert("Price must be a number e.g 300000 (comma is added for you)")
                    }
                });
                // fields validation

                if( next_step ) {
                    parent_fieldset.fadeOut(400, function() {
                        // change icons
                        current_active_step.removeClass('active').addClass('activated').next().addClass('active');
                        // progress bar
                        bar_progress(progress_line, 'right');
                        // show next step
                        $(this).next().fadeIn();
                        // scroll window to beginning of the form
                        scroll_to_class( $('.f1'), 100 );
                    });
                }
            });

            // previous step
            $('.f1 .btn-previous').on('click', function() {
                // navigation steps / progress steps
                var current_active_step = $(this).parents('.f1').find('.f1-step.active');
                var progress_line = $(this).parents('.f1').find('.f1-progress-line');

                $(this).parents('fieldset').fadeOut(400, function() {
                    // change icons
                    current_active_step.removeClass('active').prev().removeClass('activated').addClass('active');
                    // progress bar
                    bar_progress(progress_line, 'left');
                    // show previous step
                    $(this).prev().fadeIn();this
                    // scroll window to beginning of the form
                    scroll_to_class( $('.f1'), 100 );
                });
            });

            // submit
            $('.f1').on('submit', function(e) {
                // fields validation
                $(this).find('input[type="text"], input[type="password"], select').each(function() {
                    if( $(this).val() == "" && $(this).attr("required") == "required") {
                        e.preventDefault();
                        $(this).addClass('input-error');
                    }
                    else {
                        $(this).removeClass('input-error');
						alert("nofate")
                    }
                });
                // fields validation
            });

            $('#description').summernote();


        });

    </script>


         <script type="text/javascript">

            function hideAlert(){
                $.ajax({
                    type: "POST",
                    url : '/hideAlertModal',
                    complete : function(){
                    }
                });
            }

            $(document).ready(function() {
                //increase the size of post property request panel close button
                $("#alert-panel button.close").css("font-size","35px");
                $("#alert-panel2 button.close").css("font-size","35px");

                

                $('body').on('click', '.radioBtn button', function() {
                    var sel = $(this).data('title');
                    var tog = $(this).data('toggle');
                    $(this).parent().next('.' + tog).prop('value', sel);
                    $(this).parent().find('button[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
                    $(this).parent().find('button[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
                });

                $('.confirm').click(function(e){
                    if(confirm("Are You sure?")){
                        $("#ajaxWait").show();
                        $.ajax({
                            type: "POST",
                            url : $(this).attr("href"),
                            complete : function(){
                                window.location.reload();
                            }
                        });
                    }
                    e.preventDefault();
                });

                $('.confirm2').click(function(e){
                    if(confirm("Are You sure?")){
                        $("#ajaxWait").show();
                        $.ajax({
                            type: "POST",
                            url : $(this).attr("data-href"),
                            success: function(data) {
                                if(data!=="success") {
                                    alert(data);
                                }
                            },
                            complete : function(){
                                window.location.reload();
                            }
                        });
                    }
                    e.preventDefault();
                });

                $("#subscribe-btn").click(function(){
                    $('#info-box').html("");
                    $('#ajaxWait').show();
                    $.ajax({
                        type: 'POST',
                        url: $("#newsletterForm").attr("action"),
                        data: $("#newsletterForm").serialize(),
                        success: function(data) {
                            if(data==="success") {
                                $("#info-box").html("You have successfully subscribed to our home recommendation mailing list");
                            } else {
                                $("#info-box").html(data);
                            }
                            $("#ajaxWait").hide();
                            $('#info-modal').modal('show');
                        }
                    });
                    return false;
                });

                $("a[href='#top']").click(function() {
                    $("html, body").animate({ scrollTop: 0 }, "slow");
                    return false;
                });

                $(window).scroll(function(e) {
                    checkScrollLocation();
                });

                $(window).load(function(e) {
                    checkScrollLocation();
                });

                $(".alert2-btn").click(function(){
                    var valid = true;
                    var form = $(this).parents("form");
                    form.find("input").each(function(){
                        if($(this).val().length === 0 && $(this).attr("required") === "required") {
                            $(this).addClass('error');
                            valid = false;
                        } else {
                            $(this).removeClass('error');
                        }
                    });
                    if(!valid) {
                        alert("Please enter your name and email address");
                        return;
                    }
                    $("#ajaxWait").show();
                    $.ajax({
                        type: 'POST',
                        url: form.attr("action"),
                        data: form.serialize(),
                        success: function(data) {
                            if(data==="success") {
                                alert("You have successfully subscribed");
                            } else if(data==="already") {
                                alert("You have already subscribed to this search");
                            } else {
                                alert(data);
                            }
                            $("#ajaxWait").hide();
                            $('#alert-panel').slideUp();
                        }
                    });
                    return false;
                });

                $('.close-alert-panel').click(function(e){
                    hideAlert();
                    $('#alert-panel').slideUp();
                });

                $('.hide-alert-panel').click(function(e){
                    hideAlert();
                    $('#alert-panel').slideUp();
                });

                $.get('/areas.json', function(data){
                    $(".searchInput").typeahead({ source:data });
                },'json');

                $("#nav-expo img").click(function(e) {
                    window.open('/expo', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
                });

                $("#nav-expo .expo-img span").click(function(e) {
                    $.get( "/hideExpoStrip", function(data) {
                    });
                    $("#nav-expo").slideUp('slow');
                });

                $("#jumiatolet .clicktoread").click(function(e) {
                    window.open('/blog/nigeria-uga-com-ng-acquires-jumia-house-nigeria/', '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
                });

                
                    $(".push-header").css("height", "86px");
                

                $("#jumiatolet span").click(function(e) {
                    $.get( "/hideJumiaStrip", function(data) {
                    });
                    $("#jumiatolet").slideUp('slow');
                    $(".push-header").css("height", "50px");
                });


            });

            function checkScrollLocation(){
                scrollTop=$(window).scrollTop();
                intro=$('#brand').height()-70;
                if($("#header-navigation").hasClass('home')){
                    if(scrollTop > intro){
                        $('#header-navigation').fadeIn(500);
                    }
                    else{
                        $('#header-navigation').fadeOut(500);
                    }
                }
            }

            /*******************coverage collapse*******************/
            $('.collapse').on('show.bs.collapse', function (src) {
                $('#search-filter-btn').text('Close Filter');
            });


            $('.collapse').on('hidden.bs.collapse', function (src) {
                $('#search-filter-btn').text('Refine Search');
            });

        </script>
        
   

<script>
		function submitForm() {
            console.log("submit event");
            var fd = new FormData(document.getElementById("fileinfo"));
            fd.append("label", "WEBUPLOAD");
            $.ajax({
              url: "uploads.php",
              type: "POST",
              data: fd,
              processData: false,  // tell jQuery not to process the data
              contentType: false   // tell jQuery not to set contentType
            }).done(function( data ) {
                alert(data);
                $('#result').html('<img alt="picture" style="width:100% ;height:200px">');
				$('#result img').attr('src',data);
				$('#img').val(data);
				document.getElementById("post").value +="<div class='clear'></div><img src='../"+data+"' class='postimg' alt=''style='clear:both' ><br>";
				//alert($('#img').val());
				
				
            });
            return false;
        }
		
		$('document').ready(function(){$('#statu_img_but').click(function(){$('#imageresult').load('status_image.php');});});   
			$('document').ready(function(){$('#statu_hd_but').click(function(){$('#results').load('status_input.php');});}); 
			function addHd(){
				var hd=document.getElementById("hd").value;
				if(hd==""){
					alert("Please Enter heading name");
					return false;
				}
				document.getElementById("post").value +="<h3>"+hd+"</h3>";
				document.getElementById("hd").value="";
			}

var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function(){
		
      var output = document.getElementById('outputpix');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  };	
  function closediv(id){
	  document.getElementById(id).innerHTML="";
	  
  }
		</script>













</body></html>