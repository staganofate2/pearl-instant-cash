<?php
if (isset($_POST["label"])) {
    $label = $_POST["label"];


 $fileName = $_FILES["file"]["name"];
 if($fileName==""){
	 echo "<b style='color:red'>please select a file</b>";
	 exit();
 }
 $fileTmpLoc = $_FILES["file"]["tmp_name"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    } else {
		$db_file_name =date("DMjGisY")."". rand(100000000000,999999999999).".".$extension;
		list($width, $height) = getimagesize($fileTmpLoc);
		
	$db_file_name="../blog/userphoto/$db_file_name";
	$moveResult = move_uploaded_file($fileTmpLoc,$db_file_name );
	if ($moveResult != true) {
		echo" File upload failed";
	return false;
	}
	include_once("../image_resize.php");
	$target_file = $db_file_name;
	$resized_file = $db_file_name;
	$wmax = 400;
	$hmax = 200;
	img_resize($target_file, $resized_file, $wmax, $hmax, $extension);
	
		
		
			echo $db_file_name;
        }
    }
 else {
    echo "Invalid file";
}
exit();
}