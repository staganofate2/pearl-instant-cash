<script>
$('#statusBtn').mousedown(function(){$.post('status_system.php',{"action":"image","img":$('#fimg').val()});});
</script>
<button onclick="closediv('imageresult')" style='color:red'>Close</button>
<div id="result" style="border: solid;width:98%;height:200px"></div>
<form method="post" id="fileinfo" name="fileinfo" >
        <label>Select a file:</label><br>
        <input type="file" name="file" required />
        <input type="button" value="Upload" onclick="submitForm()"/>
    </form>

<form action="<?php $_SERVER['PHP_SELF']?>" method="post" >

<!--<input type="hidden" name="img" id="fimg">-->

    