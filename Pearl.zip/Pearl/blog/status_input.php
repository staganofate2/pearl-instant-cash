
<button onclick="closediv('results')" style='color:red'>Close</button>
<form method="post" id="fileinfo2" name="fileinfo2" >
        <label>Enter Heading:</label><br>
        <input type="text" name="hd" id="hd" required />
        <input type="button" value="Add" onclick="addHd()"/>
    </form>



    