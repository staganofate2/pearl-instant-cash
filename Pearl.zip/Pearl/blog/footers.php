<!--footer-->

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5c054521fd65052a5c938c24/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


<div class="agile-footer w3ls-section" style="background-color:black;">
	<div class="container" >
		<div class="col-md-10 list-footer">
		  <ul class="footer-nav">
				<li><a href='../../about.php'>About Us</a></li>
				<li><a href='../../contact.php'>Contact Us</a></li>
				<li><a href='../../faq.php'>F.A.Q</a></li>
				<li><a href='../../services.php'>Our Services</a></li>
				<li><a href='../../terms.php'>Terms & Conditions</a></li>
				
		  </ul>
		  	</div>
		
		<script language="JavaScript" type="text/javascript">
TrustLogo("https://www.pearlinstantcash.com/images/comodo_secure_seal_100x85_transp.png", "CL1", "none");
</script>
<!--a  href="https://ssl.comodo.com" id="comodoTL">Comodo SSL</a>
     </div>
</div>	 




<div class="w3_agile-copyright text-center">
		<p>© <?php echo date("Y") ?> E-Wallet. All rights reserved | Design by PEARL</p>
	</div>
	</div>
<!--//footer-->	

	
	
	<!-- //modal-sign -->    
	<!-- //banner -->
		<!-- //banner-text -->  
	<!-- //banner -->
	<!-- banner Slider starts Here -->
	
	
	<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
} 

function sendit(){
	var hr = new XMLHttpRequest();
	var url = "../message2.php";
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;
	if(name==""){
		alert("name should not be empty");
		return;
	}
	if(email==""){
		alert("Email should not be empty");
		return;
	}
	if(phone==""){
		alert("Phone should not be empty");
		return;
	}
	var mes = document.getElementById("mes").value;
	if(mes==""){
		alert("Message should not be empty");
		return;
	}
	var id = document.getElementById("id").value;
	var vars = "name="+name+"&mes="+mes+"&id="+id+"&email="+email+"&phone="+phone;
	hr.open("POST",url,true);
	hr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	hr.onreadystatechange = function(){
		if(hr.readyState == 4 && hr.status == 200){
			var return_data = hr.responseText;
		//alert(return_data);
				if(return_data != "message_sent"){
					document.getElementById('result').innerHTML="error sending message";
					
				}else{
				document.getElementById("mes").value="";
				document.getElementById("phone").value="";
				document.getElementById("email").value="";
				document.getElementById("name").value="";
					document.getElementById("result").innerHTML=" Comment sent";
					
			}
		}
	}
	hr.send(vars);	
}
</script>
	<script src="../../js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="../../js/move-top.js"></script>
	<script type="text/javascript" src="../../js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  

	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../js/bootstrap.js"></script>

</body>
</html>