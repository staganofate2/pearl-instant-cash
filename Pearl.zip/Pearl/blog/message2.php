<?php
$name=$_POST['name'];
$message=$_POST['mes'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$id=$_POST['id'];
include('../connect.php');

$query="insert into blogcomment (name,blog_id,post,phone,email,postdate)values (\"$name\",\"$id\",\"$message\",\"$phone\",\"$email\",NOW()) ";
$result=mysqli_query($con,$query) or die(mysqli_error($con));
if($result>0){
echo"message_sent";
exit();
}
else{
echo "message not sent";
}

?>
