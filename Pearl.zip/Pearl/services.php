<?php
$bar="services";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>OUR SERVICES<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-10"> 
<h3>WALLET</h3>
<p>The institution’s wallet is liken to a saving account that must be funded before performing any transaction on the platform, your personal wallet must be funded to enable you perform transaction like paying of thrift savings, pearl treasure investment, paying for food stuff, paying of bills, buying of recharge card, bank transfer etc. immediately any payment is made, it immediately deducts from the funded wallet and your wallet balance will be shown immediately, any time the packaged you subscribed is matured  is your duty to send the money back to the wallet and make a withdrawal through wallet withdrawal, 
Any money on the wallet that has not being used for any transaction can be withdrawn through your wallet withdrawal, the money will be sent to your bank account you imputed while signing up instantly after the institution confirmation..</p>

<h3>OTHER SERVICES </h3>
<ol><li>	Paying of bills example GOTV, DSTV,STARTIMES,MYTV, DSTV DOX OFFICE INFINIT TV,MONTAGE CABLE TV,TREND TV, ACTV, PLATINUM PLUS TV. ETC</li>
<li>	Buying of recharge card example 9MOBILE, AIRTEL, GLO, MTN, SMILE , AIRTEL POSTPAID PAYMENT, MTN VTU PREPAID ETC</li>
<li>	Bank transfer example All commercial banks, all micro finance banks, all known institutions in NIG.</li></ol>

<h3>MODE OF PAYMENT</h3>
The members wallet can be funded through this following means
<ol><li>	ATM ONLINE PAYMENT ( Automated update)</li>
<li>	Online Bank deposit  ( Automated update)</li>
<li>App  or ATM  transfer, USSD (5-15 Minuets before approval)</li>
<li>	Cash bank deposit(5-15 Minuets before confirmation) </li></ol>



			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	
<?php
include"footer.php";
?>