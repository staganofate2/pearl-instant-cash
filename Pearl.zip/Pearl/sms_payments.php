<?php
$bar="product";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>Send SMS<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				<center><h4 class="h3-w3l"> Send SMS  Instantly</h4> 
				<img src='images/sms.jpg' width="60%" height="100px" alt='tv subscription image'>
				<p>Just a few steps ahead, your SMS is Delivered </p></center><br>
				<div class="col-md-2 "> 
				</div>
				<div class="col-md-8 "> 
			<h3>ONLINE Bulk SMS Sending</h3>
<h2 style='color:green' id='resul'></h2>
	<?php
      if (isset($_POST['login'])){
								
								
								
								$firstname = mysqli_real_escape_string($con,$_POST['firstname']);
								$lastname = mysqli_real_escape_string($con,$_POST['lastname']);
								$email = mysqli_real_escape_string($con,$_POST['email']);
									
								$sender=mysqli_real_escape_string($con,$_POST['sender']);
				 $phone=mysqli_real_escape_string($con,$_POST['phone']);
				 $message=mysqli_real_escape_string($con,$_POST['message']);
				 if($sender==strtolower("pearl")){
					 echo "<h3 style='color:red'>You can not use pearl as sender id</h3><a href='sms.php'>Try Again</a> ";
				 }else{
				if(strlen($phone)==(strrpos($phone,",")+1)){
	 $phone=substr_replace($phone,"",-1);
				}
 $message_count=strlen($message);
$message_num=ceil(($message_count/160));
				$x=explode(",",$phone);
				$num=count($x);
				
			  
								 $amount="3.50";
								 $amount=$amount*$num*$message_num;
								$ref =rand(100000000000,999999999999);
						$query="insert into smstwo (phone,sender,amount,quantity,message,regdate,ref_no) values('$phone','$sender','$amount','$message_num','$message',now(),'$ref')";
			   $resultt=mysqli_query($con,$query) or die(mysqli_error($con));
							 $id=mysqli_insert_id($con);
						
							 
								$query="insert into paystacktwo(types,types_id,firstname,lastname,email,ref_no,amount,regdate)values('SMS','$id','$firstname','$lastname','$email','$ref','$amount',now())";
	mysqli_query($con,$query)or die(mysqli_error($con));
	if(preg_match("/\.+/",$amount)){
	$amounts=str_replace(".","",$amount);
					$amounts=$amounts."0";
	}else{
		$amounts=$amount."00";
	}		
				?>
				<center><h4 class="h3-w3l">Thank You</h4> 
				<p><b>Reference NO:  <?php echo $ref ?></b><br>
				Amount : N<?php echo $amount ?></p>
				
				
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <button type="button" onclick="payWithPaystack()" class='btn btn-info'> Pay Now </button> 
  <span id='res'></span>
</center><br>
 
<script>
var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_live_16df2e712659089017f02d153204cd5fa3c5afff',
      email: '<?php echo $email ?>',
      amount: '<?php echo $amounts ?>',
      ref: '<?php echo $ref ?>', // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      firstname: '<?php echo $firstname ?>',
      lastname: '<?php echo $lastname ?>',
      // label: "Optional string that replaces customer email"
	 
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "<?php echo $phone ?>"
            }
         ]
      },
      callback: function(response){
		  
		
         displaypay(response.reference);
		  
		 //alert('success. transaction ref is ' + response.reference);
		  
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
  function displaypay(response){
	   //alert('success. transaction ref is iu iu ' + response);
	   var ajax;
if (window.XMLHttpRequest) {
ajax = new XMLHttpRequest();
} else if (window.ActiveXObject) {
ajax = new ActiveXObject("Microsoft.XMLHTTP");
}
 
	
	
	document.getElementById("res").innerHTML = 'please wait ...';
	 ajax.open("POST", "updatesmspay.php",true);
	 ajax.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	ajax.onreadystatechange = function() {
		if(ajax.readyState==4 && ajax.status==200) {
//alert(ajax.responseText);
			
		if(ajax.responseText="done"){
		document.getElementById("res").innerHTML = '';
		document.getElementById("resul").innerHTML = 'Your SMS Sending was Successful';
			 
			}else{
				alert(ajax.responseText);
				document.getElementById("res").innerHTML = '';
				document.getElementById("resul").innerHTML = '';
				
			}	
			 
			
			
		}
	}
	ajax.send("ref="+response);
 
 
  }
</script>
  

<?php				
										
										
										
				}
	  }

								
?>
					
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	 
<?php
include"footer.php";
?>