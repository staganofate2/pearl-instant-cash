
create database bankgbo;
use bankgbo;

CREATE TABLE IF NOT EXISTS adminpanel (
id int(11) NOT NULL auto_increment primary key,
  username varchar(200) NOT NULL,
  password varchar(200) NOT NULL,
  role varchar(200) not null,
  remove enum('0','1') default '0',
  privilege varchar(20) not null
) ;
insert into adminpanel (username,password) values('admin','admin');


create table conversation(conversation_id bigint not null auto_increment,
userone varchar(100) not null,
usertwo varchar(100) not null,
contype varchar(50) not null,primary key(conversation_id));

create table message(message_id bigint not null auto_increment,
sender varchar(100) not null,
conversation_id varchar(100) not null,
image varchar(100) not null,
message text not null,
mdate datetime not null,
red enum('0','1') default '0',
primary key(message_id));

create table wallet(wallet_id bigint not null primary key auto_increment,
account_no varchar(20) not null,
total double not null,
category varchar(20) not null default 'Basic',
active enum('0','1') default '0'
);

create table send_message(send_message_id bigint not null primary key auto_increment,
subject varchar(100) not null,
phone varchar(20) not null,
target varchar(20) not null,
message text not null,
confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  rejected ENUM('0','1') NOT NULL DEFAULT '0',
  authorize_date datetime not null,
date_sent date not null,
confirm enum('0','1') default '0',
authorize enum('0','1') default '0');

create table send_email(send_email_id bigint not null primary key auto_increment,
subject varchar(100) not null,
email varchar(100) not null,
target varchar(20) not null,
message text not null,
rejected ENUM('0','1') NOT NULL DEFAULT '0',
confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
date_sent datetime not null,
confirm enum('0','1') default '0',
authorize enum('0','1') default '0');
create table site_message(site_message_id bigint not null auto_increment,
name varchar(100) not null,
email varchar(100) not null,
phone varchar(100) not null,
subject varchar(100) not null,
via varchar(10) not null,
message text not null,
reply text not null,
date_sent datetime not null,
red enum('0','1') default '0',
confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  date not null,
  authorize_date datetime not null,
date_reply date not null,
confirm enum('0','1') default '0',
authorize enum('0','1') default '0',
primary key(site_message_id));

CREATE TABLE IF NOT EXISTS notification (
id bigint(11) NOT NULL primary key auto_increment,
 account_no varchar(20) NOT NULL,
 red enum('0','1') default '0',
  purpose varchar(200) NOT NULL,
  message text NOT NULL,
  confirm ENUM('0','1') NOT NULL DEFAULT '0',
  postdate datetime NOT NULL
) ENGINE=InnoDB ;

CREATE TABLE IF NOT EXISTS registeruser (
  account_number varchar(20) NOT NULL,
  registeruser_id bigint NOT NULL auto_increment primary key ,
  firstname varchar(250) NOT NULL,
  middlename varchar(100) NOT NULL,
  lastname varchar(250) NOT NULL,
  title varchar(50) NOT NULL,
  password varchar(200) NOT NULL,
  email_address varchar(300) NOT NULL,
  conf_email enum('0','1') default '0' not null,
  phone varchar(20) NOT NULL,
  conf_phone ENUM('0','1') NOT NULL DEFAULT '0',
  alt_phone varchar(20) not null,
  dob varchar(20) NOT NULL,
  gender varchar(20) NOT NULL,
  status varchar(20) not null,
  qualification varchar(50) NOT NULL,
  institution varchar(50) NOT NULL,
  department varchar(50) NOT NULL,
  faculty varchar(50) NOT NULL,
  levels varchar(50) NOT NULL,
  address varchar(255) not null,
  office_address varchar(255) not null,
  city_res varchar(50) NOT NULL,
  state_res varchar(50) NOT NULL,
  bustop varchar(200) not null,
  lga varchar(50) not null,
  state_origin varchar(20) not null,
  id varchar(50) NOT NULL,
  id_no varchar(50) NOT NULL,
  issue_date varchar(20) NOT NULL,
  exp_date varchar(20) NOT NULL,
  id_image varchar(50) not null,
  kin_title varchar(5) NOT NULL,
  kin_name varchar(50) NOT NULL,
  kin_address varchar(250) NOT NULL,
  kin_phone varchar(20) NOT NULL,
  kin_relationship varchar(50) NOT NULL,
  kin_state varchar(50) NOT NULL,
  accountpin varchar(5) NOT NULL,
  picture varchar(50) NOT NULL,
  pin varchar(200) NOT NULL,
  passport varchar(50) NOT NULL,
  ban_reason text NOT NULL,
  signnature varchar(50) NOT NULL,
  certificate varchar(50) NOT NULL,
  regdate datetime not null,
  login datetime not null,
  banned ENUM('0','1') NOT NULL DEFAULT '0',
  activated ENUM('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB ;
create table em_confirm(id bigint not null auto_increment primary key,
code varchar(12) not null,
account_no varchar(20) not null,
email varchar(200) not null,
confirm ENUM('0','1') NOT NULL DEFAULT '0',
regdate datetime not null
 );
 create table ph_confirm(id bigint not null auto_increment primary key,
code varchar(12) not null,
account_no varchar(20) not null,
phone varchar(12) not null,
confirmed ENUM('0','1') NOT NULL DEFAULT '0',
regdate datetime not null
 );

 create table paystack(id bigint not null auto_increment primary key,
account_no varchar(20) not null,
 amount double not null default '0',
 deposit_id bigint not null,
ref_no varchar(12) not null,
confirmed ENUM('0','1') NOT NULL DEFAULT '0',
regdate datetime not null
 );
 create table paystacktwo(paystacktwo_id bigint not null auto_increment primary key,
firstname varchar(200) not null,
lastname varchar(200) not null,
email varchar(200) not null,
types varchar(20) not null,
types_id bigint not null,
 amount double not null default '0',
ref_no varchar(12) not null,
confirmed ENUM('0','1') NOT NULL DEFAULT '0',
regdate datetime not null
 );

create table account_number(id bigint not null auto_increment primary key,
account_no varchar(12) not null,
assigned ENUM('0','1') NOT NULL DEFAULT '0',
regdate datetime not null );

 create table account(account_id bigint not null primary key auto_increment,
 account_name varchar(20) not null,
 account_no varchar(12) not null,
 account_type varchar(20) not null,
 maturity_month varchar(15) not null,
 maturity_date date not null,
 start_date date not null,
 payment_structure varchar(50) not null,
 duration varchar(20) not null,
 amount double not null,
 wallet double not null,
 interests double not null,
 interest double not null,
 account_interest varchar(10) not null,
 paid ENUM('0','1') NOT NULL DEFAULT '0',
 active ENUM('0','1') NOT NULL DEFAULT '0',
  regdate datetime not null
 );
 create table account_pay(account_pay_id bigint not null primary key auto_increment,
 account_id bigint not null,
 account_no varchar(20) not null,
 pay_date  datetime not null,
 paid_date datetime not null,
 amount double not null,
 paid ENUM('0','1') NOT NULL DEFAULT '0'
  );
 create table food(food_id bigint not null primary key auto_increment,
 package_name varchar(20) not null,
 account_no varchar(12) not null,
 maturity_date date not null,
 start_date date not null,
 distribute_date date not null,
 payment_structure varchar(50) not null,
 duration varchar(20) not null,
 amount double not null default '0',
 wallet double not null,
 total double not null default '0',
 due_amount double not null,
 items varchar(255) not null,
 delivery ENUM('0','1') NOT NULL DEFAULT '0',
 paid ENUM('0','1') NOT NULL DEFAULT '0',
 active ENUM('0','1') NOT NULL DEFAULT '0',
  regdate datetime not null
 );
 create table food_pay(food_pay_id bigint not null primary key auto_increment,
 food_id bigint not null,
 account_no varchar(20) not null,
 pay_date  datetime not null,
 paid_date datetime not null,
 amount double not null,
 paid ENUM('0','1') NOT NULL DEFAULT '0'
  );
  create table delivery(delivery_id bigint not null primary key auto_increment,
 food_id bigint not null,
 name varchar(255) not null,
 phone varchar(20) not null,
 account_no varchar(20) not null,
 address  varchar(255) not null,
 delivery_date date not null,
 states varchar(100) not null,
 lga varchar(100) not null,
 done ENUM('0','1') NOT NULL DEFAULT '0'
  );
 
 create table loan(loan_id bigint not null primary key auto_increment,
 account_no varchar(20) not null,
 confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
 emp_status varchar(20) not null,
 emp_sector varchar(15) not null,
 business_name varchar(250) not null,
 business_address varchar(250) not null,
 biz_status varchar(50) not null,
 rc_no varchar(20) not null,
 monthly_profit varchar(50) not null,
 dialy_turnover varchar(50) not null,
 biz_start varchar(20) not null,
 biz_email varchar(50) not null,
  ref_no varchar(10) NOT NULL,
  wallet double not null,
   start_date date not null,
   repay_date date not null,
 biz_phone varchar(20) not null,
 tax_no varchar(50) not null,
 pension varchar(20) not null,
 interest_rate varchar(10) not null,
 repayment_plan varchar(20) not null,
 loan_duration varchar(50) not null,
 occupation varchar(200) not null,
 stage varchar(20) not null,
 category varchar(20) not null,
 req_amount double not null,
 amount double not null,
 total double not null,
 deposit double not null,
 repayment_plan_amount varchar(20) not null,
 reason_for_loan varchar(255) not null,
 interest double not null,
 confirmation varchar(50) not null,
 autorization varchar(50) not null,
 find varchar(250) not null,
 paid ENUM('0','1') NOT NULL DEFAULT '0',
 approved ENUM('0','1') NOT NULL DEFAULT '0',
 active ENUM('0','1') NOT NULL DEFAULT '0',
  collected ENUM('0','1') NOT NULL DEFAULT '0',
 confirm ENUM('0','1') NOT NULL DEFAULT '0',
  authorize ENUM('0','1') NOT NULL DEFAULT '0',
  reason text not null,
  rejected ENUM('0','1') NOT NULL DEFAULT '0',
 regdate datetime not null
 );
 
 create table loan_repay(loan_repay_id bigint not null primary key auto_increment,
 loan_id bigint not null,
 account_no varchar(20) not null,
 pay_date  datetime not null,
 paid_date datetime not null,
 amount double not null,
 paid ENUM('0','1') NOT NULL DEFAULT '0'
  );
 create table investment(investment_id bigint not null primary key auto_increment,
 invest_name varchar(200) not null,
 account_no varchar(12) not null,
  maturity_date date not null,
 duration varchar(20) not null,
 ref_no varchar(20) not null,
 amount double not null,
 wallet double not null,
 interest double not null,
  interests double not null,
 start_date date not null,
 interest_rate varchar(50) not null,
 mont_interest_witdra double not null,
 total_duration_interest double not null,
 invest_date date not null,
 active ENUM('0','1') NOT NULL DEFAULT '0',
 paid ENUM('0','1') NOT NULL DEFAULT '0',
 regdate datetime not null
 );
 create table bank_info(bank_info_id bigint not null primary key auto_increment,
 account_name varchar(200) not null,
 account_no varchar(20) not null,
 confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
 bank_name varchar(50) not null,
 account_number varchar(12) not null,
 branch_state varchar(50) not null,
 branch_road varchar(50) not null,
 bvn varchar(20) not null,
  confirm ENUM('0','1') NOT NULL DEFAULT '0',
  authorize ENUM('0','1') NOT NULL DEFAULT '0',
 regdate datetime not null
 );
 create table transfer(transfer_id bigint not null primary key auto_increment,
 account_name varchar(200) not null,
 account_no varchar(20) not null,
 sender varchar(50) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 bank_name varchar(50) not null,
 account_number varchar(12) not null,
 amount double not null,
 commission double not null,
  
   status ENUM('0','1') NOT NULL DEFAULT '0',
 
 regdate datetime not null
 );
 create table bill(bill_id bigint not null primary key auto_increment,
 account_no varchar(20) not null,
 sender varchar(50) not null,
  ref_no varchar(20) not null,
  sent_date  datetime not null,
  invoice varchar(50) not null,
   cnumber varchar(50) not null,
    name varchar(250) not null,
 types varchar(50) not null,
 variation varchar(20) not null,
 phone varchar(16) not null,
 numbers varchar(12) not null,
 amount double not null,
 total double not null,
 commission double not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
  rejected ENUM('0','1') NOT NULL DEFAULT '0',
 
 regdate datetime not null
 );
 create table billtwo(billtwo_id bigint not null primary key auto_increment,
 sender varchar(50) not null,
  ref_no varchar(20) not null,
  sent_date  datetime not null,
 types varchar(50) not null,
  invoice varchar(50) not null,
   cnumber varchar(50) not null,
    name varchar(250) not null,
 variation varchar(20) not null,
 phone varchar(16) not null,
 numbers varchar(12) not null,
 amount double not null,
 total double not null,
 commission double not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
  rejected ENUM('0','1') NOT NULL DEFAULT '0',
 
 regdate datetime not null
 );
 create table recharge(recharge_id bigint not null primary key auto_increment,
 network varchar(200) not null,
 account_no varchar(20) not null,
 sender varchar(50) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 phone varchar(20) not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
 amount double not null,

 regdate datetime not null
 );
 
 create table rechargetwo(rechargetwo_id bigint not null primary key auto_increment,
 network varchar(200) not null,
 sender varchar(50) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 phone varchar(20) not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
 amount double not null,

 regdate datetime not null
 );
 create table datas(datas_id bigint not null primary key auto_increment,
 network varchar(200) not null,
 account_no varchar(20) not null,
 sender varchar(50) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 phone varchar(20) not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
 amount double not null,

 regdate datetime not null
 );
 create table datastwo(datastwo_id bigint not null primary key auto_increment,
 network varchar(200) not null,
 sender varchar(50) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 phone varchar(20) not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
 amount double not null,

 regdate datetime not null
 );
 create table sms(sms_id bigint not null primary key auto_increment,
 sender varchar(200) not null,
 account_no varchar(20) not null,
 quantity varchar(20) not null,
 message varchar(250) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 phone text not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
 amount double not null,

 regdate datetime not null
 );
 
 create table smstwo(smstwo_id bigint not null primary key auto_increment,
 sender varchar(200) not null,
 quantity varchar(20) not null,
 message varchar(250) not null,
 total double not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  sent_date  datetime not null,
  ref_no varchar(20) not null,
 phone text not null,
  status ENUM('0','1') NOT NULL DEFAULT '0',
 amount double not null,

 regdate datetime not null
 );
 create table deposit(deposit_id bigint not null primary key auto_increment,
 account_no varchar(20) not null,
confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
 ref_no varchar(20) not null,
 total double not null,
 bonus double not null,
 amount_word varchar(250) not null,
 amount double not null,
 method varchar(50) not null,
  depositor_name varchar(50) not null,
 category varchar(12) not null,
 upload  varchar(50) not null,
 phone varchar(50) not null,
 admin varchar(50) not null default'',
 pay_structure varchar(50) not null,
 payment_date varchar(10) not null,
 bank varchar(50) not null,
  confirmed ENUM('0','1') NOT NULL DEFAULT '0',
  transfer varchar(20) not null,
   rejected ENUM('0','1') NOT NULL DEFAULT '0',
  confirm ENUM('0','1') NOT NULL DEFAULT '0',
  authorize ENUM('0','1') NOT NULL DEFAULT '0',
  regdate datetime not null
 );
 
 
  create table withdraw(withdraw_id bigint not null primary key auto_increment,
 account_no varchar(20) not null,
 confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
 amount double not null,
 total double not null,
 ref_no varchar(20) not null,
  rejected ENUM('0','1') NOT NULL DEFAULT '0',
 method varchar(50) not null,
 confirm ENUM('0','1') NOT NULL DEFAULT '0',
  authorize ENUM('0','1') NOT NULL DEFAULT '0',
  regdate datetime not null
 );
 

CREATE TABLE IF NOT EXISTS account_transact (
transact_id bigint NOT NULL primary key auto_increment,
account_id bigint NOT NULL ,
  transaction_date datetime not null,
  refno varchar(50) NOT NULL,
  description text NOT NULL,
  debit double NOT NULL,
  credit double NOT NULL,
  packages varchar(50) NOT NULL,
  account_no varchar(20) NOT NULL,
  remark varchar(200) NOT NULL,
  balance varchar(20) NOT NULL
) ENGINE=InnoDB ;

CREATE TABLE IF NOT EXISTS loan_transact (
transact_id bigint NOT NULL primary key auto_increment,
loan_id bigint NOT NULL ,
  transaction_date datetime not null,
  refno varchar(50) NOT NULL,
  description text NOT NULL,
  debit double NOT NULL,
  credit double NOT NULL,
  packages varchar(50) NOT NULL,
  account_no varchar(20) NOT NULL,
  remark varchar(200) NOT NULL,
  balance varchar(20) NOT NULL
) ENGINE=InnoDB ;
CREATE TABLE IF NOT EXISTS food_transact (
transact_id bigint NOT NULL primary key auto_increment,
food_id bigint NOT NULL ,
  transaction_date datetime not null,
  refno varchar(50) NOT NULL,
  description text NOT NULL,
  debit double NOT NULL,
  credit double NOT NULL,
  packages varchar(50) NOT NULL,
  account_no varchar(20) NOT NULL,
  remark varchar(200) NOT NULL,
  balance varchar(20) NOT NULL
) ENGINE=InnoDB ;
CREATE TABLE IF NOT EXISTS investment_transact (
transact_id bigint NOT NULL primary key auto_increment,
investment_id bigint NOT NULL ,
  transaction_date datetime not null,
  refno varchar(50) NOT NULL,
  description text NOT NULL,
  debit double NOT NULL,
  credit double NOT NULL,
  packages varchar(50) NOT NULL,
  account_no varchar(20) NOT NULL,
  remark varchar(200) NOT NULL,
  balance varchar(20) NOT NULL
) ENGINE=InnoDB ;
CREATE TABLE IF NOT EXISTS wallet_transact (
transact_id bigint NOT NULL primary key auto_increment,
packages_id bigint NOT NULL ,
  transaction_date datetime not null,
  refno varchar(50) NOT NULL,
  description text NOT NULL,
  debit double NOT NULL,
  credit double NOT NULL,
  packages varchar(50) NOT NULL,
  account_no varchar(20) NOT NULL,
  remark varchar(200) NOT NULL,
  balance varchar(20) NOT NULL
) ENGINE=InnoDB ;
create table refer(refer_id bigint not null auto_increment primary key,
account_no varchar(12) not null,
category varchar(12) not null,
link varchar(200) not null,
regdate datetime not null );

create table refer_user(refer_user_id bigint not null auto_increment primary key,
refer_id bigint not null,
account_no varchar(12) not null,
confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
ip varchar(20) not null,
signup ENUM('0','1') NOT NULL DEFAULT '0',
visit ENUM('0','1') NOT NULL DEFAULT '0',
transact ENUM('0','1') NOT NULL DEFAULT '0',
paid ENUM('0','1') NOT NULL DEFAULT '0',
confirm ENUM('0','1') NOT NULL DEFAULT '0',
 authorize ENUM('0','1') NOT NULL DEFAULT '0',
regdate datetime not null );


create table uploads(uploads_id bigint not null auto_increment primary key,
account_no varchar(12) not null,
purpose varchar(100) NOT NULL ,
image varchar(100) NOT NULL ,
regdate datetime not null );

create table standing(standing_id bigint not null auto_increment primary key,
types varchar(50) not null,
target varchar(50) not null,
confirm_user varchar(50) not null,
  authorize_user varchar(50) not null,
  confirm_date  datetime not null,
  authorize_date datetime not null,
subject varchar(100) NOT NULL ,
message text NOT NULL ,
status ENUM('0','1') NOT NULL DEFAULT '0',
account_no varchar(20) NOT NULL ,
viewed ENUM('0','1') NOT NULL DEFAULT '0',
confirm ENUM('0','1') NOT NULL DEFAULT '0',
 authorize ENUM('0','1') NOT NULL DEFAULT '0',
regdate date not null );



create table onlineusers(
onlineusers_id bigint not null auto_increment,
users varchar(100) not null,
ip varchar(20) not null,
active enum('0','1') default '0' not null,
logdate datetime not null,
primary key(onlineusers_id));


 create table blog (blog_id bigint not null auto_increment,
title varchar(250) not null,
page varchar(250) not null,
description varchar(250) not null,
post text not null,
image varchar(200) not null,
status ENUM('0','1') NOT NULL DEFAULT '0',
rejected ENUM('0','1') NOT NULL DEFAULT '0',
postdate date not null,
primary key(blog_id));

create table blogcomment (blogcomment_id bigint not null auto_increment,
blog_id bigint not null,
name varchar(200) not null,
email varchar(200) not null,
phone varchar(20) not null,
post text not null,
status ENUM('0','1') NOT NULL DEFAULT '0',
reply ENUM('0','1') NOT NULL DEFAULT '0',
rejected ENUM('0','1') NOT NULL DEFAULT '0',
postdate date not null,
primary key(blogcomment_id));

create table reply (reply_id bigint not null auto_increment,
blogcomment bigint not null,
post text not null,
postdate date not null,
primary key(reply_id));

create table bvn(
bvn_id bigint not null auto_increment,
bvn varchar(20) not null,
first_name varchar(100) not null,
last_name varchar(100) not null,
dob varchar(10) not null,
phone varchar(20) not null,
postdate date not null,
primary key(bvn_id));

create table account_confirm(
account_confirm_id bigint not null auto_increment,
account_name varchar(100) not null,
account_number varchar(100) not null,
bank varchar(10) not null,
postdate date not null,
primary key(account_confirm_id));