<?php 

function query($c,$query){
	$result=mysqli_query($c,$query) or die(mysqli_query($c));
	return $result;
}
function numrow($query){
	$result=mysqli_num_rows($query);
	return $result;
}
function escape($c,$val){
	$result=mysqli_real_escape_string($c,$val);
	return $result;
}
function fetch($query){
	$result=mysqli_fetch_array($query);
	return $result;
}
function sanitize($data){
	trim($data);
	$result=htmlspecialchars($data);
	$result=strip_tags($data);
	$result=stripslashes($data);
	return $result;
}
function num($data){
		$result = preg_replace('#[^0-9]#', '',$data);
		return $result;
		
}
function char($data){
			$result = preg_replace('#[^a-zA-Z]#', '',$data);
		return $result;
}
function numchar($data){
			$result = preg_replace('#[^a-zA-Z0-9]#', '',$data);
		return $result;
}
?>