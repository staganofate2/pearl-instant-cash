<?php
include"connect.php";
$query="select account_number,phone from registeruser where registeruser_id >'1000' and registeruser_id<'1386'";
$e=mysqli_query($con,$query) or die(mysqli_error($con));
while($x=mysqli_fetch_array($e)){
	$f=rand(100000,999999);
	$query="insert into ph_confirm(code,phone,account_no,regdate)values('$f','".$x['phone']."','".$x['account_number']."',now())";
	mysqli_query($con,$query) or die(mysqli_error($con));
}

?>