<?php
$bar="about";
include'header.php';
?>
	
	
	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l"><b>ABOUT PEARL<b></h3>
			
			
			<!-- about bottom-->
			<div class="about-bottom">
				
				<div class="col-md-10"> 
				<button class="accordion">PEARL</button>
					<div class="panel"><b style='font-size:20px;'>PEARL INSTANT CASH</b> is a brain child of "PEARL SOLUTION COOPERATIVE THRIFT AND CREDIT SOCIETY LTD " that is registered online to extend their indoor services to its members who are not around the place of office location to equally benefit from the trending online services like online thrift, online loans and online investment , online recharge, online payment of bills and online bank transfer meanwhile by signing up on this program the individual is expected to abide by all laws an policy regulating the institution and he or she is seen as the company member.

<ul><li>Pearl solution assist in multiplying your initial capital.</li>
<li>Provide you with additional interest depending on the package interested.</li>
<li>	Helping your business by means of soft loan to boost local production and business.</li>
<li>	Taking our members first in our priority.</li>
<li>	Setting a standard to be emulated.</li> 
<li>	We run online membership.</li></ul></div>	
<button class="accordion">OUR MISSION</button>
<div class="panel">To permeate the nooks and crannies of the financial environment, touching live, creating wealth and empowering the masses.</div>
<button class="accordion">OUR VISION</button>
<div class="panel">Our vision is to render efficient sound and high quality financial services to our esteemed members and to provide soft loans to boast local production. 
Our Core Values
<b>Professionalism:</b> we engaged professional in managing the day to day activities of our institution and over the year it has yielded exciting results.  
Integrity: our business is built on trust, and we are committed in ensuring that our members sanctification  becomes our priority.
<b>Empathy:</b> we are committed to serve, that is the reason while our resounding mission  is OUR MEMBERS, OUR PRIDE…  we are efficient, dedicated in serves delivery. 
Excellence: we have being known as number one in dedication to assigned duties.  
<h4> BENEFITS OF PEARL SOLUTION COOPERATIVE THRIFT AND CREDIT SOCIETY LTD  </h4>
<ul>
<li>	We assist in enlightenment to the public to cultivate the habit of saving.</li>
<li>	Harnessing creativity among members with the same ideology.</li>
<li>	 Providing soft loan to her members.</li>
<li>	Reducing the rate of unemployment.</li>
<li>	Using their pos channels to reduce congestion experienced in our ATM in banks.</li>
<li>	Rendering assistance to her members through skills acquisition.</li>
<li>	 Providing for the charity. etc</li></ul></div>	

<button class="accordion">OUR TEAM</button>
<div class="panel"><h4>THE BOARD/MANAGEMENT TEAM</h4>
The board members are characterized with devoted personality with wealth of experience in different field of endeavored selected to pilot the affairs of PEARL SOLUTION COOPERATIVE THRIFT AND CREDIT SOCIETY LTD .  The institution is poised to serving their members because they believe that their members are their pride.

<h5>1.	NNADI VINCENT:  CHAIRMAN</h5>
            <p>A professional fund manager with over fifteen year wealth of experience in the field, holds a bachelor degree in accounting, has being involved in several management position ranging from the accountant of osozone resource a production company based in aba , B pl micro finance ltd based in abia state , because of his quest for improvement, he has undergone training on marketing management, operational management, human resources management, personal productivity, risk management. He is married with children. </p>


<h5>2.	OTUECHERE IVY: SECRETARY<h5>  
           <p> A Bachelor Degree in computer science. Former staff of  KP Technology as IT officer. With wealth of experience in cooperative principle and practice. She is Married with children  </p>

<h5>3.	UCHENDU JOSEPHINE: TREASURER:</h5>
            <p>A professional in management of fund, has a wild range of experience in cooperative principle and practice. She is married with children  </p>

<h5>4.	EMEKA MORGAN: SCRUTINIZER </h5>
            <p>Electrical electronics Engineer from the Federal technology FUTO. The CEO of crystal concept allied and agro services, Awka, Anambra State as Head of Engineering & Maintenance. Has also held management position in other engineering company. He is married with children. </p>
</div>	
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	</div>
<?php
include"footer.php";
?>