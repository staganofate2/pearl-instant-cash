<?php
include "connect.php";
include"function.php";
$id= sanitize($con,$_POST["id"]) ;
$id=escape($con,$id);
  $result = mysqli_query($con,"SELECT count(*) FROM registeruser WHERE email_address='$id'");
  if(mysqli_num_rows($result)>0){
	  echo "exist"
  }
?>