<?php
include 'connect.php';
$bar="index";
include"header.php";
?>

	
	<!-- contact -->
	<div class="w3ls-section contact">
		<div class="container"> 
			 
			
			
						<div class="contact_wthreerow agileits-w3layouts">
				<div class="col-md-5 agileits_w3layouts_contact_gridl">
					
					<div class="agileits_mail_grid_right_grid">
						<h4>PEARL</h4>
						<ul class="contact_info">
						<!--------------bank address-------------->
							
							<li><!--<i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i> 
							 <span></span>91 Tetlow Road, Ist Floor Owerri, Imo State--></li>
						
							<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@pearlinstantcash.com">info@pearlinstantcash.com</a></li>
							<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+234 816 629 1593 </li>
							<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+234 901 105 0718  </li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-7 w3l_contact_form">
					<h4>LEAVE A COMMENT</h4><br>
					<style>
					form{border:solid 2px gray;
					padding:50px}
					</style>
					<form action="" method="post">
					<div><b>YOUR NAME:</b></div> 
					<div style="font-family:Chaparral Pro Light"><b>Please enter your full name</b></div><br>
						<input type="text" name="Name" placeholder="e.g Mr Micheal Kim" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required=""><br><br><br>
						
					<div><b>YOUR EMAIL:</b></div> 
					<div style="font-family:Chaparral Pro Light"><b>Please enter your email address</b></div>	
						<input type="email" name="Email" placeholder="example@domain.com" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required=""><br><br><br>
					<div><b>YOUR PHONE NUMBER:</b></div> 
					<div style="font-family:Chaparral Pro Light"><b>Please enter your Phone Number</b></div>	
						<input type="text" name="Phone" placeholder="080XXXXXXXX" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required=""><br><br><br>
					<div><b>YOUR MESSAGE:</b></div> 
					<div style="font-family:Chaparral Pro Light"><b>Please enter your question</b></div>	
						<textarea name="Message" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">Message...</textarea>
						<input type="submit" name="ok" value="Submit">
					</form>
					
					
					<?php
			 
				 if (isset($_POST['ok'])){

$name=$_POST['Name'];
$mess=$_POST['Message'];
$mail=$_POST['Email'];
$phone=$_POST['Phone'];

		$senddata2 = mysqli_query($con,"insert into site_message (name,email,phone,message,date_sent) values
	('".mysqli_real_escape_string($con,$name)."','".mysqli_real_escape_string($con,$mail)."','".mysqli_real_escape_string($con,$phone)."','".mysqli_real_escape_string($con,$mess)."',
	now())")or die(mysqli_error($con)); 
	
	if(@$senddata2){
		
	echo"<script>alert('$name, your message has been sent..do wait for our reply')</script>";
}

else{
echo"<script>alert('An error occured,please try again..')</script>";	
}
	
}
	?>
					
					
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //contact --> 
	
	<?php include'footer.php';
	?>